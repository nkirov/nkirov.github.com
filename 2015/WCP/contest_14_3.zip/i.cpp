﻿/*
Adopted from Problem 2. COW, USACO 2015 February Contest, Bronze division
Analysis - http://www.usaco.org/current/data/sol_cow_bronze.html
*/

#include <iostream>
#include <string>
using namespace std;

int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	int t, N;
	cin >> t;
	while(t--)
	{
		string S;
		cin >> N >> S;

		long long NA = 0, NB = 0, NC = 0;
		for (int i = 0; i < N; i++) 
			if (S[i] == 'A') 
				NA++;
			else if (S[i] == 'B') 
				NB += NA;
			else if (S[i] == 'C') 
				NC += NB;
			
		cout << NC << endl;
	}
	
	return 0;
}