﻿/*
Adopted from https://www.hackerrank.com/challenges/similarpair

Overview of Problem
-------------------
Given a tree of n node and a number T find the number of pair (A,B) such that :
node A is the ancestor of node B abs(A - B) <= T

Approch
-------------
First we need to traverse the tree using DFS so we need the root node and obviously
the node which has no parent is the root node. Now as we traverse each node we will
store it in a data stucture to keep track of all the ancestor for the next node but
before that get the number of its own ancestors in the range [presentNode-T, PresentNode+T] 
and add it to the total pairs.

Data Structure
--------------
Now we need a data structure which can:

1. Insert a node as we travese the tree.
2. Remove a node as we return back.
3. Give number of nodes within the range [presentNode-T, PresentNode+T] which it have stored.

All of the above 3 operation needs to be done in log(N) time because N<=10^5 so we can take up 
our complexity to O(N log(N)). Binary Index Tree (BIT) is the a data structure which fulfills 
all of the above condition (There are other data structure like Segment Tree which can also be used).
We can do the above 3 operation by initialize all the index valve of BIT to 0 and then:

1. Insert a node by updating index of that node to 1
2. Remove a node by updating index of that node to 0
3. Get number of similar pair ancestor of that node by quary for sum of range in [presentNode-T, PresentNode+T]

If you are not familiar with BIT (http://community.topcoder.com/tc?module=Static&d1=tutorials&d2=binaryIndexedTrees) or
Segment Tree Tutorial (http://community.topcoder.com/tc?module=Static&d1=tutorials&d2=lowestCommonAncestor#Segment_Trees)

Use it to solve the problem in O(N log(N)). The DFS pseudo code will look like:
DFS(int node)
    similar_pair += bit_range_sum(max(1,node-t),min(n,node+t));
    bit_update(node,1);
    for(int i=0;i<al[node].size();i++)
        dfs(al[node][i]);
    bit_update(node,0);

*/

#define _CRT_SECURE_NO_WARNINGS 1
#pragma comment(linker, "/STACK:36777216")

#include <stdio.h>
#include <vector>
#include <algorithm>
#include <memory.h>
using namespace std;

#define MAXN 100005

int parent[MAXN];
vector <vector<int> > V;
int N, T;
long long ans = 0;

long tree[MAXN];

int sum (int r)
{
	int sum = 0;
	for (; r >= 0; r = (r & (r + 1)) - 1)
		sum += tree[r];
	return sum;
}

void update (int i, int delta)
{
	for (; i < N; i = (i | (i + 1)))
		tree[i] += delta;
}

int query(int start, int end)
{
	start--, end--;
    return sum (end) - sum (start - 1);
}

void dfs(int from)
{
	update(from - 1, 1);

	for (int i = 0; i < V[from].size(); i++)
	{
		int to = V[from][i]; 
		ans += query(max(0, to - T), min(T + to, N));
		dfs(to);
	}

	update(from - 1, -1);
}

int findRoot()
{
	for(int i = 1;i <= N;i++)
		if(!parent[i])
			return i;
}

int main()
{
	int t;
	scanf("%d", &t);

	while(t--)
	{
		scanf("%d%d", &N, &T);

		V = vector<vector<int> >(N + 1);
		memset(parent, 0, sizeof parent);
		memset(tree, 0, sizeof tree);
		ans = 0;

		int from, to;
		for(int i = 0;i < N - 1;i++)
		{
			scanf("%d%d", &from, &to);
			parent[to] = from;
			V[from].push_back(to);
		}

		int root = findRoot();
		dfs(root);

		printf("%lld\n", ans);
	}

	return 0;
}