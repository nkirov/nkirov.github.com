﻿/*
Adopted from Problem 1. Cow Routing, USACO 2015 January Contest, Bronze division
Analysis - http://www.usaco.org/current/data/sol_cowroute_bronze.html
*/

#include <iostream>
using namespace std;

#define INF (int)1e9

int main() 
{
	int t, A, B, N;
	cin.sync_with_stdio(0);
	cin.tie(0);

	cin>>t;
	
	while(t--)
	{
		cin >> A >> B >> N;
		int result = INF;
		for (int i = 0; i < N; i++) 
		{
			int cost, sz;
			cin >> cost >> sz;

			/* Loop over the route. */
			bool found = false;
			for (int j = 0; j < sz; j++) 
			{
				int city;
				cin >> city;
				if (city == A) 
				{
					/* Note that we've seen city A. */
					found = true;
				}

				if (found && city == B) 
				{
					/* If we visit city B after city A then this flight is usable. */
					result = min(result, cost);
				}
			}
		}

		/* Output the min cost ticket or report that no ticket is suitable. */
		if (result == INF) 
			cout << "-1\n";
		else 
			cout << result << '\n';
	}
	
	return 0;
}