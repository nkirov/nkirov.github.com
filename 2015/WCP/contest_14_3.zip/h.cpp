/*
Adopted from Problem 2. Cow Hopscotch, USACO 2015 February Contest, Silver division
Analysis - http://www.usaco.org/current/data/sol_hopscotch_silver.html
*/

#include <iostream>
#include <memory.h>
using namespace std;

#define MOD 1000000007
#define MAXN 100

int r, c, k, t;
int grid[MAXN][MAXN], dp[MAXN][MAXN];

int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	cin>>t;
	while(t--)
	{
		cin>>r>>c>>k;
		for(int i = 0; i < r; i++) 
			for(int j = 0; j < c; j++) 
				cin>>grid[i][j];
		
		memset(dp, 0, sizeof dp);

		dp[0][0] = 1;
		for(int i = 0; i < r; i++) 
			for(int j = 0; j < c; j++) 
				for(int k = i + 1; k < r; k++) 
					for(int l = j + 1; l < c; l++) 
						if(grid[i][j] != grid[k][l]) 
						{
							dp[k][l] += dp[i][j];
							dp[k][l] %= MOD;
						}

		cout<<dp[r - 1][c - 1]<<endl;
	}

	return 0;
}