﻿/*
Adopted from COCI 2013/2014 (http://hsin.hr/coci/), CONTEST #1, Task PROSJEK
Analysys from Goran Gašić:
Let be the sum of the first numbers in Sk k sequence A. It holds
	Bk = Sk/k
It follows
	Bk+1 = Sk+Ak+1/k+1
From here we get the expression for Ak+1
	Ak+1 = (k + 1) ∙ Bk+1 − Sk
We calculate elements of the sequence Ak+1 and their sum Sk iteratively by using one loop over sequence B.
*/

#include <iostream>
#include <sstream>
#include <string>
using namespace std;

string str;

void solve()
{
	long long b, sum = 0;

	istringstream instr(str);
	
	int k = 0;
	while(instr >> b)
	{
		int a = (k + 1) * b - sum;
		cout << (k > 0 ? " " : "") << a;
		sum += a;
		k++;
	}

	cout << "\n";
}

int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while (getline(cin, str))
		solve();
	
	return 0;
}
