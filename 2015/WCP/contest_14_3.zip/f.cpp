#include <iostream>
#include <string>
using namespace std;

int getPalIndex(string s, int sz)
{
	int idx = -1;
	for(int i = 0;i < sz / 2;i++)
		if(s[i] != s[sz - i - 1])
			return i;
	
	return -1;
}

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	string s;
	while(getline(cin, s))
	{
		int sz = s.size();
		int idx = getPalIndex(s, sz);
		if(idx != -1)
		{
			string snd = s.substr(0, idx) + s.substr(idx + 1, sz - 1);
			if(getPalIndex(snd, sz - 1) != -1)
				idx = s.size() - idx - 1;
		}
		
		cout<<idx<<endl;
	}

	return 0;
}