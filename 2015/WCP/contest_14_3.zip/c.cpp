﻿/*
Adopted from Problem 4. Meeting Time, USACO 2015 January Contest, Bronze division
Analysis - http://www.usaco.org/current/data/sol_meeting_bronze.html
*/

#include <iostream>
#include <memory.h>
#include <limits.h>
using namespace std;

int N, M, t;

int bessieGrid[16][16], elsieGrid[16][16];
bool bessieCan[20000], elsieCan[20000];
 
void dfs(int dist[][16], bool* can, int currV, int currD) 
{
    if(currV == N - 1) 
	{
		can[currD] = true;
		return;
    }

    for(int i = currV + 1; i < N; i++) 
		if(dist[currV][i] > 0) 
			dfs(dist, can, i, currD + dist[currV][i]);
}

int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	cin>>t;
	
	while(t--)
	{
		cin >> N >> M;
		
		memset(bessieCan, 0, sizeof bessieCan);
		memset(elsieCan, 0, sizeof elsieCan);
		memset(bessieGrid, 0, sizeof bessieGrid);
		memset(elsieGrid, 0, sizeof elsieGrid);

		for(int i = 0;i < M;i++)
		{
			int a, b, c, d;
			cin >> a >> b >> c >> d;
			a--, b--;

			bessieGrid[a][b] = c;
			elsieGrid[a][b] = d;
		}

		dfs(bessieGrid, bessieCan, 0, 0);
		dfs(elsieGrid, elsieCan, 0, 0);

		int best = INT_MAX;
		for(int i = 0; i < 20000; i++) 
		{
			if(bessieCan[i] && elsieCan[i]) 
			{
				best = i;
				break;
			}
		}

		if(best == INT_MAX)
			cout << "IMPOSSIBLE" << endl;
		else
			cout << best << endl;
	}
	
	return 0;
}