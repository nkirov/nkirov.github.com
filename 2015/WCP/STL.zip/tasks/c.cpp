﻿#include <iostream>
#include <queue>
#include <algorithm>
#include <string>
using namespace std;

struct Student
{
    int priority;
	string name;
	Student() { }
	Student(int priority, string name) 
	{
		this->priority = priority;
		this->name = name;
	}

    bool operator < (const Student& b) const
    {
		if(priority == b.priority)
			return name > b.name;

		return priority < b.priority;
    }
};

int main()
{
	int r, k, p, t; 
	string name;
	
	cin>>t;
	while(t--)
	{
		priority_queue<Student, vector<Student> > pq;
		bool flag = true;

		while(flag)
		{
			cin>>r;
			switch (r)
			{
				case 0: 
					flag = false;
					break;
			
				case 1: 
					cin>>p>>name;
					pq.push(Student(p, name));
					break;

				case 2: 
					if(!pq.empty())
					{
						Student top = pq.top();
						pq.pop();

						cout<<top.name<<" "<<top.priority<<endl;
					}
					else
						cout<<"empty"<<endl;

					break;          
			} 
		}      
	}
	
	return 0;   
}
 
