#include <algorithm>
#include <string>
#include <ctime>
using namespace std;

int main()
{
	clock_t beg = clock();

    while(!feof(stdin))
    {
        char code[55];
        scanf("%s\n", &code);
		int len = strlen(code);
		if(len == 0)
			continue;

        if(!next_permutation(code, code + len))
        {
             printf("Impossible!\n");
			 continue; 
        }

        printf("%s\n", code);
    }

	
	printf("*** time: %.3lf ***\n",1.0*(clock() - beg)/CLOCKS_PER_SEC);

    return 0;
}  
