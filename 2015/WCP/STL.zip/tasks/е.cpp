﻿#include <cstdio>
#include <cstring>
#include <stack>
#include <string>
#include <algorithm>
using namespace std;

inline bool open(char w)
{
	return w == '(' || w == '[' || w == '{' || w == '<';
}

inline bool close(char w)
{
	return w == ')' || w == ']' ||w == '}' || w == '>';
}

inline char odr(char w)
{
	switch(w)
	{
	case ')': return '(';
	case ']': return '[';
	case '}': return '{';
	case '>': return '<';
	}
}

char buf[10000];
bool doit()
{
	gets(buf);
	int l = strlen(buf);
	stack<char> st;
	for(int i = 0;i < l;i++)
	{
		char c = buf[i]; 
		if(open(c)) 
			st.push(c);
		else if(close(c))
		{
			if(st.empty()) 
				return false;
			
			if(st.top() != odr(c))
				return false;
			
			st.pop();
		}
	}
	
	if(!st.empty()) 
		return false;
	
	return true;
}

int main()
{
	int t;
	scanf("%d\n", &t);
	while(t--)
		puts(doit() ? "1" : "0");
	
	return 0;
}
