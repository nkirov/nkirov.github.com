﻿#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <algorithm>
using namespace std;

#define MAXN 200005 
int a[MAXN], diff[MAXN];

int main()
{
	int n, t;
	scanf("%d", &t);
	while(t--)
	{
		scanf("%d", &n);
		for(int i = 0;i < n;i++)
			scanf("%d", a + i);

		sort(a, a + n);

		for(int i = 0;i < n - 1;i++)
			diff[i] = a[i + 1] - a[i];

		int minEl = *min_element(diff, diff + n - 1);

		bool first = true;
		for(int i = 0;i < n - 1;i++)
		{
			if(diff[i] == minEl)
			{
				if(first)
				{
					printf("%d %d", a[i], a[i + 1]);
					first = false;
				}
				else
				{
					printf(" %d %d", a[i], a[i + 1]);
				}
			}

			printf("\n");
		}
	}

	return 0;
}