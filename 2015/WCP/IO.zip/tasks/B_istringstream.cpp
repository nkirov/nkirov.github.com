﻿#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>
using namespace std;

int k, n, a[100000];
string s;

int compare (const void * a, const void * b)
{
	return (-*(int*)a + *(int*)b );
}

void string_to_a()
{  
	istringstream instr(s);
	instr >> k;
	int i;
	while(instr >> i) 
		a[n++] = i; 
		
}

int main()
{
    cin.sync_with_stdio(false);

    while (getline(cin, s))
    {
		 n = 0;     
		 string_to_a();
		 qsort (a, n, sizeof(int), compare);
		 int sum = 0;
		 for (int i = 0; i < k; i++) 
			 sum += a[i];
		 cout << sum << endl;
    }
    return 0;   
}
