﻿#include <stdio.h>
#include <memory.h>

#define MAX 1005

int A[MAX][MAX];
int t, n, ax, ay, bx, by, color, tmp, intersectionCount;

void init()
{
	//зануляване
    memset(A, 0, sizeof(A));
	intersectionCount = 0;
}

void solve()
{
	//четем броя на отсечките
	scanf("%d", &n);
	for(int i = 0;i < n;i++)
	{
	 //четем координатите на i-тата отсечка
       scanf("%d%d%d%d", &ax, &ay, &bx, &by);
       color = ax == bx ? 1 : 2;
       if (ax > bx) tmp = ax, ax = bx, bx = tmp;
       if (ay > by) tmp = ay, ay = by, by = tmp;
       if (color == 2)
       {
          for(int a = ax;a <= bx; a++)
          {
              if (A[a][ay] == 1)
              {
                   intersectionCount++;
                   A[a][ay] = 3;
              }
              else if (A[a][ay] != 3)
                   A[a][ay] = color;
          }
       }
       else
       {
          for(int a = ay;a <= by; a++)
          {
              if (A[ax][a] == 2)
              {
                   intersectionCount++;
                   A[ax][a] = 3;
              }
              else if (A[ax][a] != 3)
                   A[ax][a] = color;
          }
       }
   }
}

void print()
{
	//извеждаме резултата
	printf("%d\n", intersectionCount);
}

int main()
{
    //четем броя на тестовете
    scanf("%d", &t);

    //за всеки тест
    while(t--)
    {
	   init();
	   solve();
	   print();
    }
}
