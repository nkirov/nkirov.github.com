﻿#include <stdio.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

#define MAXN 100001
#define MAXL 10001

int k, n, a[MAXN];
char str[(MAXN * MAXL) + MAXL];

int compare (const void * a, const void * b)
{
	return (-*(int*)a + *(int*)b );
}

int main()
{
    while (!feof(stdin))
    {
		gets(str);
		n = 0;
		char *p = strtok(str, " ");
		k = atoi(p);
		p = strtok(NULL, " ");

		while(p != NULL)
		{
			a[n++] = atoi(p);
			p = strtok(NULL, " ");
		}

		qsort (a, n, sizeof(int), compare);
		int sum = 0;
		for (int i=0; i < k; i++) 
			sum += a[i];
		printf("%d\n", sum);
    }

    return 0;    
}
