﻿#include <iostream>
#include <time.h>
#include <limits.h>
using namespace std;

long long n, k, MIN, MAX;

int main() 
{
	MIN = LLONG_MAX, MAX = LLONG_MIN;

	//time_t start = clock();
	
	cin.sync_with_stdio(false);

	cin>>n;
	while(n--)
	{
		cin>>k;
		if(k > MAX) MAX = k;
		if(k < MIN) MIN = k;
	}

	cout<<MIN<<" "<<MAX<<endl;

	//cout<<(clock() - start) / (double)(CLOCKS_PER_SEC / 1000)<<" ms."<< endl;
	return 0;
}