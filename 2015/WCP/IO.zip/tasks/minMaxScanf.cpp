﻿#include <cstdio>
#include <limits.h>

int n;
long long k, MIN = LLONG_MAX, MAX = LLONG_MIN;

int main()
{
	scanf("%lld\n", &n);
	while(n--)
	{
		scanf("%lld\n", &k);
		if(k > MAX) MAX = k;
		if(k < MIN) MIN = k;
	}

	printf("%lld %lld\n", MIN, MAX);
	return 0;
}
