﻿#include <stdio.h>

typedef long long ll;
ll n;
int t;

bool isPowerOfTwo (ll x)
{
	/* While x is even and > 1 */
	while (((x & 1) == 0) && x > 1) 
		x >>= 1;
	
	return x == 1;
}

int Log2(ll x)
{
	int ans =  0;

	while (x >>= 1) 
		ans++;
	
	return ans;
}


int main()
{
	scanf("%d", &t);
	while(t--)
	{
		//scanf("%I64d", &n); -> wa!!!
		scanf("%lld", &n);

		int ans = Log2(n);
		if(!isPowerOfTwo(n))
			ans++;
		
		printf("%d\n", ans);
	}

	return 0;
}

