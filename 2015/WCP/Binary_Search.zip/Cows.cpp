﻿
#include <stdio.h>
#include <algorithm>
using namespace std;

#define MAXN 100005

int d[MAXN];
int t, n, c, best;

bool can(const int &p)
{
    int br = c - 1, lpos = d[0];
    for (int i = 1;i < n;i++)
	{
		if(d[i] - lpos >= p)
		{
		    br--;
		    lpos = d[i];
		}
    }

	return br <= 0 ? 1 : 0;
}

void solve() 
{
    sort(d, d + n);

    int l = 0, r = 1000000000, mid;
    while (l <= r)
	{
		mid = (r + l) / 2;
		if(can(mid))
		{
			best = mid;
			l = mid + 1;
		} 
		else 
			r = mid - 1;
    }
}

int main()
{
	scanf("%d", &t);

	while(t--)
	{
        scanf("%d %d",&n,&c);
		for(int i = 0;i < n;i++) 
			scanf("%d", d + i);
		
		solve();
		printf("%d\n", best);
	}

    return 0;
}
