﻿#include <iostream>
using namespace std;

typedef long long ll;
ll n;
int t;

bool isPowerOfTwo (ll x)
{
	/* While x is even and > 1 */
	while (((x % 2) == 0) && x > 1) 
		x /= 2;
	
	return x == 1;
}

int Log2(ll x)
{
	int ans =  0;

	while (x /= 2) 
		ans++;
	
	return ans;
}


int main()
{
	cin.sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		cin>>n;
		int ans = Log2(n);
		if(!isPowerOfTwo(n))
			ans++;
		cout<<ans<<endl;
	}

	return 0;
}

