﻿//2014 North America Qualifier 
//ACM International Collegiate Programming Contest
//Problem C - Flexible Spaces
#include <iostream>
#include <vector>
#include <set>
using namespace std;
 
typedef vector<int> VI;

int main()
{
    int W, P;
    while(cin >> W >> P && W)
	{
		VI pts(P);
		pts.push_back(0);
		for(int i = 0; i < P; i ++) 
			cin >> pts[i+1];
		pts.push_back(W);
 
		set<int> po;
		for(int i = 0; i < pts.size(); i ++) 
			for(int j = i + 1; j < pts.size(); j ++) 
				po.insert(pts[j] - pts[i]);

		bool first = true;
		for(set<int>::iterator it = po.begin(); it != po.end(); ++it)
		{
			if(!first) 
				cout << " ";
			else 
				first = false;
			
			cout << *it;
		}

		cout << endl;
	}

    return 0;
}
