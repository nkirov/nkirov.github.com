﻿//2014 North America Qualifier 
//ACM International Collegiate Programming Contest
//Problem D - Flip Five

#include <iostream>
#include <string>
#include <memory.h>
using namespace std;

bool input[3][3];
bool my[3][3];

int t;

void read()
{
	char ch;
	for(int i = 0;i < 3;i++)
		for(int j = 0;j < 3;j++)
		{
			cin>>ch;
			input[i][j] = ch == '*';
		}
}

inline void press(int k)
{
	int r = k / 3, c = k % 3;
	
	my[r][c] = !my[r][c];
	if (r > 0) my[r - 1][c] = !my[r - 1][c];
	if (r < 2) my[r + 1][c] = !my[r + 1][c];
	if (c > 0) my[r][c - 1] = !my[r][c - 1];
	if (c < 2) my[r][c + 1] = !my[r][c + 1];
}

bool ok()
{
	for(int i = 0;i < 3;i++)
		for(int j = 0;j < 3;j++)
			if(input[i][j] != my[i][j])
				return false;

	return true;
}

int solve()
{
	int min = 10;

	//check all 2^9 subsets
	for(int bits = 0; bits < (1 << 9);bits++)
	{
		int cnt = 0;
	    memset(my, 0, sizeof my);

		for(int j = 0;j < 9;j++)
			if(bits & (1 << j)) //if bit j is 1
			{
				press(j);
				cnt++;
			}

		if(cnt < min && ok())
			min = cnt;
	}

	return min;
}

int main()
{
	cin.sync_with_stdio(false);

	cin>>t;
	cin.get();
	while(t--)
	{
		read();
		cout<<solve()<<endl;
	}

	return 0;
}