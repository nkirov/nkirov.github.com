﻿#include <stdio.h>
#include <string.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MAXN 50005

char a[MAXN];
int pos[MAXN];

int howmany(int begin, int lenth, int charlenth, char c)
{
    int res = 0;
    
	for(int i = 0;i < lenth;i++)
        if(a[(begin + i) % charlenth] == c)
            res++;

    return res;
}

int main()
{
	while (true)
	{
		int T = 0, k = 0,x;
		scanf("%d\n", &x);
		if(!x)
			break;

		gets(a);
		for(int i = 0;a[i] != '\0';i++)
			if(a[i ]== 'T')
				pos[k++] = i, T++;

		int max = 0;
		for(int i = 0;a[i] != '\0';i++)
			max = MAX(max, howmany(i, T, x, 'T'));
			
		printf("%d\n",T - max);
	}
}