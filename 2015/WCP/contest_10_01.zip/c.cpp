﻿//2014 North America Qualifier 
//ACM International Collegiate Programming Contest
//Problem A - Eight Queens

#include <iostream>
#include <string>
using namespace std;

typedef pair<int, int> pii;
pii q[20];

bool isValid()
{
	for (int i = 0; i < 8; i++) 
	{
		pii q1 = q[i];
		for (int j = i + 1; j < 8; j++) 
		{
			pii q2 = q[j];
			int dx = abs(q1.first - q2.first);
			int dy = abs(q1.second - q2.second);
			if (q1.first == q2.first || q1.second == q2.second || dx == dy) 
				return false;
		}
	}

	return true;
}

int t;
int main() 
{
	cin.sync_with_stdio(false);
	
	cin>>t;
	cin.get();
	while(t--)
	{
		string board[8];
		int cnt = 0;

		for (int i = 0; i < 8; i++) 
		{
			cin >> board[i];
			for (int j = 0; j < 8; j++) 
				if (board[i][j] == '*') 
					q[cnt++] = pii(i, j);
		}

		cout<< (isValid() ? "valid" : "invalid") <<endl;
	}
}