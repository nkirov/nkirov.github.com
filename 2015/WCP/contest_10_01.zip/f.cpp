#include <cstdio>

int t, a, b, v;
int main()
{
	while(!feof(stdin))
	{
		scanf( "%d%d%d", &a, &b, &v );
		printf( "%d\n", (v-b-1)/(a-b)+1 );
	}
	
	return 0;
}

