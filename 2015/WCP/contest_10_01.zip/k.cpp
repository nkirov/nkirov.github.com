#include <iostream>
#include <cstring>

using namespace std;

int run()
  {
  char a[90];
  int n,i,j,t,p;
  int c[90],q[90],r[90];
  cin >> a;
  n=strlen(a);
  for( i=0;i<n;i++) c[i]=a[i]-'0';

  for (i=0; i<n; i++)
  {t=c[i];p=i;
   for (j=i+1;j<n;j++)
      if (t>c[j]){t=c[j]; p=j;}
      c[p]=c[i]; c[i]=t;
  }

  for(i=0;i<n;i++) {j=n-i-1; q[j]=c[i];}

  for (i=n-1; i>=0;i--)
  {  if(c[i]>q[i]){q[i]=q[i]+10; q[i-1]--;}
     r[i]=q[i]-c[i];
  }
  t=0;
  for (i=0; i<n; i++) if (r[i]!=0)t=1;
  if (t==1)  for(i=0; i<n;i++) cout <<r[i];
  else cout<<'0';
  cout<<endl;
}

int main()
{
 int nt; cin >> nt;
 for(int i=1;i<=nt; i++) run();
}


