﻿//https://www.hackerrank.com/challenges/counter-game

#include <iostream>
using namespace std;

typedef unsigned long long ull;
ull n;

int Log2(ull x)
{
	int ans =  0;
	while (x >>= 1) 
		ans++;
	return ans;
}

int main()
{
	cin.sync_with_stdio(false);
	
	while(cin>>n && n)
	{
		bool first = true;
		while(n != 1)
		{
			ull k = (ull)1 << Log2(n);
			if(k == n)
				n >>= 1;
			else
				n -= k;

			first = !first;
		}

		cout<<(first ? "X" : "Y")<<endl;
	}

	return 0;
}
