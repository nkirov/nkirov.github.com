#include<iostream>
using namespace std;
int run()
{
  unsigned long long int v=0, n=0;
  char c;
  while(1)
  {
    c=getchar();
    if(((c<'1')||(c>'9'))) break;
    n++;
    v = v + (long long int)((int)c-(int)'0');
  }
  v=v*(n-1);
  if(v>0)cout << v << endl;
  return c;
}

int main()
{
  int t; cin >> t;
  while(run()>0);    
    
}

