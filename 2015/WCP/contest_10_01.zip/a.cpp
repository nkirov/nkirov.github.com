﻿/*
http://codeforces.com/contest/46/problem/C

First of all, count the number of hamsters in the sequence. Let it is h. 
Try positions where the sequence of hamsters will start, and for each 
position count the number of tigers in the segment of length h starting 
from the fixed position.  These tigers should be swapped with hamsters 
in a number of swaps equal to the number of tigers not in proper places. 
Choose minimum among all starting posotions.

Category: two pointers
*/

#include <cstdio>

#define MIN(a, b) ((a) < (b) ? (a) : (b))

const int INF = (int)(1e9 + 0.5);
int n, ans, countH;
char s[50005];

int main() 
{
	while(true)
	{
		scanf("%d\n", &n);
		if(!n)
			break;

		gets(s);
		countH = 0;
		ans = INF;

		for(int i = 0; i < n; ++i)
			if(s[i] == 'H') 
				++countH;

		int l = 0, r = 0, cc = 0;
		while(s[l] != 'H')
			++l, ++r;

		for(; l < n;)
		{
			while(r - (l - 1) != countH)
			{
				++r;
				if(s[r % n] == 'T')
					++cc;
			}

			ans = MIN(ans, cc);
			++l;

			while(l < n && s[l] != 'H') 
				++l, --cc;
		}

		printf("%d\n", ans);
	}
	
	return 0;
}