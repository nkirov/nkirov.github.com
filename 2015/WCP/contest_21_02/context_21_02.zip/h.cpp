// Alanysis - http://www.math.bas.bg/infos/files/2015-01-04-B2.pdf

#include <stdio.h>
#include <algorithm>
using namespace std;

int n;
#define MAX 1001
int l[MAX], r[MAX];

int main()
{
	while(true)
	{
		scanf("%d", &n);
		if(n == -1)
			break;

		for(int i = 0; i < n; i++)
			scanf("%d %d", &l[i], &r[i]);

		l[n] = 10000; 
		r[n] = 10001;
  
		sort(l, l + n + 1);
		sort(r, r + n + 1);
  
		int first = l[0], second = r[0], max = 0, cnt = 0;
		for(int i = 1;i <= n;i++)
		{
			if(l[i] <= r[i - 1])
				second = r[i];
			else
			{
				cnt++;
				if (second - first > max) 
					max = second - first;
        
				first = l[i];
				second = r[i];
			}
		}

		printf("%d %d\n", cnt, max);
	}
	
	return 0;
}
