#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <queue>
#include <iomanip>
#include <algorithm>

using namespace std;

typedef unsigned long long ulong;
typedef long long ll;

int arr[1024];

int main()
{
	int N, c, max = 0, v, res;

	cin >> N;

	for (int z = 1; z <= N; z++)
	{
		res = 99999;
		max = 0;
		memset(arr, 0,  sizeof(arr));
		cin >> c; 

		for (int i = 0; i < c; i++)
		{
			cin >> v;
			arr[v]++;

			if(arr[v] > max)
			{
				res = v;
				max = arr[v];
			}
			else
			{
				if(arr[v] == max)
				{
					if(v < res)
					{
						res = v;
					}
				}
			}
		}

		cout << res;

		if(z != N)
			cout << endl;
	}

	return 0;
}
