#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long


int main()
{
  //  freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\e.txt", "r", stdin);
    int tc, n, ma, num;
    scanf("%d", &tc);
    while(tc--)
    {
        int dp[5001];
        memset(dp, -1, sizeof(dp));
        scanf("%d %d", &n, &ma);
        int pos[ma];
        for(int i = 0; i < ma; i++)
        {
            scanf("%d", &num);
            pos[i] = num;
        }
        map<int,int> m;
        dp[n] = 0;
        bool changed = true;
        while(changed){
            changed = false;
            for(int i=0; i<ma; ++i){
                for(int j=0; j<=n; ++j){
                    if(dp[j]==-1) continue;
                    int new_left = j - (dp[j]+pos[i]);
                    int new_val = dp[j] + pos[i];

                    if(new_left<0){
                        continue;
                    }
                    if(dp[new_left] < new_val) changed = true;
                   dp[new_left] = max(dp[new_left], new_val);
                   // cout << "NEW: " << new_left << " " << dp[new_left] << endl;
            }
        }
        }
        for(int i=0; i<=n; ++i){
        //    printf("{%d-%d}", i, dp[i]);
        }
        if(dp[0]!=-1){
            printf("%d\n", dp[0]);
        } else {
            printf("-1\n");
        }
    }

    return 0;
}
