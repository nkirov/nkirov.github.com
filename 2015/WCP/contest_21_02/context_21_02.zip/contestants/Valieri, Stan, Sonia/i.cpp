#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

bool isDividedBy3(vi nums){
    int sum =0;
    for(int i = 0; i < nums.size(); i++){
        sum+=nums[i];
    }
    if(sum%3 == 0){
        return true;
    }else{
        return false;
    }
}
int main()
{
   //freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\i.txt", "r", stdin);
    string s;
   while(cin >> s){
    vi zeroes;
    vi otherDigits;
    for(int i = 0; i < s.length(); i++){
        if(s[i] == '0'){
            zeroes.push_back(0);
        }else{
            otherDigits.push_back(s[i]- '0');
        }
    }

    if(zeroes.size() == 0){
        cout << -1 << endl;
    }else{
        if(isDividedBy3(otherDigits)){
            sort(otherDigits.begin(), otherDigits.end());
            for(int i = otherDigits.size() - 1; i >= 0; i--){
                cout << otherDigits[i];
            }
            for(int i = 0; i < zeroes.size(); i++){
                cout << 0;
            }
            cout << endl;
        }else{
            cout << -1 << endl;
        }
    }

   }
    return 0;
}
