#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long

bool isCorrect(string s){
    for(int i = 1; i < s.length(); i++){
        if(s[i] < s[i-1]){
            return false;
        }
    }

    return true;
}
unsigned long long dp[10][81];
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\b.txt", "r", stdin);

    for(int i = 1; i < 10; i++){
        dp[i][1] = i;
    }

    for(int j = 2; j < 81; j++){
        dp[1][j] = dp[9][j-1] + 1;
       // cout << p << endl;
        for(int i = 2; i < 10; i++){
        unsigned long long p =dp[9][j-1] - dp[i - 1][j-1] + 1;
            dp[i][j] = dp[i-1][j] + p;
           // p--;
        }
    }


    /*for(int i = 1; i < 10; i++){
        for(int j = 1; j < 5; j++){
            cout << " " << dp[i][j];
        }
        cout << endl;
    }*/
    int TC;
    string s;
    scanf("%d", &TC);
    while(TC--){
        cin >> s;
        if(isCorrect(s)){
            int sz = s.length();
            unsigned long long sum = 0;
            int dig = s[0] - '0';
            int prevDig = s[0] - '0';
            sum = dp[dig][sz];
            sz--;
            for(int i = 1; i < s.length(); i++){
                dig = s[i] - '0';
               // cout << dp[dig][sz] <<" " << dp[prevDig][sz] << endl;
                sum+= dp[dig][sz] - dp[prevDig][sz];
                prevDig = s[i] - '0';
                sz--;
            }

            cout << sum << endl;
        }else{
            cout << -1 << endl;
        }

    }
    return 0;
}
