#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long


bool have_zero(string &s){
    bool res = false;
    if(s[0]=='-' || s[0]=='+'){
        return s[1]=='?' && s.size()>2;
    }
    return s[0]=='?' && s.size()>1;

}
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\c.txt", "r", stdin);

    int TC;
    string s;
    scanf("%d", &TC);
    while(TC--){
        cin >> s;
        string num1;
        char op;
        string num2;
        string num3;
        int curr_start = 0;
        for(int i=1; i<s.size(); ++i){
            if(s[i]=='-' || s[i]=='+' || s[i]=='*'){
                num1 = s.substr(curr_start, i-curr_start);
                op = s[i];
                curr_start = i+1;
                break;
            }
        }
        for(int i=curr_start; i<s.size(); ++i){
            if(s[i]=='='){
                num2 = s.substr(curr_start, i-curr_start);
                curr_start = i+1;
                break;
            }
        }
        num3 = s.substr(curr_start);
        string base_1, base_2, base_3;
        base_1 = num1;
        base_2 = num2;
        base_3 = num3;
     //   cout << num1 << endl;
     //   cout << op << endl;
     //   cout << num2 << endl;
     //   cout << num3 << endl;
        bool first_zero = false;
        if(have_zero(num1) || have_zero(num2) || have_zero(num3)){
            first_zero = true;
        }
        bool found = false;
        for(int i=0; i<=9; ++i){

            if(first_zero && i==0) continue;
            char new_c = '0'+i;
            std::replace(num1.begin(), num1.end(), '?', new_c);
            std::replace(num2.begin(), num2.end(), '?', new_c);
            std::replace(num3.begin(), num3.end(), '?', new_c);
            int num1_i = atoi(num1.c_str());
            int num2_i = atoi(num2.c_str());
            int num3_i = atoi(num3.c_str());
            int res;
            if(op=='*') res = num1_i * num2_i;
            if(op =='-') res = num1_i - num2_i;
            if(op == '+') res = num1_i + num2_i;
            if(res == num3_i){
                found = true;
                cout << new_c << endl;
                break;
            }
            num1 = base_1;
            num2 = base_2;
            num3 = base_3;
        }
        if(!found){
            cout << -1 << endl;
        }

    }
    return 0;
}
