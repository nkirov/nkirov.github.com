#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long



int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\a.txt", "r", stdin);
    int tc, n, num;
    int maxn = 1002;
    int arr[maxn];

    scanf("%d", &tc);
    while(tc--)
    {
        for(int i = 0; i < maxn; i++)
        {
            arr[i] = 0;
        }

        scanf("%d", &n);
        for(int i = 0; i < n; i++)
        {
            scanf("%d", &num);
            arr[num]++;
        }

        int m = 0;
        int res = 0;
        for(int i = 0; i < maxn; i++)
        {
            if(arr[i] > m)
            {
                m = arr[i];
                res = i;
            }
        }
        printf("%d\n", res);
    }

    return 0;
}
