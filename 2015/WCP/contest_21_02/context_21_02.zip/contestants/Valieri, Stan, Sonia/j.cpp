#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

int main()
{
    // freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\j.txt", "r", stdin);
    int tc;
    cin >> tc;
    while(tc--)
    {
    unsigned int n;
    cin >> n;
    unsigned int a = 0;
    unsigned int res = n^(~a);
    cout << res << endl;
    }
    return 0;
}
