#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long



int main()
{
 // freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\g.txt", "r", stdin);
    int TC;
    scanf("%d", &TC);
    int n,m;
    int x,y;
    while(TC--){
        vector<int> points;
        vector<int> b;
        vector<int> e;
        scanf("%d %d", &n, &m);
        while(n--){
            scanf("%d %d", &x, &y);
            if(x>y){
                int temp = x;
                x = y;
                y = temp;
            }
            b.push_back(x);
            e.push_back(y);
        }
        while(m--){
            scanf("%d", &x);
            points.push_back(x);
        }
        sort(b.begin(), b.end());
        sort(e.begin(), e.end());
        vector<int> res;
        for(int i=0; i<points.size(); ++i){
            int bc = upper_bound(b.begin(), b.end(), points[i]) - b.begin();
            int ec = upper_bound(e.begin(), e.end(), points[i]-1) - e.begin();
            res.push_back(bc - ec);
        }
        for(int i=0; i<res.size(); ++i){
            if(i!=0) printf(" ");
            printf("%d", res[i]);
        }
        printf("\n");
    }
    return 0;
}
