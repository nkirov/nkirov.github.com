#include <iostream>
#include <climits>
using namespace std;

int main(){

    int t;
    unsigned int MAX = ULONG_MAX;
    unsigned int n;
    cin >> t;
    //cout  << MAX;
    while (t--){
        cin >> n;
        cout << (n^MAX) << endl;
    }


    return 0;
}
