#include <iostream>
#include <map>

using namespace std;

map<int,int> arr;
int tc,tmp;



int main(){
    cin>>tc;
    while(tc--){
        int n;
        cin>>n;
        int maxx = 1001,cnt=0;
        while(n--){
                cin>>tmp;
            arr[tmp]++;
        }
       for( map<int,int>::iterator it=arr.begin(); it != arr.end(); ++it){
            if(it->second > cnt ) {
                maxx = it->first;
                cnt = it->second;
            }
            if(it->second == cnt && it->first < maxx) {
                maxx = it->first;
                cnt = it->second;
            }
       }
        cout<<maxx<<endl;
        maxx=1001;cnt=0;
        arr.clear();
    }
    return 0;
}
