#include <iostream>
#include <sstream>
#include <climits>
#include <cstring>
using namespace std;

string line;
int sum=0,tmp;
int arr[10];
char n;

int main(){
    while(getline(cin,line)){
        istringstream is(line);
        while(is>>n){
            tmp = (int)(n - '0');
            arr[tmp]++;
            sum+=tmp;
        }
        if(arr[0]!=0 && sum%3==0){
            for(int k = 9; k >=0; k--){
                for(int i = 0; i < arr[k]; i++) cout<<k;
            }
        }
        else cout<<-1;
        cout<<endl;
        memset(arr,0,sizeof(arr));
        sum=0;
    }

    return 0;
}
