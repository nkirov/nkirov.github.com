#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

void print_vector(vector<int>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}


int val(char c)
{
    return c - '0';
}

int main()
{
    string n;
    while(cin >> n)
    {
        sort(n.begin(), n.end());
        reverse(n.begin(), n.end());
        int sum = 0;
        int idx = -1;
        for(int i=0; i<n.length(); i++)
        {
            sum+= val(n[i]);
            if(n[i] == '0')
                idx = i;
        }
        if(sum % 3 != 0 || idx < 0)
            cout << "-1" << endl;
        else
        {
            cout << n << endl;
        }
    }

    return 0;
}
