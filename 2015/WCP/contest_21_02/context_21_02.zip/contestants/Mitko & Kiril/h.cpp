#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define MAXN 12000
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

void print_vector(vector<int>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}

char line[MAXN];

int main()
{
    int N;
    while(cin >> N)
    {
        if(N == -1)
            break;

        memset(line, 0, sizeof(line));

        int a, b;
        for(int i = 0; i < N; i++)
        {
            cin >> a >> b;
            memset(line + a, 'l', b - a);
        }

        b = -1;
        int maxLine = 0;
        int cnt = 0;
        for(int i = 0; i < MAXN; i++)
        {
            if(line[i] != 0)
            {
                if(b == -1)
                {
                    b = i;
                }
            }
            else
            {
                if(b != -1)
                {
                    cnt++;
                    maxLine = max(maxLine, i - b);
                    b = -1;
                }
            }
        }
        cout << cnt << " " << maxLine << endl;
    }

    return 0;
}
