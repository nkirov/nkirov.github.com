#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

typedef vector<int> vi;

class UnionFind {
private: vi p, rank;
public:
    UnionFind(int N)
    {
        rank.assign(N, 0);
        p.assign(N, 0);
        for(int i = 0; i < N; i++) p[i] = i;
    }

    int findSet(int i)
    {
        return (p[i] == i) ? i : (p[i] = findSet(p[i]));
    }

    bool isSameSet(int i, int j)
    {
        return findSet(i) == findSet(j);
    }

    void unionSet(int i, int j)
    {
        if(!isSameSet(i, j))
        {
            int x = findSet(i), y = findSet(j);
            if(rank[x] > rank[y]) p[y] = x;
            else
            {
                p[x] = y;
                if(rank[x] == rank[y]) rank[y]++;
            }
        }
    }
};

int A[100000];


void print_vector(vector<int>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}


int main()
{
    int N, P;
    while(cin >> N >> P)
    {
        if(N == 0 && P == 0)
            break;

        memset(A, 0, sizeof(A));

        UnionFind uf(N);
        int aaaa, bbbbb;
        for(int i = 0; i < P; i++)
        {
            cin >> aaaa >> bbbbb;
            uf.unionSet(aaaa, bbbbb);
        }


        vector<int> v;


        for(int i = 0; i < N; i++)
        {
            int sn = uf.findSet(i);
            if(A[sn] == 0)
                v.push_back(sn);
            A[sn]++;
        }

        vector<int> prefixSums(v.size());
        prefixSums[v.size() - 1] = A[v[v.size()-1]];
        for(int i = v.size() - 2; i >= 0; i--)
        {
            prefixSums[i] = prefixSums[i+1] + A[v[i]];
        }

        long long result = 0;
        for(int i = 0; i < v.size() - 1;i++)
        {
            result += A[v[i]] * prefixSums[i+1];
        }
        cout  << result << endl;
    }

    return 0;
}
