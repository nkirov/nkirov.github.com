#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cmath>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

const unsigned MAXP = 100;

void print_vector(vector<int>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}

struct point
{
    point(double _x, double _y, double _z) :x(_x), y(_y), z(_z) {}
    double x,y,z;
};

vector<point> coordinates;
map<string, int> names;
double AdjMat[MAXP][MAXP];

void clean()
{
    coordinates.clear();
    names.clear();
    for(int i=0; i<MAXP; i++)
        for(int j=0; j<MAXP; j++)
            AdjMat[i][j] = 2000000007;
}

double dist(point a, point b)
{
    double dx = a.x-b.x;
    double dy = a.y-b.y;
    double dz = a.z-b.z;
    return sqrt( dx*dx + dy*dy + dz*dz );
}

void read()
{
    int P;
    string name;
    double x, y, z;
    cin >> P;


    for(int i = 0; i < P; i++)
    {
        cin >> name >> x >> y >> z;
        names[name] = i;
        coordinates.push_back(point(x,y,z));
    }


    int w,u,v;
    cin >> w;
    string name1, name2;
    for(int i = 0; i < w; i++)
    {
        cin >> name1 >> name2;
        u = names[name1];
        v = names[name2];
//        cout << name1 << "=" << u << endl;
        //cout << name2 << "=" << v << endl;
        AdjMat[u][v] = 0;
    }

    for(int u = 0; u < P; u++)
    {
        for(int v = 0; v < P; v++)
        {
            if(u == v)
            {
                AdjMat[u][v] = 0;
                continue;
            }

            if(AdjMat[u][v] == 0) continue;

            double w = dist(coordinates[u], coordinates[v]);
            AdjMat[u][v] = w;
        }
    }
}

void prnMat()
{
    for(int i=0; i<coordinates.size(); i++)
    {
        for(int j=0; j<coordinates.size(); j++)
            cout << AdjMat[i][j] << "\t";
        cout << endl;
    }
    cout << endl;
}

void computePaths()
{
    for(int k=0; k<coordinates.size(); k++)
    {
        for(int i=0; i< coordinates.size(); i++)
        {
            for(int j=0; j<coordinates.size(); j++)
                AdjMat[i][j] = min(AdjMat[i][j], AdjMat[i][k]+AdjMat[k][j]);
        }
    }
}

void solve()
{
    computePaths();
    int q;
    cin >> q;
    int u, v;
    string name1, name2;
    for(int i = 0; i < q; i++)
    {
        cin >> name1 >> name2;
        u = names[name1];
        v = names[name2];
        //cout << name1 << "=" << u << endl;
        //cout << name2 << "=" << v << endl;
        int result = (int)(AdjMat[u][v]+0.5);
        cout << "The distance from " << name1 << " to " << name2 << " is " << result << " parsecs."  << endl;
    }
}

int main()
{
    cin.sync_with_stdio(false);
    int t;
    cin >> t;
    for(int i=1; i<=t; i++)
    {
        cout << "Case " << i << ":" << endl;
        clean();
        read();
        solve();
    }



    return 0;
}
