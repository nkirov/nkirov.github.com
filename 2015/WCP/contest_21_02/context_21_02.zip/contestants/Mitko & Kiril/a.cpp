#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

void print_vector(vector<int>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}

void run()
{
    int N, a;
    cin >> N;
    map<int, int> m;
    for(int i = 0; i < N; i++)
    {
        cin >> a;
        m[a]++;
    }

    int max_freq = -1;
    int min_num = 20000000;
    for(map<int, int>::iterator it = m.begin(); it != m.end(); it++)
    {
        int num = (*it).first;
        int freq = (*it).second;
        if(freq > max_freq)
        {
            max_freq = freq;
            min_num = num;
        }
        else if(freq == max_freq)
        {
            min_num = min(num, min_num);
        }
    }
    cout << min_num << endl;
}


int main()
{
    int t;
    cin >> t;
    while(t--)
        run();


    return 0;
}
