#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

typedef pair<int, int> ii;

void print_vector(vector<ii>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << "(" << v[i].first << "," << v[i].second << ")" << " ";
    cout << endl;
}

const int BEG=-1;
const int END=2000000007;

int main()
{
    int t;
    cin >> t;
    while( t-- )
    {
        vector<ii> v;
        int n, m;
        //cin >> n >> m;
        scanf("%d%d", &n, &m);
        for(int i=0; i<n; i++)
        {
            int b, e;
            //cin >> b >> e;
            scanf("%d%d", &b, &e);
            if(e < b)
                swap(b, e);

            v.push_back(make_pair(b, BEG));
            v.push_back(make_pair(e, END));
        }
        vector<int> ans(m);
        for(int i=0; i<m; i++)
        {
            int p;
            //cin >> p;
            scanf("%d", &p);
            v.push_back(make_pair(p, i));
            ans[i] = 0;
        }

        sort(v.begin(), v.end());
        //print_vector(v);
        int cnt = 0;
        for(int i=0; i<v.size(); i++)
        {
            ii c = v[i];
            if(c.second == BEG)
                cnt++;
            else if(c.second == END)
                cnt--;
            else
            {
                ans[c.second] = cnt;
            }
        }

        for(int i=0; i<ans.size(); i++)
        {
            //cout << ans[i];
            printf("%d", ans[i]);
            if(i<ans.size() - 1)
                printf(" ");
                //cout << " ";
        }
        //cout << endl;
        printf("\n");
    }
    return 0;
}
