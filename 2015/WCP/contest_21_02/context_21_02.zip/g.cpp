﻿/*
XXXI.  Национална олимпиада по информатика - 2015 година
Общински кръг 4 януари 2015 г.
Група B (9 - 10 клас), зад Точки
Analysys - http://www.math.bas.bg/infos/files/2015-01-04-sol-B3.pdf
*/

#include <stdio.h>
#include <algorithm>
using namespace std;

struct point 
{
	int coord, type, number;
	point() {}
	point(int coord, int type, int number) : coord(coord), type(type), number(number) {}

	bool operator < (const point& p) const
    {
        if (coord < p.coord) 
			return true;
	
		if (coord > p.coord) 
			return false;
    
		return type > p.type;
    }
};

point t[300003];
int N, M, bt, p[100000];

int main () 
{
	int tc;
	scanf("%d",&tc);

	while(tc--)
	{
		int l, r, cnt = 0;
		scanf("%d %d",&N, &M);

		for (int i = 1;i <= N;i++) 
		{
			scanf("%d %d", &l, &r);

			if (r < l) swap (l, r);
			
			t[cnt++] = point(l, 1,  -1);
			t[cnt++] = point(r, -1, -1);
		}

		for (int i = 0;i < M;i++) 
		{
			scanf("%d",&l);
			t[cnt++] = point(l, 0, i);
		}
		
		sort(t, t + cnt);

		int br = 0;
		for (int i = 0;i < cnt;i++)
		{
			if (t[i].type == 0) 
				p[t[i].number] = br;
			else 
				br += t[i].type;
		}

		for (int i = 0;i < M - 1;i++)
			printf("%d ", p[i]);
		printf("%d\n",p[M - 1]);
	}

    return 0;
}
