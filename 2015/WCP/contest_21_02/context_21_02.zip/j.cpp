﻿//https://www.hackerrank.com/challenges/flipping-bits

#include <stdio.h>

int main() 
{
    int t;
    unsigned n;
	scanf("%d", &t);
	while(t--)
	{
        scanf("%u", &n);
        printf("%u\n", ~n);
    }

    return 0;
}