//http://en.wikipedia.org/wiki/Binomial_coefficient

#include <map>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

// n!
unsigned long long fact(int n)
{
	if(n == 0) return 1;

	unsigned long long f = 1;
	for(int i = 2;i <= n;i++)
		f *= i;
	return f;
}

// n! / (n - k)! k!
unsigned long long f1(int n, int k)
{
	return fact(n) / (fact(n - k) * fact(k));
}

// Multiplicative formula
unsigned long long f2(int n, int k)
{
	unsigned long long res = 1;
	for(int i = 1;i <= k;i++)
		res *= ((long double)(n + 1 - i) / i);

	return res;
}

void call(int n, int k)
{
	cout<< "f1(" << n <<", "<< k << ") = " << f1(n, k) << endl;
	cout<< "f2(" << n <<", "<< k << ") = " << f2(n, k) << endl << endl;
}

int main()
{
	for(int i = 0;i <= 30;i++)
		cout<< i << "! = " << fact(i) <<endl;

	call(10, 2);
	call(10, 3);
	call(20, 5);
	call(20, 13);
	call(35, 5);
	call(42, 6);
	call(49, 6);
	call(52, 6);

	int k;
	cin>>k;
}