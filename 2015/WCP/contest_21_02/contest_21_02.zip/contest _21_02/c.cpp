//Pacific Northwest Region
//Programming Contest
//Division 1
//Problem A � Runes

#include <iostream>
#include <string>
#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
using namespace std;

typedef long long ll;

bool valid(string s) {
  bool neg = s[0] == '-';
  bool leadZero = s[neg] == '0';
  if (leadZero && (neg || s.size() != 1)) 
    return false;
  return true;
}
 
bool test(char x, string a, char op, string b, string c) {
  for (int i=0; i < a.size(); i++) if (a[i] == '?') a[i] = x;
  for (int i=0; i < b.size(); i++) if (b[i] == '?') b[i] = x;
  for (int i=0; i < c.size(); i++) if (c[i] == '?') c[i] = x;
 
  if (!valid(a) || !valid(b) || !valid(c)) return false;
  ll aa = atoll(a.c_str()), bb = atoll(b.c_str()), cc = atoll(c.c_str());
  ll res;
  if (op == '+') res = aa + bb;
  else if (op == '-') res = aa - bb;
  else if (op == '*') res = aa * bb;
 
  return res == cc;
}
 
int main() 
{
  string s; 
  int T;
  cin >> T; 
  getline(cin, s);
  while(T--) {
    getline(cin, s);
    char a[10], b[10], c[10]; char op;
    if (s[0] == '-') {
      sscanf(s.c_str(), "-%[^+-*]%1[+-*]%[^=]=%s", a, &op, b, c);
    } else {
      sscanf(s.c_str(), "%[^+-*]%1[+-*]%[^=]=%s", a, &op, b, c);
    }
    string x(a), y(b), z(c);
    if (s[0] == '-') x = "-" + x;
 
    bool seen[10]; memset(seen, 0, sizeof seen);
    for (int i=0; i < s.size(); i++) if (s[i] >= '0' && s[i] <= '9')
      seen[s[i]-'0'] = true;
 
    bool solved = false;
    for (char i='0'; i <= '9'; i++) if (!seen[i-'0']) {
      if (test(i, x, op, y, z)) {
        solved = true;
        cout << i << endl;
        break;
      }
    }
    if (!solved) cout << -1 << endl;
  }
  return 0;
}