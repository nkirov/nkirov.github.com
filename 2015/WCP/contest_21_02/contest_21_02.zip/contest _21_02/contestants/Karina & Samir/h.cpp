#include <iostream>
#include <cstring>
#define SZ 10001
using namespace std;

char arr[SZ];
int n,a,b,len=0;

void init(){
    memset(arr,'0',sizeof(arr));
    len = 0;
}

int main(){
    while(cin >> n && n != -1){
        init();
        while(n--){
            cin>>a>>b;
            if (b>len) len = b;
            memset(arr + a,'1',b-a);
        }
        int start = 0,endd = 0;
        int maxx = 0;
        int lines = 0;
        for(int i = 0; i<= len; i++){
            if(arr[i] == '0'){
                continue;
            }else{
                lines++;
                int counter = 0;
                while(arr[i] == '1' && i <= len){
                    counter++;
                    i++;
                }
                if ( counter > maxx){
                    maxx = counter;
                }
            }
        }
        cout<< lines << " " << maxx << endl;
    }
    return 0;
}
