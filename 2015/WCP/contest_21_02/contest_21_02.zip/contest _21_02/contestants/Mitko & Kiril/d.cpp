//Pacific Northwest Region
//Programming Contest
//Division 1
//Problem L � Wormhole

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <math.h>
using namespace std;
 
typedef long double ld;
typedef long long ll;

struct p3d {
    ld x, y, z;
};
 
ld dist[100][100];

inline double d(p3d a, p3d b) {
	double dx = a.x - b.x;
    double dy = a.y - b.y;
    double dz = a.z - b.z;
    return sqrt(dx * dx + dy * dy + dz * dz);
}

int main() 
{
	cin.sync_with_stdio(false);

    int t; cin >> t;
    for (int c = 1; c <= t; c++) 
	{
        int p; 
		cin >> p;
         
        vector<p3d> pt(p);
        map<string, int> id;

        for (int i = 0; i < p; i++) 
		{
            string s;
			cin >> s;
            id[s] = i;

			cin >> pt[i].x >> pt[i].y >> pt[i].z;
        }
         
        for (int i = 0; i < p; i++) 
            for (int j = i; j < p; j++) 
                dist[i][j] = dist[j][i] = d(pt[i], pt[j]);
         
        int e; 
		cin >> e;

        for (int i = 0; i < e; i++) 
		{
            string s, t; 
			cin >> s >> t;
            dist[id[s]][id[t]] = 0;
        }
        
		//All-pairs shortest paths (Floyd�Warshall algorithm) 
        for (int k = 0; k < p; k++) 
            for (int i = 0; i < p; i++) 
                for (int j = 0; j < p; j++) 
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
         
        cout << "Case " << c << ":" << endl;
        int q; cin >> q;
        while (q--) 
		{
            string s, t; cin >> s >> t;
            cout << "The distance from " << s << " to " << t << " is " << ll(dist[ id[s] ][ id[t] ] + 0.5) << " parsecs." << endl;
        }
    }

    return 0;
}