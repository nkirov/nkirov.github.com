#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

void print_vector(vector<int>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}


int main()
{
    int n;
    cin >> n;
    while( n--)
    {
        unsigned a;
        cin >> a;
        cout << ~a << endl;
    }
    return 0;
}
