#include <cstdio>
#include <cctype>
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#define DEBVAR(x) printf("%s: %d\n", #x, x)
using namespace std;

void print_vector(vector<char>& v)
{
    for(int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}

int parseInt(string s, int& pos)
{
    int sign = 1;
    if(s[pos] == '-')
    {
        sign = -1;
        pos++;
    }

    vector<char> vc;
    while(isdigit(s[pos]))
    {
        vc.insert(vc.begin(), s[pos]);
        pos++;
    }
//
//    print_vector(vc);
//    exit(0);

    if(vc[vc.size()-1] == '0' && vc.size() > 1)
    {
        pos = -10;
        return -1;
    }

    int result = 0;
    int pt[] = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000};
    for(int i = 0; i < vc.size(); i++)
    {
        result += (vc[i]- '0') * pt[i];
    }
    return result * sign;
}

char parseOp(string s, int& pos)
{
    char result = s[pos];
    pos++;
    return result;
}

void replace(string& str, char replacement)
{
    for(int i = 0; i < str.size(); i++)
    {
        if(str[i] == '?')
            str[i] = replacement;
    }
}


bool trySolve(string s, char replacement)
{
    replace(s, replacement);
    int pos = 0;
    int a = parseInt(s, pos);
    if(pos == -10) return false;
    char op = parseOp(s, pos);
    int b = parseInt(s, pos);
    if(pos == -10) return false;
    char eq = parseOp(s, pos);
    int res = parseInt(s, pos);
    if(pos == -10) return false;
//
//    DEBVAR(a);
//    DEBVAR(b);
//    DEBVAR(res);


    if(op == '+')
    {
        return a + b == res;
    }
    else if(op == '-')
    {
        return a - b == res;
    }
    else if(op == '*')
    {
        return a * b == res;
    }
    else
    {
//        cout << "op = " << op << endl;
        throw "nee";
    }
}

void run()
{
    string str;
    cin >> str;
//    cout << "str="<<str<<endl;

    for(int i = 0; i < 10; i++)
    {
        if(trySolve(str, i + '0'))
        {
            cout << i << endl;
            return;
        }
    }
    cout << -1 << endl;
}

int main()
{
    cin.sync_with_stdio(false);
    int N;
    cin >> N;
//
//    int pos=0;
//    cout << "-999999 = " << parseInt("-999999", pos) << endl;
//    pos=0;
//    cout << "999999 = " << parseInt("999999", pos) << endl;
//    pos=0;
//    cout << "0 = " << parseInt("0", pos) << endl;
//    pos=0;
//    cout << "-0 = " << parseInt("-0", pos) << endl;
//    pos=0;

    while(N--)
        run();

    return 0;
}
