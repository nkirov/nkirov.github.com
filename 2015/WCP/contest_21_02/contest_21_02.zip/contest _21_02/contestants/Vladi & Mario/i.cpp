#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <sstream>

using namespace std;


typedef unsigned long long ulong;
typedef long long ll;






int main()
{
   string w;
   int counter = 0;
   while(getline(cin,w))
   {
       if(counter > 0)
       {
           cout << endl;
       }
       counter++;
       int sum = 0;
       bool zero = false;
       for(int i = 0; i < w.length();i ++)
       {
           if(w[i] == '0')
           {
               zero = true;
           }
           sum += (w[i] -'0');
       }
        if(sum % 3 == 0 && zero == true)
        {
            sort (w.rbegin(),w.rend());
            cout << w;
        }
        else{
            cout << "-1";
        }
   }



 }
