#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <sstream>

using namespace std;


typedef unsigned long long ulong;
typedef long long ll;

vector<pair<int, int>> pairs;

int main()
{
    int n, a, b, firstPassed = 0;

    while(cin >> n)
    {
		if(n == -1)
            return 0;

				if(firstPassed)
			cout << endl;

        pairs.clear();

        for(int i = 0; i < n; i++)
        {
            cin >> a >> b;
            pairs.push_back(make_pair(a, b));
        }

        sort(pairs.begin(), pairs.end());

        int counter = 1;
        int maxlength = pairs[0].second - pairs[0].first;

        for(int i = 1; i < pairs.size(); i++)
        {
            if(pairs[i].first >= pairs[i - 1].first && pairs[i].first <= pairs[i - 1].second)
            {
                if(pairs[i].second - pairs[i - 1].first > maxlength)
                {
                    maxlength = pairs[i].second - pairs[i - 1].first;
                }

				pairs[i].first = min(pairs[i-1].first, pairs[i].first);
				pairs[i].second = max(pairs[i-1].second, pairs[i].second);

            }
            else
            {
                counter++;

                if(pairs[i].second - pairs[i].first > maxlength)
                    maxlength = pairs[i].second - pairs[i].first;
            }
        }

        cout << counter << " " << maxlength;
		firstPassed = 1;
    }

    return 0;
}
