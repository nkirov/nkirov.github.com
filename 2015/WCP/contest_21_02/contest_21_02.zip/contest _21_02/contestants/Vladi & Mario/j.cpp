#include <iostream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <cstring>
#include <queue>
#include <iomanip>
#include <algorithm>
using namespace std;

typedef unsigned long long ulong;
typedef long long ll;

int main()
{
	int test;
	cin >> test;
    unsigned a;
    unsigned b;
    unsigned res;
    for(int i = 1; i <= test;i++)
    {
        cin >> a;
        b = ~a;
        cout << b;
        if( i != test)
        {
        cout << endl;
        }
    }








}
