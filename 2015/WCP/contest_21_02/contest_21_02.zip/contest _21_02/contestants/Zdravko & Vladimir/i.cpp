#include <iostream>
#include <cstdlib>
#include <string>
#include <algorithm>

using namespace std;

int main()
{
	cin.sync_with_stdio(false);

	string n;

	while(cin>> n)
	{
		int len=n.length();
		if(n.find('0')>=len)
		{
			cout << "-1" << endl;
			continue;
		}
		else
		{

			long long sum=0;
			for(int i = 0;i!=len;i++)
			{
				sum+=n[i]-'0';
			}

			if(sum%3>0)
				cout << "-1" << endl;
			else
			{
				sort(n.begin(),n.end());
				reverse(n.begin(),n.end());
				cout << n << endl;
			}
		}

	}

/*	int Cur;

	while(cin >> n)
	{
		int len=n.length();
		int fact=1;

		for(int i=1;i<=len;i++)
		{
			fact*=i;
		}

		char temp;
		int Max=0;

		int tempp=atoi(n.c_str());
		if(tempp%30==0 && tempp>Max)
			Max=tempp;

		for(int i=0;i!=fact/2;i++)
		{
			for(int j=0;j<2;j++)
			{
				temp=n[j];
				n[j]=n[j+1];
				n[j+1]=temp;

				int Cur=atoi(n.c_str());

				if(Cur%30==0 && Cur>Max)
					Max=Cur;
			}
		}

		if(Max==0)
			cout << "-1" << endl;
		else
			cout << Max << endl;
	}*/

    return 0;
}
