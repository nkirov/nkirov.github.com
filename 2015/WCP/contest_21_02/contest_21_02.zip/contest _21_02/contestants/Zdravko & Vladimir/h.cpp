#include <iostream>

using namespace std;

int main()
{
    int n;
    int a,b;

	cin.sync_with_stdio(false);

    while((cin>>n) && n!=-1)
	{
		bool Charta[10001]={false};
		int maxb=0;
		while(n--)
		{
			cin >> a >> b;

			if(b>maxb)
				maxb=b;

			for(int i=a;i<b;i++)
			{
				Charta[i]=true;
			}
		}

		int MaxLen=0,Count=0,CountCurLen=0;

		for(int i=0;i<=maxb+1;i++)
		{
			if(Charta[i]==true)
			{
				CountCurLen++;
			}
			else if((Charta[i]==false && Charta[i-1]==true))
			{
				Count++;

				if(CountCurLen>MaxLen)
					MaxLen=CountCurLen;

				CountCurLen=0;
			}
		}
		cout << Count << " " << MaxLen << endl;
	}

    return 0;
}
