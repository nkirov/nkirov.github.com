#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int main()
{
	int t;
	cin >> t;

	while(t--)
	{
		string input;
		cin >> input;

		int len=input.length();


		string num1,num2,res,Op;

		int IndexOp=0;
		if(input.find('*')!=string::npos)
			IndexOp=input.find('*');
		else if(input.find('+')!=string::npos)
			IndexOp=input.find('+');
		else
			IndexOp=input.find('-',1);

		num1=input.substr(0,IndexOp);
		Op=input.substr(IndexOp,1);
		num2=input.substr(IndexOp+1,input.find('=')-num1.length()-1);
		res=input.substr(input.find('=')+1,input.length());

		int output=-1;

		for(int i=0;i<=9;i++)
		{
			string temp1=num1;
			string temp2=num2;
			string temp3=res;

			while(temp1.find('?')!=string::npos)
			{
				int pos=temp1.find('?');
				if(i==0 && pos==0 && temp1.length()>1)
					goto L_End;

				temp1[pos]=i+'0';
			}
			while(temp2.find('?')!=string::npos)
			{
				int pos=temp2.find('?');
				if(i==0 && pos==0 && temp2.length()>1)
					goto L_End;

				temp2[pos]=i+'0';
			}
			while(temp3.find('?')!=string::npos)
			{
				int pos=temp3.find('?');
				if(i==0 && pos==0 && temp3.length()>1)
					goto L_End;

				temp3[pos]=i+'0';
			}

			int a,b,c;
			a=atoi(temp1.c_str());
			b=atoi(temp2.c_str());
			c=atoi(temp3.c_str());


			if(Op=="*" && a*b==c)
			{
				output=i;
				break;
			}
			else if(Op=="+" && a+b==c)
			{
				output=i;
				break;
			}
			else if(Op=="-" && a-b==c)
			{
				output=i;
				break;
			}

			L_End:;
		}
		cout << output << endl;

	}

    return 0;
}
