#include <iostream>

using namespace std;

int main()
{
    int n,m,cur;
    cin >> n;

    while(n--)
	{
		cin >> m;
		int Array[1001]= {0};
		int MinNumber=0,MaxCount=0;
		while(m--)
		{
			cin >> cur;

			Array[cur-1]++;

			if(Array[cur-1]>MaxCount || Array[cur-1]==MaxCount && cur<MinNumber)
			{
				MaxCount=Array[cur-1];
				MinNumber=cur;
			}
		}
		cout << MinNumber << endl;
	}


    return 0;
}
