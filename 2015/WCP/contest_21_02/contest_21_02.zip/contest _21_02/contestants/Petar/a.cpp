#include <iostream>
#include <bitset>

using namespace std;

int main()
{
	int n;
	cin >> n;

	while(n--)
	{
		unsigned int Cur;
		cin >> Cur;

		bitset<32> Mybit=Cur;

		Mybit.flip();
		Cur=Mybit.to_ulong();

		cout << Cur << endl;
	}

    return 0;
}
