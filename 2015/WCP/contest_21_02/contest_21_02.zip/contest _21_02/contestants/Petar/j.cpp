#include <iostream>

typedef unsigned long long data;
using namespace std;

data n;
data A=4294967295;
int main () {
    int T;
    cin >> T;
    for(int t = 0; t < T; t++)
    {
        cin >> n;
        cout<< (A-n)<< endl;
    }

    return 0;
}
