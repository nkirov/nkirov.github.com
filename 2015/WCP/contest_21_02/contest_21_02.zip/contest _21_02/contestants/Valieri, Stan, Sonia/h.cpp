#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long



int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\h.txt", "r", stdin);
    int n, cur, m, br, sum, prev, a, b, beg;
    int MAXN = 10002;
    int arr[MAXN];
    while(cin >> n)
    {
        if(n == -1)
            break;
        memset(arr, 0, sizeof(arr));
        while(n > 0)
        {
            scanf("%d %d", &a, &b);
            arr[a]++;
            arr[b]--;
            n--;
        }
        cur = 0;
        m = 0;
        br = 0;
        beg = 0;
        for(int i = 1; i < MAXN; i++)
        {
            prev = cur;
            cur += arr[i];
            if(cur == 0 && prev != 0)//end
            {
                br++;
                sum = i - beg;
                if(m < sum)
                {
                    m = sum;
                }
            }
            else if(cur > 0 && prev == 0)//start
            {
                beg = i;
            }
        }
        printf("%d %d\n", br, m);

    }

    return 0;
}
