#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e16
#define ll long long
#define ull unsigned long long



int main()
{
  // freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\d.txt", "r", stdin);
    int tc, p, w, q, x, y, z;
    string str;
    string s1, s2;
    scanf("%d", &tc);
    int MAXN = 61;
    double dist[61][61];
    for(int t = 1; t <= tc; t++)
    {
        //memset(dist, -1, sizeof(dist));
        for(int i=0; i<MAXN; i++){
            for(int j=0; j<MAXN; ++j){
                dist[i][j] = INF;
            }
        }
        map<string, int> mmm;
        ll arx[61];
        ll ary[61];
        ll arz[61];
        scanf("%d", &p);
        for(int i = 0; i < p; i++)
        {
            cin >> str;
            scanf("%d %d %d", &x, &y, &z);
            mmm[str] = i;
            arx[i] = x;
            ary[i] = y;
            arz[i] = z;
        }
        for(int i = 0; i < p; i++)
        {
            for(int j = 0; j < p; j++)
            {
                double d = sqrt((arx[i] - arx[j])*(arx[i] - arx[j])  +  (ary[i] - ary[j])*(ary[i] - ary[j]) + (arz[i]-arz[j])*(arz[i]-arz[j]) );

                dist[i][j] = d;
                dist[j][i] = d;
            }
        }



        scanf("%d", &w);
        while(w--){
            cin >> s1 >> s2;
            dist[mmm[s1]][mmm[s2] ] = 0;
        }

          for(int k=0; k<p; ++k)
            for(int i=0; i<p; ++i)
                for(int j=0; j<p; ++j)
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);



        scanf("%d", &q);
        printf("Case %d:\n", t);
        while(q--){
            cin >> s1 >> s2;
            double val = dist[mmm[s1]][mmm[s2]];

            ll res = (val + 0.5);
            printf("The distance from %s to %s is %lld parsecs.\n", s1.c_str(), s2.c_str(),res);
           // cout << "DISTNAGLASD : " << dist[mmm[s1]][mmm[s2]] << endl;
        }
    }

    return 0;
}
