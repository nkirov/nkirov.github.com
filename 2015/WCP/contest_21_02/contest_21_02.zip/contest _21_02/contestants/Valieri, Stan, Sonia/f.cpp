#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long

int x,y;
vector<vector<int> > v;
int visited[100001];
int dfs(int curr, int comp){
   // cout << "CALLED DFS FOR " << curr << endl;
    int comp_size = 1;
    visited[curr] = comp;
    for(int i=0; i<v[curr].size(); ++i){
        int x = v[curr][i];
        if(!visited[x]){
            comp_size += dfs(x, comp);
        }
    }
    return comp_size;
}
int main()
{
  //freopen("C:\\Users\\Administrator\\Desktop\\2014.02.21\\f.txt", "r", stdin);
    int n,p;
    while(scanf("%d %d", &n, &p)==2){
        if(n==0 && p==0) return 0;
            memset(visited, 0 ,sizeof(visited));
        v.clear();
        v.assign(n, vector<int>());
        while(p--){
            scanf("%d %d", &x, &y);
            v[x].push_back(y);
            v[y].push_back(x);
        }
        int comp = 1;
        vector<ll> comps;
        for(int i=0; i<n; ++i){
            if(!visited[i]){
                comp++;
                comps.push_back(dfs(i, comp));
            }
        }
        ll res =0;
        for(int i=0; i<comps.size(); ++i){
            res+= comps[i] * (n-comps[i]);
            n-=comps[i];
        }
        cout << res << endl;
    }
    return 0;
}
