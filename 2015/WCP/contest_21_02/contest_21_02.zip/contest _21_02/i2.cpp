﻿/*
CROATIAN OPEN COMPETITION IN INFORMATICS
4rd round, December 20th, 2014
TASK 1 - CESTA

The prime factorization of number 30is 2*3*5. Therefore, N is divisible by 30 if and only
if it is divisible by 2, 3 and 5.

We know that a number is divisible by 2 if it’s last digit is even and it’s divisible by 3 when
the sum of its digits is divisible by 3 and, naturally, we know that it’s divisible by 5 when it’s
last digit is either 0 or 5. By combining these conditions, we conclude that N is divisible by
30 if and only if it’s last digit is 0 and the sum of its digits is divisible by 3. Therefore, if the
number from the input data doesn’t contain the digit 0 or the sum of its digits is not divisible
by 3, we output 1.

What is obvious is that it is sufficient to sort the digits of number N in descending order to
get the required number.

Implementations with time complexity of O(n) or O(n’log(n’)), where n’ is the number of digits 
of N were sufficient to score all points on this task.

Necessary skills: divisibility, greedy algorithms
Category: number theory, adhoc
*/

#include <string>
#include <iostream>
#include <functional>
#include <algorithm>
using namespace std;

int main()
{
	string N;
    while(cin >> N)
	{
		sort(N.begin(), N.end(), greater<char>());

		int sum = 0;
		for(int i = 0;i < N.size();i++)
			sum += N[i] - '0';
		
		if (sum % 3 == 0 && N.back() == '0')
			cout << N << '\n';
		else
			cout << "-1\n";
	}

    return 0;

}
