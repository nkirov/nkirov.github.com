//Pacific Northwest Region
//Programming Contest
//Division 1
//Problem H � Pushups

#include <iostream>
#include <memory.h>
using namespace std;

#define MAXP 11000
#define MAXC 20

char dp[MAXP + 1][MAXP + 1];
int a[MAXC];

int main() 
{
	int t;
	cin.sync_with_stdio(false);

	cin >> t;
	while (t--)
	{
		int n, m;
		cin >> n >> m;
		for(int i = 0; i < m; i++)
			cin >> a[i];

        memset(dp, 0, sizeof dp);

		dp[0][0] = 1;
		for(int i = 0;i < n; i++)
			for(int j = 0;j < n; j++)
				if (dp[i][j])
					for(int k = 0;k < m; k++)
						dp[i + j + a[k]][j + a[k]] = 1;
      
		int hi = -1;
		for(int i = n;i >= 0;i--)
             if (dp[n][i])
             {
                hi = i;
				break;
             }

		cout << hi << endl;
	}
}
