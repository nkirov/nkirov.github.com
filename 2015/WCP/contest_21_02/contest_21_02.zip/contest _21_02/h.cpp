// Alanysis - http://www.math.bas.bg/infos/files/2015-01-04-sol-B2.pdf

#include <stdio.h>
#include <algorithm>
using namespace std;

int n;
#define MAX 1001
int l[MAX], r[MAX];

int main()
{
	while(true)
	{
		scanf("%d", &n);
		if(n == -1)
			break;

		for(int i = 0; i < n; i++)
			scanf("%d %d", &l[i], &r[i]);

		l[n] = 10000; 
		r[n] = 10001;
  
		sort(l, l + n + 1);
		sort(r, r + n + 1);
  
		int left = l[0], right = r[0], max = 0, cnt = 0;
		for(int i = 1;i <= n;i++)
		{
			if(l[i] <= r[i - 1])
				right = r[i];
			else
			{
				cnt++;
				if (right - left > max) 
					max = right - left;
        
				left = l[i];
				right = r[i];
			}
		}

		printf("%d %d\n", cnt, max);
	}
	
	return 0;
}
