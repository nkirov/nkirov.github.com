/*
https://www.hackerrank.com/challenges/journey-to-the-moon

This problem can be thought of as a graph problem. 
The very first step is to compute how many different countries are there. 
For this, we apply Depth First Search to calculate how many different 
connected components are present in the graph where the vertices are 
represented by the people and the people from the same country form one 
connected component. After we get how many connected components are present, 
say M, we just need to calculate the number of ways of selecting two persons 
from two different connected component. Let us assume that component i contains 
Mi people. So, for the number of ways selecting two persons from different 
components, we subtract the number of ways of selecting two persons from the 
same component from the total numbers of ways of selecting two persons i.e.

Ways = N choose 2 - (∑(Mi Choose 2) for i = 1 to M)
*/

#define _CRT_SECURE_NO_WARNINGS 1

#include <stdio.h>
#include <vector>
#include <memory.h>
using namespace std;

#pragma comment(linker, "/STACK:16777216")

#define MAX 100005
int n, m;

vector < vector <int> > p;
int ccColor[MAX], ccCount[MAX];

void floodFill(int from, int color)
{
	ccColor[from] = color;
	
	for(int i = 0;i < p[from].size();i++)
		if(!ccColor[p[from][i]])
		{
			floodFill(p[from][i], color);
			ccCount[color]++;
		}
}

void solve()
{
	int numComponents = 0; 
	long long result = 0, sum = 0;

	for(int i = 0;i < n;i++)
		if(!ccColor[i])
		{
			numComponents++;
			ccCount[numComponents]++;
			floodFill(i, numComponents);
            result += sum * ccCount[numComponents];
            sum += ccCount[numComponents];
		}
		
	printf("%lld\n", result);
}

void solve2()
{
	int numComponents = 0; 
	long long totalWays = (long long)n * (n - 1) / 2, sameWays = 0;

	for(int i = 0;i < n;i++)
		if(!ccColor[i])
		{
			numComponents++;
			ccCount[numComponents]++;
			floodFill(i, numComponents);
            sameWays += (ccCount[numComponents] * (ccCount[numComponents] - 1) / 2);
		}
		
	printf("%lld\n", totalWays - sameWays);
}

bool read()
{
	int u, v;
	scanf("%d %d\n", &n, &m);
	if(n == 0 && m == 0)
		return false;

	memset(ccColor, 0, sizeof ccColor);
	memset(ccCount, 0, sizeof ccCount);

	p = vector<vector<int> >(n);

	for(int i = 0;i < m;i++)
	{
		scanf("%d%d", &u, &v);
		p[u].push_back(v);
		p[v].push_back(u);
	}

	return true;
}

int main()
{
	while(read())
	{
		solve2();
	}

	return 0;
}
