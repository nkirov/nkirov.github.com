﻿#include <stdio.h>
#include <memory.h>

int n, t, k;
int a[1005];

int main()
{
	scanf("%d", &t);
	while(t--)
	{
		memset(a, 0, sizeof a);

		scanf("%d", &n);
		for(int i = 0;i < n;i++)
		{
			scanf("%d", &k);
			a[k]++;
		}

		int best = 0;
		for(int i = 1;i <= 1000;i++)
			if(a[i] > a[best])
				best = i;

		printf("%d\n", best);
	}

    return 0;
}
