#define _CRT_SECURE_NO_WARNINGS 1

#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>
using namespace std;

#define MAXN 1000

int t, n, k;

struct contestant {
    string name;
    int tasks, time;

	contestant() { }
    contestant(string name, int tasks, int time) : name(name), tasks(tasks), time(time) { }

	bool operator < (const contestant &c) const {
        if(tasks == c.tasks)
		{
			if(time == c.time)
				return name < c.name;

			return time < c.time;
		}

        return tasks > c.tasks;
    }
};

contestant c[MAXN];

void print()
{
	for(int i = 0;i < 27;i++)
	  cout<<"-";
    cout<<endl;
}

int main()
{
	cin.sync_with_stdio(false);
		
	int t = 0;
	while(!cin.eof())
	{
		string line;
		n = 0;

		while(getline(cin, line))
		{
            if(line.size() == 0)
                return 0;
                
			istringstream instr(line);
			int tasks, time;
			string name;
			instr>>tasks>>time>>name;
			if(name.size() > 0)
				c[n++] = contestant(name, tasks, time);
			else
			{
				k = tasks;
				break;
			}
		}

		if (line.size() == 0)
			return 0;

		sort(c, c + n);

		if(t > 0)
			cout<<endl;

		cout<<"Summary for contest "<<++t<<" (top "<< k <<" of " << n << " participants):"<<endl<<endl;

		print();

		cout<<"|"<<setw(2)<<"#"<<"|"<<setw(10)<<"name"<<"|"<<setw(5)<<"tasks|"<<setw(5)<<"time"<<"|"<<endl;
		
		print();

		for(int i = 0;i < k;i++)
			cout<<"|"<<std::right<<setw(2)<<i + 1<<"|"<<setw(10)<<std::left<<c[i].name<<"|"<<setw(5)<<std::right<<c[i].tasks<<"|"<<setw(5)<<c[i].time<<"|"<<endl;

		print();
	}

    return 0;
}

