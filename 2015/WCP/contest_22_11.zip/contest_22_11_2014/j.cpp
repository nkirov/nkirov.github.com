//task - http://codeforces.com/contest/190/problem/D
//analysis - http://codeforces.com/blog/entry/4556

#include <cstdio>
#include <algorithm>
#include <map>
#include <memory.h>
using namespace std;

#define MAXN 400000

int N,K;
pair<int, int> a[MAXN];
int start[MAXN];

int main()
{
    while(scanf("%d %d", &N, &K) == 2 && N)
	{
		for(int i = 0;i < N;++i)
		{
			scanf("%d", &a[i].first);
			a[i].second = i;
		}
    
		sort(a, a + N);

		for(int i = 0;i < N;)
		{
			int e = i;
        
			while(e < N && a[e].first == a[i].first) 
				++e;
        
			for(int j = i;j < e;++j)
			{
				if(j - i < K - 1) 
					start[a[j].second] = -1;
				else 
					start[a[j].second] = a[j - K + 1].second;
			}
        
			i = e;
		}
    
		long long ans = 0;
		for(int i = 0,e = 0;i < N;++i)
		{
			while(e < N && start[e] < i) 
				++e;
			ans += N - e;
		}
    
		printf("%I64d\n", ans);
	}
    
    return 0;
}
