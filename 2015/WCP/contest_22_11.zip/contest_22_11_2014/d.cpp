//ЗИМНИ СЪСТЕЗАНИЯ ПО ИНФОРМАТИКА 
//Велико Търново, 10 – 12 февруари 2012 г.
//Група Е, 4 – 5 клас

#include<iostream>
using namespace std;

int main()
{
	cin.sync_with_stdio(false);

	while(true)
	{
		int a, p, c = 1, r = 0, n;
		cin >> n;
		if(!n)
			break;

		cin >> p;
		for(int i = 0;i < n - 1;i++)
		{
			cin>>a;
			if(a > p) 
				c++;
			else 
			{
				if(r < c)
					r = c; 
				c = 1;
			}
			
			p = a;    
		}     
		
		if(r < c)
			r = c;
		
		cout << r << endl;  
	}
}

