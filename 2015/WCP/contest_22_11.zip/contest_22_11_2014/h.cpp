//http://codeforces.com/contest/466/problem/A
//http://codeforces.com/blog/entry/13758

#include <iostream>
using namespace std;

int n, m, a, b;

int main()
{
    ios_base::sync_with_stdio(false);

    while(cin >> n >> m >> a >> b)
	{	
		if (m * a <= b)
			cout << n * a << "\n";
		else 
			cout << (n / m) * b + min((n % m) * a, b) << "\n";
	}

    return 0;
}
