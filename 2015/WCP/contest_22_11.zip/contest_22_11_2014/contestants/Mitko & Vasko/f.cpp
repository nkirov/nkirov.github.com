#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
#include <cctype>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

int K;
int tc = 1;
struct competitor
{
    int problems;
    int time;
    string name;

    inline bool operator<(const competitor& other) const
    {
        if(this->problems == other.problems)
        {
            if(this->time == other.time)
            {
                return this->name < other.name;
            }
            else
            {
                return this->time < other.time;
            }
        }
        else
        {
            return this->problems > other.problems;
        }
    }
};
vector<competitor> A;

int clamp(int n, int m)
{
    if(n < m) return n;
    return m;
}

void print()
{
    if(tc > 1)
    {
        cout << endl;
    }

    cout << "Summary for contest " << tc << " (top " << K  << " of " << A.size() << " participants):" << endl;
    cout << endl;
    cout << string(27,'-') << endl;
    cout << "|" << setw(2) << right << "#" << "|" << setw(10) << right << "name" << "|" << setw(5) << right << "tasks" << "|" << setw(5) << right << "time" << "|" << endl;
    cout << string(27,'-') << endl;

    int howManyToPrint = clamp(A.size(), K);
    for(int i = 0; i < howManyToPrint; i++)
    {
        cout << "|" << setw(2) << right << i + 1 << "|" << setw(10) << left << A[i].name << "|" << setw(5) << right << A[i].problems << "|" << setw(5) << right << A[i].time << "|" << endl;
    }
    cout << string(27,'-') << endl;
}


int main()
{
    cin.sync_with_stdio(false);
    string line;
    while(getline(cin, line))
    {
        int charsRead = line.size();
//        cout <<"read:"<< charsRead << " ";
//        cout << line << endl;
        istringstream iss(line);

        if(charsRead >= 1 && charsRead <= 5)
        {
//            cout << "------solve\n";
            iss >> K;
            sort(A.begin(), A.end());
            print();
            tc++;
            A.clear();
        }
        else
        {
//            cout << "------read\n";
            competitor c;
            iss >> c.problems >> c.time >> c.name;
            A.push_back(c);
        }
    }

    return 0;
}
