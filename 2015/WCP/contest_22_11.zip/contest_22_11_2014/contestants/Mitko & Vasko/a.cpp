#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
#define MAXN 31
#define MAXV (MAXN * MAXN - 1)
#define INF 1000000000
using namespace std;

int dx[] = { 0 , 0, -1, 1 };
int dy[] = { -1, 1, 0, 0 };

inline bool in(int x, int y, int N)
{
    return x >= 0 && x < N && y >= 0 && y < N;
}

int AdjMat[MAXV][MAXV];
string G[MAXN];

void run()
{
    int N, A, B;
    cin >> N >> A >> B;

    int cnt = N * N;
    for(int i = 0; i < cnt; i++)
    {
        for(int j = 0; j < cnt; j++)
        {
            AdjMat[i][j] = INF;
        }
    }

    for(int i = 0; i < N; i++)
    {
        cin >> G[i];
    }
    for(int i = 0; i < N; i++)
    {
        for(int j = 0; j < N; j++)
        {
            for(int k = 0; k < 4; k++)
            {
                int x = i + dx[k];
                int y = j + dy[k];
                if(!in(x,y,N)) continue;

                int u = i * N + j;
                int v = x * N + y;
                int w = (G[i][j] == G[x][y] ? A : B);

                AdjMat[u][v] = AdjMat[v][u] = w;
            }
        }
    }

    for(int k = 0; k < cnt; k++)
    {
        for(int  i = 0; i < cnt; i++)
        {
            for(int  j = 0; j < cnt; j++)
            {
                AdjMat[i][j] = min(AdjMat[i][j], AdjMat[i][k] + AdjMat[k][j]);
            }
        }
    }

//    for(int i = 0; i < cnt; i++)
//    {
//        cout << i << "=\t";
//        for(int j = 0; j < cnt; j++)
//            cout << (AdjMat[i][j] == INF ? -1 : AdjMat[i][j]) << ",\t";
//        cout << endl;
//
//    }

    int best = 0;
    for(int i = 0; i < cnt; i++)
        for(int j = 0; j < cnt; j++)
            if(AdjMat[i][j] != INF && i != j)
                best = max(best, AdjMat[i][j]);
    cout << best << endl;
}

int main()
{
    cin.sync_with_stdio(false);
    int t;
    cin >> t;
    while(t--)
        run();

    return 0;
}
