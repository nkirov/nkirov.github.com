#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
using namespace std;


int main()
{
    int N;
    cin>>N;

    for (int i = 0 ; i < N ; i++)
    {
        vector<string> A(8);
        for (int q = 0 ; q < 3 ; q++)
        {
            cin>>A[q];
        }
        string All = "";

        for (int s = 0 ; s < 3 ; s++)
        {
            A[3 + s] = "" + A[0].substr(0 + s,1) + A[1].substr(0 + s,1) + A[2].substr(0 + s,1);
            All = All + A[s];
        }
        A[6] = A[0].substr(0, 1) + A[1].substr(1,1) + A[2].substr(2,1);
        A[7] = A[2].substr(0, 1) + A[1].substr(1,1) + A[0].substr(2,1);

//        if (i == 0)
//        {
//                for (int s = 0 ; s < 8 ; s++)
//                {
//                    cout<<"|"<<A[s]<<endl;
//                }
//        }


        int countX = 0;
        int count0 = 0;
        for (int s = 0 ; s < 9 ; s++)
        {
            if (All[s] == '0'){
                count0++;
            }
            else if (All[s] == 'X')
            {
                countX++;
            }
        }
        if ((count0 > countX) || (countX > count0 + 1) )
        {
            cout<<"illegal"<<endl;continue;
        }



        bool winX = false;
        bool win0 = false;
        for (int s = 0 ; s < 8 ; s++)
        {
            if (A[s] == "XXX")
            {
                winX = true;
            }
            else if (A[s] == "000")
            {
                win0 = true;
            }
        }



        if (winX && win0)
        {
            cout<<"illegal"<<endl;continue;
        }
        if (winX)
        {
            if (countX == count0)
            {
                cout<<"illegal"<<endl;continue;
            }
            else
            {
                cout<<"the first player won"<<endl;continue;
            }
        }
        if (win0)
        {
            if (countX == count0)
            {
                cout<<"the second player won"<<endl;continue;
            }
            else
            {
                cout<<"illegal"<<endl;continue;
            }
        }

        if (countX + count0 == 9)
        {
            cout<<"draw"<<endl;continue;
        }
        if (countX == count0)
        {
            cout<<"first"<<endl;continue;
        }
        if (countX == count0 + 1)
        {
            cout<<"second"<<endl;continue;
        }
        cout<<"SHOULD NOT BE HERE!"<<endl;
    }


    return 0;
}
