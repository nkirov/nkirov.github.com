#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
#define MAXN 50100
using namespace std;

int N, M;
set<int> E[MAXN];
bool used[MAXN];
char letter[MAXN];


void clean()
{
    for(int i = 0; i <= N; i++)
        E[i].clear();
    memset(used, 0, sizeof(used));
    memset(letter, 0, sizeof(letter));
}

void read()
{
    int u,v;
    for(int i = 0; i < M; i++)
    {
        cin >> u >> v;
        E[u].insert(v);
        E[v].insert(u);
    }
}

int current_x;
int total;
bool dfs(int u, char l)
{
    used[u] = true;
    letter[u] = l;

    if(l == 'X') current_x++;
    total++;

    for(set<int>::iterator iter = E[u].begin(); iter != E[u].end(); iter++)
    {
        int v = *iter;
        if(!used[v])
        {
            bool res = dfs(v, l == 'X' ? 'Y' : 'X');
            if(!res) return false;
        }
        else
        {
            if(letter[u] == letter[v])
                return false;
        }
    }
    return true;
}

void solve()
{
    int ans = 0;
    for(int i = 1; i <= N; i++)
    {
        if(!used[i])
        {
            current_x = 0;
            total = 0;

            if(dfs(i, 'X'))
            {
                ans += max(current_x, total - current_x);
            }
            else
            {
               ans = -1;
               break;
            }
        }
    }
    cout << ans << endl;
}

int main()
{
    cin.sync_with_stdio(false);
    while (cin >> M >> N)
    {
        if(N == 0 && M == 0) break;

        clean();
        read();
        solve();
    }
    return 0;
}
