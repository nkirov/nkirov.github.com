#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
using namespace std;


int main()
{
    int n,m,a,b;

    while(cin>>n)
    {
        cin>>m>>a>>b;

        if (a*m <= b)
        {
            cout<<a*n<<endl;
        }
        else
        {
            int part = (n/m)*b;// + (n%m)*a;
            if ( n%m > 0)
            {
                if (n%m * a < b)
                {
                    part += n%m*a;
                }
                else
                {
                    part+=b;
                }
            }

            cout<<part<<endl;
        }

    }

    return 0;
}
