#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
#include <string>
#include <sstream>
using namespace std;


void run()
{
    string line;
    getline(cin, line);
    istringstream iss(line);
    char op;
    double num;
    double prevnum;
    char prevOperation = '+';
    double result = 0;
    iss >> prevnum;
    while(iss >> op >> num)
    {
        if(op == '+' || op == '-')
        {
            if (prevOperation == '+')
            {
                result += prevnum;
                prevnum = num;
            }
            else
            {
                result-=prevnum;
                prevnum = num;
            }
            prevOperation = op;
        }
        else // '*' || '/'
        {
            if(op == '*') prevnum *= num;
            else prevnum /= num;
        }
    }
    if (prevOperation == '+')
    {
        result += prevnum;
    }
    else
    {
        result-=prevnum;
    }
    cout<<result<<endl;
}

int main()
{
    cin.sync_with_stdio(false);

    int t;
    cin >> t;
    cin.ignore();
    while(t--)
        run();


    return 0;
}
