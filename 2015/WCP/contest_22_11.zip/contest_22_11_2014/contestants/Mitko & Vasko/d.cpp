#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;


int main()
{
    cin.sync_with_stdio(false);
    int N;
    while(cin >> N && N)
    {
        vector<int> A(N);
        for(int i = 0; i < N; i++)
        {
            cin >> A[i];
        }
//
//        for(int i = 0; i < A.size(); i++)
//        {
//            cout << A[i] << " ";
//        }
//        cout << endl;

        int low_i = 0, best = 1;
        for(int i = 1; i < A.size(); i++)
        {
            if(A[i] <= A[i-1])
            {
                best = max(best, i - low_i);
//                cout << "asc range: (" << low_i << ", " << i - 1 << ")\n";
//                cout <<"curans: " << i - low_i << endl;
                low_i = i;
            }
        }
        cout <<best << endl;
    }
    return 0;
}
