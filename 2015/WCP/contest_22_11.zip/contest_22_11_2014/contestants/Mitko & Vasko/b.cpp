#include <cstdio>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <iostream>
using namespace std;

bool can(int v, int k , int n)
{
    int result = v;
    int cur = v/k;
    while(cur>0)
    {
        result+=cur;
        cur/=k;
    }
    return result >=n;
}

int main()
{
    int N,K;
    while(cin>>N && N)
    {
        cin>>K;
        int low = 1, hi = N, mid, ans =1;
        while(hi >=low)
        {
            mid = (hi + low) / 2;
            if(can(mid, K , N))
            {
                ans = mid;
                hi = mid - 1;
            }
            else
            {
                low = mid + 1;
            }
        }
        cout << ans << endl;
    }

    return 0;
}
