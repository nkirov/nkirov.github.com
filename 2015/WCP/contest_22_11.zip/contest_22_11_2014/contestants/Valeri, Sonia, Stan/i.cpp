#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <sstream>
#include <cctype>
#include <iomanip>

using namespace std;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.11.22\\i.txt", "r", stdin);
    int TC;
    scanf("%d", &TC);
    while(TC--){

        string l1,l2,l3;
        cin >> l1 >> l2 >> l3;

     //   cout << l1 << endl;
      //  cout << l2 << endl;
       // cout << l3 << endl;
        int dotCount = 0;
        int xCount = 0;
        int zCount = 0;
        int xWin = 0;
        int zWin = 0;
        int xWinHorz = 0;
        int xWinVert = 0;
        int xWinDiag = 0;
        int zWinHorz = 0;
        int zWinVert = 0;
        int zWinDiag = 0;

        for(int i=0; i<3; ++i){
            if(l1[i] == 'X') xCount++;
            if(l1[i] == '.') dotCount++;
            if(l1[i] == '0') zCount++;

            if(l2[i] == 'X') xCount++;
            if(l2[i] == '.') dotCount++;
            if(l2[i] == '0') zCount++;

            if(l3[i] == 'X') xCount++;
            if(l3[i] == '.') dotCount++;
            if(l3[i] == '0') zCount++;
        }

        //check horizontal
        if(l1 == "XXX"){ xWin++; xWinHorz++;}
        if(l2 == "XXX") { xWin++; xWinHorz++;}
        if(l3 == "XXX") { xWin++; xWinHorz++;}

        if(l1 == "000") {zWin++; zWinHorz++;}
        if(l2 == "000") {zWin++; zWinHorz++;}
        if(l3 == "000") {zWin++; zWinHorz++;}

        // check vertical
        for(int i=0; i<3; ++i){
            if(l1[i] == l2[i] && l2[i] == l3[i]){
                if(l1[i] == 'X'){
                    xWin++; xWinVert++;
                } else if(l1[i] == '0'){
                    zWin++; zWinVert++;
                }
            }
        }

        // check diagonals
        if(l1[0] == l2[1] && l2[1] == l3[2]){
            if(l1[0] == 'X'){
                xWin++; xWinDiag++;
            } else if(l1[0] == '0'){
                zWin++; zWinDiag++;
            }
        }

        if(l1[2] == l2[1] && l2[1] == l3[0]){
            if(l1[2] == 'X'){
                xWin++; xWinDiag++;
            } else if(l1[2] == '0'){
                zWin++; zWinDiag++;
            }
        }
        // is legal
        bool legalFinish;

        if(xWin && zWin){
            legalFinish = false;
        }  else {
            if(xWin){
                legalFinish = (xWin == 1) || (xWinHorz == 1 && xWinVert == 1) || (xWinDiag == 2) || (xWinDiag == 1 && xWinHorz==1) || (xWinDiag == 1 && xWinVert==1);
                legalFinish = legalFinish && (zCount+1 == xCount);
            } else {
                legalFinish = (zWin == 1) || (zWinHorz == 1 && zWinVert == 1) || (zWinDiag == 2) || (zWinDiag == 1 && zWinHorz==1) || (zWinDiag == 1 && zWinVert==1);
                legalFinish = legalFinish && (zCount == xCount);
            }
        }

        bool isLegal = ((xCount == zCount) || (xCount == zCount+1));
        if(isLegal){
            if(xWin + zWin){
                if(!legalFinish){
                    printf("illegal\n");
                } else if(xWin){
                    printf("the first player won\n");
                } else if(zWin){
                    printf("the second player won\n");
                }
            } else if(dotCount == 0){
                printf("draw\n");
            } else {
                 if(xCount == zCount){
                    printf("first\n");
                } else {
                    printf("second\n");
                }
            }


        } else {
            printf("illegal\n");
        }

    }

    return 0;
}
