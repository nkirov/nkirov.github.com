#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <sstream>
#include <cctype>
#include <iomanip>
#define INF 1000000000

using namespace std;
int moveX[4]= {-1,0,1,0};
int moveY[4]= {0,-1,0,1};
     int N, A,B;
     long long max1 = -999;
bool ok(int x, int y){
    if(x >= 0 && x < N && y >=0 && y < N){
        return true;
    }
    return false;
}
vector<vector<char> > m(32);
vector<vector<long long> > dist(32);
void dijkstra(pair<int,int> source){
    for(int i = 0; i < dist.size(); i++){
        for(int j = 0; j < dist.size(); j++){
            dist[i].push_back(INF);
        }
    }
    priority_queue<pair<int, pair<int,int> >,vector< pair<int, pair<int,int> > >, greater<pair<int, pair<int,int> > > > q;
    dist[source.first][source.second] = 0;
    q.push(make_pair(0, source));

    while(!q.empty()){
        pair<int, pair<int,int> > curr = q.top();
        q.pop();
        if(curr.first > dist[curr.second.first][curr.second.second]){
            continue;
        }

        for(int i = 0; i < 4; i++){
            int newX = curr.second.first + moveX[i];
            int newY = curr.second.second + moveY[i];
            int w = 0;
            if(ok(newX, newY)){
                if(m[curr.second.first][curr.second.second] == m[newX][newY]){
                    w = A;
                }else{
                    w = B;
                }
                if(dist[curr.second.first][curr.second.second] + w < dist[newX][newY]){
                    dist[newX][newY] = dist[curr.second.first][curr.second.second] + w;
                    q.push(make_pair(dist[newX][newY], make_pair(newX, newY)));
                }
            }

        }
    }

    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            max1 = max(max1, dist[i][j]);
        }
    }
}
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.11.22\\a.txt", "r", stdin);
    int TC;
    cin >> TC;
    while(TC--){
        m.clear();
        m.resize(32);
        max1 = -999;
        cin >> N >> A >> B;
        char c;
        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                cin >> c;
                m[i].push_back(c);
            }
        }

        for(int i = 0; i < N; i++){
            for(int j = 0; j < N; j++){
                pair<int, int> source = make_pair(i,j);
                dist.clear();
                dist.resize(32);
                    dijkstra(source);
            }
        }

        cout << max1 <<endl;
    }

    return 0;
}
