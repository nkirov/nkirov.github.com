#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <sstream>
#include <cctype>

using namespace std;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.11.22\\d.txt", "r", stdin);
       int n;
       cin >> n;
    while(n != 0 ){
        vector<int> nums;
        for(int i = 0; i < n; i++){
            int curr;
            cin >> curr;
            nums.push_back(curr);
        }

        vector<int> lis(nums.size());
        lis[0] = 1;
        int cnt = 1;
        for(int i = 1; i < nums.size(); i++){
            if(nums[i] > nums[i-1]){
                cnt++;
                lis[i] = cnt;
            }else{
                cnt = 1;
                lis[i] = cnt;
            }
        }

        int max1 = lis[0];
        for(int i = 1; i < lis.size(); i++){
            max1 = max(max1, lis[i]);
        }

        cout << max1 << endl;
        cin >> n;
    }

    return 0;
}
