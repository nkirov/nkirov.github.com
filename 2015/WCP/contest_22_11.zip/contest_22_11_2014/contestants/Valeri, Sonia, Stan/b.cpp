#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <sstream>
#include <cctype>

using namespace std;

int n,k;

bool can(int mid)
{
    int sum = 0;
    int power = 1;
    while(sum < n)
    {
        sum += mid/power;
        power *= k;
        if(mid/power == 0)
        {
            break;
        }
    }
    if(sum < n)
    {
        return false;
    }
    return true;
}

int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\2014.11.22\\b.txt", "r", stdin);
    int l, r, mid;
    while(scanf("%d %d", &n, &k) == 2)
    {
        int ans = 0;
        l = 1;
        r = n + 1;
        //while(l != r)
        for(int i = 0; i < 40; i++)
        {
            mid = (l+r)/2;
            if(can(mid))
            {
                ans = mid;
                r = mid -1;
            }
            else
            {
                l = mid +1;
            }
        }
        cout << ans << endl;

    }

    return 0;
}
