#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <sstream>
#include <cctype>

using namespace std;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2014.11.22\\h.txt", "r", stdin);
        int n,m,a,b;
    while( scanf("%D %D %D %D",&n,&m,&a,&b) == 4 ){
        pair<int, int> rate1 = make_pair(1, a);
        pair<int, int> rate2 = make_pair(m, b);

        bool use_rate2 = false;
        int na = n*a;

        if(a*m > b){
            use_rate2 = true;
        }

        int cntProm = 0;
        if(n <= m){
            cntProm = 1;
        }else{
            cntProm = n/m;
        }

        int rest = (n - cntProm*m);
        int cntPlusRest = cntProm*b + max(rest, 0)*a;
        int cntPromPlus1 = (cntProm + 1)*b;

        int min1 = min(cntPromPlus1,min(cntPlusRest,na));

        printf("%d\n", min1);
    }

    return 0;
}
