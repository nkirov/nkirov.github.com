#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <sstream>
#include <cctype>
#include <iomanip>

using namespace std;

int main()
{
   //freopen("C:\\Users\\Administrator\\Desktop\\2014.11.22\\f.txt", "r", stdin);
    int r, t, k, n, tc = 0;
    string str, name;
    //getline(cin, str);
    getline(cin, str);
    while(!feof(stdin))
    {
    vector<pair<pair<int, int>, string> > val;
    vector<pair<pair<int, int>, string> >::iterator it;
        tc++;
        n = 0;

        istringstream inp;


        inp.str("");
        inp.clear();
        inp.str(str);
        inp >> r>> t>> name;
        do
        {
            getline(cin, str);
            //cout << str << endl;
            inp.str("");
            inp.clear();
            inp.str(str);
            n++;
            val.push_back(make_pair(make_pair(-r,t), name));
        }
        while((inp >> r) && (inp >> t) && (inp >> name));
        k = r;
         /* for(int i=0; i<val.size(); ++i){
            cout << " " << val[i].first.second;
        }
        cout << endl;*/
        sort(val.begin(), val.end() );

        //print
        printf("Summary for contest %d (top %d of %d participants):\n\n", tc, k, n);
        for(int i = 0; i < 27; i++)
        {
            cout << '-';
        }
        cout << endl;
        printf("| #|      name|tasks| time|\n");
        for(int i = 0; i < 27; i++)
        {
            cout << '-';
        }
        cout << endl;

        it = val.begin();
        int iter = 1;

        while(iter <= k)
        {

            cout << "|" << right << setw(2) << iter << "|";
            cout <<left<< setw(10) << it->second <<  "|";
            cout <<right<< setw(5) << (-1) * it->first.first << "|";
            cout << setw(5) << it->first.second << "|" << endl;
            iter++;
            it++;
        }
        for(int i = 0; i < 27; i++)
        {
            cout << '-';
        }
        cout << endl;

        getline(cin, str);
        if(str == ""){
            break;
        }else{
            cout << endl;
        }

    }


    return 0;
}
