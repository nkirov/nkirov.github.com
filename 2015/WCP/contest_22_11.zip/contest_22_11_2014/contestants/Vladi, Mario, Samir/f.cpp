#include <string>
#include <iostream> 
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <map>
#include <sstream>
#include <iterator>
#include <set>
#include <utility>
#include <bitset>
#include <cstring>
#include <queue>
using namespace std;
#define pb push_back;
#define fi first;
#define se second;
#define _CRT_SECURE_NO_WARNINGS
#define INF 1000000000;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector< vector<int> > vvi;
typedef map<string, int> msi;
typedef map<int, string> mis;
typedef priority_queue <pair <int, ii > > pqpi;


struct reslt
{
	string name;
	int tasks;
	int time;
};


bool cmp(reslt a, reslt b)
	{
		if(a.tasks == b.tasks)
		{
			if(a.time == b.time)
			{
				return a.name < b.name;
			}
			else
				return a.time < b.time;
		}
		else
			return a.tasks > b.tasks;
	}



reslt allResults[200];

int main()
{
	int r, arrSize = 0, index = 1;

	while(cin >> r)
	{
		char ch;
		ch = getchar();
		if(ch == '\n')
		{
			cout << "Summary for contest " << index << " (top " << r << " of " << arrSize << " participants):" << endl;
			cout << endl;
			cout << "---------------------------"<<endl;
			cout <<"| #|" << right << setw(10) << "name"<< "|" << right << setw(5) << "tasks" <<"|"<< right << setw(5) << "time"<<"|" <<endl;
			cout << "---------------------------"<<endl;
			sort(allResults, allResults + arrSize, cmp);
			for(int i = 0; i < r;i++)
			{
				cout << "|" <<right<<setw(2)<< i+1 << "|" <<left << setw(10) << allResults[i].name << "|" << right << setw(5) << allResults[i].tasks << "|" <<right << setw(5) << allResults[i].time <<"|"<<endl;
			}
			cout << "---------------------------"<<endl;
			arrSize = 0;
			index++;
			break;
		}
		else
		{
			reslt res;
			int w;
			cin>>w;
			string q;
			cin>>q;

			res.tasks = r;
			res.time = w;
			res.name = q;

			allResults[arrSize] = res;
			arrSize++;
			//cout << r << " " << w << " "<< q << endl;
		}
	}



	while(cin >> r)
	{
		char ch;
		ch = getchar();
		if(ch == '\n')
		{
			cout << endl;
			cout << "Summary for contest " << index << " (top " << r << " of " << arrSize << " participants):" << endl;
			cout << endl;
			cout << "---------------------------"<<endl;
			cout <<"| #|" << right << setw(10) << "name"<< "|" << right << setw(5) << "tasks" <<"|"<< right << setw(5) << "time"<<"|" <<endl;
			cout << "---------------------------"<<endl;
			sort(allResults, allResults + arrSize, cmp);
			for(int i = 0; i < r;i++)
			{
				cout << "|" <<right<<setw(2)<< i+1 << "|" <<left << setw(10) << allResults[i].name << "|" << right << setw(5) << allResults[i].tasks << "|" <<right << setw(5) << allResults[i].time <<"|"<<endl;
			}
			cout << "---------------------------"<<endl;
			arrSize = 0;
			index++;
		}
		else
		{
			reslt res;
			int w;
			cin>>w;
			string q;
			cin>>q;

			res.tasks = r;
			res.time = w;
			res.name = q;

			allResults[arrSize] = res;
			arrSize++;
			//cout << r << " " << w << " "<< q << endl;
		}
	}

	return 0;
}
