#include <string>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <map>
#include <sstream>
#include <iterator>
#include <set>
#include <utility>
#include <bitset>
#include <cstring>
#include <queue>
using namespace std;
#define pb push_back;
#define fi first;
#define se second;
#define _CRT_SECURE_NO_WARNINGS
#define INF 1000000000;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector< vector<int> > vvi;
typedef map<string, int> msi;
typedef map<int, string> mis;
typedef priority_queue <pair <int, ii > > pqpi;

ll n,k,hi,lo,v,best;

ll calcPow(ll k,ll pow ){
    long long rezz = k;
    if ( pow == 1 ){
        return k;
    }
    for ( int i = 1; i< pow; i++ ){
        rezz *= k;
    }
    return rezz;

};

bool can( ll v ){

    ll r = v;
	 ll tmp;
    ll pow = 1;
    do {
        tmp = v / calcPow(k,pow);
        r += tmp;
        pow++;
    }while(tmp > 0);
    return (r>=n);
};


int main()
{
    while (cin >> n ){
        if ( n == 0 ){
            break;
        }
        cin >> k;
        hi = n;
        lo = 0;
        v = n/2;

        while(lo <= hi){
            if ( can(v) ){
                best = v;
                hi = v-1;
                v = ( lo + hi ) / 2;
            }else{
                lo = v+1;
                v = (lo + hi)/2;
            }
        }
        cout << best << endl;


    }


	return 0;
}


























