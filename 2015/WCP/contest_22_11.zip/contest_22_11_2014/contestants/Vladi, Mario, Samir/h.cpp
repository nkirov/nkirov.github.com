#include <string>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <map>
#include <sstream>
#include <iterator>
#include <set>
#include <utility>
#include <bitset>
#include <cstring>
#include <queue>
using namespace std;
#define pb push_back;
#define fi first;
#define se second;
#define _CRT_SECURE_NO_WARNINGS
#define INF 1000000000;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector< vector<int> > vvi;
typedef map<string, int> msi;
typedef map<int, string> mis;
typedef priority_queue <pair <int, ii > > pqpi;

int n,m,a,b;
int best;

int main()
{
	while(cin >> n >> m >> a >> b)
    {
        best = n*a;
        int x = (n/m)*b + (n%m)*a;
        if(x < best) { best = x; }
        int rr = (n/m)*b + b;
        if(best > rr) {best = rr;}
        cout << best <<endl;
    }
	return 0;
}
