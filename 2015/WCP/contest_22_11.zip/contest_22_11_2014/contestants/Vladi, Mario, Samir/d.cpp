#include <string>
#include <iostream> 
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <vector>
#include <iomanip>
#include <cmath>
#include <map>
#include <sstream>
#include <iterator>
#include <set>
#include <utility>
#include <bitset>
#include <cstring>
#include <queue>
using namespace std;
#define pb push_back;
#define fi first;
#define se second;
#define _CRT_SECURE_NO_WARNINGS
#define INF 1000000000;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector< vector<int> > vvi;
typedef map<string, int> msi;
typedef map<int, string> mis;
typedef priority_queue <pair <int, ii > > pqpi;



int main(){

	int n;
	while(cin >> n)
	{
		int bestlen= 1;
		int pastlen=1;
		if(n==0)
		{
			break;}
		else
		{
			vector<int> a;
			a.clear();
			for(int i = 0; i < n;i++)
			{
				int w;cin>>w;
				a.push_back(w);
			}
			for(int i = 1 ;i  < a.size();i++)
			{
				if(a[i-1] < a[i])
				{
					bestlen++;
				}
				else
				{
					if(pastlen < bestlen)
					{
						pastlen = bestlen;
						bestlen = 1;
					}
					else{
					bestlen = 1;
					}
				}
			}
		}
		if(bestlen < pastlen)
		{
			cout << pastlen << endl;
		}
		else
		{
			cout << bestlen << endl;
		}
	}

	return 0;
}
