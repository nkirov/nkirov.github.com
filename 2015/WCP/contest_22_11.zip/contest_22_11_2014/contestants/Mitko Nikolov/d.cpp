#include <iostream>
using namespace std;


int main()
{
int num;


while(cin>>num)
{
	int alti[100000]={0};
	int proud[100000]={0};
	if(num==0)
	{
		exit(0);
	}
	else
	{
		// Inputting values
		for(int i=0; i<num; i++)
		{
			cin>>alti[i];
		}

		//Processing them
		int i=0, p=0;
		while(i<num-1)
		{
			if(alti[i]<alti[i+1])
			{
				proud[p]++;
				i++;
			}
			else
			{
				proud[p]++;
				p++;
				i++;
			}
		}

		// Finding the maximum
		int max=0;
		for(int i=0; i<p-1; i++)
		{
		
		if((proud[i]>=proud[i+1]) && (proud[i]>max))
		{
		max=proud[i];
		}
		else  if ((proud[i+1]>proud[i]) && (proud[i+1]>max))
		{
		max=proud[i+1];
		}
		
		
		//cout<<proud[i]<<endl;
			
		}
		//cout<<endl<<endl;
		cout<<max<<endl;
		
		
	}

}

return 0;
}

