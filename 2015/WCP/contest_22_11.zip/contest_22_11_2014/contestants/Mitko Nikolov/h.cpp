#include <iostream>
using namespace std;

int main()
{
	int n, m, a, b;
	while(cin>>n>>m>>a>>b)
	{
	int price1=0;
	
	if((b/m)<a)
	{
		while((n-m)>=0)
		{
		n=n-m;
		price1=price1+b;
		}
		//cout<<n;

		if(n!=0)
		{
			if((n*a)<b)
			{
				while(n!=0)
				{
				n=n-1;
				price1=price1+a;
				}
			}
			else
			{
				price1=price1+b;
			}
		}

	}
	else
	{
		while(n!=0)
		{
		n=n-1;
		price1=price1+a;
		}
	}


	cout<<price1<<endl;
	}
	//system("pause");

	return 0;
}
