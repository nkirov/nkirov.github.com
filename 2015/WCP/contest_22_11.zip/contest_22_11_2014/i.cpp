//http://codeforces.com/contest/3/problem/C

#include <stdio.h>
using namespace std;

char bord[5][5];

bool check(char s) 
{
    if (bord[1][1] == s && bord[2][1] == s && bord[3][1] == s)
        return true;
    
	if (bord[1][2] == s && bord[2][2] == s && bord[3][2] == s)
        return true;
    
	if (bord[1][3] == s && bord[2][3] == s && bord[3][3] == s)
        return true;
    
	if (bord[1][1] == s && bord[1][2] == s && bord[1][3] == s)
        return true;
    
	if (bord[2][1] == s && bord[2][2] == s && bord[2][3] == s)
        return true;
    
	if (bord[3][1] == s && bord[3][2] == s && bord[3][3] == s)
        return true;
    
	if (bord[3][1] == s && bord[2][2] == s && bord[1][3] == s)
        return true;
    
	if (bord[1][1] == s && bord[2][2] == s && bord[3][3] == s)
        return true;
    
	return false;
}

int main() 
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		bool ok = false;
		int sumX = 0, sumO = 0;
		scanf("%s", bord[1] + 1);
		scanf("%s", bord[2] + 1);
		scanf("%s", bord[3] + 1);

		for (int i = 1; i <= 3; i++) 
			for (int j = 1; j <= 3; j++)
			{
				if (bord[i][j] == 'X') 
					sumX++;

				if (bord[i][j] == '0') 
					sumO++;
			}
		
		if (sumX - sumO >= 2 || sumX < sumO)
			puts("illegal");
		else if (check('X') && check('0'))
			puts("illegal");
		else if (sumX > sumO && check('0'))
			puts("illegal");
		else if (sumX == sumO && check('X'))
			puts("illegal");
		else if (check('X'))
			puts("the first player won");
		else if (check('0'))
			puts("the second player won");
		else if (sumX + sumO == 9)
			puts("draw");
		else if (sumX > sumO)
			puts("second");
		else if (sumX == sumO)
			puts("first");
	}

    return 0;
}
