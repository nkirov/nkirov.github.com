#include <cstdlib>
#include <iostream>
#include <stack>
using namespace std;

double calculator()
{
    stack <double> number_st;
    stack <char> operat_st;
    double curr_number = 0.0;
    cin >> curr_number;
    number_st.push(curr_number);
    char curr_operat = '\0';
    cin >> curr_operat;
    operat_st.push(curr_operat);
    
    while(true)
    {
        char test;
        cin.get(test);
        if (test == '\n')
        {
            cin.unget();
            break;
        }
        else if (test >= '0' && test <= '9')
        {
            cin.unget();
            cin >> curr_number;
            if (operat_st.top() == '*')
            {
                operat_st.pop();
                number_st.top() = number_st.top() * curr_number;
            }
            else if (operat_st.top() == '/')
            {
                operat_st.pop();
                number_st.top() = number_st.top() / curr_number;
            }
            else if (operat_st.top() == '-')
            {
                operat_st.top() = '+';
                number_st.push((-1) * curr_number);
            }
            else
            {
                number_st.push(curr_number);
            }
        }
        else
        {
            cin.unget();
            cin >> curr_operat;
            operat_st.push(curr_operat);
        }   
    }
    
    while(!operat_st.empty())
    {
        if (operat_st.top() == '+')
        {
            double numb_right = number_st.top();
            number_st.pop();
            double numb_left = number_st.top();
            number_st.pop();
            number_st.push(numb_left + numb_right);            
        }
        else if (operat_st.top() == '-')
        {
            double numb_right = number_st.top();
            number_st.pop();
            double numb_left = number_st.top();
            number_st.pop();
            number_st.push(numb_left - numb_right);            
        }
        operat_st.pop();
    }
    return number_st.top();
}

int main()
{
	ios_base::sync_with_stdio(false);

    int t;
    cin >> t;
    for (int i = 0; i < t; i++)
        cout << calculator() << endl; 
    
    return 0;
}
