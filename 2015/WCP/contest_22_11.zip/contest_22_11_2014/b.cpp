/*
http://codeforces.com/problemset/problem/165/B

This problem can be solved using binary search for the answer. 
Obviously, if number v is an answer than every number w > v is also the answer, because the number of written lines of code could only become more. 
To check some number v you can use formula given in the problem, because it will have less than O(logN) positive elements. The complexity is O(log^2 (N)).
*/

#include <iostream>
using namespace std;

typedef long long ll;

int main() 
{
	ios_base::sync_with_stdio(false);

    ll n, k;

    while(cin >> n >> k && n)
	{
		ll l = 1, r = n + 1;
		while(l < r) 
		{
			ll av = (l + r) / 2;
			ll val = 1;
			ll cnt = 0;
			while(av / val > 0 && cnt < n) 
			{
				cnt += av / val;
				val *= k;
			}
			
			if(cnt >= n) 
				r = av;
			else 
				l = av + 1;
		}

		cout << r << endl;
	}

    return 0;
}
