﻿//http://codeforces.com/contest/466/problem/A
//http://codeforces.com/blog/entry/13758

#include <iostream>
using namespace std;

#define MAXN 100005
int dp[MAXN];
int n, m, a, b;

int main()
{
    ios_base::sync_with_stdio(false);

    while(cin >> n >> m >> a >> b)
	{	
		dp[0] = 0;
		for(int i = 1;i <= n;i++)
		{
			dp[i] = dp[i - 1] + a;
			dp[i] = min(dp[i], dp[max(i - m, 0)] + b);
		}

		cout << dp[n] << endl;
	}

    return 0;
}