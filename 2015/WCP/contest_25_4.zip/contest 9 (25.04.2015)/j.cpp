#include <iostream>
#include <string>
using namespace std;

int main()
{ 
	ios::sync_with_stdio(0);
	cin.tie(0);

	string s;
	while(getline(cin, s))
	{
		int sum = 0, k;
		for(int i = 0;i < 9;i++)
			if(s[i] == '*') 
				k = i;
		else 
			sum += (10 - i) * (s[i] - '0');
		
		if(s[9] == '*') 
			k = 9;
		else if(s[9] == 'X') 
			sum += 10;
		else 
			sum += (s[9]-'0');
		
		int dmax;
		if(k < 9) 
			dmax = 9;
		else 
			dmax = 10;

		for(int d = 0; d <= dmax; d++)
			if((sum + (10 - k) * d) % 11 == 0)
				if(d < 10) 
					cout << d << endl;
				else 
					cout << 'X' << endl;
	}
	
	return 0;
}
