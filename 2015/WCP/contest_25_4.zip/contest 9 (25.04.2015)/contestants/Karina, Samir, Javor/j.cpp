#include <iostream>
#include <cstring>
#include <sstream>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
using namespace std;

string line;

void solve(){
    int sum = 0;
    int mis = 0;
    for (int i = 0; i < 11; i++){
        if (line[i] == '*') mis = 10 - i;
        else {
           if (line[i] != 'X')
                sum += (line[i] - '0')*(10 - i);
            else
                sum += 10;
        }
    }
    int r = (11 - sum%11)%11;
     for(int i = 0;i <= 10; i++){
        if ((i*mis)%11 == r){
            if (i == 10)cout << 'X' << endl;
           else  cout << i << endl;
            return;
        }
    }
}

int main()
{
  while (cin >> line){
    solve();
  }
    return 0;
}
