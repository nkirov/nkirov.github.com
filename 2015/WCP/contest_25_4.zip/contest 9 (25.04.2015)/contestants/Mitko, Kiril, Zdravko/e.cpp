#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long data;

bool canDoIt(vector<data>& A, data sum)
{
    data csum = 0;
    for(int i = 0; i < A.size(); i++)
    {
        csum += A[i];
        if(csum > sum)
            return false;

        if(csum == sum)
            csum = 0;
    }
    if(csum > 0)
        return false;

    return true;
}

void run()
{
    int N, tc;
    cin >> tc >> N;
    vector<data>A(N);
    for(int i = 0; i < N; i++)
    {
        cin >> A[i];
    }
    data csum = 0;
    for(int i = 0; i < A.size(); i++) {
        csum += A[i];
        if(canDoIt(A, csum)) {
            cout << tc  << " " <<csum << endl;
            break;
        }
    }
}

int main()
{
    cin.sync_with_stdio(false);
    int t;
    cin >> t;
    while(t--)run();
    return 0;
}
