#include <iostream>
#include <string>

using namespace std;

int digit(char c)
{
    if(c =='*')
        return -1;
    else if(c == 'X')
        return 10;
    else
        return c - '0';

}

int findx(string &isbn)
{
    for(int i=0;i<isbn.length(); i++)
        if(isbn[i] == '*')
            return i;
    return -1;
}

bool check(string &isbn, int xValue)
{
    int result=0;
    for(int m=10; m>0; m--)
    {
        int d = digit(isbn[isbn.length()-m]);
        if(d<0)
            d = xValue;
        result += m*d;
    }

    return (result % 11 == 0);
}

char solve(string &isbn)
{
    for(int i=0; i<11; i++)
    {
        if(check(isbn, i))
        {
            if(i == 10)
                return 'X';
            else
                return '0' + i;
        }
    }
    return '!';
}

int main()
{
    string isbn;
    while(cin >> isbn)
    {
        char ans = solve(isbn);
        cout << ans << endl;
    }
    return 0;
}
