import java.util.*;

//cout << "indToCheck=" << indToCheck << endl;
//cout << "pathSoFar.size()=" << pathSoFar.size() << endl;
//cout << "r=" << r << endl;
//cout << "c=" << c << endl;
//cout << endl;
//cout << "Caching halfStr=" << halfStr << endl;
public class i {
 
	private static void read()
	{
		N = s.nextInt();
		s.nextLine();
	    halfPath = N - 1;

	    ans = 0;
	    _cache.clear();
	    G = new ArrayList<String>();

	    for(int i = 0; i < N; i++) {
	    	String element = s.nextLine();
	    	G.add(element);
	    }
	}
	private static Boolean isPalindrom(String s)
	{
	    for(int i = 0; i < s.length(); i++)
	    {
	        int j = s.length() - i - 1;
	        if(s.charAt(i) != s.charAt(j))
	        {
	            return false;
	        }

	        if(i > j)
	            break;
	    }
	    return true;
	}
	
	private static void visit(String pathSoFar, int r, int c)
	{
	    char newChar = G.get(r).charAt(c);

	    if(pathSoFar.length() > halfPath)
	    {
	        int indToCheck = 2 * halfPath - pathSoFar.length();
	        if(pathSoFar.charAt(indToCheck) != newChar){
	            return;
	        }

	        String halfStr=  pathSoFar.substring(0, halfPath+1);
	        if(_cache.contains(halfStr))
	            return;
	    }

	    pathSoFar += newChar;

	    if(r == N - 1 && c == N - 1)
	    {
	        if(isPalindrom(pathSoFar)) {
	            String halfStr = pathSoFar.substring(0, halfPath+1);
	            ans++;
	            _cache.add(halfStr);
	        }
	    }


	    if(r < N - 1) {
	        visit(pathSoFar, r + 1, c);
	    }

	    if(c < N - 1) {
	        visit(pathSoFar, r, c + 1);
	    } 
	}

	
	private static void solve()
	{
	    String path = new String(); 
	    visit(path, 0, 0);
	    System.out.println(ans);
	}

	private static int N;
	private static int halfPath;
	private static int ans;
	private static HashSet<String> _cache = new HashSet<String>();
	private static ArrayList<String> G;
	private static Scanner s = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int t;
		t = s.nextInt();
		
		for(int i =0 ;i < t; i++)
		{
			read();
			solve();
		}
	}

}
