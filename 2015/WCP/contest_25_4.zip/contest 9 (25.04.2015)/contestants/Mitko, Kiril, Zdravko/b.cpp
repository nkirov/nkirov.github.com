#include <iostream>
#include <vector>
#include <bitset>
using namespace std;

string convert_to_bin(const string& s)
{
    string result;

    int k = 0;
    for(int i = 0; i < s.size(); i++)
    {
        long cval = 0;
        if(s[i] != ' ')
            cval = s[i] - 'A' + 1;

        bitset<5> bs(cval);
        result += bs.to_string();
    }
    return result;
}

void print_data(string& v)
{
    for(int i =0 ;i < v.size(); i++)
        cout << v[i];
    cout << endl;
}

void print_A(vector<vector<char> >& A)
{
    for(int i =0 ;i < A.size(); i++)
    {
        for(int j =0 ; j < A[i].size(); j++)
            cout << A[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

void fillspiral(vector<vector<char> >& A, string& data, int R, int C)
{
    int r = 0, c = 0, k = 0;
    int maxR = R, maxC = C;
    int minR = 0, minC = 0;

    bool inserted;
    do {
        inserted = false;

        while(true)
        {
            if(c >= C || A[r][c] != 0)
                break;

            A[r][c] = (k < data.size() ? data[k++] : '0');
            inserted = true;
            c++;
        }
        c--; r++;

        while(true)
        {
            if(r >= R || A[r][c] != 0)
                break;

            A[r][c] = (k < data.size() ? data[k++] : '0');
            inserted = true;
            r++;
        }
        r--; c--;

        while(true)
        {
            if(c < 0 || A[r][c] != 0)
                break;

            A[r][c] = (k < data.size() ? data[k++] : '0');
            inserted = true;
            c--;
        }
        c++; r--;

        while(true)
        {
            if(r < 0 || A[r][c] != 0)
                break;

            A[r][c] = (k < data.size() ? data[k++] : '0');
            inserted = true;
            r--;
        }
        r++; c++;

    } while(inserted);
}

void run(int tc)
{
    int R, C;
    cin >> R >> C;
    cin.ignore();
    string message;
    getline(cin, message);

    string data = convert_to_bin(message);

    vector<vector<char> > A;
    A.resize(R);
    for(int i = 0; i < R; i++)
        A[i].resize(C);

    for(int i =0 ;i < A.size(); i++)
        for(int j =0 ; j < A[i].size(); j++)
            A[i][j] = 0;

//    print_data(data);
    fillspiral(A, data, R, C);
    //print_A(A);

    cout << tc << " ";
    for(int i =0 ;i < A.size(); i++)
        for(int j =0 ; j < A[i].size(); j++)
            cout << A[i][j];
    cout << endl;
}

int main()
{
    cin.sync_with_stdio(false);
    int t;
    cin >> t;
    for(int i = 1; i <= t; i++)
        run(i);


    return 0;
}
