#include <iostream>
#include <vector>
#include <bitset>
using namespace std;

string convert_to_bin(const string& s)
{
    string result;

    int k = 0;
    for(int i = 0; i < s.size(); i++)
    {
        long cval = 0;
        if(s[i] != ' ')
            cval = s[i] - 'A' + 1;

        bitset<5> bs(cval);
        result += bs.to_string();
    }
    return result;
}

void print_data(string& v)
{
    for(int i =0 ;i < v.size(); i++)
        cout << v[i];
    cout << endl;
}

void print_A(vector<vector<char> >& A)
{
    for(int i =0 ;i < A.size(); i++)
    {
        for(int j =0 ; j < A[i].size(); j++)
            cout << A[i][j] << " ";
        cout << endl;
    }
    cout << endl;
}

void filldata(vector<vector<char> >& A, vector<char>& data, int R, int C)
{
    int r = 0, c = 0;

    bool inserted;
    do {
        inserted = false;

        while(true)
        {
            if(c >= C || A[r][c] == 0)
                break;

            data.push_back(A[r][c]);
            A[r][c] = 0;
            inserted = true;
            c++;
        }
        c--; r++;
//        cout << "11" << endl;

        while(true)
        {
            if(r >= R || A[r][c] == 0)
                break;

            data.push_back(A[r][c]);
            A[r][c] = 0;
            inserted = true;
            r++;
        }
        r--; c--;
//        cout << "22" << endl;

        while(true)
        {
            if(c < 0 || A[r][c] == 0)
                break;

            data.push_back(A[r][c]);
            A[r][c] = 0;
            inserted = true;
            c--;
        }
        c++; r--;
//        cout << "33" << endl;

        while(true)
        {
            if(r < 0 || A[r][c] == 0)
                break;

            data.push_back(A[r][c]);
            A[r][c] = 0;
            inserted = true;
            r--;
        }
        r++; c++;
//        cout << "44" << endl;
    } while(inserted);
}

void run(int tc)
{
    int R, C;
    cin >> R >> C;
    cin.ignore();
    string message;
    getline(cin, message);

    vector<vector<char> > A;
    A.resize(R);
    for(int i = 0; i < R; i++)
        A[i].resize(C);

//    cout << "1" << endl;
    int k = 0;
    for(int i =0 ;i < A.size(); i++)
        for(int j =0 ; j < A[i].size(); j++)
            A[i][j] = message[k++];

//    cout << "2" << endl;
    vector<char> data;
    filldata(A, data, R, C);
    //print_A(A);

//    cout << "3" << endl;
    string s;
    string result;
    for(int i = 0; i < data.size(); i++){
        s.push_back(data[i]);
        if(s.size() == 5) {
            bitset<5> bs(s);
            int ival = (int)bs.to_ulong();
            if(ival == 0) {
                result += " ";
            } else {
                result += ('A' + ival - 1);
            }
            s.clear();
        }
    }

    int b=0, e=result.size()-1;
    while(b < result.size() && result[b] == ' ') b++;
    while(e >= 0 && result[e] == ' ') e--;
    cout << tc << " ";
    for(int i=b; i<=e; i++)
        cout << result[i];
    cout << endl;
}

int main()
{
    cin.sync_with_stdio(false);
    int t;
    cin >> t;
    for(int i = 1; i <= t; i++)
        run(i);


    return 0;
}

