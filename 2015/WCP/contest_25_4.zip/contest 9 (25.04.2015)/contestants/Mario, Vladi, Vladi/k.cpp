#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<deque>
#include<stack>
#include<iomanip>
#include<functional>
#include<algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int main()
{

	ios_base::sync_with_stdio(0);
	cin.tie(0);
	deque<long long> lujici, vilici;

	//freopen("K.in", "r", stdin);

	int n,m, cnt, cnt2;

	while(cin >> n)
	{
		lujici.clear();
		vilici.clear();

		if(n==0)
		{
			break;

		}

		cin >> m;
		cnt = 0;
		cnt2 = 0;

		for(int i= 0 ;i < n; i++)
		{
			int r ; cin >> r;
			lujici.push_back(r);
		}
		for(int i = 0; i < m; i++)
		{
			int r; cin >> r;
			vilici.push_back(r);
		}

		sort(lujici.begin(), lujici.end());
		sort(vilici.begin(), vilici.end());

		int initSize = vilici.size() / 2;

		for (deque<long long>::reverse_iterator it = lujici.rbegin(); it != lujici.rend(); it++)
		{
			if(cnt == initSize)
			{
				break;
			}

			if(*it < *vilici.rbegin())
			{
				vilici.pop_back();
				cnt++;
			}
		}

		for (deque<long long>::iterator it = lujici.begin(); it != lujici.end(); it++)
		{
			if(cnt2 == initSize)
			{
				break;
			}

			if(*it > *vilici.begin())
			{
				vilici.pop_front();
				cnt2++;
			}
		}

		cout << min(cnt, cnt2) << endl;
	}
	
	return 0;
}
