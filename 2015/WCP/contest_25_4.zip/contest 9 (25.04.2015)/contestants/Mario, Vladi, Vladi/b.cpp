#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>
#include<algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

char matrix[20][20];
string mapp[256];

void init()
{
	mapp[' '] = "00000";
	char ch = 'A';

	for (ch = 'A'; ch <= 'Z'; ch++)
	{
 		int i = (ch - 'A') + 1;

		while (i != 0)
		{
			mapp[ch] += (i % 2) + '0';
			i /= 2;
		}

		for (int b = mapp[ch].size(); b < 5; b++)
		{
			mapp[ch] += '0';
		}

		reverse(mapp[ch].begin(), mapp[ch].end());
	}
}

int main()
{
	//freopen("B.in", "r", stdin);
	init();
	string input, nums;
	int n, c, r, counter = 0;
	cin >> n;

	

	while(n--)
	{
		counter++;
		cin >> r >> c;
		input = "";
		nums = "";
		memset(matrix, '0', sizeof(matrix));
		getchar();
		char p = getchar();
		while(p != '\n' && p != EOF)
		{
			input+=p;
			p = getchar();
		}

		int index = 0, rb = c - 1, lb = 0, upb = 0, db = r - 1;

		for (int k = 0; k < input.size(); k++)
		{
			nums += mapp[input[k]];
		}

		if(input != "")
		{
			while(true)
		{
			int rr = upb, cc = lb; 
			
			while (cc <= rb)
			{
				matrix[rr][cc] = nums[index];
				cc++;
				index++;

				if((index >= nums.size()) || (index == (r*c)))
				{
					goto fuckYou;
				}
			}

			cc--;
			rr++;
			upb++;

			while(rr <= db)
			{
				matrix[rr][cc] = nums[index];
				rr++;
				index++;
				if((index >= nums.size()) || (index == (r*c)))
				{
					goto fuckYou;
				}
			}

			rr--;
			rb--;
			cc--;

			while (cc >= lb)
			{
				matrix[rr][cc] = nums[index];
				cc--;
				index++;
				if((index >= nums.size()) || (index == (r*c)))
				{
					goto fuckYou;
				}
			}

			cc++;
			db--;
			rr--;

			while (rr >= upb)
			{
				matrix[rr][cc] = nums[index];
				rr--;
				index++;
				if((index >= nums.size()) || (index == (r*c)))
				{
					goto fuckYou;
				}
			}

			rr++;
			lb++;
			cc++;
		}
		}	
fuckYou:
		cout << counter << " ";

		for (int row = 0; row < r; row++)
		{
			for (int col = 0; col < c; col++)
			{
				cout << matrix[row][col];
			}
		}

		cout << endl;
	}

	return 0;
}
