#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>
#include<algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	

	//freopen("J.in", "r", stdin);
	string p; int z;
	while(cin >> p)
	{
		int sum = 0 ;
		int zvezda= 0 ;
		int tempsum = 0;
		for(int i = 0 ; i < 10;i++)
		{
			if(i == 9 && p[i] == 'X')
			{
				sum+=10;
			}
			else if(p[i] != '*')
			{
				sum+= (p[i]-'0') * (10 - i); 
			}
			else if(p[i] == '*')
			{
				zvezda = i;
			}
		}
		if(zvezda == 9)
		{
			tempsum = sum;
			tempsum+=10;
			if(tempsum % 11 == 0)
			{
				cout << 'X' << endl;
			}
		}
		for(int i = 0 ; i <= 9;i++)
		{
			tempsum = sum;
			tempsum+=i*(10-zvezda);
			if(tempsum % 11 == 0)
			{
				cout << i << endl;
				break;
			}
		}
	

	}
	return 0;
}
