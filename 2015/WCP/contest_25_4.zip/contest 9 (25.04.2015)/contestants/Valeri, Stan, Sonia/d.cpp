#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <climits>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
#define INF 1e9
#define ll long long
#define ull unsigned long long

map<ll,ll> m;
vector<ll> v;
void f(ll sum,ll index, ll mask){
    //cout << index << endl;
    if(index>=v.size()) return;
    ll new_sum = sum + v[index];
    ll new_elem_val = 1 << index;
    ll new_mask =  mask | (new_elem_val);
    m[new_sum] = new_mask;
    f(sum , index+1, mask);
    f(new_sum, index+1, new_mask);
}
void print_mask(int mask){
    bool first = true;
    for(int i=0; i<v.size(); ++i){
        if(mask & (1<<i)){
            if(!first) printf(" ");
            first = false;
            printf("%d", v[i]);
        }
    }
    cout << endl;

}
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2015.04.25\\d.txt", "r", stdin);
    int TC;
    for(ll i=1; i<=4000000000; i*=3){
        v.push_back(i);
    }
    m[0] = 0;
    f(0, 0, 0);
    scanf("%d", &TC);

    while(TC--){
        char cmd; int n;
        cin >> cmd >> n;
        ll min_;
        ll min_mask;
        bool min_found = false;
        for(map<ll,ll>::iterator it = m.begin(); it!=m.end(); ++it){
            ll curr = it->first;
            ll curr_mask = it->second;
            ll comp = it->first - n;
            if(m.count( comp )){
                if(!min_found || (it->first < min_)){
                    min_found = true;
                    min_ = it->first; min_mask = it->second;
                    break;
                }
            }
        }
        if(cmd == 'L'){
            cout << "L:";
            print_mask(m[min_ - n]);
            cout << "R:"; print_mask(m[min_]);

        } else {
            cout << "L:";
            print_mask(m[min_]);
            cout << "R:"; print_mask(m[min_ - n]);
        }

    }
    return 0;
}
