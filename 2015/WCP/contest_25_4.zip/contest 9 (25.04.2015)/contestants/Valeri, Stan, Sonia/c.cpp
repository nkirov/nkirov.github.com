#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <climits>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
#define INF 1e9
#define ll long long
#define ull unsigned long long

char mat[32][32];
//prevdir 1 otlqwo
//2 otdqsno
//3 otgore
//4 otdolu
int R; int C;
int dirX[] = {0,1,0,-1};
int dirY[] = {1,0,-1,0};
  map<string, char> a;
string res = "";
string tmp = "";
bool visited[32][32];
void fillMatrix(int i, int j, int currDir){
    tmp += mat[i][j];
   // cout << mat[i][j] <<" "<< i <<" " << j <<" " << tmp << endl;
    visited[i][j] = true;
    if(tmp.size() == 5){
        res+=a[tmp];
       // cout << res << endl;
        tmp = "";
        //return;
    }

    int newI = i+dirX[currDir];
    int newJ = j+dirY[currDir];
    if(newI < 0 || newI >= R || newJ < 0 || newJ >=C || visited[newI][newJ]){
        currDir++;
        currDir = currDir%4;
    }

    newI = i+dirX[currDir];
    newJ = j+dirY[currDir];
    if(newI < 0 || newI >= R || newJ < 0 || newJ >=C ||visited[newI][newJ]){
        return;
    }
    fillMatrix(newI, newJ, currDir);
}
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2015.04.25\\b.txt", "r", stdin);
    int TC;
    cin >> TC;
    cin.get();

    a["00001"] = 'A';
    a["00010"] = 'B';
                    a["00011"] = 'C';
                    a["00100"] = 'D';
                    a["00101"] = 'E';
                    a["00110"] = 'F';
                    a["00111"] = 'G';
                    a["01000"] = 'H';
                    a["01001"] = 'I';
                    a["01010"] = 'J';
                    a["01011"] = 'K';
                    a["01100"] = 'L';
                    a["01101"] = 'M';
                    a["01110"] = 'N';
                    a["01111"] = 'O';
                    a["10000"] = 'P';
                    a["10001"] = 'Q';
                    a["10010"] = 'R';
                    a["10011"] = 'S';
                    a["10100"] = 'T';
                    a["10101"] = 'U';
                    a["10110"] = 'V';
                    a["10111"] = 'W';
                    a["11000"] = 'X';
                    a["11001"] = 'Y';
                    a["11010"] = 'Z';
                    a["00000"] = ' ';

    int t = 1;
    while(TC--){
            memset(visited, 0, sizeof(visited));
            res="";
            tmp="";
        cin >> R >> C;
        //cout << R << " " << C << endl;
        string s;
        cin >> s;
        int p = 0;
        for(int i =0 ; i < R; i++){
            for(int j = 0; j < C; j++){
                mat[i][j] = s[p];
              //  cout <<" a" << s[p] << endl;
                p++;
            }
        }

        fillMatrix(0,0,0);
        int b = 0; int e = res.size()-1;
        while(res[b] == ' ') b++;
        while(res[e]==' ') e--;
        cout << t << " ";
        for(int i = b; i <= e; i++){
            cout << res[i];
        }
        cout << endl;
        t++;
    }
    return 0;
}
