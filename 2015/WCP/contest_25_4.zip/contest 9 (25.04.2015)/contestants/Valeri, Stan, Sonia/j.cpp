#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <climits>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
#define INF 1e9
#define ll long long
#define ull unsigned long long

const int MAX = 100001;
int used[MAX];
int prime[MAX];
vector<int> primes;

int main()
{
  //  freopen("C:\\Users\\Administrator\\Desktop\\2015.04.25\\j.txt", "r", stdin);
    string s;
    while(cin >> s){
        int sum = 0;
        int star;
        for(int i=0; i<s.size(); ++i){
            if(s[i]=='*'){
                star = i;
            } else if(s[i]=='X'){
                sum+= (10-i) * 10;
            } else {
                sum+= (10 -i)* (s[i]-'0');
            }
        }
        int e = star == 9? 10 : 9;
        for(int i=0; i<=e; ++i){
            if((sum + (10-star)*i)%11 == 0){
                if(i == 10){
                    cout << "X" << endl;
                } else {
                    cout << i << endl;
                }
                break;
            }
        }
    }

    return 0;
}
