#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <climits>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
#define INF 1e9
#define ll long long
#define ull unsigned long long

int mat[32][32];
//prevdir 1 otlqwo
//2 otdqsno
//3 otgore
//4 otdolu
int R; int C;
int dirX[] = {0,1,0,-1};
int dirY[] = {1,0,-1,0};
void fillMatrix(string s, int pos, int i, int j, int currDir){
    if(pos >= s.size()){
        return;
    }
    int c1 = s[pos]- '0';
    mat[i][j] = c1;
    int newI = i+dirX[currDir];
    int newJ = j+dirY[currDir];
    if(newI < 0 || newI >= R || newJ < 0 || newJ >=C || mat[newI][newJ] != -1){
        currDir++;
        currDir = currDir%4;
    }

    newI = i+dirX[currDir];
    newJ = j+dirY[currDir];
    fillMatrix(s, pos+1, newI, newJ, currDir);
}
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\2015.04.25\\b.txt", "r", stdin);
    int TC;
    cin >> TC;
    cin.get();
    string a[27] = {"00001",
                    "00010",
                    "00011",
                    "00100",
                    "00101",
                    "00110",
                    "00111",
                    "01000",
                    "01001",
                    "01010",
                    "01011",
                    "01100",
                    "01101",
                    "01110",
                    "01111",
                    "10000",
                    "10001",
                    "10010",
                    "10011",
                    "10100",
                    "10101",
                    "10110",
                    "10111",
                    "11000",
                    "11001",
                    "11010"
                    "00000",
                    };

    int t = 1;
    while(TC--){
        string line;
        getline(cin, line);
        istringstream ss(line);
        string s = "";

        ss >> R >> C;
       // cout << R << C;
        getline(ss, s);
       // cout << s << endl;
        memset(mat, -1, sizeof(mat));
        string res = "";
        for(int i =1; i < s.size(); i++){
               // cout <<"B " << res << endl;
            if(s[i] != ' '){
                res+=a[s[i] - 'A'];
            }else{
                res+="00000";
            //cout << res << endl;
            }
        }
       // cout << res << endl;
        fillMatrix(res,0,0,0,0);
        for(int i = 0; i < R; i++){
            for(int j = 0; j < C; j++){
                if(mat[i][j] == -1){
                    mat[i][j] = 0;
                }
            }
        }
        cout << t <<  " ";
        for(int i = 0; i < R; i++){
            for(int j = 0; j < C; j++){
                cout << mat[i][j];
            }
        }
        cout << endl;
        t++;
    }
    return 0;
}
