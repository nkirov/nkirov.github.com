/*
Adopted from USACO 2015 US Open, Bronze Problem 4. Palindromic Paths (Bronze) - http://www.usaco.org/index.php?page=viewproblem2&cpid=548
Analysis - http://www.usaco.org/current/data/sol_palpath_bronze.html

See also the GOLD version of the problem -http://www.usaco.org/index.php?page=viewproblem2&cpid=553 and it's analysis - http://www.usaco.org/current/data/sol_palpath_gold.html
*/

import java.io.*;
import java.util.*;

public class i {
  static int n, t;
  static Set<String>[] rows1, rows2;
  
  @SuppressWarnings("unchecked")
public static void main(String[] args) throws IOException {
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    t = Integer.parseInt(br.readLine());
    while(t-- > 0){
    n = Integer.parseInt(br.readLine());
    char[][] grid = new char[n][n];
    // rows1[a] stores all strings from the top-left corner to
    // the square on the diagonal at row a
    rows1 = new HashSet[n];
    // rows2[a] stores all strings from the bottom-right corner to
    // the square on the diagonal at row a
    rows2 = new HashSet[n];
    for(int a = 0; a < n; a++) {
      rows1[a] = new HashSet<String>();
      rows2[a] = new HashSet<String>();
    }
    for(int i = 0; i < n; i++) {
      String s = br.readLine();
      for(int j = 0; j < n; j++) {
        grid[i][j] = s.charAt(j);
      }
    }

    // by rotating the grid twice, I could reuse the dfs function
    // instead of having to write a second one that goes up and left
    dfs(grid, 0, 0, rows1, "");
    transpose(grid);
    dfs(grid, 0, 0, rows2, "");
    
    Set<String> ans = new HashSet<String>();
    for(int a = 0; a < n; a++) {
      for(String s: rows1[a]) {
        // check if a string can be generated from both corners
        if(rows2[a].contains(s)) {
          ans.add(s);
        }
      }
    }
    System.out.println(ans.size());
    }
  }
  
  public static void dfs(char[][] grid, int x, int y, Set<String>[] sets, String curr) {
    if(x + y == n-1) {
      sets[x].add(curr + grid[x][y]);
    }
    else {
      dfs(grid, x+1, y, sets, curr + grid[x][y]);
      dfs(grid, x, y+1, sets, curr + grid[x][y]);
    }
  }
  
  // this makes column n of the grid row (n+1-i)
  public static void transpose(char[][] grid) {
    for(int i = 0; i < n; i++) {
      for(int j = 0; j < n; j++) {
        if(i + j >= n-1) continue;
        char t = grid[i][j];
        grid[i][j] = grid[n-1-j][n-1-i];
        grid[n-1-j][n-1-i] = t;
      }
    }
  }
}