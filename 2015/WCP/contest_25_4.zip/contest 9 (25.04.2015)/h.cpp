/*
Adopted from USACO 2015 US Open, Silver, Problem 3. Bessie's Birthday Buffet - http://www.usaco.org/index.php?page=viewproblem2&cpid=551
Analysis - http://www.usaco.org/current/data/sol_buffet_silver.html
*/

#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <memory.h>
using namespace std;

#define MAXN 1010
int Q[MAXN];
int DP[MAXN];
int D[MAXN];
		
bool cmp (const int &x, const int &y)
{
	return Q[x] < Q[y];
}

int main() 
{
	ios::sync_with_stdio(0);
	cin.tie(0);

	int t;
	cin>>t;
	while(t--)
	{
		memset(DP, 0, sizeof DP);

		int N, ECST;
		cin >> N >> ECST;
		
		vector<vector<int> > E = vector<vector<int> >(MAXN);

		for (int i = 0; i < N; i++) 
		{
			int D;
			cin >> Q[i] >> D;
			for (int j = 0; j < D; j++) 
			{
				int v;
				cin >> v;
				E[i].push_back(v - 1);
			}
		}

		vector<int> PI;
		for (int i = 0; i < N; i++) 
			PI.push_back(i);
		
		sort(PI.begin(), PI.end(), cmp);

		int result = 0;
		for (int i = N - 1; i >= 0; i--) 
		{
			int u = PI[i];
			queue<int> q;
			memset(D, -1, sizeof(D));
			q.push(u);
			D[u] = 0;
			while (!q.empty()) 
			{
				int v = q.front();
				q.pop();
				for (int i = 0; i < E[v].size(); i++) 
				{
					int nv = E[v][i];
					if (D[nv] == -1) 
					{
						D[nv] = D[v] + 1;
						q.push(nv);
					}
				}
			}

			int res = Q[u];
			for (int j = 0; j < N; j++) 
				if (D[j] != -1) 
					res = max(res, Q[u] + DP[j] - ECST * D[j]);
			
			DP[u] = res;
			result = max(result, res);
		}

		cout << result << endl;
	}
	
	return 0;
}