#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <climits>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
#define INF 1e9
#define ll long long
#define ull unsigned long long

int arr[10050];
int cum[10050];
int c[100000005];
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\2015.04.25\\e.txt", "r", stdin);
    int TC;
    scanf("%d", &TC);
    while(TC--){
        memset(cum, 0, sizeof(cum));
        memset(c, 0 ,sizeof(c));
        int test, n;
        scanf("%d %d", &test, &n);
        int max_num = -9999;
        for(int i=0; i<n; ++i){
            scanf("%d", &arr[i]);
            max_num = max(max_num, arr[i]);
        }
        cum[0] = arr[0];
        int max_cum = cum[0];
        for(int i=1; i<n; ++i){
            cum[i] = cum[i-1] + arr[i];
            max_cum = max(max_cum, cum[i]);
        }
        for(int i=0; i<n; ++i){
            c[cum[i]] = 1;
        }
        for(int i=0; i<n; ++i){
            int k;
          if(cum[i]<max_num) continue;
          //  cout <<" asd " << cum[i] << endl;
            for(k= cum[i]; k<=max_cum; k+=cum[i]){
                if(c[k]==0){
                    break;
                }
            }
            if(k>= max_cum && max_cum%cum[i]==0){
                printf("%d %d\n", test, cum[i]);
                break;
            }
        }


    }
    return 0;
}
