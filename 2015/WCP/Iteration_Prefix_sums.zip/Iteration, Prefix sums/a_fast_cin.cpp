﻿#include <iostream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <memory.h>
using namespace std;
#define MAXN 100005

double sums[MAXN];
string s;
int n;

inline double query(int idx1, int idx2)
{
    return sums[idx2] - (idx1 > 0 ? sums[idx1 - 1] : 0.0);
}

int main()
{
	cin.sync_with_stdio(false);
	cout << fixed << setprecision(3);

	while (getline(cin, s))
	{
		//init
		n = 0; 
		memset(sums, 0, sizeof sums);

		double d;
		
		sums[n++] = 0;
		istringstream instr(s);
		instr >> d;
		sums[n++] = d;

		//read all elements and prepare prefix sums 
		while(instr >> d) 
			sums[n++] = d + sums[n - 1]; 

		int p, q;
		while(cin>>p && p)
		{
			cin>>q;
			cout<<query(p, q)<<endl;
		}

		cin.get();
	}
	
	return 0; 
}