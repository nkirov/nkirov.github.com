﻿#include <stdio.h>
#include <memory.h>

#define MAXN 100005

int count[MAXN];

int main()
{
	int T;
	scanf("%d", &T);
	for (int t = 1;t <= T; t++)
	{
		memset(count, 0, sizeof count);
		
		int n, a;
		scanf("%d", &n);

		for(int i = 0;i < n;i++)
		{
			scanf("%d", &a);
			count[a]++;
		}

		int cnt = 0, idx;
		for(int i = 0;i <= n;i++)
			if(cnt < count[i])
				idx = i, cnt = count[i];

		printf("test case #%d: %d %d\n", t, idx, cnt);
	}
	
	return 0;
}
