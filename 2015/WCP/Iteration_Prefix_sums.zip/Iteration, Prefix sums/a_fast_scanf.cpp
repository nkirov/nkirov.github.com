﻿#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <memory.h>
using namespace std;

#define MAXN 100001
#define MAXL 10
char str[(MAXN * MAXL) + MAXL];

double sums[MAXN];

inline double query(int idx1, int idx2)
{
    return sums[idx2] - (idx1 > 0 ? sums[idx1 - 1] : 0.0);
}

int main()
{
	while (!feof(stdin))
	{
		//init
		int n = 0; 
		memset(sums, 0, sizeof sums);

		gets(str);

		double d;
		
		sums[n++] = 0;
		char *p = strtok(str, " ");
		d = atof(p);
		p = strtok(NULL, " ");
		sums[n++] = d;
		
		while(p != NULL)
		{
			sums[n++] = atof(p) + sums[n - 1]; 
			p = strtok(NULL, " ");
		}		int a, b;		while(true)		{			scanf("%d", &a);			if(!a)				break;			scanf("%d", &b);			printf("%.3lf\n", query(a, b));		}		char ch = getchar();	}	return 0;}