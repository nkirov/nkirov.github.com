﻿#include <stdio.h>
#include <memory.h>

#define MAXN 100005

int a[MAXN], n;

int countX(int X) 
{
    int ans = 0;
    for (int i = 0; i < n; i++) 
        if (a[i] == X)
            ans++;

    return ans;
}

int main()
{
	int T;
	scanf("%d", &T);
	for (int t = 1;t <= T; t++)
	{
		memset(a, 0, sizeof a);
		
		int p;
		scanf("%d", &n);

		for(int i = 0;i < n;i++)
			scanf("%d", &a[i]);
		
		int maxCount = 0, number;
		for (int i = 0; i < n; i++)
		{
			int currentCount = countX(a[i]);
			if(currentCount > maxCount)
			{
				maxCount = currentCount;
				number = a[i];
			}
			else if(maxCount == currentCount && number > a[i])
			{
				maxCount = currentCount;
				number = a[i];
			}
		}

		printf("test case #%d: %d %d\n", t, number, maxCount);
	}
	
	return 0;
}
