﻿/*
LANG: C++
TASK: grading
ID: espr1t
TOUR: Dean's Cup 2009
*/

#include <iostream>
using namespace std;

int main(void)
{

	int numTests;
	scanf("%d", &numTests);
	for (int i = 0;i < numTests; i++)
	{
		int a, b;
		scanf("%d %d", &a, &b);
		
		int sum = 0;
		for (int c = a; c <= b; c++) 
			sum += c % 2 ? c : -c;

		printf("%d\n", abs(sum) % 5 + 2);
	}
	
	return 0;
}
