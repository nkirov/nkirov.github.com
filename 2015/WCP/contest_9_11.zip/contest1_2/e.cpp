//task - http://www.math.bas.bg/infos/files/2014-04-28-E2.pdf
//analysys - http://www.math.bas.bg/infos/files/2014-04-28-sol-E2.pdf

#include <iostream>
using namespace std;

char c, prevCh;
int t, maxL, minL, currL, currCh;
char maxCh, minCh;

int main()
{
	cin.sync_with_stdio(false);

	cin>>t;
	for(int i = 0; i < t;i++)
	{
		cin >> prevCh;
		minL = 500;
		maxL = 0;
		currL = 1;
		currCh = prevCh;

		while (prevCh != '.')
		{
			cin >> c;
			if (c == prevCh)
			  currL++;
			else
			{
				  if ((prevCh >= 'a') && (prevCh <= 'z'))
				  {
					  if (currL > maxL)
					  {
						  maxL = currL;
						  maxCh = prevCh;
					  }
					  
					  if (currL < minL)
					  {
						  minL = currL;
						  minCh = prevCh;
					  }
				  }
				  
				  currL = 1;
				  currCh = c;
			}

			prevCh = c;
		}

		if(maxL == 0)
			cout << 0  << endl;
		else
			cout << maxL << " " << maxCh << endl;
		
		if(minL == 500)
			cout << 0  << endl;
		else
			cout << minL << " " << minCh << endl;

		if(i != t  - 1)
			cout<< endl;
	}

    return 0;
}
