/*
We will split the sample into two parts; the first part being before the
asterisk (let us call it S) and the second part after the asterisk (let us call
it T). The file name matches the pattern if it is in the form of S + R + T,
where R is some string (possible an empty one). Therefore, the file name
must begin with S and end with T. However, this is not a sufficient
condition.

If we take the sample �ab*bc�, we have S = ab and T = bc. The file name
�abc� begins with S and ends with T, but it still doesn�t match the sample
�ab*bc�. It is necessary to check whether S and T overlap in the file name.
In other words, is length(S) + length(T) > length(file name).

Hence, if a word doesn�t begin with S or doesn�t end with T or the
aforementioned condition with lengths is met, we output �NO�, else we output �YES�.

Source: COCI 2013/2014, 6th round, March 8th, 2014, Task VJEKO
*/

#include <iostream>
#include <string>
#include <algorithm>
#include <sstream>
using namespace std;

typedef long long ll;

int main()
{
	cin.sync_with_stdio(false);

	int t;
	cin>>t;
	while(t--)
	{
		int N;
		string pat, pref, suff;
		cin >> N >> pat;
		replace(pat.begin(), pat.end(), '*', ' ');
		istringstream toks(pat);
		toks >> pref >> suff;
		for (int i = 0; i < N; i++)
		{
			string word;
			cin >> word;
			if (word.size() >= pref.size() + suff.size()
				&& word.substr(0, pref.size()) == pref
				&& word.substr(word.size() - suff.size()) == suff)
				cout << "YES\n";
			else
				cout << "NO\n";
		}
	}

    return 0;
}
