#include <iostream>
#include <sstream>
#include <string>
#include <memory.h>
using namespace std;

string line;
int C[11];

int main()
{
	cin.sync_with_stdio(false);

	int tc = 0, n = 0;
	while (getline(cin, line))
	{
		istringstream instr(line);
		int a, cnt = 0, len = 0, k;
		while(instr >> a) 
		{
			cnt += a;
			len++;
		}

		if(len > 1)
		{
			C[cnt]++;
			n++;
		}
		else if(len == 1)
		{
			k = a;
			int res = 0;
			for(int i = k;i < 11;i++)
				res += C[i];

			cout<<"During the "<<res<<" of "<<n<<" contests team " <<(char)(++tc + 64)<<" solved at least "<<k<<" tasks."<<endl;
			
			n = 0;	
			memset(C, 0, sizeof C);
		}
		else
		{
			cout<<"Something wrong in input!"<<endl;
		}
	}

	return 0;
}
