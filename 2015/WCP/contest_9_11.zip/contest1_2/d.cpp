//analysis - http://www.math.bas.bg/infos/files/2014-06-16-sol-C2.pdf

#include <cstdio>
#include <vector>
#include <string>
#include <iostream>
#include <algorithm>
#include <memory.h>
using namespace std;

long long a[62][62];
int n; 
string s;

int main()
{
	cin.sync_with_stdio(false);

	while(getline(cin, s))
	{
		n = s.size();
		if(n == 0)
			return 0;

		memset(a, 0, sizeof a);

		for(int j = 1;j <= n;j++)
		{
			for(int i = 0;i < n + 1 - j;i++)
			{ 
				if(j == 1) 
					a[i][j] = 1;
				else if(j == 2)
				{ 
					if(s[i] == s[i+1]) 
						a[i][j] = 3;
					else 
						a[i][j] = 2;
				}
				else
				{ 
					a[i][j] = a[i][j - 1] + a[i + 1][j - 1];
					if(s[i] != s[i + j - 1]) 
						a[i][j] -= a[i + 1][j - 2];
					else 
						a[i][j] += 1;
				}
			}
		}
		
		cout<<a[0][n]<<endl;
	}
	return 0;
}
