#include<iostream>
using namespace std;

void solve()
{
    int n, s = 0;
    cin >> n;
    for(int i=1; i<=n; i++) s = s + i;
    cout << 2*s << endl;
}

int main()
{
  int nt; cin >> nt;
  for(int i=1;i<=nt;i++) solve();

}
