/*
Firstly, we will enumerate the nodes in the tree in the following way: the
root is number 1, its left child is number 2 and its right child is number 3.
Generally, the left child of a node t is numbered with 2 * t and the right
child is numbered with 2 * t + 1.

Walks around visiting the buildings following this recursive algorithm:

	visit(x)
	if x < 2K-1, visit(2 * x)
	write down x on paper
	if x < 2K-1, visit(2 * x + 1)

We can construct a �reverse� recursive function which will reconstruct a tree
for a given route of visits. We will use an array tree[] where the ith item is
going to be a label of the ith node and a counter p which is initially set to 1.

	return(x)
		if x < 2K-1, return(2 * x)
		tree[x] = route[p]
		p = p + 1
		if x < 2K-1, return(2 * x + 1)

In the end, we output items of the array tree[].

The task could have been solved without recursion, with noticing regularities
in the route of visits of the tree. Consult the source code for this type of
solution.

Necessary skills: recursion, for loop
Category: ad-hoc

Source: COCI 2013/2014, round 5, task OBILAZAK
*/

#include <cstdio>
using namespace std;

const int MAXK = 10;

int k, t, pos, v[1 << MAXK];
int ans[1 << MAXK];

void solve(int t) 
{
	if(t >= 1 << k)
		return;

	solve(2 * t);
	ans[t] = v[pos++];
	solve(2 * t + 1);
}

int main() 
{
	scanf("%d", &t);
	while(t--)
	{
		scanf("%d", &k);
		for(int i = 0; i < (1 << k) - 1; ++i)
			scanf("%d", v + i);

		pos = 0;
		solve(1);

		int start = 1;
		for(int i = 0; i < k; ++i) 
		{
			for(int j = start; j < 2 * start - 1; ++j)
				printf("%d ", ans[j]);
			printf("%d\n", ans[2 * start - 1]);
			start *= 2;
		}
	}

	return 0;

}
