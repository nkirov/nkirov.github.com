//task - http://www.math.bas.bg/infos/files/2014-04-28-C3.pdf
//analysis - http://www.math.bas.bg/infos/files/2014-04-28-sol-C3.pdf

#include <vector>
#include <algorithm>
#include <stdio.h>
#include <memory.h>
using namespace std;

int n , q;

struct query 
{
    int u, v, num;
    long long ans;
    query (){}
    query (int u , int v, int num)
	{
        this -> u = u;
        this -> v = v;
        this -> num = num;
    }
};

struct edge 
{
    int v;
    long long  w;
    edge (){}
    edge (int v, long long w)
	{
        this -> v = v;
        this -> w = w;
    }
};

vector<query> Q;
vector<vector<edge> > v;
long long dist[6000];

void init()
{
	v.assign(n + 1, vector<edge>()); 
	Q.assign(q, query());
}

void read ()
{
    long long x , y , z;
    scanf ("%d%d", &n, &q);

	init();

    for (int i = 2; i <= n; ++i)
	{
        scanf ("%lld%lld%lld", &x , &y , &z);
        v[x].push_back(edge(y, z));
        v[y].push_back(edge(x, z));
    }

    for (int i = 0; i < q; ++i)
	{
        scanf("%d%d", &x, &y);
        if (y < x) 
			swap (x, y);

        Q[i].u = x;
        Q[i].v = y;
        Q[i].num = i;
    }
}

void dfs (int node)
{
    int sz = v[node].size();
    for (int i = 0; i < sz; ++i)
		if (!dist[v[node][i].v]) 
		{
            dist[v[node][i].v] = dist[node] + v[node][i].w;
            dfs (v[node][i].v);
        }
}

bool cmp1 (query t1 , query t2) {
    return t1.u < t2.u;
}

void solve ()
{
	sort (Q.begin(), Q.end(), cmp1);
    int cur = -1;
    for (int i = 0; i < q; ++i) 
	{
		if (Q[i].u == cur) 
            Q[i].ans = dist[Q[i].v]-1;
		else
		{
            memset(dist, 0, sizeof dist);
            dist[Q[i].u] = 1;
            dfs (Q[i].u);
            Q[i].ans = dist[Q[i].v] - 1;
            cur = Q[i].u;
        }
    }
}

bool cmp2 ( query t1 , query t2 ) {
    return t1.num < t2.num;
}

void print()
{
	sort(Q.begin(), Q.end(), cmp2);
    for (int i = 0; i < q; ++i)
        printf("%lld\n" , Q[i].ans);
}

int main () 
{
	int t;
	scanf("%d\n", &t);

	while(t--)
	{
		read();
		solve();
		print();
	}
	
	return 0;
}
