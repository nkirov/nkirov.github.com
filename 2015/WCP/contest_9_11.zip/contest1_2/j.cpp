/*
Depending on starting position, we can distinguish two cases:

Case #1 (appearing in 20% of test data): it is impossible to reach any trampoline.
	At first glance, we might think that it is enough to simply
	compare the number of skyscrapers visitable by moving as far as
	possible to the left versus to the right. However, there are two
	additional possibilities: moving left visiting all skyscrapers with
	the same height as the starting one and then moving all the way
	to the right, as well as the mirror case of this. It is easy to check
	both possibilities and choose the better one.

Case #2 (appearing in 20% of test data): at least one trampoline is reachable.
	Let us assume that A, B, C, ..., M are indices of all skyscrapers
	which contain a trampoline or have at least one trampoline
	reachable from them. We will call such skyscrapers beautiful.
	Notice that the starting skyscraper (K) is among them according
	to the assumption. Let T(A), T(B), T(C), ..., T(M) be the
	corresponding reachable skyscrapers with trampolines (not necessarily distinct).
	Consider the following path:
	K -> ... -> T(K) -> A -> � -> T(A) -> B -> � -> T(B) -> C -> �
	-> T(C) -> � � � -> M -> � -> T(M)
	This path is guaranteed to visit all beautiful skyscrapers. After
	that, we need to visit the longest possible sequence of nonbeautiful
	skyscrapers (ones with no reachable trampoline); we
	can reach any such sequence using T(M). The total solution is
	then the sum of the number of beautiful skyscrapers and the
	length of the longest non-beautiful skyscraper sequence.
	We can implement this solution in several steps:
		1) We first mark all skyscrapers containing a trampoline as beautiful.
		2) Traversing the skyscrapers from left to right, we mark
		skyscraper i as beautiful if skyscraper (i � 1) is beautiful and
		we can jump from i to (i � 1).
		3) Traversing the skyscrapers from right to left, we mark
		skyscraper i as beautiful if skyscraper (i + 1) is beautiful and
		we can jump from i to (i + 1).
		4) For all skyscrapers that haven't been marked beautiful in one
		of the previous steps, we have to find the number of
		skyscrapers we can visit from that skyscraper going to the
		left. It can be computed dynamically, in a way similar to step
		2). Analogously, the number of skyscrapers visitable to the
		right can be computed similarly to step 3).
		5) The final length of the longest non-beautiful sequence is
		simply the largest of the numbers obtained in step 4).

The complexity of the algorithm is O(N) in both cases.

Source: COCI 2011/2012, Round 7 - COI, task TRAMPOLIN
*/

#include <cstdio>
#include <memory.h>
using namespace std;

inline int max(int x, int y) { return x > y ? x : y; }

const int NN = 1000005;

int h[NN], left[NN], right[NN], maks[NN];
char t[NN];

int main()
{
    int n, k, tc;
	scanf("%d", &tc);
	while(tc--)
	{
		scanf("%d%d", &n, &k);
		--k;

		memset(left, 0, sizeof left);
		memset(right, 0, sizeof right);
		memset(maks, 0, sizeof maks);

		for(int i=0; i<n; i++) scanf("%d", h+i);
		scanf("%s", t);

		// svima izracunaj koliko maksimalno mogu left.
		// sve koji left mogu do trampolina, pretvori u trampoline.
		for(int i = 1;i < n; ++i)
		{
			if(h[i] < h[i - 1]) 
				continue;

			if(t[i - 1] == 'T') 
				t[i] = 'T';
			
			left[i] = 1 + left[i - 1];
		}

		// svima izracunaj koliko maksimalno mogu right.
		// sve koji right mogu do trampolina, pretvori u trampoline.
		for(int i = n - 2;i >= 0; --i)
		{
			if(h[i] < h[i + 1]) 
				continue;

			if(t[i + 1] == 'T') 
				t[i] = 'T';
			
			right[i] = 1 + right[i + 1];
		}

		// izbroji trampoline i nadji najbolji ne-trampolin
		int T = 0, best = 0;
		for(int i = 0;i < n; i++)
		{
			if(t[i] == 'T') 
				++T;
			else
				best = max(best, 1 + max(left[i], right[i]));
		}

		if(t[k] == 'T') 
			printf("%d\n", T + best);
		// ako pak ne mogu do trampolina...
		else
		{
			int l = k, r = k;

			while(l > 0 && h[l-1] == h[k]) 
				l--;

			while(r < n - 1 && h[r + 1] == h[k]) 
				r++;

			printf("%d\n", r - l + 1 + max(left[l], right[r]));
		}
	}

    return 0;
}
