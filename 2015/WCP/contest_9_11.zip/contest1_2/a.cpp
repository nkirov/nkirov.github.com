/*
Let�s observe the function f(x) where x represents the height of the
middle column (the one with the minimal height) which tells us the number
of minimal moves necessary to rearrange the piles in the described way.
We can calculate this because then the minimal number of moves is
uniquely determined: if a column has more bricks than necessary, we need
to remove them and if it is missing bricks, we need to add new bricks.

We have two piles, but it is stated that in the end the corresponding
columns have to be of equal heights. Then Mirko�s pile is f1(x) = |cm1 - x|
+ |cm2 - x| + � + |cmn - x| and Slavko�s pile is f2(x) = |cs1 - x| + |cs2 - x|
+ � + |csn - x| where cm1, cm2, � , cmn i cs1, cs2, �, csn are constants which
depend on the height and position of the column.

If we observe the graph of the function (f1 + f2)(x) we will notice that the
function is decreasing at first, then increasing and it has only one global
minimum.

It is easily noticed that this minimum is exactly the first point m for which
the following holds: (f1 + f2)(m) < (f1 + f2)(x + 1). In other words, it is
the point where the function starts to increase. Also, we can notice that
for every point to the left of m the following holds: (f1 + f2)(x) > (f1 +
f2)(x + 1) and for every point to the right of m: (f1 + f2)(x) < (f1 +
f2)(x + 1). This is why we can locate point m using binary search, by
comparing the relation of function values of two adjacent points.

Alternative approach (Bruce Merry). The first trick is to notice that the
slightly odd target shape can be removed from the problem: simply
subtract |i - N / 2| from element i of the inputs (the shortest target shape)
and now solve for a flat target. You have 2N numbers and need to find the
m such that sum(|a_i - m|) is minimised. This is just the median of the
numbers (exercise: prove this, if you don't already know why). The median
can be found in O(N) time using std::nth_element; a binary search is also
fast enough.

Source: COCI 2013/2014, 6th round, March 8th, 2014 - Task KOCKICE
*/
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#define MAXN 300001
using namespace std;

typedef long long ll;

ll a[MAXN], b[MAXN];
int n;

ll f(ll x)
{
    ll ret = 0;
    for (int i = 0; i < n; i++)
	{
        ll height = x + abs(n/2 - i);
        ret += abs(height - a[i]);
        ret += abs(height - b[i]);
    }

    return ret;
}

int main()
{
	int T;
	scanf ("%d", &T);
	for(int t = 1;t <= T;t++)
	{
		scanf ("%d", &n);
		for (int i=0; i<n; i++) 
			scanf ("%lld", &a[i]);

		for (int i=0; i<n; i++) 
			scanf ("%lld", &b[i]);

		ll lo = 0, hi = 0; 
		for (int i=0; i<n; i++) 
			hi = max(hi, max(a[i], b[i]));

		while(lo < hi)
		{
			ll mid = (lo + hi ) / 2;
			if (f(mid) < f(mid+1)) 
				hi = mid;
			else                  
				lo = mid + 1;
		}

		printf ("Test case # %d:\t%lld\n", t, f(lo));
	}

    return 0;
}
