#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main()
{
  char KM[20];
  int i, j=1, k, b, br;
  long int  Sum=0;
  
  scanf("%d", &br);
  for(b=1; b<=br; b++)
  {
  scanf("%s", &KM);
  for(i=18; i>=0; i--)
  { if (KM[i]!='-')
               { if (!(j%2))
                    { k=((int)KM[i]-(int)'0')*2;
                      if (k<10)
                            Sum+=k;
                        else
                           Sum+=(k%10+k/10%10);
                      } 
                    else
                       Sum+=((int)KM[i]-(int)'0');
                  j++;
                 }
            }

    if (!(Sum%10)) if (KM[0]=='4') printf("VISA");
                       else if ((KM[0]=='5') && (KM[1]>'0') && (KM[1]<'6')) printf("MasterCard");
                              else printf("YES");
         else printf("NO");
    if (b<br) printf("\n");
   }
                                    
      return 0;  
    }
