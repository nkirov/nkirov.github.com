// Adopted from http://acmgnyr.org/year2007/b.pdf

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

char line [50];
int t = 1, tc;

int main()
{	
	scanf("%d\n", &tc);
	while (tc--)
	{
		gets(line);
		
		char* s = strtok(line, " ");
		double d = atof(s);
		s = strtok(NULL, " ");

		if (!strcmp(s, "kg"))  
            printf("%d %.4lf lb\n", t++, d * 2.2046);  
        else if (!strcmp(s, "l"))  
            printf("%d %.4lf g\n", t++, d * 0.2642);  
        else if (!strcmp(s, "lb"))  
            printf("%d %.4lf kg\n", t++, d * 0.4536);  
        else if (!strcmp(s, "g"))  
            printf("%d %.4lf l\n", t++, d * 3.7854);  
	}

	return 0;
}
