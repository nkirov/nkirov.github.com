#include <iostream>
#include <string>
using namespace std;

//http://www.math.bas.bg/infos/files/2013-01-06-E3.pdf

string s;

int main()
{
	while(cin >> s)
	{
		int x = s[0] - '0', y = s[1] - '0', z = s[2] - '0'; 
		int v = x + y + z;
		if(x + y * z > v) 
			v = x + y * z;
		if(x * y + z > v) 
			v = x * y + z;
		if(x * y * z > v) 
			v = x * y * z;

		cout << v << endl;
	}

	return 0;
}
