/*
Adopted from http://acmgnyr.org/year2008/b.pdf
*/

#include <stdio.h>
#include <string.h>

int main()
{
	int n;
	char szbuf[128], szkey[40];

	scanf("%d\n", &n);
	for(int i = 1; i <= n; i++)
	{
		gets(szbuf);
		gets(szkey);

		printf("%d ", i);
		int len = strlen(szbuf);
		for(int j = 0; j < len; j++)
		{
			if(szbuf[j] == ' ')
				printf(" ");
			else
				printf("%c", szkey[szbuf[j] - 'A']);
		}

		printf("\n");
	}

	return 0;
}