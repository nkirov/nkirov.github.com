#include <iostream>
using namespace std;

int price, tended, t = 1;

int main()
{

	while(cin >> price >> tended && price)
	{
		int change = tended - price;
		int tens = change / 10;
		int afterTens = change % 10;
		int fives = afterTens / 5;
		int ones = afterTens % 5;

		cout<< "Case " << t++ << ": " << change << " = " << tens << " * 10 + " << fives << " * 5 + " << ones << " * 1" << endl;
	}

	return 0;
}
