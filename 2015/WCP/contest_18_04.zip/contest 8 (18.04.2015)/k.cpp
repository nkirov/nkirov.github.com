#include <cstdio>
#include <memory.h>
using namespace std;

#define MAX 100001

int N, C;
int v[MAX][2];          /* the left and right subtree indexes */
int vis[MAX];           /* the distance from the root */

/* The 'DFS' (depth first search) routine is the recursive workhorse */
void DFS (int x)
{
	for (int i = 0; i < 2; i++)       /* both left and right branches */
	{
		/* termination condition -- don't continue if no branches */
		if (v[x][i] != 0 && vis[v[x][i]] == 0) 
		{                           
			vis[v[x][i]] = vis[x] + 1;    /* this is the "I'm one farther deeper" marker */
			DFS (v[x][i]);                /* then continue deeper into the tree */
		}
	}
}

int main()
{
	while(true)
	{
		scanf ("%d%d", &N, &C);
		if(N == 0 && C ==0)
			break;

		memset(v, 0, sizeof(v));
		memset(vis, 0, sizeof(vis));
		
		for (int i = 0; i < C; i++)
		{
			int x, b1, b2;
			scanf ("%d%d%d", &x, &b1, &b2);
			v[x][0] = b1;
			v[x][1] = b2;
		}

		vis[1] = 1;
		DFS (1);

		for (int i = 1; i <= N; i++)
			printf ("%d\n", vis[i]);
	}
	
	return 0;
}