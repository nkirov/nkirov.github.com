//Adopted from http://hsin.hr/coci/archive/2009_2010/, contest 2, task 2

#include <map>
#include <set>
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

string ones[] = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
string tens[] = {"", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"};

map <string, int> all;

string get(int x) {
	return tens[x / 10] + ones[x % 10];
}

int main() 
{
	for (int x = 1; x < 100; ++x) 
		all[get(x)] = x;
	
	
	string num;
	while(getline(cin, num))
	{
		if(num.length() == 0)
			break;

		sort(num.begin(), num.end());
		string res = "";
		int best = 10000;
		do 
		{
			if (all.count(num) && best > all[num]) 
			{
				best = all[num];
				res = num;
			}
		} 
		while (next_permutation(num.begin(), num.end()));
		
		cout << res << endl;
	}

	return 0;
}