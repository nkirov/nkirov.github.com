#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;

typedef long long ll;

const ll BASE = 313;
vector<ll> basePowMem(1, 1);

ll basePow(int e) {
	while((int)basePowMem.size() < e + 1) 
		basePowMem.push_back(basePowMem[(basePowMem.size() - 1)] * BASE);
	return basePowMem[e];
}

struct Hasher {
	string const& s;
	const int N;
	vector<ll> pre;
	
	Hasher(string const& _s): s(_s), N(_s.size()) {
		pre.resize(N + 1, 0);
		for(int i = 0; i < N; ++i)
			pre[i + 1] = pre[i] * BASE + s[i];
	}
	
	ll sub(int b, int e) {
		return pre[e] - pre[b] * basePow(e - b);
	}
	
};

bool pal(int b, int e, int N, Hasher& sh, Hasher& rh) {
	if(b < 0 || e > N) 
		return false;

	ll shs = sh.sub(b, e);
	ll rhs = rh.sub(N-e, N-b);
	
	return shs == rhs;
}

int solve(string const& s) {
	const int N = s.size();
	string r = s; reverse(r.begin(), r.end());
	Hasher sh(s);
	Hasher rh(r);
	int best = 1;
	//pal(b, e): s[b..e] == r[N-e .. N-b]
#define PAL(b, e) ((b) >= 0 && (e) <= N && sh.sub((b), (e)) == rh.sub(N-(e), N-(b)))
	for(int es = 1; es <= 2; ++es) {
		int b = 0;
		int e = es;
		while(e <= N) {
			while(pal(b-1, e+1, N, sh, rh)) {
				--b; 
				++e;
			}
			if(pal(b, e, N, sh, rh)) best = max(best, e - b);
			++b; 
			++e;
		}
	}
#undef PAL
	return best;
	
}

int slow(string const& s) 
{
	int res = 0;
	const int N = s.size();
	for(int e = 0;e <= N;e++)
		for(int b = 0;b < e;b++) {
		string u = s.substr(b, e - b);
		string v = u; reverse(v.begin(), v.end());
		if(u == v) res = max(res, e - b);
	}
	return res;
}

int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	string text;
	while (getline(cin, text))
		cout << solve(text) << "\n";
	
	return 0;
}
