#include <iostream>
using namespace std;

int t, n, k;

int main()
{
	cin>>t;
	while(t--)
	{
		unsigned long long sum = 0;
		cin>>k>>n;
		
		for (int j = 1;j <= n;j++)
			sum = sum * 2 + k;
		
		cout<<sum / 100<<" "<<sum % 100<<endl;
	}

	return 0;
}