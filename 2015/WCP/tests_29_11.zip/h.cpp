#include <stdio.h>
#include <algorithm>
using namespace std;

int a[105];
int n, m, t, sol, ij;

int main()
{
	while(true)
	{
		scanf("%d", &n, &m);
		if(n < 3 || n > 100)
			break;
		
		scanf("%d", &m);

		for(int i = 0;i < n;i++)
			scanf("%d", &a[i]);

		sol = 0;
		for(int i = 0;i < n;i++)
			for(int j = i + 1;j < n;j++)
			{
				ij = a[i] + a[j];
				for(int k = j + 1;k < n; k++)
					if(a[i] + a[j] + a[k] <= m )
						sol = max(sol, a[i] + a[j]+a[k]);
			}

		printf("%d\n", sol);
	}

    return 0;
}
