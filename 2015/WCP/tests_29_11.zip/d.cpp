#include <iostream>
#include <string>
#define NUM 26
using namespace std;

int a[NUM];

void print()
{
 for (int i=0; i < NUM; i++) cout << a[i] << " ";
 cout << endl;         
}     

string sub(string s)
{
     for (int i=0; i < NUM; i++) a[i] = 0;  
        for (int i=0; i<s.length(); i++) a[s[i] - 'a']++;
//        print();
        
        for (int i=0; i<NUM; i++) 
            if ( a[i] == 0 ) return "0";     
          
        int i1 = 0;
        bool b = true;
        while ( i1 < s.length() && b ) 
        {
            if ( a[s[i1] - 'a'] > 1 ) { a[s[i1] - 'a']--; i1++; }
            else b = false;
         }   
         int i2 = s.length() - 1;   
         b = true;
         while ( i2 > 0 && b )
         {
             if ( a[s[i2] - 'a'] > 1 ) { a[s[i2] - 'a']--; i2--; }
             else b = false;
         }
//         cout << i1 << " " << i2 << endl;    
         return s.substr(i1, i2 - i1 + 1);    
}
int main()
{
    string s;
    while (cin >> s)
    {
//          cout << s << " " << s.length() << endl;
          cout << sub(s) << endl;
          }
    return 0;
}

