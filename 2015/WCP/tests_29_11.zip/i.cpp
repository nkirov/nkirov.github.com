#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int letters[2][32];
char str[1024];

void run() 
{
    for(int i=0;i<32;i++) {letters[0][i]=letters[1][i]=0;}
    
    int len;

    for(int i=0;i < 2;i++) {
        scanf("%s", &str);
        len = strlen(str);
        for(int j=0;j < len;j++) {
            letters[i][str[j] - 'a']++;
        }
    }

    int cnt;

    for(int i=0;i < 26;i++) {
        cnt = min(letters[0][i], letters[1][i]);
        for(int j=0;j < cnt;j++) {
            printf("%c", i + 'a');
        }
    }

    printf("\n");


}


int main()
{
  int nt; scanf("%d",&nt);
  for(int it=1;it<=nt;it++) run();   
}
