

#include <iostream>
#include <string>
using namespace std;

bool happy(int n)
{
    string s;
    int k = n;
    while (k > 0)
    {
        s += (k%2 == 1 ? "1" : "0");
        k /= 2;
    }
//    cout << k << " " << s << endl;
    int l = s.length();
    if (l%2 == 1) return false;
    int left = 0, right = 0;
    for (int i = 0; i < l; i++)
        if (i < l/2) left += s[i] - '0';
        else right += s[i] - '0';
//    cout << left << " - " << right <<  " " << s << " " << n << endl;
    return left == right;
}

void interval()
{
    int a, b;
    while (cin >> a >> b)
    {
        int num = 0;
        for (int i = a; i <= b; i++)
            if (happy(i)) num++;
        cout << num << endl;
    }
}

void number()
{
    int a;
    while (cin >> a) cout << (happy(a)?"YES":"NO") << endl;
}

int main()
{
    number();
    return 0;
}
