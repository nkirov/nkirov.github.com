#include <iostream>
using namespace std;

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	int dig;
	long long n;
	while(cin>>dig>>n)
	{
		long long total[22] = {0}, num = 1, temp = 0, dop = 1;
		int i = 1, k[22] = {0};
  
		if(n < 10) 
			cout<<(n >= dig)<<endl;
		else
		{
			if (dig == 0) 
				temp = 1;
			
			while(n > 0)
			{
				total[i] = 10 * total[i - 1] + num;
				k[i] = n % 10;
				if(k[i] > dig)
					temp += num;
				else if (k[i] == dig)
					temp += dop;
        
				dop += k[i] * num;
				temp += k[i] * total[i - 1] - (dig == 0) * num;
				num *= 10;
				n /= 10;
				i++;
        }
			
			temp += k[i] * total[i - 1];
			cout<<temp<<endl;
		}
	}
}
