#include <iostream>
using namespace std;

int n, k;
int a[1000];

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while(cin >> n >> k)
	{
		for(int i = 0; i < n; i++)
			cin >> a[i];

		int best = 0;
		for(int i = 0; i < n; i++) 
		{
			int cur = 0;
			for(int j = 0; j < k; j++)
				cur += a[(i + j) % n];
			
			best = max(best, cur);
		}

		cout << best << endl;
	}
}
