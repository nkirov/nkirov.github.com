import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class i {
	public static void main(String[] args) {
		InputReader r = new InputReader(System.in);
		int n = -1;
		while (true) {
			try {
				n = r.nextInt();
			} catch (Exception e) {
				break;
			}
			int k = r.nextInt();
			int a = r.nextInt();
			int b = r.nextInt();
			HashSet<Integer>[] adj = new HashSet[n];
			for (int i = 0; i < adj.length; i++) {
				adj[i] = new HashSet<Integer>();
			}
			for (int i = 0; i < k; i++) {
				int from = r.nextInt() - 1;
				int to = r.nextInt() - 1;
				adj[from].add(to);
				adj[to].add(from);
			}
			Queue<Integer> q = new LinkedList<Integer>();
			q.add(0);
			q.add(0);
			boolean[] vis = new boolean[n];
			vis[0] = true;
			long Acost = Long.MAX_VALUE;
			while (!q.isEmpty()) {
				int front = q.remove();
				int cost = q.remove();
				if (front == n - 1) {
					Acost = (long) cost * a;
					break;
				}
				for (int x : adj[front]) {
					if (!vis[x]) {
						vis[x] = true;
						q.add(x);
						q.add(cost + 1);
					}
				}
			}
			HashSet<Integer> set = new HashSet<Integer>();
			for (int i = 1; i < n; i++)
				set.add(i);
			q = new LinkedList<Integer>();
			q.add(0);
			q.add(0);
			vis = new boolean[n];
			vis[0] = true;
			long Bcost = Long.MAX_VALUE;
			while (!q.isEmpty()) {
				int front = q.remove();
				int cost = q.remove();
				if (front == n - 1) {
					Bcost = (long) cost * b;
					break;
				}
				HashSet<Integer> t = new HashSet<Integer>();
				for (int x : set) {
					if (!vis[x] && !adj[front].contains(x)) {
						vis[x] = true;
						q.add(x);
						q.add(cost + 1);
						t.add(x);
					}
				}
				for (int x : t)
					set.remove(x);
			}
			System.out.println(Math.min(Acost, Bcost));
		}
	}

	static class InputReader {
		private BufferedReader reader;
		private StringTokenizer tokenizer;

		public InputReader(InputStream stream) {
			reader = new BufferedReader(new InputStreamReader(stream));
			tokenizer = null;
		}

		public InputReader(FileReader stream) {
			reader = new BufferedReader(stream);
			tokenizer = null;
		}

		public String nextLine() {
			try {
				return reader.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}

		public String next() {
			while (tokenizer == null || !tokenizer.hasMoreTokens()) {
				try {
					tokenizer = new StringTokenizer(reader.readLine());
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return tokenizer.nextToken();
		}

		public int nextInt() {
			return Integer.parseInt(next());
		}

		public long nextLong() {
			return Long.parseLong(next());
		}
	}
}