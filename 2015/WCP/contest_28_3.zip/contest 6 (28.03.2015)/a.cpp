/*
Зимни състезания по информатика
Велико Търново, 27 февруари - 1 март 2015 г.
Група С (8 клас)
Analysis - http://www.math.bas.bg/infos/files/2015-03-01-sol-C3.pdf
*/

#include <iostream>
#include <cmath>
#include <memory.h>
using namespace std;

const int MAXINT = 999999999;
const int N = 1000;
int t, n, a[N], s[N][N];


void dosums()
{
	for(int i = 0;i < n;i++)
	{
		for(int j = 0;j < n;j++)
		{
			int v = 0;
			for(int k = i;k <= j;k++) 
				v += a[k];
			
			s[i][j] = v;
		}
	}
}

int memo[N][N];

int solve(int i1, int i2)
{
	if(i1 == i2)
		return 0;
  
	if(memo[i1][i2] > 0) 
		return memo[i1][i2];

	int m = MAXINT;
	for(int k = i1;k < i2;k++)
	{
		int r1 = solve(i1,k);
		int r2 = solve(k+1,i2);
		int v = r1 + r2 + s[i1][k] + s[k + 1][i2];
		if(m > v) 
			m = v;
	}
	
	memo[i1][i2] = m;
	return m;
}



int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	cin >> t;

	while(t--)
	{
	   cin >> n;

	   for(int i = 0;i < n;i++) 
		   cin >> a[i];

	   memset(memo, 0, sizeof memo);

	   dosums();

	   cout << solve(0, n - 1) << endl;
	}

	return 0;
}
