/*
Since the test data is very large (~130 MB) you can download it from http://acm.ro/2013/index.html, problem B 
or to check your solution at UVa - https://icpcarchive.ecs.baylor.edu/index.php?option=com_onlinejudge&Itemid=8&category=613&page=show_problem&problem=4436
*/

#include<stdio.h>
#include<algorithm>
#include<map>
#include<list>
#include<queue>
#include<memory.h>
#define MAXN 500050
using namespace std;

typedef long long LL;

int n, k, newCost, oldCost;

struct node {
    int st, en, next;
}E[MAXN * 2];

int p[MAXN], num;

void init()
{
    memset(p, -1, sizeof(p));
    num = 0;
}

void add(int st, int en)
{
    E[num].en = en;
    E[num].next = p[st];
    p[st] = num++;
}

map <pair<int, int>, int> ma;
int dis[MAXN];

void bfs(int st)
{
	queue<int> q;
	memset(dis, -1, sizeof(dis));
    
	dis[st] = 0;
    q.push(st);
    
	int front, i, w;
    while(q.size())
    {
        front = q.front();
        q.pop();
        for(i = p[front];i + 1; i = E[i].next)
        {
            w = E[i].en;
            if(dis[w] == -1)
            {
                dis[w] = dis[front] + 1;
                if(w == n)
                    return;

                q.push(w);
            }
        }
    }
}

list<int>lis;
list<int>::iterator it;
void go(int st)
{
    queue<int> q;
    memset(dis, -1, sizeof(dis));
    lis.clear();

    for(int i = 2;i <= n;i++)
        lis.push_back(i);

    q.push(st);
    dis[st] = 0;
    int front, u, v;

    while(q.size())
    {
        front = q.front();
        q.pop();
        for(it = lis.begin(); it != lis.end();)
        {
            u = front, v = *it;
            if(u > v)
                swap(u,v);

            if(ma.count(make_pair(u, v)) == 0)
            {
                dis[*it] = dis[front] + 1;
                q.push(*it);
                it = lis.erase(it);
            }
            else
                it++;
        }
    }
}
int main()
{
    int u,v;
    pair<int, int> uv;

    while(scanf("%d%d%d%d", &n, &k, &newCost, &oldCost) != EOF)
    {
        init();
        ma.clear();

        for(int i = 1;i <= k;i++)
        {
            scanf("%d%d",&u, &v);
            add(u, v);
            add(v, u);
            if(u > v) 
				swap(u,v);

            ma[make_pair(u,v)] = 1;
        }

        if(ma.count(make_pair(1, n)) == 0)
        {
            if(oldCost <= newCost)
                printf("%d\n", oldCost);
            else
            {
                bfs(1);

                if(dis[n] != -1 && LL(dis[n]) * newCost <= oldCost)
                    printf("%d\n", dis[n] * newCost);
                else
                    printf("%d\n", oldCost);
            }
        }
        else
        {
            if(newCost <= oldCost)
                printf("%d\n", newCost);
            else
            {
                go(1);

                if(dis[n] != -1 && LL(dis[n]) * oldCost <= newCost)
                    printf("%d\n", dis[n] * oldCost);
                else
                    printf("%d\n", newCost);
            }
        }
    }

    return 0;
}
