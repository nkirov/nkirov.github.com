#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>
#include<algorithm>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	int n; int k;

	while ( cin >> n )
	{
		cin >> k;
		int ans = 0;
		int sum = 0;
		vector<int> pizza;
		for(int i = 0 ;i < n ;i++)
		{
			int temp; cin >> temp;
			pizza.push_back(temp);
		}

		for (int i = 0; i < pizza.size(); i++)
		{
			sum = 0;

			for (int j = 0; j < k; j++)
			{
				if((i + j) < pizza.size())
				{
					sum += pizza[i+j];
				}
				else
				{
					sum += pizza[(i + j) % n];
				}
			}

			ans = max(sum, ans);
		}

		cout << ans << endl;

	}
	return 0;
}
