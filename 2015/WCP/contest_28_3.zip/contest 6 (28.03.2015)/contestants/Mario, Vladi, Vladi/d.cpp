#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int alpha[26];

map<char, char> mapShit;

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);
	int tc;
	cin >> tc;
	cin.get();
	while (tc--)
	{
		memset(alpha,0,sizeof(alpha));
		mapShit.clear();
		string key;
		cin >> key;
		string dubkey;
		vector<vector<char> > b;
		for(int i = 0 ; i < key.length();i++)
		{		
			for(int j = i+1; j < key.length();j++)
			{
				if(key[i] == key[j])
				{
					key.erase(key.begin()+j);
				}
			}

		}

		for(int i = 0 ; i < key.length() ;i++)
		{
			alpha[key[i]-'A']++;
		}
		b.assign(26 , vector<char>()) ;

		for(int i = 0 ;i < b.size();i++)
		{
			b[i].assign(key.length(),' ');
		}
		for(int i = 0 ; i < 1;i++)
		{
			for(int j = 0 ; j < b[0].size();j++)
			{
				b[i][j] = key[j];
			}
		}
		int p = 0;
		for(int i = 1 ; i < b.size();i++)
		{
			for(int j = 0 ; j < b[i].size();j++)
			{
					for(int z = 0; z<26; z++)
					{
						if(alpha[z] == 0)
						{
							b[i][j] = z + 'A';
							alpha[z]++;
							break;
						}
					}
			}
			
		}
		for (int d = 0; d < b[0].size(); d++)
		{
			char minChar = b[0][d];
			int index = d;

			for (int i = d; i < key.length(); i++)
			{
				if(b[0][i] != ' '){
				if(b[0][i] < minChar)
				{
					minChar = b[0][i];
					index = i;
				}}
			}

			for (int g = 0; g < 26; g++)
			{
				char temp = b[g][index];
				b[g][index] = b[g][d];
				b[g][d]  = temp;
			}
		}

		char ins = 'A';
		for (int i = 0; i < 26; i++)
		{
			mapShit.insert(make_pair(ins, ins));
			ins++;
		}

		ins = 'A';
		for (int d = 0; d < b[0].size(); d++)
		{
			for (int c = 0; c < 26; c++)
			{
				if(b[c][d] == ' ')
					break;

				mapShit[b[c][d]] = ins;
				ins++;
			}
		}
		
		string input;
		cin.get();
		getline(cin, input);

		for (int f = 0; f < input.size(); f++)
		{
			if(input[f] != ' ')
				cout << mapShit[input[f]];
			else
				cout << " ";
		}

		cout << endl;
	}

	return 0;
}
