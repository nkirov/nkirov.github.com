#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include <sstream>
#include<stack>
#include<iomanip>
#include<functional>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	string p;
	while(getline(cin,p))
	{
	int ans = 0;
	vector<int> bla;
	istringstream pp(p);
	int w;
	while(pp>>w)
	{
		bla.push_back(w);
	}
	for(int i = 0 ;i < bla.size()-1;i++)
	{
		if(bla[i] < bla[i+1])
		{
			ans++;
		}
	}
	cout << ans << endl;

	}

	return 0;
}
