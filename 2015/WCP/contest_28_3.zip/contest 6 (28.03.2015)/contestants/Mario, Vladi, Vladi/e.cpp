#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>
#include<algorithm>
#include<bitset>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

bitset<100000> bs;
int primes[16384];
int used[16384];
int sqr[16];
vi currUsed;

void gen_primes()
{
	bs.set();
	bs[0] = bs[1] = 0;
	for (int i = 2; i < 10001; i++) if(bs[i]) {
		for (int j = i*i; j < 10001; j += i) bs[j] = 0;
		primes[i] = 1;
}}

void gen_sqr()
{
	for (int i = 0; i < 10; i++)
	{
		sqr[i] = i * i;
	}
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	gen_primes();
	gen_sqr();
	int n, k, m, mCpy;

	cin >> n;

	for (int i = 0; i < n; i++)
	{
		cin >> k >> m;
		mCpy = m;

		if(m == 1) { cout << k << " " << m << " NO" << endl; }
		else
		{
			if(primes[m])
			{
				int sum = 0;
				currUsed.clear();

				while(sum != 1)
				{ 
					sum = 0;
					while (mCpy != 0)
					{
						sum += sqr[(mCpy % 10)];
						mCpy /= 10;
					}


					if(used[sum])
					{
						cout << k << " " << m << " NO" << endl;
						break;
					}

					used[sum] = 1;
					currUsed.push_back(sum);
					mCpy = sum;
				}

				if(sum == 1)
				{
					for (int i = 0; i < currUsed.size(); i++)
					{
						used[currUsed[i]] = 0;
					}

					cout << k << " " << m << " YES" << endl;
				}
			}
			else
			{
				cout << k << " " << m << " NO" << endl;
			}
		}
	}

	return 0;
}
