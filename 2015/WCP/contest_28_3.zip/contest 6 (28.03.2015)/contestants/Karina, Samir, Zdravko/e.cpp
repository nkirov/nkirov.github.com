#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <stdio.h>
#include <set>

using namespace std;

string str;
int tmp;
int tc;

int sqr[10] = {0,1,4,9,16,25,36,49,64,81};
bool notPrime[100001] = {0};
void findPrimes();
long long cs, numb, sum, inNumb;
set<long long> prev;

int main()
{
    findPrimes();

    for(int i = 2; i<10000; i++){
        if(!notPrime[i]){
       //     cout << i << endl;
        }
    }
    cin >> tc;
    while(tc--){
        prev.clear();
        sum = 0;

        cin >> cs >> numb;
        inNumb = numb;
        if(notPrime[numb]){
            cout << cs << " " <<  inNumb << " NO" << endl;
            continue;
        }else{
            start:
            while(numb>0){
                tmp = numb % 10;
                sum += sqr[tmp];
                numb /= 10;
            }
            if(sum == 1){
                cout << cs << " " <<  inNumb << " YES" << endl;
                continue;
            }else{
                if(prev.count(sum)){
                    cout << cs << " " <<  inNumb << " NO" << endl;
                    continue;
                }else{
                    prev.insert(sum);
                    //cout << "INSERTED" <<endl;
                }
            }
           // cout << sum << endl;
            numb = sum;
            sum = 0;
            goto start;
        }
    }
}


void findPrimes(){
    notPrime[0] = notPrime[1] = true;
    for(int i = 2; i<1000; i++){
        if(!notPrime[i]){
            for(int j = i+i; j<100001; j+=i){
                notPrime[j] = true;
            }
        }
    }
}










