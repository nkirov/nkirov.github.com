#include <iostream>
#include <cstring>


using namespace std;

int n,k,tmp,sum,best;
int arr[1024];


int main(){

    while (cin >> n >> k){
        best = 0;
        sum = 0;
        memset(arr, 0, sizeof(arr));
        for(int i = 0; i < n; i++){
            cin >> tmp;
            arr[i] = tmp;
        }
        for(int i = 0; i<n+k; i++){
            if ( i < k){
                best += arr[i];
                sum += arr[i];
            }else{
                sum += arr[i%n];
                sum -= arr[i-k];
                if (best < sum){
                    best = sum;
                }
            }
        }
        cout << best << endl;
    }

    return 0;
}
