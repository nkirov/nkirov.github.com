#include <iostream>
#include <string>
#include <sstream>

using namespace std;

string s;
int n,prev,ans;
bool found = false;


int main(){
    
    while( getline(cin,s) ){
        ans = 0;
        prev = 0;
        istringstream line(s);
        while (line>>n){
            if(n>prev){
                ans++;
            }
            prev = n;
        }

        cout << ans << endl;

    }

    return 0;
}
