#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>

using namespace std;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\b.in", "r", stdin);
    int n,k;
    while(scanf("%d %d", &n, &k)==2){
        vector<int> v;
        while(n--){
            int x;
            scanf("%d", &x);
            v.push_back(x);
        }
        int res = 0;
        int sum = 0;
        for(int i=0; i<k; ++i){
            sum+= v[i];
        }
        res = sum;
        for(int i=1; i<v.size(); ++i){
            sum-=v[i-1];
            sum+= v[ (i+k-1)%v.size() ];
            res = max(res, sum);
         //   cout << res << " " << i << endl;
        }
        cout << res << endl;
    }

    return 0;
}
