#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>

using namespace std;
vector<vector<int> > v;
int visited[500005];
int main()
{
  //  freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\f.in", "r", stdin);

    string line;
    int num;
    while(getline(cin, line))
    {
        istringstream ins(line);
        int prev = 0;
        int res = 0;
        while(ins >> num)
        {
            if(prev < num)
            {
                res++;
            }
            prev = num;
        }
        printf("%d\n", res);
    }

    return 0;
}
