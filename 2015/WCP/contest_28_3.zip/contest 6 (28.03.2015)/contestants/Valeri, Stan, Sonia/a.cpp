#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>

using namespace std;
int arr[505];
int cum[505];
int dp[505][505];
        int n;
int solve(int b, int e){
    if(dp[b][e]!=-1) return dp[b][e];
    if(b == e){
        return dp[b][e] = 0;
    }
    int min_ = 5000000;
    for(int i=b ; i<e; ++i){
        min_ = min(min_, solve(b,i) + solve(i+1, e));
    }
    return dp[b][e] = min_ + (cum[e+1] - cum[b]);
}
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\a.in", "r", stdin);

    int TC;
    scanf("%d", &TC);
    while(TC--){
        memset(arr, 0, sizeof(arr));
        memset(dp, -1, sizeof(dp));
        memset(cum, 0, sizeof(cum));
        scanf("%d", &n);
        for(int i=0; i<n; ++i){
            scanf("%d", &arr[i]);
        }
        cum[1] = arr[0];
        for(int i=2; i<=n; ++i){
            cum[i] = cum[i-1] + arr[i-1];
        }
        printf("%d\n", solve(0, n-1));

    }

    return 0;
}
