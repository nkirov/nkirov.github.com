#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>
#define ll long long
using namespace std;

vector<int>  visited(10001);
int prime[10001];

int p(int m){
    int sum = 0;
    while(m > 0){
        int dig = m%10;
        sum+=dig*dig;
        m/=10;
    }
    return sum;
}
string f(int m){
    queue<int> q;
    q.push(m);
    visited[m] = 1;
    while(!q.empty()){
        int fron = q.front();
        q.pop();
        int child = p(fron);
        if(visited[child] == 0){
            if(child == 1){
                return "YES";
            }else{
                q.push(child);
                visited[child] = 1;
            }
        }else{
            return "NO";
        }
    }
}

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\e.in", "r", stdin);

    int most = 10001;
    prime[2] = 0;
    for(int i = 2; i < most; i++ )
    {
        if(prime[i] == 0){
            for(int j= i+i; j < most; j+=i){
                prime[j] = 1;
            }
        }
    }


   int TC;
   cin >> TC;
   while(TC--){
    int k, m;
   visited.clear();
   visited.assign(10001, 0);
    cin >> k >> m;

    if(prime[m] == 1){
        cout << k << " " << m << " NO" << endl;
    }else{
        cout << k << " " << m << " " << f(m) << endl;
    }
   }


    return 0;
}
