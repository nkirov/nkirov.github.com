#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>
#define ll long long
using namespace std;

vector<int> v;
int n,m;
ll bs(ll b, ll e){
    if(b==e){
        return b;
    }
    if(b == e-1){
        ll sum2 = 0;
        for(int i=0; i<v.size(); ++i){
            if(v[i]>e){
                sum2+= v[i]-e;
            }
        }
        if(sum2>= m){
            return e;
        } else return b;
    }
    ll mid = (b+e)/2;
    ll sum = 0;
    for(int i=0; i<v.size(); ++i){
        if(v[i]>mid){
            sum+= v[i]-mid;
        }
    }
    if(sum < m){
        return bs(b, mid-1);
    } else {
        return bs(mid, e);
    }
}
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\h.in", "r", stdin);
    while(scanf("%d %d", &n, &m)==2){
        v.clear();
        while(n--){
            int x;
            scanf("%d", &x);
            v.push_back(x);
        }
        cout << bs(0, 1000000000) << endl;

    }


    return 0;
}
