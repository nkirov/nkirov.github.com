#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>

using namespace std;
vector<vector<int> > v;
int visited[500005];
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\j.in", "r", stdin);

   int n, m;
   int sz = sizeof(int);
   fread(&n, sz, 1, stdin);
   fread(&m, sz, 1, stdin);

   vector<vector<int> > v(n);
   for(int i = 0; i < n; i++){
    v[i].resize(m);
    for(int j = 0; j < m; j++){
       // cin >> v[i][j];
        fread(&v[i][j], sz, 1,  stdin);
    }
   }

   int a, b;
   while(fread(&a, sz, 1,  stdin)){
        fread(&b, sz, 1,  stdin);
    int ans = 0;
    for(int i = 0; i < n; i++){
            vector<int>::iterator it1 = lower_bound(v[i].begin(), v[i].end(),a);
            vector<int>::iterator it2 = v[i].begin();
        int c = it1 - it2;
        int d = upper_bound(v[i].begin(), v[i].end(),b) - v[i].begin();
        ans+=d-c;
    }
    cout << ans << endl;
   }

    return 0;
}
