#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>
using namespace std;

vector<vector<pair<int,int> > > v;
int visited[10000];
int cost(int x, int min_){
    visited[x] = 1;
    int sum = 0;

    bool any = false;
    for(int i=0; i<v[x].size(); ++i){
        pair<int,int> next = v[x][i];
        if(!visited[next.first]){
            sum+=cost(next.first, next.second);
            any = true;
        }
    }
    if(any){
        return min(min_, sum);
    } else {
        return min_;
    }
}
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\c.in", "r", stdin);
    int n, c;
    while(scanf("%d %d", &n, &c)==2){
        c--;
        v.clear();
        v.assign(n, vector<pair<int,int> > ());
        memset(visited, 0 , sizeof(visited));
        for(int p=0 ; p<n-1; ++p){
            int x,y,z;
            scanf("%d %d %d", &x, &y, &z);
            x--; y--;
            v[x].push_back(make_pair(y, z));
            v[y].push_back(make_pair(x, z));
        }
        cout << cost(c, 100000000) << endl;
    }


    return 0;
}
