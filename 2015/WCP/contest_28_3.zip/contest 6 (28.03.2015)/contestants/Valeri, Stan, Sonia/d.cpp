#include <iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>

#include<vector>
#include<set>
#include<queue>
#include<stack>
#include<bitset>
#include<map>
#include<sstream>
#include<algorithm>

using namespace std;

int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\28.03.2015\\d.in", "r", stdin);
    int tc;
    string key, msg, tKey;
    int used[26];

    cin >> tc;
    cin.get();
    while(tc--)
    {
        memset(used, 0, sizeof(used));
        getline(cin, key);
        getline(cin, msg);
        tKey = "";


        for(int i = 0; i < key.length(); i++)
        {
            if(used[key[i]-'A'] == 0)
            {
                tKey += key[i];

            }
            used[key[i]-'A'] = 1;
        }

        int col = tKey.length();
        int row = 26/col;
        if(26%col != 0)
        {
            row++;
        }

        char arr[row][col];
        for(int i = 0; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {
                arr[i][j] = '-';
            }
        }

        for(int i = 0; i < col; i++)
        {
            arr[0][i] = tKey[i];
        }

        int cur = 0;
        int last = 25;

        for(int i = 1; i < row; i++)
        {
            for(int j = 0; j < col; j++)
            {

                while(cur < 26 && used[cur] )
                {
                    cur++;
                }

                arr[i][j] = cur+'A';
                cur++;
            }
        }

        sort(tKey.begin(), tKey.end());
        string crip;
        for(int i = 0; i < col; i++)
        {
            for(int j = 0; j < col; j++)
            {
                if(arr[0][j] == tKey[i])
                {
                    for(int p = 0; p < row-1; p++)
                    {
                        crip += arr[p][j];
                    }
                    if(isalpha( arr[row-1][j]))
                    {
                        crip += arr[row-1][j];
                    }
                }
            }
        }

        map<char, char> m;
        char ch = 'A';
        for(int i = 0; i < crip.length(); i++)
        {
            m[crip[i]] = ch;
            ch++;
        }

        for(int i =0; i < msg.length(); i++)
        {
            if(msg[i] == ' ')
            {
                printf(" ");
                continue;
            }
            printf("%c", m[msg[i]]);
        }
        printf("\n");


    }


    return 0;
}
