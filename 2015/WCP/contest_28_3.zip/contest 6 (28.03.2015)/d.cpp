/*
Adopted from https://www.hackerrank.com/challenges/keyword-transposition-cipher
*/

#include <iostream>
#include <map>
#include <string>
#include <algorithm>
#include <map>
#include <memory.h>
using namespace std;

string keyword, ciphertext;
bool h[30];
string T[30];
map<char, char> mapping;

string removeDuplicateLetters (string s)
{
	memset(h, 0, sizeof h);

	string result;
	for(int i = 0;i < s.size();i++)
	{
		if(!h[s[i] - 'A'])
			result += s[i];

		h[s[i] - 'A'] = true;
	}

	return result;
}

void arange()
{
	int cols = keyword.size();
	int rows = (26 / cols) + (26 % cols);
	
	for(int i = 0;i < 27;i++)
		T[0] = "";

	T[0] = keyword + '.';
	
	int k = -1;
	for(int i = 1;i <= rows;i++)
	{
		T[i] = string(cols, '.');

		for(int j = 0;j < cols;j++)
		{
			while(h[++k]);

			if(k >= 26)
				break;

		    T[i][j] = k + 'A';
		}

		T[i][cols] = '.';
	}

	T[rows + 1] = string(cols, '.');

	int t=0;
}

void makeMapping()
{
	mapping.clear();

	int l = 0;
	for(int i = 0;i < keyword.size();i++)
	{
		int col = T[0].find(keyword[i]);
		int k = 0;
		while(isalpha(T[k++][col]))
		{
			mapping[T[k - 1][col]] = l + 'A';
			l++;
		}
	}
}

void decode()
{
	for(int i = 0;i < ciphertext.size();i++)
		if(isalpha(ciphertext[i]))
			cout<<mapping[ciphertext[i]];
		else
			cout<<ciphertext[i];

	cout<<endl;
}

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	int n;
	cin>>n;
	cin.get();

	while(n--)
	{
		getline(cin, keyword);
		getline(cin, ciphertext);

		//1.
		keyword = removeDuplicateLetters(keyword);

		//2.
		arange();

		//3.
		sort(keyword.begin(), keyword.end());

		//4.
		makeMapping();

		//5.
		decode();
	}

	return 0;
}
