/*
You can download the test data from http://acm.ro/2013/index.html, problem C 
or to check your solution at UVa - https://icpcarchive.ecs.baylor.edu/index.php?option=com_onlinejudge&Itemid=8&category=613&page=show_problem&problem=4437
*/

#include<cstdio>
#include<algorithm>
using namespace std;

int m, n;
int a[10005][10005];

int main()
{
	int sz = sizeof (int);
    fread(&n, sz, 1, stdin);
    fread(&m, sz, 1, stdin);

    for(int i = 0;i < n;i++)
        fread(a[i], sz, m, stdin);

    int l, r, last = m;
    while(fread(&l, sz, 1, stdin))
    {
        fread(&r, sz, 1, stdin);
        int ans = 0;

        for(int i = 0;i < n;i++)
        {
            if(a[i][0] > r)
				break;
            
			int ll = lower_bound(a[i], a[i] + last, l) - a[i];
            int rr = upper_bound(a[i], a[i] + last, r) - a[i];
            
			if(rr <= ll)
				continue;
            
			ans += rr - ll;
        }

        printf("%d\n", ans);
    }

    return 0;
}
