#include<cstdio>
using namespace std;

int a[1000003];

#define max(a, b) a > b ? a : b

int main()
{
    int n, m;
    while(scanf("%d%d", &n, &m) == 2 && n != -1)
	{
		int maks = 0;
		for(int i = 0;i < n; i++)
		{
			scanf("%d", a + i);
			maks = max(maks, a[i]);
		}

		int lo = 0, hi = maks;
		while(lo < hi)
		{
			int mid = (lo + hi + 1) / 2;
			long long ans = 0;
			for(int i = 0;i < n; i++)
				ans += max(0, a[i] - mid);

			if(ans < m) 
				hi = mid - 1;
			else 
				lo = mid;
		}

		printf("%d\n", lo);
	}
}
