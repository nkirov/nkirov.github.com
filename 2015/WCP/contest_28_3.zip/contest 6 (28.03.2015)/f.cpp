/*
 * A - Islands in the Data Stream
 * ICPC 2013 Greater NY Regional
 * Solution by Fred Pickel
 * Problem by Fred Pickel
 */

#include <iostream>
#include <sstream>
#include <string>
using namespace std;

string str;

void solve()
{
	istringstream instr(str);
	
	int cur, prev = 0, res = 0;
	while(instr >> cur)
	{
		if(cur > prev) 
			res++;

		prev = cur;
	}

	cout << res << endl;
}

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while (getline(cin, str))
		solve();

	return 0;
}