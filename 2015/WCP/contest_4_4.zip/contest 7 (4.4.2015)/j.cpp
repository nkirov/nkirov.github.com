#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007
#define MAXN 1000000

const int MAX_ROMAN_LEN = 10;

const char* roman1_9[] = {"", "A", "AA", "AAA", "AB", "B", "BA", "BAA", "BAAA", "AC"};
const char* romanDig[] = {"IVX", "XLC", "CDM", "M" };

void getRomanDig(char* result, char x, unsigned char pow){
    const char* pch;
    for(pch = roman1_9[x]; '\0' != *pch; pch++){
        *result++ = romanDig[pow][*pch - 'A'];
    }
    *result = '\0';
}

char* decToRome(char* result, int x){

    unsigned char pow = 0;
    char buf[10];
    char oldRes[MAX_ROMAN_LEN];
    for(*result = '\0', pow = 0; x > 0; pow++, x/=10){
        getRomanDig(buf, (char)(x%10), pow);
        strcpy(oldRes, result);
        strcpy(result, buf);
        strcat(result,oldRes);
    }
    return result;
}

int toDec(string roman)
{
    int rslt, value, old;
    string saveRoman = roman;
    char buf[MAX_ROMAN_LEN];

    old = 1000;
    rslt = 0;
    int p = 0;
    while(p < roman.length())
    {
        switch(roman[p++])
        {
            case 'I': value = 1; break;
            case 'V': value = 5; break;
            case 'X': value = 10; break;
            case 'L': value = 50; break;
            case 'C': value = 100; break;
            case 'D': value = 500; break;
            case 'M': value = 1000; break;
            default: ;
        }
        rslt += value;
        if(value > old)
        {
            rslt -= 2*old;
        }
        old = value;
    }
    return rslt;
}

int main()
{

   // freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\j.txt", "r", stdin);

    int TC;
    cin >> TC;
    int na, nb, res;
    string a, b, aU, bU;
    char sign;

    while(TC--){
        cin >> a;
        cin >> b;
        cin >> sign;

        aU = "";
        bU = "";
        for(int i = 0; i < a.length(); i++)
        {
            aU += toupper(a[i]);
        }

        for(int i = 0; i < b.length(); i++)
        {
            bU += toupper(b[i]);
        }

        na = toDec(aU);
        nb = toDec(bU);
        bool found = false;
        if(sign == '+')
        {
            res = na + nb;
        }
        else if(sign == '-')
        {
            res = na - nb;
            if(na == nb)
            {
                found = true;
            }
        }
        else if(sign == '*')
        {
            res = na * nb;
        }
        else if(sign == '/')
        {
            res = na / nb;
        }

        char s[MAX_ROMAN_LEN] ;


        char* bss = decToRome(s, res);

        if(found){
            cout << endl;
        }else{
            cout << bss << endl;
        }
    }
    
    return 0;
}
