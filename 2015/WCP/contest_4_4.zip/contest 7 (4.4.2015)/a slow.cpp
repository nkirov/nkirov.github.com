﻿#include <iostream>
using namespace std;

struct square 
{
	int a, b, c, d;
};

bool equals(square a, square b) 
{
	if (a.a == b.a && a.b == b.b && a.c == b.c && a.d == b.d) return true;
	if (a.a == b.b && a.b == b.c && a.c == b.d && a.d == b.a) return true;
	if (a.a == b.c && a.b == b.d && a.c == b.a && a.d == b.b) return true;
	if (a.a == b.d && a.b == b.a && a.c == b.b && a.d == b.c) return true;
	if (a.a == b.a && a.d == b.b && a.c == b.c && a.b == b.d) return true;
	if (a.a == b.b && a.d == b.c && a.c == b.d && a.b == b.a) return true;
	if (a.a == b.c && a.d == b.d && a.c == b.a && a.b == b.b) return true;
	if (a.a == b.d && a.d == b.a && a.c == b.b && a.b == b.c) return true;
	return false;
}

int main() 
{
	int n, cnt;
	for (n = 1; n < 11; n++) 
	{
		cnt = 0;
		square s[10000];
		for (int i = 0; i < n*n*n*n; ++i) 
		{
			int j = i;
			s[i].a = j % n;
			j = j / n;
			s[i].b = j % n;
			j = j / n;
			s[i].c = j % n;
			j = j / n;
			s[i].d = j;
			bool f = true;
			for (j = 0; j < i; ++j) 
			{
				if (equals(s[i], s[j])) 
				{
					f = false;
					break;
				}
			}
			if (f) ++cnt;
		}
		cout << "a[" << n - 1 << "] = " << cnt << ";" << endl;
	}
	return 0;
}