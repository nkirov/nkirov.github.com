#include <iostream>
using namespace std;

//http://judge.openfmi.net:9080/mediawiki/index.php/%D0%A1%D0%9F-2007-%D0%92%D1%82%D0%BE%D1%80%D0%BE-%D0%A1%D1%8A%D1%81%D1%82%D0%B5%D0%B7%D0%B0%D0%BD%D0%B8%D0%B5_-_%D0%A0%D0%B5%D1%88%D0%B5%D0%BD%D0%B8%D0%B5_%D0%BD%D0%B0_squares

int n;
int a[33] = {1, 6, 21, 55, 120, 231, 406, 666, 1035, 1540, 2211, 3081, 4186, 5565, 7260, 9316, 11781, 14706, 18145, 22155, 26796, 32131, 38226, 45150, 52975, 61776, 71631, 82621, 94830, 108345, 123256, 139656};

int main() 
{
	while (!cin.eof()) 
	{
		cin >> n;
		if (!cin) return 0;
		cout << a[n - 1] << endl;
	}

	return 0;
}
