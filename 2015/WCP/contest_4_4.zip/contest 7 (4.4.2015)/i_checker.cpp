#include <stdio.h>
#include <stdlib.h>
   int g[501][501];
   int O[2000000];

int main(int argc, char *argv[])
{
   FILE * in; FILE * ou;
   int t,T,N,le=1,re=1,ed,i,j,k,p; 
   if (argc != 3)
   {  printf("bw_checker input_file competitor_answer");
      return 1;
   }

   in=fopen(argv[1],"r");
   if((ou=fopen(argv[2],"r"))==NULL)
   {printf("No output file!\n"); fclose(in);return 1;}

   fscanf(in,"%d",&T);
   for(t=1;t<=T;t++)
   { 
       fscanf(in,"%d",&N);
	   for(i=1;i<=N;i++)
		   for(j=0;j<=N;j++)
			   g[i][j]=0;
       ed=0;
       while(1)
	   {
          fscanf(in,"%d %d",&le,&re);
		  if(le==0) break;
		  ed++;
		  g[le][re]++;g[re][le]++;
		  g[le][0]++;g[re][0]++;
	   }
 	   //odd degrees
	   p=0;
	   for(i=1;i<=N;i++) if(g[i][0]%2) p++;
       if(p==0)p=1; else p=p/2;
       fscanf(ou,"%d",&re);
	   if(p!=re)
	   { printf("Test %d - wrong number of paths!\n",t); 
         fclose(in);fclose(ou); return 1;}
       for(i=1;i<=p;i++)
       {  if(fscanf(ou,"%d",&le)== -1)
          { printf("Test %d - not all edges covered!\n",t); 
            fclose(in);fclose(ou);return 1;}
          if(fscanf(ou,"%d",&re)== -1||re==0)
          {  printf("Test %d - not all edges covered!\n",t);
             fclose(in);fclose(ou); return 1;}
          while(re!=0)
	      {
//		     printf("(%d,%d)=%d=%d\n",le,re,g[le][re],g[re][le]);
             if(g[le][re]!=0)
		     {
		        g[le][re]--;g[re][le]--;
			    ed--;
		     }
		     else
		     {
                printf("Test %d - wrong edge (%d,%d)!\n",t,le,re);
                  fclose(in);fclose(ou); return 1;
             }
		     le=re;
             if(fscanf(ou,"%d",&re)== -1)
             {  printf("Test %d - Unexpected end of output!\n",t);
                fclose(in);fclose(ou); return 1;}
             }   
	   }
	   if(ed>0)
       {  printf("Test %d - not all edges covered!\n",t);
          fclose(in);fclose(ou); return 1;}

   }
   printf("OK!\n");
   fclose(in);fclose(ou);
   return 0;
}
