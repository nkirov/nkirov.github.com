#include <stdio.h>
int g[501][501],h[501][501],O[262144],P[262144],r;
void Euler_loop()
{  int i,j;
   O[0]=1;i=0;
	do
	{
	   do
	   {
		   if(g[O[i]][0]==0) break;
		   j=1;
		   while(g[O[i]][j]==0)j++;
		   g[O[i]][j]--;g[j][O[i]]--;
		   g[O[i]][0]--;g[j][0]--;
		   O[++i]=j;
		} while(1);
      while(i>=0 && g[O[i]][0]==0){printf("%d ",O[i]);i--;}
		if(i<0) break;
	 } while(1);
}

void Euler_cover(int b)
{  int i,j;
   O[0]=b;i=0;
	do
	{
	   do
	   {
		   if(g[O[i]][0]==0) break;
		   j=1;
		   while(g[O[i]][j]==0)j++;
		   g[O[i]][j]--;g[j][O[i]]--;
		   g[O[i]][0]--;g[j][0]--;
		   O[++i]=j;
		} while(1);
      while(i>=0 && g[O[i]][0]==0)
      { if (h[O[i]][O[i-1]]==0)
        {
           printf("%d ",O[i]);i--;
        }
        else
        {  h[O[i]][O[i-1]]--;h[O[i-1]][O[i]]--;
           printf("%d 0\n",O[i]);i--;
        }
      }
		if(i<0) break;
	 } while(1);
}

int main()
{
   int t,T,N,le=1,re=1,i,j,k,flag,st;

   scanf("%d",&T);
   for(t=1;t<=T;t++)
   {   scanf("%d",&N);
	   for(i=1;i<=N;i++)
		   for(j=0;j<=N;j++)
			{  g[i][j]=0;  h[i][j]=0; }
       while(1)
	   {  scanf("%d %d",&le,&re);
		  if(le==0) break;
		  g[le][re]++;g[re][le]++;
		  g[le][0]++;g[re][0]++;
	   }
 	   //odd degrees
	   le=0;
	   for(i=1;i<=N;i++)
		   if(g[i][0]%2) le++;
       if(le==0) //if 0 odd degrees - Euler cycle
	   {
        printf("1\n");
        Euler_loop();
        printf("0\n");
	   }
	   else // if nonzero odd egrees - le/2 paths.
	   {  le=le/2;
	      printf("%d\n",le);
		   k=1;flag=1;
		   while(1)
         { while(k<=N&&g[k][0]%2==0) k++;
           if(k>N) break;
           le=k++;
           while(g[k][0]%2==0) k++;
		     re=k++;
		     if(flag) {st=le;flag=0;}
		     else {
		     g[le][re]++;g[re][le]++;
		     h[le][re]++;h[re][le]++;
		     g[le][0]++;g[re][0]++;
//printf("(%d %d)\n",le,re);
		     }
         }
		   Euler_cover(st);
		   printf("0\n");
		 }
   }
}
