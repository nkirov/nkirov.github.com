#include <stdio.h>
#include <algorithm>
#include <set>
#include <string>
#include <string.h>
#include <assert.h>

using namespace std;

char keyboard[3][11] = {
	"qwertyuiop",
	"asdfghjkl#",
	"zxcvbnm###"
};

int mapping[256][2];
int distMatrix[256][256];

void precompute()
{	
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 10; j++) 
		{
			mapping[(int) keyboard[i][j]][0] = i;
			mapping[(int) keyboard[i][j]][1] = j;
		}
	}
	
	for (int i = 0; i < 256; i++)
	{
		for (int j = i + 1; j < 256; j++)
		{
			distMatrix[i][j] = abs(mapping[i][0] - mapping[j][0]) + abs(mapping[i][1] - mapping[j][1]);
			distMatrix[j][i] = distMatrix[i][j];
		}
	}
}

int main() 
{
	precompute();

	int t;
	scanf("%d", &t);
	while (t--) 
	{
		int numStrings;
		multiset<pair<int,string> > result;
		char buf[10005], orig[10005];
		scanf("%s%d", orig, &numStrings);

		for (int i = 0; i < numStrings; i++) 
		{
			int cur = 0;
			scanf("%s", buf);
			for (int i = 0; i < (signed) strlen(buf); i++) 
				cur += distMatrix[(int)buf[i]][(int)orig[i]];

			result.insert(make_pair(cur, string(buf)));
		}

		for (multiset<pair<int,string> >::iterator it = result.begin(); it != result.end(); it++) {
			printf("%s %d\n", it->second.c_str(), it->first);
		}
	}

	return 0;
}
