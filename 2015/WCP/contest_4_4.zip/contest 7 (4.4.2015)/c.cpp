#include <stdio.h>

int main()
{
	int t, p, n, imax;
	
	scanf("%d", &t);
	while(t--)
	{
		scanf("%d%d", &p, &n);
		imax = n;
		while(n > 1)
		{
			if(n & 1)
				n = 3 * n + 1;
			else 
				n /= 2;
				
			if(n > imax)
				imax = n;
		}

		printf("%d %d\n", p, imax);
	}

	return 0;
}
