#include <iostream>
#include <string>
using namespace std;

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int t;
	cin>>t;
	cin.get();

	while(t--)
	{
		string name;
		getline(cin, name);
		int k, i, n, a, b, s = 0;

		n = name.size();
		for(i = 0;i < n;i++)
		{
			if(name[i] < 'a') 
				name[i] = name[i] + 32;
 
			k = name[i] - 'a' + 1;
			a = k % 9; 
			if(a == 0) 
				a = 9;
			
			s = s + a; 
		}

		if(s <= 9) 
			b = s;
		else if(s == 33) 
			b = 33;
		else if(s > 9 && s < 100) 
		{
			b = s / 10 + s % 10; 
			if (b > 9) 
				b = b / 10 + b % 10; 
		}
		else if(s > 99) 
		{ 
			b = s / 100 + s / 10 % 10 + s % 10; 
			if (b > 9)  
				b = b / 10 + b % 10; 
		}
		
		cout<<b<<endl;
	}

	return 0;
}
