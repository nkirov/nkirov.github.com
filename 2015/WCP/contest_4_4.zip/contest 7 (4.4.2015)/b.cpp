#include<iostream>
#include<string>
using namespace std;

string s;
char  a[2100];

int pal(int k)
{
	int m = k / 2;
	for (int i = 1;i <= m;i++)
		if (a[i] != a[k + 1 - i])
			return 0;
	
	return 1;
}

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while(getline(cin, s))
	{
		int n = s.size();
		for(int i = 0;i < n;i++)
			a[i + 1] = s[i];

		for (int i = 0;i <= n - 1;i++)
		{
			for(int j = 1;j <= i;j++)
				a[n + j] = a[i + 1 - j]; 
			
			if(pal(n + i))
			{
				cout<<i<<endl; 
				if(i > 0)
				{
					for(int j = 1;j <= i;j++)
						cout<<a[n + j];
					cout<<endl;
				}

				break;
			}
		}
	}

	return 0;
}