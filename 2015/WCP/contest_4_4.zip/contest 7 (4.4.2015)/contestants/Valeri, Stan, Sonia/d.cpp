#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007

using namespace std;

int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\d.txt", "r", stdin);
    int n;
    scanf("%d", &n);
    int a[26] = {1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,8};
    for(int i = 0; i < n; i++){
        string curr;
        cin >> curr;
        int sum = 0;
        for(int j = 0; j < curr.length(); j++){

            sum += a[tolower(curr[j]) -'a'];
        }

        while(sum > 9 && sum != 33){
                int k = sum;
                int p = 0;
            while(k > 0){
                p+=k%10;
                k/=10;
            }
            sum = p;
        }

        cout << sum << endl;
    }

    return 0;
}

