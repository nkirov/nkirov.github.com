#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007

using namespace std;

int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\b.txt", "r", stdin);
    string s;
    while(cin >> s){
        int index = s.size()-1;
        for(int i=0; i<s.size(); ++i){
            bool pal = true;
            for(int j=i; j<=(i+s.size())/2; ++j){
                if(s[j]!=s[s.size()-1-(j-i)]){
                    pal = false;
                }
            }
            if(pal){
                index = i;
               break;
            }
        }
        printf("%d\n", index);
        for(int k=index-1; k>=0; --k){
            printf("%c", s[k]);
        }
        if(index)
        printf("\n");
    }
    return 0;
}
