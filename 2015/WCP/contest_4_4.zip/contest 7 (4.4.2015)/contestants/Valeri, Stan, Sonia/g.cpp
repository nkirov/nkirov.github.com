#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007

using namespace std;
pair<int,int> arr[26] = {make_pair(1,0),//a
                        make_pair(2,4), //b
                        make_pair(2,2), //c
                        make_pair(1,2), //d
                        make_pair(0,2), //e
                        make_pair(1,3), //f
                        make_pair(1,4), //g
                        make_pair(1,5), //h
                        make_pair(0,7), // i
                        make_pair(1,6), // j
                        make_pair(1,7), // k
                        make_pair(1,8), // l
                        make_pair(2,6), // m
                        make_pair(2,5), // n
                        make_pair(0,8), // o
                        make_pair(0,9), // p
                        make_pair(0,0), // q
                        make_pair(0,3), // r
                        make_pair(1,1), // s
                        make_pair(0,4), // t
                        make_pair(0,6), // u
                        make_pair(2,3), // v
                        make_pair(0,1), // w
                        make_pair(2,1), // x
                        make_pair(0,5), // y
                        make_pair(2,0)  // z
};
int main()
{
  //  freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\g.txt", "r", stdin);
    ios_base::sync_with_stdio(false);
    int TC;
    cin >> TC;
    string s;
    string s1;
    int l;
    while(TC--){
        cin >> s >> l;
        vector<pair<int, string> > res;
        while(l--){
            cin >> s1;
            int dist = 0;
            for(int i=0; i<s.size(); ++i){
                pair<int,int> p1 = arr[s[i]-'a'];
                pair<int,int> p2 = arr[s1[i]-'a'];
                dist+= abs(p1.first - p2.first) + abs(p1.second - p2.second);
            }
            res.push_back(make_pair(dist, s1));
        }
        sort(res.begin(), res.end());
        for(int i=0; i<res.size(); ++i){
            cout << res[i].second << " " << res[i].first << endl;
        }
    }
    return 0;
}
