#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>
#include <list>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007
#define MAXN 1000000
int mat[512][512];
int main()
{

  // freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\a.txt", "r", stdin);
    long long n;
    while(cin >> n){
        long long sum = 0;
        sum+=n;
        sum+=n*(n-1)*4/2;
        sum+=n*(n-1)*(n-2);
        sum+=n*(n-1)*(n-2)*(n-3)/8;
        cout << sum << endl;
    }
    return 0;
}
