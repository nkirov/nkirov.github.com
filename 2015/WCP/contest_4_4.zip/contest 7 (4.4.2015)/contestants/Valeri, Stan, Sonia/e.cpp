#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007
#define MAXN 1000000
int gcd(int a, int b){
    return b==0 ? a : gcd(b, a % b);
}
int lcm (int a, int b){
    return a * (b / gcd(a,b));
}
vector<vector<pair<int,int> > > v;
int dist[1000];
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\e.txt", "r", stdin);

    int TC;
    int n, m;
    int a,b,c,d;
    scanf("%d", &TC);
    while(TC--){
        priority_queue<pair<int,int> > q;
       // memset(dist, -1, sizeof(dist));
        scanf("%d %d", &n, &m);
        for(int i=0; i<=n; ++i){
            dist[i] = INF;
        }
        v.clear();
        v.assign(n, vector<pair<int,int> >());
        while(m--){
            scanf("%d %d %d %d", &a, &b,&c, &d);
            int w = lcm(b,d);
            a--; c--;
            v[a].push_back(make_pair(c, w));
            v[c].push_back(make_pair(a, w));
        }
        dist[0] = 0;
        q.push(make_pair(0, 0));
        while(!q.empty()){
            pair<int,int> p = q.top(); q.pop();
            if(dist[p.second]<p.first){
                continue;
            }
            for(int i=0; i<v[p.second].size(); ++i){
                int lc = v[p.second][i].second;
                int new_w;
                if(dist[p.second]%lc==0 && dist[p.second]/lc!=0){
                    new_w = dist[p.second] + 1;
                } else {
                    new_w = ((dist[p.second]/lc)+1) * lc + 1;
                }
                if(dist[ v[p.second][i].first ] > new_w){
                    dist[v[p.second][i].first ] = new_w;
                    q.push(make_pair(new_w, v[p.second][i].first));
                }
            }
        }
        cout << dist[n-1]-1 << ".5" << endl;
    }
    return 0;
}
