#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007
#define MAXN 1000000

ll f(ll n){
    ll res = n;
    while(n!=1){
        if(n%2==0){
            n/=2;
        } else {
            n= 3*n + 1;
        }
        res = max(res, n);
    }
    return res;
}


int main()
{
    ios_base::sync_with_stdio(false);
  //  freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\c.txt", "r", stdin);
    int TC;
    int test;
    int n;
    cin >> TC;//scanf("%d", &TC);
    while(TC--){
        cin >> test >> n;//scanf("%d %d", &test, &n);
        cout << test << " " << f(n) << "\n";
    }
    return 0;
}
