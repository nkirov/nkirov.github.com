#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <cctype>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <bitset>
#include <iterator>
#include <list>

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define INF 1e9
#define ll long long
#define ull unsigned long long
#define MOD 1000000007
#define MAXN 1000000
int mat[512][512];
int main()
{

   // freopen("C:\\Users\\Administrator\\Desktop\\04.04.2015\\h.txt", "r", stdin);
    int TC;
    int n;
    scanf("%d", &TC);
    int x,y;
    while(TC--){
        int id, n;
        cin >> id >> n;
        vector<long long> rests;
        rests.push_back(1);
        rests.push_back(1);

        int lp = 0;
        int rp = rests.size() -1;
        int i = 2;
        while(lp < rp){
            long long nextFib = rests[i - 1] + rests[i-2];

            long long rest = nextFib%n;
        //cout <<i<<" " <<rests.size() << " " <<nextFib << " " << rest << endl;
            if(rests[lp] == rest){
                lp++;
                rests.push_back(rest);
            }else{
                for(int j = 0; j < lp; j++){
                   rp++;
                }
                lp = 0;
                rests.push_back(rest);
                rp++;
            }
            i++;
        }
        cout << id << " " << lp + 1 << endl;
    }

    return 0;
}
