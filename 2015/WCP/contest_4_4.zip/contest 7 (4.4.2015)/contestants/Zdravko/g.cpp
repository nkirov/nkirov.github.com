#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

string Matr[3]={"qwertyuiop","asdfghjkl","zxcvbnm"};

int findDif(char ch1,int ch2)
{
    int ipos1,ipos2,jpos1,jpos2;
    for(int i=0;i<3;i++)
    {
        std::size_t word = Matr[i].find(ch1);
        if(word!=string::npos)
        {
            ipos1=i;
            ipos2=word;
            goto L_Skip1;
        }
    }
    L_Skip1:;

    for(int i=0;i<3;i++)
    {
        std::size_t word = Matr[i].find(ch2);
        if(word!=string::npos)
        {
            jpos1=i;
            jpos2=word;
            goto L_Skip2;
        }
    }
    L_Skip2:;

    return abs(ipos1-jpos1)+abs(ipos2-jpos2);
}

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        string in;
        int c;
        cin >> in >> c;
        vector< pair<int,string> > Corr(c);
        int len=in.length();
        for(int i=0;i<c;i++)
        {
            string input;
            cin >> input;
            Corr[i]=make_pair(0,input);
            for(int j=0;j<len;j++)
                if(input[j]!=in[j])
                    Corr[i].first+= findDif(input[j],in[j]);

        }
        sort(Corr.begin(),Corr.end());
        for(int i=0;i<c;i++)
            cout << Corr[i].second << " " <<  Corr[i].first << endl;
    }

    return 0;
}
