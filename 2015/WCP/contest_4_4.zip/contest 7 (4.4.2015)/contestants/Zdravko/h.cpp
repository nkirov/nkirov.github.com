#include <iostream>
#include <stdio.h>
#include <bitset>

using namespace std;
typedef long long ll;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int m,num;
        scanf("%d%d",&num,&m);
        {
            long long ToFind=1%m;
            long long Count=0,Left=2;
            long long FibNext=1,FibPrev=1,FibNew;

            do
            {
                FibNew=(FibNext+FibPrev)%m;
                if(FibNew==ToFind)
                    Left--;
                else
                    Left=2;
                FibPrev=FibNext;
                FibNext=FibNew;
                Count++;
            }
            while(Left>0);

            printf("%d %d\n",num,Count);
        }
    }

    return 0;
}
