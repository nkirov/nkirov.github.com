#include <iostream>
#include <stdio.h>
#include <climits>

using namespace std;

int main()
{
    int t,num,n;
    cin >> t;
    while(t--)
    {
        scanf("%d%d",&num,&n);
        int MAX=n;
        while(n>1)
        {
            if(n%2==0)
            {
                n/=2;
            }
            else
            {
                n=3*n+1;
                if(MAX<n)
                    MAX=n;
            }
        }
        printf("%d %d\n",num,MAX);
    }
    return 0;
}
