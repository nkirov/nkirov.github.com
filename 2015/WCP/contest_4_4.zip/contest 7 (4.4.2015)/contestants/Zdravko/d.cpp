#include <iostream>
#include <stdlib.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>

using namespace std;


void to_Upper(string &s)
{
    for(int i=0;i<s.length();i++)
        if(s[i]>='a')
            s[i]-=32;
}

int main()
{
    string Table[]={"AJS1","BKT2","CLU3","DMV4","ENW5","FOX6","GPY7","HQZ8","IR9"};
    int t;
    cin >> t;
    while(t--)
    {
        string Input;
        cin >> Input;

        to_Upper(Input);
        int len=Input.length(),sum=0;
        for(int i=0;i<len;i++)
        {
            for(int j=0;j<9;j++)
            {
                if(Table[j].find(Input[i])!= string::npos)
                {
                    sum+=j+1;
                    goto L_Skip;
                }
            }
            L_Skip:;
        }
        if(sum<10 || sum==33)
            cout << sum << endl;
        else
        {
            char *s;
            while(sum>=10)
            {
                sprintf(s,"%d",sum);
                int len = strlen(s),temp=0;
                for(int i=0;i<len;i++)
                    temp += s[i]-'0';
                sum=temp;
            }
            cout << sum << endl;
        }
    }

    return 0;
}
