#include <iostream>
#include <string>
#include <map>

std::map<char,int> Rome;

using namespace std;

int ToNumber(string &s)
{
    int num=0;
    for(int i=0;i<s.length();i++)
    {
        if(s[i]=='I' || s[i]=='i')                 if(i<s.length()-1 && s[i+1]!='I'){num-=1;} else {num+=1;}
        else if(s[i]=='V' || s[i]=='v')            if(i<s.length()-1 && Rome[s[i+1]]>Rome['V']){num-=5;} else {num+=5;}
        else if(s[i]=='X' || s[i]=='x')            if(i<s.length()-1 && Rome[s[i+1]]>Rome['X']){num-=10;} else {num+=10;}
        else if(s[i]=='L' || s[i]=='l')            if(i<s.length()-1 && Rome[s[i+1]]>Rome['L']){num-=50;} else {num+=50;}
        else if(s[i]=='C' || s[i]=='c')            if(i<s.length()-1 && Rome[s[i+1]]>Rome['C']){num-=100;} else {num+=100;}
        else if(s[i]=='D' || s[i]=='d')            if(i<s.length()-1 && Rome[s[i+1]]>Rome['D']){num-=500;} else {num+=500;}
        else if(s[i]=='M' || s[i]=='m')            num+=1000;
    }
    return num;
}

string ToString(int &num)
{
    string res="";
    while(num>=1000)        {res.insert(res.length(),"M");(num-=1000);}
    while(num>=900)        {res.insert(res.length(),"CM");(num-=900);}
    while(num>=500)        {res.insert(res.length(),"D");(num-=500);}
    while(num>=400)        {res.insert(res.length(),"CD");(num-=400);}
    while(num>=100)        {res.insert(res.length(),"C");(num-=100);}
    while(num>=90)        {res.insert(res.length(),"XC");(num-=90);}
    while(num>=50)        {res.insert(res.length(),"L");(num-=50);}
    while(num>=40)        {res.insert(res.length(),"XL");(num-=40);}
    while(num>=10)        {res.insert(res.length(),"X");(num-=10);}
    while(num>=9)        {res.insert(res.length(),"IX");(num-=9);}
    while(num>=5)        {res.insert(res.length(),"V");(num-=5);}
    while(num>=4)        {res.insert(res.length(),"IV");(num-=4);}
    while(num>=1)        {res.insert(res.length(),"I");(num--);}

    return res;
}

int main()
{
    Rome['I']=1;
    Rome['V']=5;
    Rome['X']=10;
    Rome['L']=50;
    Rome['C']=100;
    Rome['D']=500;
    Rome['M']=1000;

    int t;
    cin >> t;
    while(t--)
    {
        string as,bs,op;
        int a,b;
        cin >> as >> bs >> op;
        a = ToNumber(as);
        b = ToNumber(bs);
        int num;
        if(op=="+")            num=a+b;
        else if(op=="-")            num=a-b;
        else if(op=="*")            num=a*b;
        else if(op=="/")            num=a/b;

        cout << ToString(num) << endl;
    }

    return 0;
}
