#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<sstream>
#include<stack>
#include<iomanip>
#include<functional>
#include<cmath>
#include<algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int matrix[256][256];

int column[256];
string keyboard[3] = 
{
	"qwertyuiop",
	"asdfghjkl",
	"zxcvbnm"
};

void gen_matrix()
{
	for (int row = 0; row < 3; row++)
	{
		for (int col = 0; col < keyboard[row].size(); col++)
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < keyboard[i].size(); j++)
				{
					matrix[keyboard[row][col]][keyboard[i][j]] = abs(row - i) + abs(col - j);
				}
			}
		}
	}
}

vector<pair<int, string> > arr;

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	gen_matrix();

	int N, qNum;
	string org, q;
	cin >> N;

	while (N--)
	{
		cin >> org >> qNum;

		for (int i = 0; i < qNum; i++)
		{
			cin >> q;

			int sum = 0;

			for (int j = 0; j < q.size(); j++)
			{
				sum += matrix[q[j]][org[j]];
			}

			arr.push_back(make_pair(sum, q));
		}

		sort(arr.begin(), arr.end());

		for (int i = 0; i < arr.size(); i++)
		{
			cout << arr[i].second << " " << arr[i].first << endl;
		}

		arr.clear();
	}

	return 0;
}
