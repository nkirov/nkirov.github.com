#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int arr[256];

int main()
{
	int n;
	cin.sync_with_stdio(0);
	cin.tie(0);

	arr['A'] = arr['J'] = arr['S'] = arr['a'] = arr['j'] = arr['s'] = 1;
	arr['B'] = arr['K'] = arr['T'] = arr['b'] = arr['k'] = arr['t'] = 2;
	arr['C'] = arr['L'] = arr['U'] = arr['c'] = arr['l'] = arr['u'] = 3;
	arr['D'] = arr['M'] = arr['V'] = arr['d'] = arr['m'] = arr['v'] = 4;
	arr['E'] = arr['N'] = arr['W'] = arr['e'] = arr['n'] = arr['w'] = 5;
	arr['F'] = arr['O'] = arr['X'] = arr['f'] = arr['o'] = arr['x'] = 6;
	arr['G'] = arr['P'] = arr['Y'] = arr['g'] = arr['p'] = arr['y'] = 7;
	arr['H'] = arr['Q'] = arr['Z'] = arr['h'] = arr['q'] = arr['z'] = 8;
	arr['I'] = arr['R'] = arr['i'] = arr['r'] = 9;

	string str;
	cin >> n;

	for (int i = 0; i < n; i++)
	{
		cin >> str;
		int sum = 0, tempSum = 0;

		for (int j = 0; j < str.size(); j++)
		{
			sum += arr[str[j]];
		}

		if(sum == 33)
		{
			cout << "33" << endl;
			continue;
		}

		while(sum > 9)
		{
			tempSum = sum;
			sum = 0;

			while (tempSum != 0)
			{
				sum += (tempSum % 10);
				tempSum /= 10;
			}
		}

		cout << sum << endl;
	}

	return 0;
}
