#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);
	
	int k;
	while(cin >> k)
	{
		if(k == 1)
		{
			cout << "1"<< endl;
			continue;
		}
		if(k == 2)
		{
			cout << "6" << endl;
			continue;
		}
		if(k == 3)
		{
			cout << k+(2*k)*(k-1) + k*(k-1)*(k-2) << endl;
			continue;
		}
		else
		    cout << k+(2*k)*(k-1) + k*(k-1)*(k-2) + k*(k-1)*(k-2)*(k-3)/8 << endl;
      }

	return 0;
}
