#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>
#include<algorithm>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;


string T, P;
int b[100010];
int n,m;
int ptr;

void kmp1()
{
	int i = 0, j = -1; b[0] = -1;
	while(i<m){
		while(j >= 0 && P[i] != P[j] ) j = b[j];
		i++;j++;
		b[i] = j;
}}
void kmp2()
{
	int i = 0, j = 0;
	while(i < n)
	{
		while(j>= 0 && T[i] != P[j]) j = b[j];
		i++;j++;
		ptr = i-j;
		if(j ==m )
		{
			//found
			j= b[j];
		}}}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	while(cin >> T)
	{
		memset(b,0,sizeof(b));
		P = T;
		reverse(P.begin(),P.end());	
		n = T.length(); m = P.length();
		kmp1(); kmp2();
		if(ptr == 0 )
		{
			cout << ptr << endl;
		}else{

		cout << ptr << endl;
		if(ptr > 0 )
		{
			for (int i = ptr-1; i >= 0; i--)
			{
				cout << T[i];
			}
			cout << endl;
		}
		}
	}













}
