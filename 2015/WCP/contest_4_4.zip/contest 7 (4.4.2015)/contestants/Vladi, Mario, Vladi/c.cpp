#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;

vector<ii> graph[1024];

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int t, k, n, maxx;

	cin >> t;

	for (int i = 0; i < t; i++)
	{
		cin >> k >> n;
		maxx = n;

		while (n != 1)
		{
			if(n > maxx)
				maxx = n;

			/*if(n && !(n & (n - 1)))
				break;*/

			if(n % 2 == 0)
				n /= 2;
			else
				n = (3*n) + 1;
		}

		cout << k << " " << maxx << endl;
	}

	return 0;
}
