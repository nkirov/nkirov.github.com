#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<iomanip>
#include<functional>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef pair<int, int> ii;


const char  *roman1_9[]={"" , "A", "AA", "AAA" , "AB", "B", "BA", "BAA", "BAAA", "AC"};
const char *romanDigits[] = {"IVX" , "XLC" , "CDM", "M"};


void getRomanDigit(char *rslt, char x, unsigned char power)
{
	const char *pch;

	for (pch = roman1_9[x]; '\0' != *pch; pch++)
		*rslt++ = romanDigits[power][*pch - 'A'];

	*rslt = '\0';
}

char *decimal2Roman(char *rslt, unsigned x)
{ 
	unsigned char power;
	char buf[10];
	char oldRslt[256];

	for (*rslt = '\0', power = 0; x > 0; power++, x /= 10) 
	{
		getRomanDigit(buf, (char)(x % 10), power);
		strcpy(oldRslt, rslt);
		strcpy(rslt,buf);
		strcat(rslt,oldRslt);
	}

	return rslt;
}

unsigned roman2Decimal(const char *roman, char *error)
{
	unsigned rslt, value, old;
	const char *saveRoman = roman;
	char buf[256];
	old = 1000; rslt = 0;
	while ('\0' != * roman)
	{
		switch (*roman++) {
		case 'I': value = 1; break;
		case 'V': value = 5; break;
		case 'X': value = 10; break;
		case 'L': value = 50; break;
		case 'C': value = 100; break;
		case 'D': value = 500; break;
		case 'M': value = 1000; break;
		default:
		 *error = 1;
		 return (unsigned)(-1);
		 }
		 rslt += value;
		 if (value > old)
		rslt -= 2*old;
		 old = value;
	}
	return (*error = strcmp(saveRoman,decimal2Roman(buf,rslt)))
 ? (unsigned)(-1) : rslt;
}

int main()
{
	int N;
	
	/*while(N--)
	{
		getline(cin , A); cin.get();
		getline(cin , A); 
		getline(cin , B);
		char op;
		transform(A.begin(), A.end(), A.begin(), ::toupper);
		transform(B.begin(), B.end(),B.begin(), ::toupper);
		op = cin.get();
		


		c

	}*/
	unsigned aNum, bNum, resNum;
	char A[256], B[256], res[256], err[256], operation;
	scanf("%d", &N);

	while(N--)
	{
		scanf("%s", A);
		scanf("%s", B);

		int index = 0;

		while (A[index] != '\0')
		{
			A[index] = toupper(A[index]);
			index++;
		}
		index = 0;
		while (B[index] != '\0')
		{
			B[index] = toupper(B[index]);
			index++;
		}

		getchar();
		scanf("%c", &operation);

		aNum = roman2Decimal(A, err);
		bNum = roman2Decimal(B, err);

		if(operation == '+')
		{
			resNum = aNum + bNum;
		}
		else if(operation == '*')
		{
			resNum = aNum * bNum;
		}
		else if(operation == '/')
		{
			resNum = aNum / bNum;
		}
		else if(operation == '-')
		{
			resNum = aNum - bNum;
		}

		decimal2Roman(res, resNum);

		printf("%s\n", res);
	}

	

	//char res[256];
	//char err;
	//char str[256];
	//scanf("%s", str);
	//	unsigned chislo = roman2Decimal(str, &err);


	//	cout << chislo << endl;

	//	
	//		
	//		decimal2Roman(res, chislo);
	//		printf("%s\n", res);
	return 0;
}
