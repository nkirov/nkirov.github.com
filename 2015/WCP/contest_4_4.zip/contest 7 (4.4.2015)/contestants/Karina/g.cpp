#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <set>
#include <cmath>

using namespace std;

char chars[3][10] = {{'q','w','e','r','t','y','u','i','o','p'},{'a','s','d','f','g','h','j','k','l','/'},{'z','x','c','v','b','n','m','/','/','/'}};
int mat[26][26] = {};
string a,b;
struct classcomp {
  bool operator() (const pair<int,string>& lhs, const pair<int,string>& rhs) const{
    if (lhs.first==rhs.first) {
            int sz = lhs.second.size();
            int i = 0;
            while ( i < sz-1 && lhs.second[i] == rhs.second[i]) i++;
            return lhs.second[i] < rhs.second[i];
    }
    else {
            return lhs.first < rhs.first;
    }
  }
};
set<pair<int,string>,classcomp> map4e;
int tc,counter;

void init(){
    for(int i = 0; i< 3; i++){
        for(int j = 0;j < 10; j++){
            char c1 = chars[i][j];
            if(c1 == '/') continue;
            for(int r = 0; r < 3; r++){
            for(int c = 0 ;c < 10; c++){
                char c2 = chars[r][c];
                if(c2 == '/') continue;
                int dist  = abs(i-r) + abs(j-c);
                mat[c1-'a'][c2-'a'] = mat[c2-'a'][c1-'a'] = dist;
            }
            }
        }
    }
}

void solve(){
    int sz = a.size();
    int sum= 0;
    for(int i = 0;i < sz; i++){
        sum+= mat[a[i]-'a'][b[i]-'a'];
    }
    map4e.insert(pair<int,string>(sum,b));
}


int main(){
    cin>>tc;
    init();
    while(tc--){
        cin>>a>>counter;
        while(counter--){
            cin>>b;
            solve();

        }
        for(set< pair<int,string> >::iterator it = map4e.begin();it!=map4e.end();++it){
            cout<<it->second<<" "<<it->first<<endl;
        }
        map4e.clear();
    }
    return 0;
}
