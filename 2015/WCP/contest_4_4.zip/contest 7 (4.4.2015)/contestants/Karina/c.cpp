#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
using namespace std;

int tc,k;
long long n;

long long solve(){
    long long maxx = n;
    while (n != 1){
        if (n%2 == 0) n=n/2;
        else n = 3*n+1;

        if (n > maxx) maxx = n;
    }
    return maxx;
}

int main(){
    cin>>tc;
    while(tc--){
        cin>>k>>n;
        cout<<k<<" "<<solve()<<endl;
    }
    return 0;
}
