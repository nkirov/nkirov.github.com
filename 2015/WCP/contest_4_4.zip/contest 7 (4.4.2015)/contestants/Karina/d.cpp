#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
using namespace std;

int mat[26] = {1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,8,9,1,2,3,4,5,6,7,8};
string line;
int tc,tmp,sum;
char c;
void solve(){
    while (sum > 9 && sum != 33){
        int ts = 0;
        while(sum>0){
           ts+=sum%10;
           sum = sum/10;
        }
        sum = ts;
        ts = 0;
    }
}

int main(){
    getline(cin,line);
    istringstream isk(line);
    isk>>tc;
    while(tc--){
        sum = 0;
        getline(cin,line);
        istringstream is(line);
        while(is>>c){
            if(c < 'a') tmp = c-'A';
            else tmp = c-'a';
            sum += mat[tmp];
        }
        solve();
        cout<<sum<<endl;
    }
    return 0;
}

