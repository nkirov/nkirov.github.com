#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <map>
using namespace std;
map<int,int> mp;
string x,y;
long long a,b,c;
char sg;
int tc,tmp;

void f(){
mp['i'-'a'] = 1;
mp['v'-'a'] = 5;
mp['x'-'a'] = 10;
mp['l'-'a'] = 50;
mp['c'-'a'] = 100;
mp['d'-'a'] = 500;
mp['m'-'a'] = 1000;

}


void init(){
    a=b=0;
    int sz = x.size();
    int prev =0;
   for(int i = sz - 1; i>=0 ;i--){
        if (x[i] < 'a') tmp = x[i] - 'A';
        else tmp = x[i] - 'a';
       if (prev && mp[tmp] < mp[prev]) {a-=mp[tmp];}
       else {a+=mp[tmp];}
       prev = tmp;
   }
  sz = y.size();
    prev =0;
   for(int i = sz - 1; i>=0 ;i--){
        if (y[i] < 'a') tmp = y[i] - 'A';
        else tmp = y[i] - 'a';
       if (prev && mp[tmp] < mp[prev]) {b-=mp[tmp];}
       else {b+=mp[tmp];}
       prev = tmp;
   }
  // cout<<a<<" "<<b<<endl;
}
void solve(){
    string res="";
    if(sg =='+'){c=a+b;}
     if(sg =='*'){c=a*b;}
      if(sg =='-'){c=a-b;}
      if(sg=='/'){c=a/b;}
     // cout<<c<<endl;
      if(c == 0){ cout<<endl;return;}
    while(c >= 1000) {res+="M";c-=1000;}
    if (c>=900) {res+="CM"; c-=900;}
    if(c >= 500) {res+="D";c-=500;}
    if(c >= 400) {res+="CD";c-=400;}
    while(c >= 100) {res+="C";c-=100;}
    if (c>=90) {res+="XC"; c-=90;}
    if(c >= 50) {res+="L";c-=50;}
    if(c >= 40) {res+="XL";c-=40;}
    while(c >= 10) {res+="X";c-=10;}
    if (c>=9) {res+="IX"; c-=9;}
     if(c >= 5) {res+="V";c-=5;}
    if(c >= 4) {res+="IV";c-=4;}
     while(c > 0) {res+="I";c-=1;}
     cout<<res<<endl;
}

int main(){
    f();
   cin>>tc;
    while(tc--){
        cin>>x>>y>>sg;
        init();
        solve();
    }
    return 0;
}

