#include <stdio.h>
int g[101][201],u[101];
double c[101][201],d[101];
#define MAX 2000000000.0

double cldiv(double d, double y)
{
    int a=d/y;
	if(y*a<d) a++;
	return y*a;
}

int scm(int a,int b)
{
	int g,t;
	if(a<b){t=a;a=b;b=t;}
	t=a*b;
	while(a%b!=0){g=a%b;a=b;b=g;}
    return t/b;
}

int main()
{
	int N,M,i,j,x,p;
	int L1,L2,S1,S2; double y,min;
	int T,t;
scanf("%d",&T);
for(t=1;t<=T;t++)
{
    scanf("%d %d",&N,&M);
	for(i=1;i<=N;i++) g[i][0]=0;

	for(i=1;i<=M;i++)
	{
        scanf("%d %d %d %d",&S1,&L1,&S2,&L2);
		g[S1][++g[S1][0]]=S2;
		g[S2][++g[S2][0]]=S1;
		c[S1][g[S1][0]]=c[S2][g[S2][0]]=(double)scm(L1,L2);
	}
	// Dijkstra
	// initialization
	d[1]=0;u[1]=1;
	for(i=2;i<=N;i++){d[i]=MAX,u[i]=0;}
	for(i=1;i<=g[1][0];i++) //the neigbours of 1
		if(d[g[1][i]]>c[1][i]+0.5)
			d[g[1][i]]=c[1][i]+0.5;
    for(j=2;j<=N;j++)
	{
		min=MAX;
		for(i=2;i<=N;i++)
			if(u[i]==0&&d[i]<min){min=d[i];p=i;}
//fprintf(ou,"%f\n",min);
		if(p==N) break;
		u[p]=1;
		for(i=1;i<=g[p][0];i++)
		{
			x=g[p][i];y=cldiv(d[p],c[p][i]);
			if(u[x]==0&&d[x]>y+0.5) d[x]=y+0.5;
		}
	}
	if(d[N]==MAX) printf("NO WAY\n");
	else printf("%.1f\n",d[N]);
}
    return 0;
}
