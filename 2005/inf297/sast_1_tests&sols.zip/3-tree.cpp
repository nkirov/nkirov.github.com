#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

const int MAX = 512;

struct Edge {
	int x, y, z;
	bool operator<(const Edge& other) const {
		if (z != other.z) {
			return (z < other.z);
		}
		else {
			return (x < other.x || (x == other.x && y < other.y));
		}
	}
};

int n, m, tati[MAX], ans;
vector<Edge> edge;

int Who(int i) {
	int j = i;
	while (tati[j] != j) {
		j = tati[j];
	}
	while (i != j) {
		int next = tati[i];
		tati[i] = j;
		i = next;
	}
	return j;
}

int main() {
	int i, j, k , testNo; 
	cin >> testNo;
	while (testNo--) {
		edge.clear();
//input
		cin >> n >> m;
		while (m--) {
			Edge e;
			cin >> e.x >> e.y >> e.z;
			e.x--; e.y--;
			edge.push_back(e);
		}
//solve
		for (i = 0; i < n; i++) tati[i] = i;
		sort(edge.begin(), edge.end());
		ans = 0;
		for (k = 0; k < (int)edge.size(); k++) {
			i = edge[k].x;
			j = edge[k].y;
			if (Who(i) != Who(j)) {
				ans += edge[k].z;
				tati[Who(i)] = Who(j);
			}
		}
//output
		j = Who(0);
		for (i = 0; i < n; i++)
			if (Who(i) != j) {
				ans = -1;
				break;
			}

		if (ans > -1) {
			cout << ans << "\n";
		}
		else {
			cout << "no solution\n";
		}
	}

	return 0;
}
