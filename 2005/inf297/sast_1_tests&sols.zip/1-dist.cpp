#include <iostream>
#include <cstring>
using namespace std;

const int MAX = 512;
const int INF = 0x3F3F3F3F;

int a[MAX][MAX], n, m;

int main() {
	int i, j, k , p, q, testNo; 
	cin >> testNo;
	while (testNo--) {
//init
		memset(a, 0x3F, sizeof(a));
		for (i = 0; i < MAX; i++) a[i][i] = 0;
//input
		cin >> n >> m;
		while (m--) {
			int x, y, z;
			cin >> x >> y >> z;
			x--; y--;
			if (a[x][y] > z) { a[x][y] = a[y][x] = z; }
		}
//solve
		for (k = 0; k < n; k++)
			for (i = 0; i < n; i++)
				for (j = 0; j < n; j++)
					if (a[i][k] + a[k][j] < a[i][j]) {
						a[i][j] = a[i][k] + a[k][j];
					}
//output
		p = q = 0;
		for (i = 0; i < n; i++)
			for (j = i; j < n; j++)
				if (a[i][j] > a[p][q]) {
					p = i;
					q = j;
				}
		if (a[p][q] < INF) {
			cout << a[p][q] << "\n";
		}
		else {
			cout << "no solution\n";
		}
	}

	return 0;
}
