﻿#include <iostream>
using namespace std;

//http://www.math.bas.bg/infos/files/2013-06-05-sol-C2.pdf

int dist(int a, int b)
{
  if(a>b) swap(a,b);
  int c=b-a;
  a += 43200;
  int d=a-b;
  return min(c,d);   
}

int main()
{
	int t, c1, m1, s1, c2, m2, s2, ga, gm;
	cin>>t;
	while(t--)
	{
		cin >> c1 >> m1 >> s1 >> c2 >> m2 >> s2 >> ga >> gm;
  
		int dg=ga*120+gm*2;
    
		int t=0;
		int dur=0;
  
		int r=43200;
		bool flag=false;
		while(1)
		{
		int c=t;
		int m=t*12;
		int c0 = c%43200;
		int m0 = m%43200;
		int ct = (c/3600)%12;
		int mt = (m/720)%60;
		int st = t%60;
		int d = dist(c0,m0);
    
			if(c1==ct&&m1==mt&&s1==st) flag=true;     
    
		if(flag) 
		{
             
		if(d<=dg) dur++;         
		}
		t++;
		if(flag)
		if(c2==ct&&m2==mt&&s2==st) break;       
		}
		cout << dur/60 << " " << dur%60 << endl;
	}
}
