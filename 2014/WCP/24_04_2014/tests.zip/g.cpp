﻿#include<iostream>
#include<algorithm>
using namespace std;

const int m_min=-999999999;

int b,c,d;

const int C_max=10;

const int N_max=100001;
int a[N_max];
int n;
int t[C_max][N_max];

int main()
{  
	int tc;
	cin>>tc;
	while(tc--)
	{
	  cin >> n >> b >> c >> d;
	  for(int i=0;i<n;i++) cin >> a[i];  
    
	  for(int j=b;j<=c;j++) t[j][0]=j*a[0];
  
	  for(int i=1;i<n;i++)
	   for(int j=b;j<=c;j++)
		{ 
		  int m=m_min;     
		  for(int k=b;k<=c;k++)
		   if(abs(k-j)<=d)
			if(t[k][i-1]>m) m=t[k][i-1];                   
		  if(m==m_min) m=0;
		  t[j][i]=m+j*a[i]; 
		}  

	  int m=m_min;
	  for(int j=b;j<=c;j++)
	   if(t[j][n-1]>m) m=t[j][n-1];              

	  cout << m << endl;
  }
     
}
