﻿#include <iostream>
using namespace std;

//http://www.math.bas.bg/infos/files/2013-07-04-sol-C3.pdf

long long c(long long x, long long y)
{
    return (x + y) * (x + y + 1) / 2 + y;
}

int main()
{ 
	long long n;
	int t = 1;
	while(cin>>n)
	{
		int a = 0, b = 50000;
		while (a < b) 
		{ 
			int m = a + (b - a) / 2;
			if (n < c(m+1, 0)) 
				b = m;
			else 
				a = m + 1;
		}
		int y = n - c(b, 0);
		int x = b - y;
		cout<<"test case #"<<t++<< ": " << x <<" "<< y <<endl;
	}
	
	return 0;
}
