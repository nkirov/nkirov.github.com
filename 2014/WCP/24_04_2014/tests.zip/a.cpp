﻿#include <iostream>
#define MAX_N 100
using namespace std;

//http://www.usaco.org/current/data/sol_reorder.html

int A[MAX_N+1], B[MAX_N+1];
int done[MAX_N+1], where_in_B[MAX_N+1], N;

int trace_cycle(int start)
{
  int count = 0;
  int i = start;
  do {
    done[i] = 1;
    i = where_in_B[A[i]];
    count++;
  } while (i != start);
  return count;
}

int main()
{
	cin.sync_with_stdio(false);

	while(true)
	{
		int num_cycles = 0, longest_cycle = -1;
		cin >> N;
		if(!N)
			break;
		for (int i=1; i<=N; i++) 
			cin >> A[i];
		
		for (int i=1; i<=N; i++)
		{
			cin >> B[i];
			where_in_B[B[i]] = i;
		}
		
		memset(done, 0, sizeof done);

		for (int i=1; i<=N; i++) 
			if (A[i] != B[i] && !done[i])
			{
				int len = trace_cycle(i);
				if (len > longest_cycle) longest_cycle = len;
				num_cycles++;
			}

		cout << num_cycles << " " << longest_cycle << "\n";
	}  
  return 0;
}