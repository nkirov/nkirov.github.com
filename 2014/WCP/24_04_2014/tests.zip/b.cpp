﻿#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

//http://www.usaco.org/current/data/sol_lazy_bronze.html

template<class T> inline int size(const T&c) { return c.size(); }

struct Patch {
  int x;
  int g;
};

inline bool operator<(const Patch &a, const Patch &b) {
  return a.x < b.x;
}

int K;
vector<Patch> patches;

int Solve() {
  int res = 0;
  sort(patches.begin(), patches.end());
  int p=0;
  int sum = 0;
  for(int i=0;i<size(patches);++i) {
    sum += patches[i].g;
    while(patches[i].x - patches[p].x > 2*K) {
      sum -= patches[p].g;
      ++p;
    }
    res = max(res, sum);
  }
  return res;
}

int main() {
  ios_base::sync_with_stdio(false);
  int n;
  while(true)
  {
	cin >> n;
	if(!n)
		break;
	cin >> K;
	patches.clear();
	patches.reserve(n);
	for(int i=0;i<n;++i) 
	{
	Patch p;
	cin >> p.g >> p.x;
	patches.push_back(p);
	}
	int res = Solve();
	cout<<res<<endl;
  }
}