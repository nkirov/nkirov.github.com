#include <stdio.h>
int t,T,N,a[100];
int norm(int i)
{ if(i>N) return i%N;
  if(i<1) return i+N;
  return i;
}
int main()
{
   int i,j,k,m,x,y,s;
   scanf("%d",&T);
   for(t=1;t<=T;t++)
   {
	   scanf("%d",&N);
	   for(i=1;i<=N;i++)
	      scanf("%d",&a[i]);
       j=1;
       while(a[j]!=1) j=norm(j+1);
	   for(i=1;i<N;i++)
	   {
          k=norm(j+1);
          while(a[k]!=i+1)
          {   printf("%d %d\n",i,a[k]);
              a[j]=a[k];a[k]=i;
              for(m=1;m<i;m++)
              {  x=norm(j-m);y=norm(x+1);
                 printf("%d %d\n",a[x],a[y]);
                 s=a[x];a[x]=a[y];a[y]=s; 
              }
              j=k;k=norm(j+1); 
          }
          j=k;    
       }
       printf("0\n");
   }
   return 0;
}
