#include <stdio.h>
int t,T,N,a[100],perm[100];
int norm(int i)
{ if(i>N) return 1;
  if(i<1) return N;
  return i;
}
int main(int argc,char* argv[])
{
   int i,j,k,m,x,y,s;
   FILE *inp, *res, *eval;
   inp=fopen(argv[1],"r");
   res=fopen(argv[2],"r");
   eval=fopen(argv[3],"w"); 
   fscanf(inp,"%d",&T);
   for(t=1;t<=T;t++)
   {
	   fscanf(inp,"%d",&N);
	   for(i=1;i<=N;i++)
	   {fscanf(inp,"%d",&a[i]);perm[a[i]]=i;}
       m=0;        
       while(1)
       {
 
          fscanf(res,"%d",&i);
          if(i==0){s=0;break;}
          fscanf(res,"%d",&j);m++;
          if(m>50000) {s=5;break;}
          if(i<1||i>N||j<1||j>N) {s=1;break;}
          if((i-j)*(i-j)==1) {s=2;break;}
          x=perm[i];y=perm[j];
          if(!(x==y+1||y==x+1||(x==1&&y==N)||(x==N&&y==1))) {s=3;break;}
          k=a[x];a[x]=a[y];a[y]=k;
          perm[i]=y;perm[j]=x;
       }
       if(s==0)
       {for(i=1;i<N;i++) 
          if(a[i]+1!=a[i+1])
             if(a[i]==N&&a[i+1]!=1) {s=4;fprintf(eval,"%d %d\n",a[i],a[i+1]); break;}
       }   
       if(s!=0) {fprintf(eval,"Error %d test %d\n",s,t);break;}
   }
   if(s==0) fprintf(eval,"OK\n");
   return 0;
}
