#include <stdio.h>

#define PROBLEM_ID          "attack"
#define MAXN                1000
#define MAX(a, b)           (((a) > (b)) ? (a) : (b));
#define MIN(a, b)           (((a) < (b)) ? (a) : (b));

int x[MAXN], y[MAXN], s[MAXN];

int main() {
int T,t;
int xCur, yCur, n, i;
double sCur;
scanf("%d", &T);
for(t=1;t<=T;t++)
{    
    double res;
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d %d %d", &x[i], &y[i], &s[i]);
    }

    xCur = x[0];
    yCur = y[0];
    sCur = s[0];

    for (i = 1; i < n; i++) {
        sCur = MIN(xCur + yCur + sCur, x[i] + y[i] + s[i]);
        xCur = MAX(xCur, x[i]);
        yCur = MAX(yCur, y[i]);
        sCur = sCur - xCur - yCur;
        if (sCur <= 0) {
            sCur=0.0;
            break;
        }
    }
    printf("%.3f\n", sCur * sCur / 2.0);
}    
    return 0;
}
