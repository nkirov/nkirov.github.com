#include<iostream>
using namespace std;

//http://www.math.bas.bg/infos/files/2014-04-28-sol-E5.pdf

int a, b, c, aa, bb, cc, t;

int main()
{
	cin>>t;
	while(t--)
	{
		cin >> aa >> bb >> cc;
		a = aa/10 + aa%10;
		b = bb/100 + (bb%100)/10 + bb%10;
		c = cc/1000 + (cc%1000)/100 + (cc%100)/10 + cc%10;
		if (a>b && a>c) 
			cout << aa << endl;
		if (b>=a && b>c) 
			cout << bb << endl;
		if (c>=a && c>=b) 
			cout << cc << endl;
	}
	
	return 0;
}

