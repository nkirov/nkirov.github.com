#include <cstdio>
using namespace std;

//http://www.math.bas.bg/infos/files/2014-04-28-sol-AB3.pdf

const int MaxTasks=20001, MaxWorkers=20; 
int K[MaxWorkers], T[MaxTasks], BitMap[MaxWorkers];
int S,Workers;

void CreateList()
{
  int w,l,h;
  l=1;
  for(int i=1; i<=Workers; i++)
   for(int j=1; j<=K[i]; j++)
    { T[l]=i; l++; }
  l=1; h=S-1;   
  while (l<h) {
   w=T[l]; T[l]=T[h]; T[h]=w;
   l++; l++; h--; h--;
  }
}

void CreateBits()
{
  int Rec,w,BitC;
  Rec=0; T[S+1]=0; BitC=1;
//  printf("---\n");
  for (int j=1; j<=S; j++) {
   w=T[j]+T[j+1]-Workers;
   if (w>0) Rec=Rec+w;
   for (int i=1; i<=Workers; i++) BitMap[i]=0;
   w=T[j]; 
   while (w>0) {
    BitMap[BitC]=1;
    w--; BitC++;
    if (BitC>Workers) BitC=1;
   }
  }
  printf("%d\n",Rec);
}

int main()
{
	while(true)
	{
		Workers=5; S=0;
		if(scanf("%d %d %d %d %d\n", &K[1], &K[2], &K[3], &K[4], &K[5]) <= 0)
			break;

		for(int i = 1;i < 6;i++)
			S += K[i];

		CreateList();
		CreateBits();
	}

	return 0;
}
