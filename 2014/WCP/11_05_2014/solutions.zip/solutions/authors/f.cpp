#include <stdio.h>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

//http://www.math.bas.bg/infos/files/2014-04-28-sol-C6.pdf

const int inf = 1000 * 1000 * 1000;

int len[4], ans[4], cnt[4], last[4];
vector <pair <int, int> > things;


int main()
{
    int i, j, c, best, p, count;

    for (i = 0; i < 4; i++)
    {
        scanf("%d", &len[i]);
        for (j = 0; j < len[i]; j++)
        {
            scanf("%d", &c);
            things.push_back(make_pair(c, i));
        }
    }
    sort(things.begin(), things.end());

    best = inf;
    count = 0;
    p = 0;

    for (i = 0; i < things.size(); i++)
    {
        count += (++cnt[things[i].second] == 1);
        last[things[i].second] = things[i].first;
        while (cnt[things[p].second] > 1)
            cnt[things[p++].second]--;
        if (count == 4 && things[i].first - things[p].first < best)
        {
            best = things[i].first - things[p].first;
            for (j = 0; j < 4; j++)
                ans[j] = last[j];
        }
    }

    printf("%d %d %d %d", ans[0], ans[1], ans[2], ans[3]);

    return 0;
}
