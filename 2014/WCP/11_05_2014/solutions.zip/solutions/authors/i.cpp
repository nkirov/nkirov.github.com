#include <stdio.h>

#define PROBLEM_ID          "maze"
#define MAXN                50
#define INF                 1000000

char f[MAXN][MAXN][MAXN];
int ans[MAXN][MAXN][MAXN];
int q[MAXN * MAXN * MAXN];
char mark[MAXN][MAXN][MAXN];

int dx[] = { -1,  0,  0,  1, 0 };
int dy[] = {  0, -1,  1,  0, 0 };
int dz[] = {  0,  0,  0,  0, 1 };

int main() {
    int x, y, z, xx, yy, zz;
    int h, n, m;
    int i, j, k;
    int low, hi;
    int cur;
int t,T,fl;
scanf("%d",&T);
for(t=1;t<=T;t++)
{
    scanf("%d %d %d", &h, &n, &m);
    for (i = 0; i < h; i++) {
        for (j = 0; j < n; j++) {
            for (k = 0; k < m; k++) {
                char ch = getc(stdin);
                while (ch != '.' && ch != '1' && ch != '2' && ch != 'o')
                    ch = getc(stdin);

                f[i][j][k] = ch;
            }
        }
    }

    low = 0;
    hi = 0;

    for (i = 0; i < h; i++) {
        for (j = 0; j < n; j++) {
            for (k = 0; k < m; k++) {
                cur = (i << 16) + (j << 8) + k;
                ans[i][j][k] = INF;
                mark[i][j][k] = 0;
                if (f[i][j][k] == '1') {
                    ans[i][j][k] = 0;
                    q[hi++] = cur;
                    mark[i][j][k] = 1;
                }
            }
        }
    }
   fl=0; 
    while (low < hi) {
        cur = q[low++];
        y = cur & 255;
        x = (cur >> 8) & 255;
        z = (cur >> 16) & 255;

        for (i = 0; i < 5; i++) {
            xx = x + dx[i];
            yy = y + dy[i];
            zz = z + dz[i];
            if (xx < 0 || xx >= n || yy < 0 || yy >= m || zz < 0 || zz >= h)
                continue;

            if (f[zz][xx][yy] == 'o' || mark[zz][xx][yy])
                continue;

            q[hi++] = (zz << 16) + (xx << 8) + (yy);
            ans[zz][xx][yy] = ans[z][x][y] + 1;
            mark[zz][xx][yy] = 1;
            if (f[zz][xx][yy] == '2') {fl=1;
                printf("%d\n", 5 * ans[zz][xx][yy]);
                break;
            }
        }
        if(fl) break;
    }
}
    return 0;
}
