#include <stdio.h>
#include <string.h>

#define PROBLEM_ID          "phones"

int max;
char answer[10];
char phone[8];

int matches(char *part, char *pattern) {
    int n, i, j;

    n = strlen(pattern);
    if (strlen(part) != n)
        return 0;

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if ((part[i] == part[j]) != (pattern[i] == pattern[j])) {
                return 0;
            }
        }
    }
    return 1;
}

int calc(char *part) {
    if (matches(part, "aa")) return 2;
    if (matches(part, "aab")||matches(part, "aba") || matches(part, "baa")) return 2;
    if (matches(part, "aaa")) return 3;
    if (matches(part, "aabc")||matches(part, "abac") || matches(part, "abca")) return 2;
    if (matches(part, "baac")||matches(part, "baca") || matches(part, "bcaa")) return 2;
    if (matches(part, "aabb")||matches(part, "abab")||matches(part, "abba")) return 3;
    if (matches(part, "aaab")||matches(part, "baaa") || matches(part, "abaa") || matches(part, "aaba")) return 4;
    if (matches(part, "aaaa")) return 5;
    return 0;
}

void updateAnswer(char *pattern) {
    int i, j;

    for (i = 0, j = 0; pattern[i] != '\0'; i++) {
        answer[i] = pattern[i];
        if (pattern[i] == 'x') {
            answer[i] = phone[j++];
        }
    }
    answer[i] = '\0';
}

void test1(int u, char *pattern) {
    char ch = phone[u];
    int cost;

    phone[u] = '\0';
    cost = calc(phone);
    phone[u] = ch;
    cost = cost + calc(phone + u);

    if (cost > max) {
        max = cost;
        updateAnswer(pattern);
    }
}

void test2(int u, int v, char *pattern) {
    char ch1 = phone[u];
    char ch2 = phone[u + v];
    int cost;

    phone[u] = '\0';
    cost = calc(phone);
    phone[u] = ch1;
    phone[u + v] = '\0';
    cost = cost + calc(phone + u);
    phone[u + v] = ch2;
    cost = cost + calc(phone + u + v);

    if (cost > max) {
        max = cost;
        updateAnswer(pattern);
    }
}

int main() {
int t,T;
scanf("%d",&T);
for(t=1;t<=T;t++)
{
    scanf("%s", phone);
    max = -1;
    test1(3, "xxx-xxxx");
    test1(4, "xxxx-xxx");
    test2(2, 2, "xx-xx-xxx");
    test2(2, 3, "xx-xxx-xx");
    test2(3, 2, "xxx-xx-xx");

//    printf("%s\n", answer);
    printf("%d\n", max);
}
    return 0;
}
