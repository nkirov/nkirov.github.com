#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int sumdd(int x)
{
//    cout << x;
    int res = 0;
    while(x / 10)
    {
        res += x % 10;
        x /= 10;
    }
    res += x % 10;
//    cout << ", " << res << endl;
    return res;
}

struct num
{
    int number;
    int sumd;

    num(int a)
    {
        number = a;
        sumd = sumdd(a);
    }
};

bool cmp(const num& a, const num& b)
{
    if(a.sumd == b.sumd)
    {
        return a.number < b.number;
    }
    return a.sumd < b.sumd;
}

void run()
{
    int a,b,c;
    cin >> a >> b >> c;
    vector<num> A;
    A.push_back(num(a));
    A.push_back(num(b));
    A.push_back(num(c));
    sort(A.begin(), A.end(), cmp);
    cout << A[2].number << endl;
}

int main()
{
    int t;
    cin >> t;

    while(t--)
    {
        run();
    }
    return 0;
}
