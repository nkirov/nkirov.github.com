#include <cstdio>
#include <iostream>
#include <queue>
#include <algorithm>
#include <vector>
#include "memory.h"

#define MAXN 60
using namespace std;

int N, M, H;
vector< vector< string > > G;
int D[MAXN][MAXN][MAXN];

struct pos
{
    int x, y, z;
    pos() :x(0), y(0), z(0) {}
    pos(int _z, int _x, int _y) :x(_x), y(_y), z(_z) { }
};

int dx[5] = { 0, -1, 1,  0, 0 };
int dy[5] = { 0,  0, 0, -1, 1 };
int dz[5] = { 1,  0, 0,  0, 0 };

inline bool in(const pos& p)
{
    return p.x < M && p.x >= 0 && p.y < N && p.y >= 0 && p.z < H && p.z >= 0;
}

int bfs(pos s, pos e)
{
    queue<pos> q;
    q.push(s);
    D[s.z][s.x][s.y] = 0;

    while(!q.empty())
    {
        pos u = q.front(); q.pop();

        for(int i = 0; i < 5; i++)
        {
            pos v = pos(u.z + dz[i], u.x + dx[i], u.y + dy[i]);
            if(!in(v) || G[v.z][v.x][v.y] == 'o')
            {
                continue;
            }

            if(D[v.z][v.x][v.y] != -1)
            {
                continue;
            }


            D[v.z][v.x][v.y] = D[u.z][u.x][u.y] + 1;
//            printf("pushing (%d,%d,%d) = %d\n",v.z,v.x,v.y,D[v.z][v.x][v.y]);
            q.push(v);
        }
    }
    return D[e.z][e.x][e.y] * 5;
}

void run()
{
    cin >> H >> M >> N;
    G.clear();
    memset(D, -1, sizeof(D));
    G.resize(H);
    for(int i =0; i < H; i++)
    {
        G[i].resize(M);
    }

    pos s, e;
    for(int z = 0; z < H; z++)
    {
        for(int x = 0; x < M; x++)
        {
            cin >> G[z][x];
            for(int y = 0; y < G[z][x].size(); y++)
            {
                if(G[z][x][y] == '1')
                {
                    s = pos(z,x,y);

                }
                else if(G[z][x][y] == '2')
                {
                    e = pos(z,x,y);
                }
            }
        }
    }
//    for(int z = 0; z < H; z++)
//    {
//        for(int x = 0; x < M; x++)
//        {
//            cout << G[z][x] << endl;
//        }
//        cout << endl;
//    }
//    cout << endl;
//
//    cout << G[1][0][0] << endl;

    printf("%d\n", bfs(s,e));
}


int main()
{
    int t;
    cin >> t;
    while(t--) run();

    return 0;
}
