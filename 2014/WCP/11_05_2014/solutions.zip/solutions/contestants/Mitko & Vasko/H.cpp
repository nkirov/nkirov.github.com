#include<stdio.h>

typedef struct
{
    double X;
    double Y;
    double S;
} Ship;

Ship SHIPS[100];
int main()
{
    int TESTS;
    scanf("%d",&TESTS);

    for(int j=0; j<TESTS; j++)
    {
        int N;
        scanf("%d", &N);

        for(int i=0; i < N; i++)
        {
            scanf("%lf",&SHIPS[i].X);
//            printf("\n%lf",SHIPS[i].X);
            scanf("%lf",&SHIPS[i].Y);
//            printf("\n%lf",SHIPS[i].Y);
            scanf("%lf",&SHIPS[i].S);
//            printf("\n%lf",SHIPS[i].S);
        }



        int maxX=SHIPS[0].X,maxY=SHIPS[0].Y,minS=SHIPS[0].X+SHIPS[0].Y+SHIPS[0].S;
        for(int i=0; i<N; i++)
        {
            if(maxX<SHIPS[i].X)maxX=SHIPS[i].X;
            if(maxY<SHIPS[i].Y)maxY=SHIPS[i].Y;
            if(minS>(SHIPS[i].X+SHIPS[i].Y+SHIPS[i].S))minS=(SHIPS[i].X+SHIPS[i].Y+SHIPS[i].S);

        }

        double k =(minS-(maxX+maxY));
        if(k<0)k=0;
        printf("%.3lf\n",k*k/2.0);
    }


}




