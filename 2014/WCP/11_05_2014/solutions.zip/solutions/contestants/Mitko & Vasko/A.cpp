#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include "memory.h"
#include <algorithm>
using namespace std;

struct ssss
{
    int res;

    ssss() { res = 0 ; }

    void add(int gr, int x)
    {
        if(x < 2) return;

        if(gr < 2)
        {
            if(x == 2)
            {
                if(res == 2) res++;
                else res = 2;
            }
            if(x == 3) res = 4;
            if(x == 4) res = 5;
        }
        else if(gr < 4)
        {
            if(x == 2) res = 2;
            if(x == 3) res = 3;
        }
        else
        {
            if(x == 2) res = 2;
        }
    }
};

int a[7][10];
int score(string& s, vector<int> &A)
{
    memset(a, 0, sizeof(a));
    for(int i = 0; i < A.size(); i++)
    {
        int gr = A[i];
        int dig = s[i] - '0';
        a[gr][dig]++;
    }
    int result = 0;
    for(int i = 1; i < 7; i++)
    {
        ssss sc;
        for(int j = 0; j < 10; j++)
        {
            sc.add(i, a[i][j]);
        }
        result += sc.res;
    }
    return result;
}

int main()
{

    vector< vector<int> > A;
    int a[7] = { 1, 1, 1, 1, 2, 2, 2};
    A.push_back(vector<int>(a, a + 7));
//    int b[7] = { 0, 1, 1, 1, 1, 4, 4 };
//    A.push_back(vector<int>(b, b + 7));
//    int c[7] = { 4, 4, 1, 1, 1, 1, 0 };
//    A.push_back(vector<int>(c, c + 7));
    int d[7] = { 2, 2, 2, 1, 1, 1, 1 };
    A.push_back(vector<int>(d, d + 7));

//    int e[7] = { 2, 2, 2, 3, 3, 3, 0 };
//    A.push_back(vector<int>(e, e + 7));
//    int f[7] = { 0, 2, 2, 2, 3, 3, 3 };
//    A.push_back(vector<int>(f, f + 7));
//    int z[7] = { 2, 2, 2, 0, 3, 3, 3 };
//    A.push_back(vector<int>(z, z + 7));

    int l[7] = { 2, 2, 2, 4, 4, 5, 5 };
    A.push_back(vector<int>(l, l + 7));
//    int k[7] = { 0, 2, 2, 2, 4, 4, 0 };
//    A.push_back(vector<int>(k, k + 7));
    int m[7] = { 4, 4, 2, 2, 2, 5, 5 };
    A.push_back(vector<int>(m, m + 7));
//    int n[7] = { 4, 4, 0, 2, 2, 2, 0 };
//    A.push_back(vector<int>(n, n + 7));
    int o[7] = { 4, 4, 5, 5, 2, 2, 2 };
    A.push_back(vector<int>(o, o + 7));

//    int g[7] = { 4, 4, 5, 5, 6, 6, 0 };
//    A.push_back(vector<int>(g, g + 7));
//    int h[7] = { 0, 4, 4, 5, 5, 6, 6 };
//    A.push_back(vector<int>(h, h + 7));

    string s;
    int t;
    cin >> t;

    while(t--)
    {
        cin >> s;

        int best = 0;
        for(int i = 0; i < A.size(); i++)
        {
            best = max(best, score(s, A[i]));
        }
        printf("%d\n",best);
    }

    return 0;
}
