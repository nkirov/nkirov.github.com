#include <cstdio>
#include <vector>
#include <algorithm>
#define INF 2000000000
#define MAXN 1001000
using namespace std;

int N[4];
int A[4][MAXN];

int main()
{
    bool end = false;
    do
    {
        for(int nu = 0; nu < 4; nu++)
        {
            if(scanf("%d", &N[nu]) != 1)
            {
                end = true;
                break;
            }
            for(int i =0; i < N[nu]; i++)
            {
                scanf("%d", &A[nu][i]);
            }
            sort(A[nu], A[nu] + N[nu]);
        }
        if(end) break;

//        printf("=====\n");
//        for(int i = 0; i < 4; i++)
//        {
//            for(int j = 0; j < N[i]; j++)
//            {
//                printf("%d, ", A[i][j]);
//            }
//            printf("\n");
//        }
//

        int ans[4] = { 0 };
        int pt[4] = { 0 };
        int best = INF;
        do
        {
            int min_i = 0;
            int max_i = 0;
            int min_v = INF;
            int max_v = -1;
            for(int i = 0; i < 4; i++)
            {
                if(A[i][pt[i]] < min_v)
                {
                    min_i = i;
                    min_v = A[i][pt[i]];
//                    printf("min index: %d, min value %d\n", min_i, min_v);
                }

                if(A[i][pt[i]] > max_v)
                {
                    max_i = i;
                    max_v = A[i][pt[i]];
//                    printf("max index: %d, max value %d\n", min_i, min_v);
                }
            }

            if(max_v - min_v < best) {
//                printf("cur diff=%d\n (best=%d)\n",max_v - min_v, best);
                best = max_v - min_v;
                ans[0] = A[0][pt[0]];
                ans[1] = A[1][pt[1]];
                ans[2] = A[2][pt[2]];
                ans[3] = A[3][pt[3]];
            }

            pt[min_i]++;
        } while(pt[0] < N[0] && pt[1] < N[1] && pt[2] < N[2] && pt[3] < N[3]);

        printf("%d %d %d %d\n", ans[0], ans[1], ans[2], ans[3]);
    } while(!end);

    return 0;
}
