#include <cstdio>
#include <algorithm>
#define MAXN 101000
#define INF 2000000000

using namespace std;

int dp[2][MAXN];

int main()
{
    int N;

    while(scanf("%d", &N) && N)
    {
        int a;
        scanf("%d", &a);
        int best = a;

        dp[0][0] = a;
        dp[1][0] = a;
        if(N == 1) {
            printf("%d\n", a);
            continue;
        }
        scanf("%d", &a);
        dp[0][1] = dp[0][0] + a;
        dp[1][1] = -INF;

        for(int i = 2; i < N; i++)
        {
            scanf("%d", &a);
            dp[0][i] = a + max(dp[0][i-1], dp[1][i-1]);
            dp[1][i] = a + dp[0][i-2];


            best = max(max(best,dp[0][i]), dp[1][i]);
        }
//        printf("====\n");
//        for(int i = 0; i < N; i++)
//        {
//            printf("%d, ", dp[0][i]);
//        }
//        printf("\n");
//        for(int i = 0; i < N; i++)
//        {
//            printf("%d, ", dp[1][i]);
//        }
//        printf("\n");

        printf("%d\n", best);
    }

    return 0;
}
