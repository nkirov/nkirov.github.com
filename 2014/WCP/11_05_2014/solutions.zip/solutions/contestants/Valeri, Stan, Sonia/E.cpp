#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#define ll long long
using namespace std;
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\dnes\\a\\e.txt", "r",stdin);
    int N;
    cin >> N;
    while(N!=0)
    {
        vector<int> nums;
        for(int i = 0; i < N; i++)
        {
            int curr;
            cin >> curr;
            nums.push_back(curr);
        }

        vector<pair<int, int> > v; //second  = double skok
        pair<int, int> p0 = make_pair(nums[0],nums[0]);
        v.push_back(p0);
        pair<int, int> p1 = make_pair(nums[0] + nums[1],nums[0] + nums[1]);
        v.push_back(p1);

        int max1 = max(nums[0], nums[0] + nums[1]);
        int k = 2;
        while(true)
        {
            if(k < N)
            {
                int x = max((v[k-1].first + nums[k]),(v[k-1].second + nums[k]));
                max1 = max(max1, max(x,v[k-2].first + nums[k]));
                pair<int, int> p2 = make_pair(x,v[k-2].first + nums[k]);

                v.push_back(p2);
            }
            else
            {
                break;
            }
            k++;
        }

        cout << max1 <<endl;
        cin >> N;
    }
    return 0;
}
