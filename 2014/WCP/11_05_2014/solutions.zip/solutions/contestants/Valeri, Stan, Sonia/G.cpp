#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>

using namespace std;

int sol(int s)
{
    int res = 0;
    while(s!=0)
    {
        res+=s%10;
        s= s/10;
    }
    return res;
}
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\dnes\\a\\g.txt", "r",stdin);
    int n1, n2,n3;

    int TC;
    cin >> TC;
    while(TC--)
    {
        cin >>n1 >> n2 >>n3;

        int sn1 = sol(n1);
        int sn2 = sol(n2);
        int sn3 = sol(n3);

        int ans = -1;
        if(sn1 > sn2)
        {
            if(sn1 == sn3)
            {
                if(n1 > n3)
                {
                    ans = 1;
                }
                else
                {
                    ans = 3;
                }
            }
            else if(sn1 > sn3)
            {
                ans = 1;
            }
            else
            {
                ans = 3;
            }
        }
        else if(sn1 == sn2)
        {
            if(sn1 > sn3)
            {
                if(n1 > n2)
                {
                    ans = 1;
                }
                else
                {
                    ans = 2;
                }
            }
            else
            {
                ans = 3;
            }
        }
        else
        {
            if(sn2 > sn3)
            {
                ans = 2;
            }
            else
            {
                if(sn2 == sn3)
                {
                    if(n2 > n3)
                    {
                        ans = 2;
                    }
                    else
                    {
                        ans = 3;
                    }
                }
                else
                {
                    ans  = 3;
                }
            }
        }

    if(ans == 1)
    {
        cout <<n1 <<endl;
    }
    else if(ans == 2)
    {
        cout << n2 <<endl;
    }
    else
    {
        cout << n3 <<endl;
    }
    }
    return 0;
}
