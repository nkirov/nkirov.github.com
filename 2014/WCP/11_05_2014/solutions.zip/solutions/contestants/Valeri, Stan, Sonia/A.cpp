#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>

#include <vector>
#include <map>
#include <set>
#include <queue>
#define ll long long
using namespace std;
int check2(string s)
{
    if(s[0]==s[1])
    {
        return 2;
    }
    return 0;
}
int check3(string s)
{
    if(s[0] == s[1] && s[1] == s[2])
    {
        return 3;
    }
    else if(s[0]==s[1])
    {
        return 2;
    }
    else if(s[1] == s[2])
    {
        return 2;
    }
    return 0;
}
int check4(string s)
{
    if(s[0] == s[1] && s[1] == s[2] && s[2] == s[3])
    {
        return 5;
    }
    else if(check3(s.substr(0,3)) > 2 || check3(s.substr(1,3)) > 2)
    {
        return 4;
    }
    else if(check2(s.substr(0,2)) == 2 && check2(s.substr(2,2)) == 2)
    {
        return 3;
    }
    else if(check2(s.substr(0,2))==2 || check2(s.substr(1,2))==2 || check2(s.substr(2,2))==2)
    {
        return 2;
    }
    return 0;
}
int main()
{
   // freopen("C:\\Users\\Administrator\\Desktop\\dnes\\a\\a.txt", "r",stdin);
    int N;
    cin >> N;
    string s;
    for(int i = 0; i < N; i++)
    {
        cin >> s;
        string p1 = s.substr(0,4);
        string p2 = s.substr(3,4);
        string p3 = s.substr(0,3);
        string p4 = s.substr(4,3);
        string p5 = s.substr(2,3);
        string p6 = s.substr(0,2);
        string p7 = s.substr(2,2);
        string p9 = s.substr(3,2);
        string p8 = s.substr(5,2);

        sort(p1.begin(), p1.end());
        sort(p2.begin(), p2.end());
        sort(p3.begin(), p3.end());
        sort(p4.begin(), p4.end());
        sort(p5.begin(), p5.end());
        sort(p6.begin(), p6.end());
        sort(p7.begin(), p7.end());
        sort(p8.begin(), p8.end());
        sort(p9.begin(), p9.end());


        int s1 = check4(p1);
        int s2 = check4(p2);
        int s3 = check3(p3);
        int s4 = check3(p4);
        int s5 = check3(p5);
        int s6 = check2(p6);
        int s7 = check2(p7);
        int s8 = check2(p8);
        int s9 = check2(p9);
     //  cout << s1 <<" " <<s2 <<" "<<s3 <<" "<<s4 <<" "<<s5<<" "<<s6<<" "<<s7<<" "<<s8<<endl;
     //  cout << p1 <<" " <<p2 <<" "<<p3 <<" "<<p4 <<" "<<p5<<" "<<p6<<" "<<p7<<" "<<p8<<endl;
        int max1 = max((s1 + s4),(s2+s3));

        int max2 = max((s6+s7+s4),max((s3+s9+s8),(s6+s5+s8)));

        cout << max(max1, max2) <<endl;

        //cout << p1 <<" "<< p2  <<" "<< p3  <<" "<< p4  <<" "<< p5  <<" "<< p6  <<" "<<p7  <<" "<< p8  <<" "<<endl;

    }
    return 0;
}
