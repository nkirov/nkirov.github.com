#include "stdio.h";
#include <string.h>
#include <iostream>
#include <queue>
using namespace std;

#define INF = 1000000000
#define MAXN 500
#define MAXM 500
#define MAXMN MAXN * MAXM

char field [MAXN][MAXM];    
bool viz[MAXN][MAXM];

int dr[4] = {1, -1,  0, 0},  dc[4] = {0,  0, -1, 1};
int r, c, rr, cc, dd, nr, nc, startX, startY, endX, endY;

inline bool in(int nr, int nc)
{
	return nr >= 0 && nr < r && nc >= 0 && nc < c;
}

void bfs(queue< pair < int, int> > &q)
{
	while (!q.empty())
	{
		pair < int, int > p = q.front();
		q.pop();
		rr = p.first;
		cc = p.second;
		
		for (int i = 0; i < 4; i++)
		{
			nr = rr + dr[i]; 
			nc = cc + dc[i];
			if(!in(nr, nc))
				continue;
			
			if(viz[nr][nc])
				continue;
			viz[nr][nc] = true;

			if (field[nr][nc] == '*')
				continue; 
			
			if (field[nr][nc] == 'F')
			{
				printf ("YES\n");
				return;
			}

			q.push(make_pair(nr, nc));
		}
	}
	printf ("NO\n");
}

void main () 
{
	int t;
	freopen("labirint.in", "r", stdin);
	scanf ("%d", &t);
	
	while(t--)
	{
		memset(field, 0, sizeof(field));
		memset(viz, 0, sizeof(viz));
		
		scanf ("%d%d\n", &r, &c);
		for (int i = 0; i < r; i++)
			scanf("%s\n", &field[i]);
		
		scanf ("%d%d%d%d\n", &startX, &startY, &endX, &endY);
		startX--, startY--, endX--, endY--;
		
		field[endX][endY] = 'F';

		queue<pair <int, int > > qu;
		qu.push(make_pair(startX, startY));
		bfs(qu);
	}
}

