#include <cstdio>
#include <queue>
using namespace std;
#define MP(x, y) make_pair((x), (y))
#define MAXN 10000
typedef pair<int, int> pt;
int A[MAXN][MAXN];
char G[MAXN][MAXN];
bool used[MAXN][MAXN];
int N, M;
int delta[4][2] = {{1, 0},  0, 1}, {-1, 0}, {0, -1}};

bool read()
{
	if(scanf("%d%d", &N, &M) != 2) return false;
	getchar();
	for(int i = 0; i < N; i++) 
		gets(G[i]);
	return true;


inline bool in(int x, int y) { return x >= 0 && x < N && y >= 0 && y < M; }

void solve()
{
	queue<pt> q;
	for(int i = 0; i < N; i++)
	{
		for(int j = 0; j < M; j++)
		{
			for(int k = 0; k < 4; k++)
			{
				int dx = delta[k][0] + i;
				int dy = delta[k][1] + j;
				if(in(dx, dy))
				{
					if(G[i][j] != G[dx][dy])
					{
						if(!used[dx][dy])
						{
							used[dx][dy] = true;
							q.push(MP(dx, dy));
						}
						if(!used[i][j])
						{
							used[i][j] = true;
							q.push(MP(i, j));
						}
						A[i][j] = A[dx][dy] = 1;
					}
				}
			}
		}
	}
	pt top;
	int x, y;
	while(!q.empty())
	{
		top = q.front(); q.pop();
		x = top.first;
		y = top.second;
		for(int k = 0; k < 4; k++)
		{
			int dx = delta[k][0] + x;
			int dy = delta[k][1] + y;
			if(in(dx, dy) && !used[dx][dy])
			{
				A[dx][dy] = A[x][y] + 1;
				used[dx][dy] = true;
				q.push(MP(dx,dy));
			}
		}
	}
	int ans = 0;
	for(int i = 0; i < N; i++)
		for(int j = 0; j < M; j++)
			ans += A[i][j];
	printf("%d\n", ans);
}

int main()
{
	//freopen("mobo.in", "r", stdin);
	//freopen("mobo.out", "w", stdout);
	while(read())
	{
		memset(used, 0, sizeof used);
		memset(A, 0, sizeof A);
		solve();
	}
	return 0;
}