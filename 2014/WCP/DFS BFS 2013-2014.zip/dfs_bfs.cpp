#include "stdio.h"
#include <queue>
#include <vector>
using namespace std;

#define MAXN 1000

vector < vector < int > > Graph(MAXN);
vector<bool> viz;
int n, m;

void bfs(int startV)
{
	queue <int> bfs;

	viz[startV] = true; // маркираме стартовия връх като обходен
	bfs.push(startV); // и го добавяме в опашката

	// докато в опашката има елементи (върхове) 
	while (!bfs.empty())
	{
		// взимаме върха, който е най-напред в опашката
		const int vertex = bfs.front();
		// махаме го от опашката
		bfs.pop();
		
		printf("%d ", vertex + 1);
		
		// за всеки негов съсед
		for (int i = 0; i < Graph[vertex].size(); i++)
		{
			const int toVisit = Graph[vertex][i];
			// ако е необходен
			if (!viz[toVisit])
			{
				viz[toVisit] = true; // маркираме го като обходен
				bfs.push(toVisit); // добавяме го в опашката
			}
		}
	}
	printf("\n");
}

void dfs(int startV)
{
	printf("%d ", startV + 1);
	// маркираме текущия връх като обходен
	viz[startV] = true;
	
	// разглеждаме всички негови съседи
	for (int i = 0; i < Graph[startV].size(); i++) 
	{
		const int toVisit = Graph[startV][i];
		// ако поредния съсед не е бил посещаван
		if(!viz[toVisit])
			dfs(toVisit); // рекурсия
	}
}

void read()
{
	int from, to;
	//freopen("bfs_dfs.in", "r", stdin);
	
	//n - брой върхове, m - брой ребра 
	scanf("%d%d", &n, &m);
	for (int i = 0; i < m; i++)
	{
		scanf("%d%d", &from, &to);
		from--, to--;
		Graph[from].push_back(to); 
		Graph[to].push_back(from); //if the graph is b-directional
	}
}

void init()
{
	viz.clear();
	viz.resize(n, false);
}

int main()
{
	read();

	int startV = 5;
	startV--;

	init();
	printf("bfs from %d: ", startV + 1);
	bfs(startV);
	
	init();
	printf("dfs from %d: ", startV + 1);
	dfs(startV);
	
	return 0;
}