﻿#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

//USACO 2013 December Contest, Bronze
//Problem 1. Record Keeping - http://www.usaco.org/index.php?page=viewproblem2&cpid=358
//Analysis - http://www.usaco.org/current/data/sol_records.html

int n;
string groups[1001];

int main()
{
	while(cin >> n && n)
	{
		for (int i=0; i<n; i++)
		{
			string str[3];
			cin >> str[0] >> str[1] >> str[2];
			sort(str, str + 3); // sort each group
			groups[i] = str[0] + " " + str[1] + " " + str[2]; // and convert it to a string
		}
		
		sort(groups, groups + n);	// sort the entire list

		int best = 0;
		for (int i = 0,j = 1; i < n; i++,j++)
			// continue counting until the next string is different
			if (groups[i] != groups[i+1])
			{
				if (best < j) 
					best = j;		// update the best count
				j = 0;
			}

		
		cout << best << "\n";
	}
}