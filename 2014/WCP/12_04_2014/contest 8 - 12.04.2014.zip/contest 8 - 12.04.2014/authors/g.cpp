#include <stdio.h>
#define MAXN 2001
#define MAXM 2001

//http://www.math.bas.bg/infos/files/2014-03-31-sol-B3.pdf

int A[MAXM][MAXN],M,N,newsong[MAXM];
int songc=0,B[MAXN][MAXM],uni[MAXM];

int main()
{  
	int t;
	scanf("%d",&t);
	while(t--)
	{
		songc = 0;
		int i,j,k;
		scanf("%d %d",&M,&N);
		for(i=1;i<=M;i++)
		{  
			newsong[i]=0;
			scanf("%d",&A[i][0]);
			for(j=1;j<=A[i][0];j++)
			{   
				scanf("%d",&A[i][j]);
				if(A[i][j]==1)
					newsong[i]=++songc; 
			}
			for(j=2;j<=N;j++) 
				B[j][i]=0;
	   }

	   for(i=2;i<=N;i++)
		   B[i][0]=0;

	   for(i=1;i<=M;i++)
	   {  
		   int a=newsong[i];
		   if(a!=0)
		   { 
			   for(j=1;j<=A[i][0];j++)
			   {   
				   B[A[i][j]][a]=1;
					B[A[i][j]][0]++;
			   }
		  }
		  else
		  { 
			  uni[0]=0;
			  for(j=1;j<=songc;j++)
			  {  
				  uni[j]=B[A[i][1]][j];
				  for(k=2;k<=A[i][0];k++)
					uni[j]=uni[j]||B[A[i][k]][j];
					uni[0]+=uni[j];
			  }
			
			  for(k=1;k<=A[i][0];k++)
				for(j=0;j<=songc;j++)
					B[A[i][k]][j]=uni[j];
		  }
	   }

	   int flag=0,cnt=0;
	   for(i=2;i<=N;i++) 
		   if(B[i][0]==songc)
			   cnt++;

	   printf("%d\n",cnt);
	   for(i=2;i<=N;i++)
		  if(B[i][0]==songc)
		  { 
			  if(flag) 
				  printf(" %d",i);
			  else 
			  {
				  printf("%d",i);
				  flag=1;
			  }
		  }
	   if(cnt != 0) printf("\n");
	}
   return 0;
}
