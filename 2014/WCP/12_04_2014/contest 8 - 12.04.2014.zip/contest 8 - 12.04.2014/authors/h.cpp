#include<cstdio>
#include<algorithm>
using namespace std;

//http://www.math.bas.bg/infos/files/2014-03-31-B1.pdf

int main()
{
    int n, a, maxres, maxsum;
	while(true)
	{
		scanf("%d", &n);
		if(n == -1)
			break;
		scanf("%d", &a);
		maxsum = maxres = a;
		for(int i=1; i<n; i++)
		{
			scanf("%d", &a);
			maxres = max(maxres+a, a);
			maxsum = max(maxres, maxsum);
		}
		printf("%d\n", maxsum);
	}

    return 0;
}
