#include <iostream>
#include <cstdlib>
using namespace std;

//Analysis - http://www.math.bas.bg/infos/files/2014-03-31-sol-A3.pdf

typedef unsigned char byte;
typedef struct{
	long v;byte c;
}Number;

Number a[1000001];
int cmpNum(const void *p,const void *q)
{
	Number a=*(Number*)p,b=*(Number*)q;
	if (a.c<2 && b.c<2) return a.v-b.v;
	if (a.c!=b.c) return (int)a.c-(int)b.c;
	return a.v-b.v;
}

void eratosthenesSieve(long n,Number *p)
{
	long i;
	p[1].v=1;p[1].c=0;
	p[2].v=2;p[2].c=0;
	for (i=3;i<=n;i++) 
	{
		p[i].v=i;
		p[i].c=1-(i&1);
	}
	
	long b=(n>>1);
	for (i=3;i<=b;i+=2) 
	if(!p[i].c) 
		for (long j=i+i;j<=n;j+=i) 
			p[j].c++;
}

int main()
{
	long n, r, c;
	
	while(cin>>n && n)
	{
		cin>>r>>c;
		eratosthenesSieve(n*n+1,a);
		qsort(&a[1],n*n,sizeof(Number),cmpNum);
		cout<<a[n*(r-1)+c].v<<endl;    
	}

	return 0;
}
