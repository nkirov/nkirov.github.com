#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <algorithm>
#include <map>
#include <string>
#define INF 2000000007
#define DEBVAR(x) cout << #x << " = " << x << endl;
using namespace std;

int main()
{
    cin.sync_with_stdio(false);
    int h;
    string S[3], s;
    while(cin >> h && h)
    {
        int b = 0;
        map<string, int> m;
        for(int i = 0; i < h; i++)
        {
            cin >> S[0] >> S[1] >> S[2];
            sort(S, S + 3);
            s = S[0] + S[1] + S[2];
        //    DEBVAR(s);
            m[s]++;
          //  DEBVAR(m[s]);

            b = max(m[s], b);
        }
        cout << b << endl;;
    }

    return 0;
}

