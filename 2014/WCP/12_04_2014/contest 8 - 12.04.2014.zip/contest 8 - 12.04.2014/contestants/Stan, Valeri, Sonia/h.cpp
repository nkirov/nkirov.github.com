#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include<map>

using namespace std;
int TC, N, M, num, s;
int a[1000000];
int main()
{
    scanf("%d", &N);
    while(N!=-1)
    {
        M = N;
        vector<int> nums;
        while(M--)
        {
            int curr;
            scanf("%d", &curr);
            nums.push_back(curr);
        }

        a[0] = nums[0];
        int max1 = -100000000;
        for(int i = 1; i < N; i++)
        {
            if(a[i-1] < 0)
            {
                a[i] = nums[i];
            }
            else
            {
                a[i] = nums[i] + a[i-1];
            }
            max1 = max(max1, a[i]);
        }
        cout << max1 << endl;
        scanf("%d", &N);
    }

    return 0;
}
