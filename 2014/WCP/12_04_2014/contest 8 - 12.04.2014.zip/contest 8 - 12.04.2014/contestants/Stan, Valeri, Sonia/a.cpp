#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include<map>

using namespace std;
int TC, N, M, num, s;
int main()
{
    scanf("%d", &TC);
    while(TC--)
    {
        int z;
        scanf("%d", &z);

        int x = z + 1;
        int y = 1000000000;

        while(x < y)
        {
            int nom = z*x;
            int denom = (x-z);
            if(nom%denom == 0)
            {
                y = nom/denom;
                if(x!=y)
                {
                    printf("%d %d\n", x,y);
                }
            }
            x++;
        }
    }

    return 0;
}
