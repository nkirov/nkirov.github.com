#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include <bitset>

using namespace std;
int TC, N, M, num, s;
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\12.04.2014\\bin\\Debug\\a.txt", "r", stdin);
    scanf("%d", &TC);
    while(TC--)
    {
        int song_count = 0;
        vector< bitset<2001> > v(2001);
        scanf("%d %d", &M, &N);
        while(M--)
        {
            scanf("%d", &num);
            vector<int> contest;
            bool stancho_here = false;
            while(num--)
            {
                scanf("%d", &s);
                if(s == 1)
                {
                    stancho_here = true;
                }
                else
                {
                    contest.push_back(s-1);
                }
            }
            if(stancho_here)
            {
                for(int i =0; i<contest.size(); ++i)
                {
                    v[contest[i]].set(song_count);
                    //v[contest[i]].insert(song_count);
                }
                song_count++;
            }
            else
            {
                bitset<2001> new_b;
                for(int i =0; i<contest.size(); ++i)
                {
                    new_b |= v[contest[i]];
                }
                for(int i =0; i<contest.size(); ++i)
                {
                    v[contest[i]] = new_b;
                }
            }
        }
        int max_songs = 0;
        vector<int> max_guys;
        for(int i=1; i<=N; ++i)
        {
            if(v[i].count() == song_count)
            {
                max_songs++;
                max_guys.push_back(i+1);
            }
        }
        sort(max_guys.begin(), max_guys.end());
        if(max_songs == 0){
            printf("0\n");
        } else {
            printf("%d\n", max_songs);
            for(int i=0; i<max_guys.size(); ++i)
            {
                if(i>0)
                {
                    printf(" ");
                }
                printf("%d", max_guys[i]);
            }
            printf("\n");
        }
    }
    return 0;
}
