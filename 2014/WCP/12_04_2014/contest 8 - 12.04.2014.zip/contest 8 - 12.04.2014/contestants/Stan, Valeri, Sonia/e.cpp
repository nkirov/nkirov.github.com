#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include<map>

using namespace std;
int TC;

int main()
{
    scanf("%d", &TC);
    while(TC--)
    {
        string s;
        cin >> s;
        vector<char> v;
        for(int i =0; i<s.size(); ++i){
            if(v.size() == 0){
                v.push_back(s[i]);
            }
            else if(v.back() == s[i]){
                v.pop_back();
            } else {
                v.push_back(s[i]);
            }
        }
        for(int i=0; i<v.size(); ++i){
            cout << v[i];
        }
        cout << endl;

    }

    return 0;
}
