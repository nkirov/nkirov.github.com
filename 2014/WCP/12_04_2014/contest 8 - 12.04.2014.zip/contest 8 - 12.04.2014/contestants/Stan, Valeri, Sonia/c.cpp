#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include<map>

using namespace std;
int TC, N, x;
vector<int> v;

int f(int x, int y){
    return upper_bound(v.begin(), v.end(), 2*(y-x) + y) - lower_bound(v.begin(), v.end(), y + y -x);
}
int main()
{
    scanf("%d", &TC);
    while(TC--)
    {
        scanf("%d", &N);
        while(N--){
            scanf("%d", &x);
            v.push_back(x);
        }
        sort(v.begin(), v.end());
        int max_sum = 0;
        for(int i=0; i<v.size(); ++i){
            for(int j=i+1; j<v.size(); ++j){
                max_sum += f(v[i],v[j]);
            }
        }
        cout << max_sum << endl;
        v.clear();
    }

    return 0;
}
