#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include<map>

using namespace std;
int TC;
const int N = 1000001;
int lp[N];
int npr[N];
void findPrimes(int p)
{
    int k = p;
    int den = lp[k];
    int pos = k;
    int num = 0;
    set<int> primes;
    primes.insert(den);
    while(k > 1)
    {
            k/=den;
            pos = k;
            den = lp[k];
            primes.insert(den);
    }

    npr[p] = primes.size() -1;
}
void sieve()
{
    vector<int> pr;
    for(int i = 2; i < N; i++)
    {
        if(lp[i] == 0)
        {
           npr[i] = 1;
            lp[i] = i;
            pr.push_back(i);
        }

        for(int j = 0; j <pr.size() && pr[j]<=lp[i] && i*pr[j] <=N;j++)
        {
            int p = i*pr[j];
            lp[p] = pr[j];
            findPrimes(p);
        }
    }
}
int main()
{
    sieve();
    npr[1] = 1;
    int n,r,c;
    cin >> n;
    while(n!=0)
    {
        cin >> r >> c;
        vector<int> nums;
        //vector<int> used(N*N + 1);
        int numUsed = n*n;
        int np = 1;
        while(numUsed)
        {
            int curr = 1;
            while(curr <= n*n)
            {
                if(npr[curr] == np)
                {
                    numUsed--;
                    nums.push_back(curr);
                }
                curr++;
            }
            np++;
        }

        int pos = (r-1)*n + c;
        cout << nums[pos - 1] << endl;

        cin >> n;
    }
    return 0;
}
