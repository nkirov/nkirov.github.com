#include <iostream>
#include <string>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <iomanip>
#include <set>
#include<map>

using namespace std;
int TC, N, M, num, s;
int main()
{
    scanf("%d", &N);
    while(N!=0)
    {
        int max1 = -1;
        map<set<string> , int> a;
        while(N--)
        {
            string a1,a2,a3;
            set<string> abc;

            cin >> a1 >> a2 >> a3;
            abc.insert(a1);
            abc.insert(a2);
            abc.insert(a3);

            a[abc]++;
            max1 = max(max1, a[abc]);
        }
        cout << max1<< endl;
        scanf("%d", &N);
    }

    return 0;
}
