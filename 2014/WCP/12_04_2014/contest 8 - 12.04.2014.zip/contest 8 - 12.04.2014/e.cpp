﻿#include <iostream>
#include <string>
#include <stack>
using namespace std;

//Analysis - http://www.math.bas.bg/infos/files/2014-03-31-sol-C3.pdf

string message;

void print(stack<char> &st)
{
    int i=0;
	string ans;

    while (!st.empty())
    {
        ans += st.top();
        st.pop();
        i++;
    }

    i--;
    for (; i>=0; i--) cout << ans[i];
    cout << endl;
}

void solve()
{
	stack<char> st;
    int i, sz;
    cin >> message;
    sz = message.size();

    st.push(message[0]);
    for (i=1; i<sz; i++)
    {
        if (st.empty())
        {
            st.push(message[i]);
        }
        else
        {
            if (st.top() == message[i])
            {
                st.pop();
            }
            else
            {
                st.push(message[i]);
            }
        }
    }

	print(st);
}

int main ()
{
	int t;
	cin>>t;
	while(t--)
	{
		solve();
	}
	
	return 0;
}
