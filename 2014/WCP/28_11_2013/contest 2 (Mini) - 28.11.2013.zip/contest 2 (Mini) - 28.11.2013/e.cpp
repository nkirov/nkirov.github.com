﻿#include <stdio.h>
#include <algorithm>
#include <queue >
using namespace std;

//http://codeforces.com/problemset/problem/218/B

int n, m;

int main()
{
	while (true)
    {
		priority_queue <int> m1, m2;
		int a, min = 0, max = 0;
		scanf("%d %d\n", &n, &m);
		if(n == 0 && m == 0)
			break;

		for(int i = 0; i < m;i++)
		{
			scanf("%d", &a);
			m1.push(a); 
			m2.push(-a);
		}

		for(int i = 0; i < n;i++)
		{ 
			int q = m1.top(); 
			max += q; 
			m1.pop();
			
			if (q - 1) 
				m1.push(q - 1);

			q =- m2.top(); 
			min += q; 
			m2.pop();
			
			if (1 - q) 
				m2.push(1 - q);
		}

		printf("%d %d\n", max, min);
	}

	return 0;
}