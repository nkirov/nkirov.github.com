﻿#include <algorithm>  
#include <stdio.h> 
using namespace std; 

#define MAX 50

int main()
{
    while(true)
    {
        char s[MAX];
        scanf("%s\n", &s);
		int len = strlen(s);
		if(s[0] == '-') break;
				
		if(prev_permutation(s, s + len))
		{
			printf("%ld\n", atol(s));
		}
		else
		{
			printf("Impossible!\n");
		}
    }

    return 0;
}  
