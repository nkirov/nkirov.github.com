﻿#include <stdio.h>
#include <algorithm>
#include <map>
#include <vector>
using namespace std;

//http://www.informatika.bg/interviews#LargestRepeated

#define MAXN 100001
#define MAXL 101

char str[(MAXN * MAXL) + MAXL];

int main()
{
	while (!feof(stdin))
    {
		gets(str);
		
		char *p = strtok(str, " ");
		if(p == NULL)
			break;

		map<long, int> s;
		map<long, int>::iterator it;
		int m = atoi(p);
		p = strtok(NULL, " ");

		int k = atoi(p);
		p = strtok(NULL, " ");
		
		while(p != NULL)
		{
			long l = atol(p);
			it = s.find(l);
			if(it != s.end())
				it->second++;
			else
				s.insert(make_pair(l, 1));

			p = strtok(NULL, " ");
		}

		vector<pair<long, int>> v(m);
		int c = 0;
		map<long, int>::reverse_iterator revIt;
		for(revIt = s.rbegin(); revIt != s.rend(); ++revIt)
		{
			if(revIt->second < k)
				continue;

			v[c++] = (make_pair(revIt->first, revIt->second));
			if(c == m) break;
		}

		if(c != m)
			printf("No solution!\n");
		else
		{
			for(int i = m - 1;i > 0;i--)
				printf("{%ld %d}, ", v[i].first, v[i].second);
			printf("{%ld %d}\n", v[0].first, v[0].second);
		}
    }

	return 0;
}