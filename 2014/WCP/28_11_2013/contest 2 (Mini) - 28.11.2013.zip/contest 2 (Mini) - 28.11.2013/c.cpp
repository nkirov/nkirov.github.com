﻿#include <stdio.h>
#include <bitset>
#include <algorithm>
using namespace std;

#define MAXN 10001
#define MAXL 101

int k, n, a[MAXN];
char str[(MAXN * MAXL) + MAXL];

int compare (const int a, const int b)
{
	bitset<32> bsa((int)a);
	bitset<32> bsb((int)b);
	int ac = bsa.count();
	int bc = bsb.count();
	if(ac == bc)
		return a > b;
	else
		return ac < bc;
}

int main()
{
    while (!feof(stdin))
    {
		gets(str);
		n = 0;
		char *p = strtok(str, " ");

		while(p != NULL)
		{
			a[n++] = atoi(p);
			p = strtok(NULL, " ");
		}

		sort (a, a + n, compare);
		
		for (int i = 0; i < n - 1; i++)
			printf("%d ", a[i]);
		
		printf("%d\n", a[n - 1]);
    }

    return 0;    
}
