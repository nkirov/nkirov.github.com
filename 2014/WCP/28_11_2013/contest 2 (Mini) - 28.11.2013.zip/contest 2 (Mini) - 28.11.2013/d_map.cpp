﻿#include <string>
#include <map>
#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int t, n, min, max;
	
	cin>>t;
	while(t--)
    {
		min = INT_MAX, max = INT_MIN;
		string name;
		map<string, int> names;
		map<string, int>::iterator it;

		cin>>n;
		while(n--)
		{
			cin>>name;
			it = names.find(name);
			if(it != names.end())
				it->second++;
			else
				names.insert(make_pair(name, 1));
		}
		
		for (it = names.begin(); it != names.end(); it++)
		{
			if(min > it->second) min = it->second;
			if(max < it->second) max = it->second;
		}

		printf("%d %d\n", max, min);
    }

    return 0;    
}
