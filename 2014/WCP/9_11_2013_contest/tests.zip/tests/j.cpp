#include <stdio.h>
#define MAXX 20
#define INF 2000000000
int d[MAXX],a[MAXX],N,K;

int next_K()
{  int i,j;
   i=K;
   while(a[i]==N-K+i) i--;
   if(i==0) return 0;
   a[i]++;
   for(j=i+1;j<=K;j++) a[j]=a[j-1]+1;
   return 1;
}

int main()
{  int i,j,min,lmin,sum,x;
   int t,T;
  scanf("%d",&T);
  for(t=1;t<=T;t++)
  {  min=INF;
     scanf("%d %d",&N,&K); d[1]=0;
     for(i=2;i<=N;i++) scanf("%d",&d[i]);
     for(i=1;i<=K;i++) a[i]=i;a[0]=-1;
     do
     { sum=0;
       for(i=1;i<=N;i++)
       {  lmin=INF;
          for(j=1;j<=K;j++)
          {  x=0;if(i<a[j]) x=d[a[j]]-d[i];
             else if(i>a[j])x=d[i]-d[a[j]];
             if(x<lmin)lmin=x;
          }
          sum+=lmin;
       }
       if(sum<min)min=sum;
     } while(next_K());
     printf("%d\n",min);
  }
}
