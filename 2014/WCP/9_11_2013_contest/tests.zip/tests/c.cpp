﻿//http://community.topcoder.com/stat?c=problem_statement&pm=10180&rd=13519

#include<algorithm>  
#include<vector> 
#include<stdio.h> 
using namespace std; 

#define MAX 1000

int main()
{
	int t = 0;
    while(!feof(stdin))
    {
        char s[MAX];
        scanf("%s\n", &s);
		int len = strlen(s);
		if(len == 0)
			continue;
		
		int ans = 0; 
		sort(s, s + len); 
		
		do 
		{ 
			bool ok = true; 
			for(int i = 0;i < len - 1;i++)
				if(s[i] == s[i+1]) 
				{ 
					ok = false;
					break; 
				} 

			if(ok) ans++; 
		} 
		while(next_permutation(s, s + len)); 

		printf("Test# %d: %d\n", ++t, ans);
    }

    return 0;
}  
