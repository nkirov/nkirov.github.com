#define MAXM 10000
#define MAXN 1000
#define MAXD 1000
#define MAXG 250000
#define INF 1000000000

/* Abstract Types Graph */
typedef struct
{  int N,M,directed;
   int E[MAXM][2]; } LE_Graph;

typedef struct
{  int N,M,directed;
   int E[MAXM][3]; } WLE_Graph;

typedef struct
{  int N,M,directed;
   int T[MAXN+1][MAXN+1]; } AM_Graph;

typedef struct
{  int N,M,directed;
   int T[MAXN+1][MAXD+1]; } LN_Graph;

typedef struct
{  int N,M,directed;
   int T[MAXG+1][5]; } Grid_Graph;

typedef struct
{  int N,M,directed;
   int T[MAXN+1][MAXD+1][2]; } WLN_Graph;

/* Abstract Types Tree */
typedef struct
{  int N; int P[MAXN+1]; } LP_Tree;
typedef struct
{  int N; int S[MAXN+1][2]; } LS_2Tree;

typedef struct
{  int N; int S[MAXN+1][3]; } LS_3Tree;

/* Abstract Type Permutation */
#define MAXP MAXN
typedef struct
{  int N,e[MAXP+1]; } Perm;

void init_P(Perm* p, int N)
{  int i;
   p->N=N;
   for(i=0;i<=p->N;i++) p->e[i]=i;
}

int next(Perm* p)
{  int i=p->N-1,j=p->N,t;
   while(p->e[i]>p->e[i+1]) i--;
   if(i==0) return 0;
   while(p->e[i]>p->e[j]) j--;
   t=p->e[i];p->e[i]=p->e[j];p->e[j]=t;
   i++;j=p->N;
   while(j>i)
   {  t=p->e[i];p->e[i]=p->e[j];p->e[j]=t;
      i++;j--;
   }
   return 1;
}

void print_P(Perm* p)
{  int i;
   for(i=1;i<=p->N;i++) printf("%d ",p->e[i]);
   printf("\n");
}

/* Inputs for Graphs and Transformations*/
void input_LE(LE_Graph* G)
{  int i;
   scanf("%d %d %d",&G->N,&G->M,&G->directed);
   for(i=1;i<=G->M;i++)
      scanf("%d %d", &G->E[i][0],&G->E[i][1]);
}

void input_AM(AM_Graph* G)
{  int i,j,v,w;
   scanf("%d %d %d",&G->N,&G->M,&G->directed);
   for(i=1;i<=G->N;i++)
      for(j=1;j<=G->N;j++) G->T[i][j]=0;
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d", &v,&w); G->T[v][w]++;
      if(!G->directed) G->T[w][v]++;
   }
}


void input_WAM(AM_Graph* G)
{  int i,j,v,w,c;
   scanf("%d %d %d",&G->N,&G->M,&G->directed);
   for(i=1;i<=G->N;i++)
   {  for(j=1;j<=G->N;j++) G->T[i][j]=INF;
      G->T[i][i]=0;
   }
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d %d", &v,&w,&c); G->T[v][w]=c;
      if(!G->directed) G->T[w][v]=c;
   }
}

void input_WLE(WLE_Graph* G )
{  int i,j,v,w,c;
   scanf("%d %d %d",&G->N,&G->M,&G->directed);
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d %d", &v,&w,&c);
      G->E[i][0]=v;G->E[i][1]=w;G->E[i][2]=c;
   }
}


void input_WLN(WLN_Graph* G)
{  int i,j,v,w,c;
   scanf("%d %d %d",&G->N,&G->M,&G->directed);
   for(i=1;i<=G->N;i++) G->T[i][0][0]=0;
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d %d", &v,&w,&c);
      G->T[v][++G->T[v][0][0]][0]=w;
      G->T[v][G->T[v][0][0]][1]=c;
      if(!G->directed)
      {  G->T[w][++G->T[w][0][0]][0]=v;
         G->T[w][G->T[w][0][0]][1]=c;
      }
   }
}

void print_AM(AM_Graph* G)
{
   int i,j;
   for(i=1;i<=G->N;i++)
   {  printf("%d: ",i);
      for(j=1;j<=G->N;j++)
         printf("%d ",G->T[i][j]);
      printf("\n");
   }
}

void in_deg(AM_Graph* G)
{
   int i,j,s;
   for(j=1;j<=G->N;j++)
   {
      s=0;
      for(i=1;i<=G->N;i++) s+=G->T[i][j];
      G->T[0][j]=s;
   }
}

void print_LN(LN_Graph* G)
{
   int i,j;
   for(i=1;i<=G->N;i++)
   {  printf("%d: ",i);
      for(j=1;j<=G->T[i][0];j++)
         printf("%d ",G->T[i][j]);
      printf("\n");
   }
}

void print_LN_dag(LN_Graph* G)
{
   int i,j;
   for(i=1;i<=G->N;i++)
   {  printf("%d: ",i);
      for(j=1;j<=G->N;j++)
         printf("%d ",G->T[i][j]);
      printf("\n");
   }
}
int is_edge_LE(LE_Graph* G,int v,int w)
{  int i;
   for(i=1;i<=G->M;i++)
   {
      if(G->E[i][0]==v && G->E[i][1]==w) return 1;
      if(!G->directed &&
      G->E[i][0]==w && G->E[i][1]==v) return 1;
   }
   return 0;
}

void trans_LE_to_AM(LE_Graph* G1,AM_Graph* G2)
{  int i,j;
   G2->N=G1->N;
   for(i=1;i<=G2->N;i++)
      for(j=1;j<=G2->N;j++)
         G2->T[i][j]=0;
      for(i=1;i<=G1->M;i++) {
         G2->T[G1->E[i][0]][G1->E[i][1]]++;
         if(!G1->directed) G2->T[G1->E[i][1]][G1->E[i][0]]++;
      }
      G2->M=G1->M;G2->directed=G1->directed;
}

void trans_AM_to_LN(AM_Graph* G1,LN_Graph* G2)
{  int i,j;
   G2->N=G1->N;G2->M=G1->M;
   G2->directed=G1->directed;
   for(i=1;i<=G2->N;i++) G2->T[i][0]=G2->T[i][1]=0;
   for(i=1;i<=G1->N;i++)
      for(j=1;j<=G1->N;j++)
         if(G1->T[i][j])
         {
             G2->T[i][++G2->T[i][0]]=j;
             G2->T[i][G2->T[i][0]+1]=0;
         }
}

void input_LN(LN_Graph* G)
{  int i,v,w;
   scanf("%d %d %d",&G->N,&G->M,&G->directed);
   for(i=1;i<=G->N;i++) G->T[i][0]=0;
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d", &v,&w);
      G->T[v][++G->T[v][0]]=w;G->T[v][G->T[v][0]+1]=0;
      if(!G->directed)
      {G->T[w][++G->T[w][0]]=v;G->T[w][G->T[w][0]+1]=0;}
   }
}

void input_dir_LN(LN_Graph* G)
{  int i,v,w;
   scanf("%d %d",&G->N,&G->M); G->directed=1;
   for(i=1;i<=G->N;i++) G->T[i][0]=G->T[0][i]=0;
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d", &v,&w);
      G->T[v][++G->T[v][0]]=w;
      G->T[w][G->N-G->T[0][v]++]=v;
   }
}

void input_LN_nd(LN_Graph* G)
{  int i,v,w;
   scanf("%d %d",&G->N,&G->M);
   for(i=1;i<=G->N;i++) G->T[i][0]=0;
   for(i=1;i<=G->M;i++)
   {  scanf("%d %d", &v,&w);
      G->T[v][++G->T[v][0]]=w;
      G->T[w][++G->T[w][0]]=v;
   }
}

void input_LP(LP_Tree* T)
{  int i,v,w;
   scanf("%d",&T->N);
   for(i=1;i<=T->N;i++)
   {   scanf("%d",&v); T->P[i]=v; }
}

void print_LP(LP_Tree* T)
{  int i;
   for(i=1;i<=T->N;i++)
      printf("%d: %d\n",i,T->P[i]);
}

void add_to_LP(LP_Tree* D,int v)
{ D->P[++D->N]=v; }

void asgn_par_LP(LP_Tree* D,int u,int v)
{ D->P[v]=u; }

int is_leaf_LP(LP_Tree* D,int v)
{  int i;
   for(i=1;i<=D->N;i++)if(D->P[i]==v) return  0;
   return 1;
   }

int del_from_LP(LP_Tree* D,int v)
{  if(is_leaf_LP(D,v))
   {  D->P[v]=D->P[D->N--]; return 1;}
    else return 0;
}

void build_dag(LN_Graph* G,int S[][2])
{  int i,j;
   for(i=1;i<=G->N;i++)
   { G->T[i][0]=0;G->T[0][i]=G->N+1;
     for(j=1;j<=G->N;j++)G->T[i][j]=0;
   }
   for(i=1;i<G->N;i++)
      for(j=i+1;j<=G->N;j++)
      {  if(S[i][0]<=S[j][0]&&S[j][1]<=S[i][1])
         {  G->T[j][++G->T[j][0]]=i;
            G->T[i][--G->T[0][i]]=j;
         }
         if(S[j][0]<=S[i][0]&&S[i][1]<=S[j][1])
         {  G->T[i][++G->T[i][0]]=j;
            G->T[j][--G->T[0][j]]=i;
         }
      }
}
/* Implementation of Queue */
#define MAXQ MAXN
typedef struct
{  int e[MAXQ+1],begin,end; }int_Queue;

void empty_queue(int_Queue* q)
{  q->begin=0;q->end=-1; }
int is_empty_queue(int_Queue* q)
{  if(q->begin>q->end) return 1;
   else return 0;
}
void add_queue(int_Queue* q,int a)
{  q->e[++q->end]=a;}
int get_queue(int_Queue* q)
{  return q->e[q->begin++];}

/* Implementation of Stack */
#define MAXS MAXM
typedef struct
{  int e[MAXS+1],top; } int_Stack;
void empty_stack(int_Stack* s)
{  s->top=-1; }
int is_empty_stack(int_Stack* s)
{  if(s->top<0) return 1;
   else return 0;
}
void add_stack(int_Stack* s,int a)
{  s->e[++s->top]=a;}
int look_stack(int_Stack* s)
{  return s->e[s->top];}
void delete_stack(int_Stack* s)
{  s->top--;}
int get_stack(int_Stack* s)
{  return s->e[s->top--];}
int stack_count(int_Stack* s)
{ return s->top+1; }

// implementation of heap
// special for hDijkstra
typedef struct
{ int key; int other; } heapel;

typedef struct
{heapel data[MAXN]; int N, where[MAXN];} heap;

void swap(heap* H, int i, int j)
{  int t;
   H->where[H->data[i].other]=j;
   H->where[H->data[j].other]=i;
   t=H->data[i].key; H->data[i].key=H->data[j].key;
   H->data[j].key=t;
   t=H->data[i].other; H->data[i].other=H->data[j].other;
   H->data[j].other=t;
}

void heapify(heap* H,int i)
{  int j = i;
   if(2*i <= H->N && H->data[j].key > H->data[2*i].key) j=2*i;
   if(2*i+1<=H->N&&H->data[j].key>H->data[2*i+1].key) j=2*i+1;
   if(j!=i) { swap(H,i,j); heapify(H,j); }
}

void make_heap(heap* H)
{  int i;
   for(i=H->N/2;i>=1;i--) heapify(H,i);
}

void get_min(heap* H, heapel* min)
{  min->key=H->data[1].key;
   min->other=H->data[1].other;
   H->data[1].key=H->data[H->N].key;
   H->data[1].other=H->data[H->N].other;
   H->N--; heapify(H,1);
}

void go_up(heap* H, int i)
{
   while(i!=1&&H->data[i].key<H->data[i/2].key)
   {  swap(H,i,i/2); i/=2; }
}

/* Breadt First Search for Spanning Tree */
void BFS_ST(LN_Graph* G, LP_Tree* D,int r)
{  int used[MAXN+1],x,y,i;  int_Queue Q;
   for(i=1;i<=G->N;i++) used[i]=0; D->N=G->N;
   empty_queue(&Q);
   add_queue(&Q,r);used[r]=1;D->P[r]=0;
   while(!is_empty_queue(&Q))
   {  x=get_queue(&Q);
      for(i=1;i<=G->T[x][0];i++)
      {  y=G->T[x][i];
         if(!used[y])
         {  used[y]=1;D->P[y]=x; add_queue(&Q,y); }
      }
    }
}

/* Breadt First Search for Spanning Tree in Grid*/
void BFS_ST_Grid(Grid_Graph* G, LP_Tree* D,int r)
{  int used[MAXN+1],x,y,i;  int_Queue Q;
   for(i=1;i<=G->N;i++) used[i]=0; D->N=G->N;
   empty_queue(&Q);
   add_queue(&Q,r);used[r]=1;D->P[r]=0;
   while(!is_empty_queue(&Q))
   {  x=get_queue(&Q);
      for(i=1;i<=G->T[x][0];i++)
      {  y=G->T[x][i];
         if(!used[y])
         {  used[y]=1;D->P[y]=x; add_queue(&Q,y); }
      }
    }
}

/* Breadt First Search for Spanning Forest */
void BFS_spanning_forest(LN_Graph* G, LP_Tree* D)
     {  int used[MAXN+1],x,y,r,i;  int_Queue Q;
        for(r=1;r<=G->N;r++) used[r]=0; D->N=G->N;
        for(r=1;r<=G->N;r++)
        {  if(used[r]) continue;
           empty_queue(&Q);
           add_queue(&Q,r);used[r]=1;D->P[r]=0;
           while(!is_empty_queue(&Q))
           {  x=get_queue(&Q);
              for(i=1;i<=G->T[x][0];i++)
              {  y=G->T[x][i];
                 if(!used[y])
                 {  used[y]=1;D->P[y]=x; add_queue(&Q,y); }
              }
            }
        }
     }
/* Restauring LN - after DFS, HL etc. */
void restore_LN(LN_Graph* G)
{  int i,j;
   for(i=1;i<=G->N;i++)
   {  j=0; while(G->T[i][j+1]!=0) j++;
      G->T[i][0]=j;
   }
}

void restore_single_LN(LN_Graph* G,int v)
{  int j;
   j=0; while(G->T[v][j+1]!=0) j++;
   G->T[v][0]=j;
}

/* Depth First Search for Spanning Tree */
void DFS_spanning_tree(LN_Graph* G,LP_Tree* D,int r)
{

}

/* Euler  */
int is_Euler_AM(AM_Graph* G)
{
    int i,j,s;
    for (i=1;i<=G->N;i++)
    {
        s=0;
        for(j=1;j<=G->N;j++) s+=G->T[i][j];
        if(s%2) return 0;
    }
    return 1;
}

int directed_is_Euler(LN_Graph* G)
{
   int i,j,a[MAXN];
   for(i=1;i<=G->N;i++) a[i]=0;
   for(i=1;i<=G->N;i++)
      for(j=1;j<=G->T[i][0];j++) a[G->T[i][j]]++;
   for(i=1;i<=G->N;i++)
      if(a[i]!=G->T[i][0]) return 0;
   return 1;
}

void init_AM(AM_Graph* G)
{
   int i;
   for(i=1;i<=G->N;i++) G->T[i][0]=1;
}

int next_edge_AM(AM_Graph* G,int v)
{
   while(G->T[v][0]<=G->N&&G->T[v][G->T[v][0]]==0)
        G->T[v][0]++;
   if(G->T[v][0]<=G->N)
   {  G->T[v][G->T[v][0]]--;
      G->T[G->T[v][0]][v]--;
      return G->T[v][0];
   }
   else return 0;
}

int Euler_Loop_directed(LN_Graph* G,int* E_Loop)
{  int i=0,v; int_Stack S;
   if(!directed_is_Euler(G)) return 0;
   empty_stack(&S);add_stack(&S,1);
   while(!is_empty_stack(&S))
   {  v=look_stack(&S);
      if(G->T[v][0]!=0)
      {  v=G->T[v][G->T[v][0]--]; add_stack(&S,v); }
       else E_Loop[i++]=get_stack(&S);
   }
   E_Loop[i]=0; return i;
}

int Euler_Loop(AM_Graph* G,int* E_Loop)
{  int i=0,v; int_Stack S;
   if(!is_Euler_AM(G)) return 0;
   init_AM(G);empty_stack(&S);add_stack(&S,1);
   while(!is_empty_stack(&S))
   {  v=look_stack(&S);
      if((v=next_edge_AM(G,v))!=0) add_stack(&S,v);
      else E_Loop[i++]=get_stack(&S); }
   E_Loop[i]=0; return i;
}

/*  Hamilton Loop  */
int is_Hamilton(AM_Graph* G,Perm* p)
{  int i;
   p->e[p->N+1]=p->e[1];
   for(i=1;i<=p->N;i++)
   {   if(!G->T[p->e[i]][p->e[i+1]]) return 0;
   }
   return 1;
}

int Hamilton_Loop(AM_Graph* G,Perm* P)
{  init_P(P,G->N);
   do
      if(is_Hamilton(G,P)) return 1;
   while(next(P));
   return 0;
}

int Hamilton_Loop1(LN_Graph* G,AM_Graph* G1,Perm* P)
{  int used[MAXN+1],x,y,i; int_Stack S;
   for(i=1;i<=G->N;i++) used[i]=0;
   empty_stack(&S);
   add_stack(&S,1);used[1]=1;
   while(!is_empty_stack(&S))
   {  x=look_stack(&S);
      if(G->T[x][0]>0)
      {  y=G->T[x][G->T[x][0]--];
         if(!used[y])
         {  used[y]=1; add_stack(&S,y);
            if(stack_count(&S)==G->N)
               if(G1->T[1][y])
               {
                  for(i=0;i<G->N;i++)
                    P->e[i+1]=get_stack(&S);
                  P->N=G->N;
                  return 1;
               }
         }
       }
       else
       {  x=get_stack(&S); used[x]=0;
          restore_single_LN(G,x);
       }
   }
   return 0;
}

void Topological_Sort(AM_Graph* G, Perm* P)
{  int i,j=1,k;
   P->N=G->N;in_deg(G);
   for(i=1;i<=G->N;i++)
   {  while(G->T[0][j]!=0)
      {  j=j+1;if(j>G->N)j=1; }
      P->e[i]=j;G->T[0][j]=-1;
      for(k=1;k<=G->N;k++)
        if(G->T[j][k]!=0)
        {  G->T[j][k]--;G->T[0][k]--; }
      j++;if(j>G->N)j=1;
   }
}

void DF_Topological_Sort(LN_Graph* G, Perm* P)
{  int used[MAXN+1],x,y,i,j=G->N; int_Stack S;
   for(i=1;i<=G->N;i++) used[i]=0;P->N=G->N;
   for(i=1;i<=G->N;i++)
   {  if(!used[i])
      {  empty_stack(&S); add_stack(&S,i);used[i]=1;
         while(!is_empty_stack(&S))
         {  x=look_stack(&S);
            if(G->T[x][0]>0)
            {  y=G->T[x][G->T[x][0]--];
               if(!used[y])
               {  used[y]=1; add_stack(&S,y); }
            }
            else P->e[j--]=get_stack(&S);
         }
      }
   }
}

/* Min Spanning Tree */

void Prim_0(AM_Graph* G,LP_Tree* D,int r)
{  int used[MAXN]={0};
   int i,j,k,minc,minv,minp;
   D->P[r]=0; used[r]=1;
   for(i=1;i<G->N;i++)
   {  minc=INF;minv=minp=0;
      for(j=1;j<=G->N;j++)
         for(k=1;k<=G->N;k++)
            if(j!=k&&used[j]!=used[k]&&G->T[j][k]<minc)
            {  minc=G->T[j][k];
               minv=(used[j]?k:j);minp=(used[j]?j:k);
             }
      D->P[minv]=minp;used[minv]=1;
   }
   D->N=G->N;
}

void Prim(AM_Graph* G,LP_Tree* D,int r)
{  int used[MAXN]={0},near[MAXN];
   int i,j,k,minc,minv;
   D->P[r]=0; used[r]=1;
   for(i=1;i<=G->N;i++) near[i]=r;
   for(i=1;i<G->N;i++)
   {  minc=INF;minv=0;
      for(j=1;j<=G->N;j++)
         if(!used[j]&&G->T[j][near[j]]<minc)
         {  minc=G->T[j][near[j]];minv=j; }
      D->P[minv]=near[minv];used[minv]=1;
      for(j=1;j<=G->N;j++)
         if(!used[j]&&G->T[j][near[j]]>G->T[j][minv])
           near[j]=minv;
   }
   D->N=G->N;
}

void Dijkstra(AM_Graph* G,LP_Tree* D, int r)
{  int used[MAXN],dist[MAXN];
   int i,j,k,mind,minv;
   for(i=1;i<=G->N;i++)
   {  dist[i]=G->T[r][i];D->P[i]=r;used[i]=0; }
   dist[r]=0;D->P[r]=-1;used[r]=1;
   for(i=1;i<G->N-1;i++)
   {  mind=INF;minv=-1;
      for(j=1;j<=G->N;j++)
        if(!used[j]&&dist[j]<mind)
        {  mind=dist[j];minv=j; }
        j=minv;used[j]=1;
        for(k=1;k<=G->N;k++)
          if(!used[k])
            if(dist[k]>dist[j]+G->T[j][k])
            {  dist[k]=dist[j]+G->T[j][k];D->P[k]=j; }
   }
}

void hDijkstra(WLN_Graph* G,LP_Tree* D, int r)
{  int used[MAXN]; heap H; heapel E;
   int i,j,k,x,y,z;
   for(i=1;i<=G->N;i++)
   {  H.data[i].key=INF; H.data[i].other=i;
      D->P[i]=r; used[i]=0; H.where[i]=i;
   }
   H.data[r].key=0;D->P[r]=-1;
   H.N=G->N;make_heap(&H);
   for(i=1;i<=G->N;i++)
   {  get_min(&H,&E); j=E.other; used[j]=1; z=E.key;
      //printf("%c %d\n",'a'-1+j,z);
      for(k=1;k<=G->T[j][0][0];k++)
      {  x=G->T[j][k][0];y=G->T[j][k][1];
         if(!used[x]&&H.data[H.where[x]].key>z+y)
         {  H.data[H.where[x]].key=z+y;
            go_up(&H,H.where[x]);D->P[x]=j;
         }
      }
   }
}

int Bellman_Ford(WLE_Graph* G,LP_Tree*D, int r)
{  int dist[MAXN],i,j,k,u,v,c;
   for(i=1;i<=G->N;i++) dist[i]=INF;
   dist[r]=0; D->P[r]=-1;
   for(i=1;i<G->N-1;i++)
   {  for(j=1;j<=G->M;j++)
      {  u=G->E[j][0];v=G->E[j][1];c=G->E[j][2];
         if(dist[v]>dist[u]+c)
         {  dist[v]=dist[u]+c; D->P[v]=u; }

      }
   }
   for(j=1;j<=G->M;j++)
   {  u=G->E[j][0];v=G->E[j][1];c=G->E[j][2];
      if(dist[v]>dist[u]+c) return 1;
   }
   return 0;
}

