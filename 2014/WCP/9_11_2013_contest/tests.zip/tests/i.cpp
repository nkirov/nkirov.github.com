#include <stdio.h>
#include "graphs.h"
#define MAXX 20

int next_P(Perm* p)
{  int i=p->N-1,j=p->N,t;
   while(p->e[i]>p->e[i+1]) i--;
   if(i==0) return 0;
   while(p->e[i]>p->e[j]) j--;
   t=p->e[i];p->e[i]=p->e[j];p->e[j]=t;
   i++;j=p->N;
   while(j>i)
   {  t=p->e[i];p->e[i]=p->e[j];p->e[j]=t;
      i++;j--;
   }
   return 1;
}

AM_Graph G; Perm H;
int main()
{  int i,j,cnt;
   int t,T;
  scanf("%d",&T);
  for(t=1;t<=T;t++)
  {  cnt=0;
     input_AM(&G);H.N=G.N;
     for(i=0;i<=G.N;i++) H.e[i]=i;
     do
     {  if(is_Hamilton(&G,&H)) cnt++;
//else
//{for(i=1;i<=H.N;i++) printf("%d ",H.e[i]); printf("\n");return 0;}
        next(&H);
     } while(H.e[1]==1);
     printf("%d\n",cnt/2);
  }
}
