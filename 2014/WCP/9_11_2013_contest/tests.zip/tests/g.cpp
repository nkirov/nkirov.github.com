//Task: kod
//Author: Bistra Taneva
#include<iostream>
#include <string>
using namespace std;
int main()
{ char a[21],b1[21];

    int i,k,min=520,n;
    cin>>n;
for (int j=0;j<n;j++)
{ cin>>a;
 int s=0;
   for (i=0;i<strlen(a);i++)
    {
    k=a[i] -'a';
    k=k+1;
    s=s+k;

    }
   if(s<min) {strcpy(b1,a); min=s;}

}
cout<<b1<<" "<<min<<endl;
return 0;
}

