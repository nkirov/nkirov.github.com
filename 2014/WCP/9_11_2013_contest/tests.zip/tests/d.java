
import java.math.BigInteger;
import java.util.Scanner;

public class program {
	
	private static BigInteger [] fact;
	private static Scanner in;
	private static void precompute(int max){
		fact = new BigInteger[max];
		fact[0] = BigInteger.ZERO;
		fact[1] = BigInteger.ONE;
		
		for(int i = 2;i < max;i++){
			fact[i] = fact[i - 1].multiply(BigInteger.valueOf(i));
		}
	}
	
	private static BigInteger calc(int k, int n)
	{
		if(k == n) return BigInteger.ONE;
		if(k == 1) return BigInteger.valueOf(n);
			
		return fact[n].divide(fact[k].multiply(fact[n - k]));
	}
	
	public static void main(String[] args) {
		
		precompute(51);

		in = new Scanner(System.in);
		
		while(true)
		{
			int k = in.nextInt();
			int n = in.nextInt();
			if(k == 0 && n == 0) break;
			
			System.out.printf("C(%d, %d) = %d\n", k, n, calc(k, n));
		}
	}

}
