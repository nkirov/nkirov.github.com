/*
ID: espr1t
LANG: C++
TASK: Sysadmin
KEYWORDS: Binary Search
*/

#include <cstdio>

#define MAX 32768
FILE* in; FILE* out;

int a[MAX], n, k;

int canDoIt(int val)
{
	int cnt = 0;
	for (int i = 0; i < n; i++)
	{
		cnt += a[i] / val;
		if (cnt >= k) return 1;
	}
	return 0;
}

int eval()
{
	int ans = -1;	
	int left = 1, right = 100000000, mid;
	while (left <= right)
	{
		mid = (left + right) / 2;
		if (canDoIt(mid))
			ans = mid, left = mid + 1;
		else right = mid - 1;
	}
	return ans;
}

int main(void)
{
	in = stdin; out = stdout;
//	in = fopen("Sysadmin.in", "rt"); out = fopen("Sysadmin.out", "wt");
	
	int numTests;
	fscanf(in, "%d", &numTests);
	for (int test = 0; test < numTests; test++)
	{
		fscanf(in, "%d %d", &n, &k);
		for (int i = 0; i < n; i++)
			fscanf(in, "%d", &a[i]);
		fprintf(out, "%d\n", eval());
	}
	return 0;
}
