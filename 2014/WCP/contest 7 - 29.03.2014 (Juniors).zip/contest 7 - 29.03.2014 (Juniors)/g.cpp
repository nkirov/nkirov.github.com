#include <stdio.h>
#include <string>
using namespace std;

#define MAXN 21//n unmbers
#define MAXL 20//with no more than 20 digits 
#define MAXS MAXN + 10//spaces

int A[MAXN], B[MAXN];

bool same(int N)
{
	for (int i = 0; i < N; i++) 
		if (A[i] != A[0]) 
			return false;

	return true;
}

int main()
{
	int id = 1;
    while (!feof(stdin))
    {
		int N = 0;
		char *str = new char[(MAXN * MAXL) + MAXS];
		gets(str);

		char *p = strtok(str, " ");
		A[N++] = atoi(p);

		p = strtok(NULL, " ");
		while(p != NULL)
		{
			A[N++] = atoi(p);
			p = strtok(NULL, " ");
		}
		
		int count = 0;
		while (!same(N) && count <= 1000)
		{
			copy(A, A + N, B);
			for (int i = 0; i < N; i++) 
				A[i] = abs(B[i] - B[(i+1)%N]);
			
			count++;
		}
		
		printf("Case %d: ", id++);
		
		if (same(N)) 
			printf("%d %s\n", count, count == 1 ? "iteration" : "iterations");
		else 
			printf("not attained\n");
	}
	
	return 0;
}

