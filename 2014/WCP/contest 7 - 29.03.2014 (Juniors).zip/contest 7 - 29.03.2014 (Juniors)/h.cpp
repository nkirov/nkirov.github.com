#include <stdio>
#include <memory.h>

//http://www.milo0.eu/spoj0/status.pl?problem_id=172

#define MAX 1005

int nums[MAX], len[MAX], beg[MAX];
int n, gi, i, j;

int main()
{	
	while(true)
	{
		scanf("%d\n", &n);

		if (n == 0) break;

		for(i = 1; i <= n; i++)
			scanf("%d", &nums[i]);

		memset(len, 0, sizeof len);
		memset(beg, 0, sizeof beg);

		len[1] = beg[1] = 1;
			
		for(i = 2; i <= n; i++)
		{
			len[i] = 1;
			beg[i] = i;
			for(j = 1; j < i; j++)
			{
				if (nums[j] < nums[i])
				{
					if (len[j] + 1 > len[i] || (len[j] + 1 == len[i] && beg[j] < beg[i]))
					{
						len[i] = len[j] + 1;
						beg[i] = beg[j];
					}
				}
			}
		}

		int bi = 1;
			
		for(i = 2; i <= n; i++)
		{
			if (len[i] > len[bi] || (len[i] == len[bi] && beg[i] < beg[bi]))
			{
				bi = i;
			}
		}

		printf("%d %d %d\n", len[bi], beg[bi], bi);
	}

	return 0;
}