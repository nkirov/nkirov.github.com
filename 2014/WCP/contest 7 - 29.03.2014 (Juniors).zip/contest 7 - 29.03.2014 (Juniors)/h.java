import java.util.Scanner;
import java.util.ArrayList;

public class solution
{	
	static int[] nums = new int[1004];
	static int[] len = new int[1004];
	static int[] beg = new int[1004];
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		int gi,i,j;
		
		while(true)
		{
			int n = sc.nextInt();
			
			//System.out.println(n);
			
			if (n == 0)
				break;
			
			for(i = 1; i <= n; i++)
			{
				nums[i] = sc.nextInt();
			}
			
			len[1] = 1;
			beg[1] = 1;
			
			for(i = 2; i <= n; i++)
			{
				len[i] = 1;
				beg[i] = i;
				for(j = 1; j < i; j++)
				{
					if (nums[j] < nums[i])
					{
						if (len[j] + 1 > len[i] || 
								(len[j] + 1 == len[i] && beg[j] < beg[i]))
						{
							len[i] = len[j] + 1;
							beg[i] = beg[j];
						}
					}
				}
			}
			
			int bi = 1;
			
			for(i = 2; i <= n; i++)
			{
				if (len[i] > len[bi] || (len[i] == len[bi] && beg[i] < beg[bi]))
				{
					bi = i;
				}
			}
			
			System.out.println(len[bi] + " " + beg[bi] + " " + bi);
		}
	}
}
