import java.io.*;
import java.util.*;
/**

Laszlo Szuecs
10/17/2011

*/

public class Main
{

           	public static class System {
		public static java.io.InputStream in;
		public static java.io.PrintWriter out;

		static {
		  try {
		    in = new java.io.FileInputStream("i.in");
		    out = new java.io.PrintWriter("i.out");
		  } catch (Exception e) {
		    throw new RuntimeException(e);
		  }
		  java.lang.Runtime.getRuntime().addShutdownHook(new java.lang.Thread(new java.lang.Runnable() { public void run() { System.close(); } }));
		}

		public static void close() {
		  try {
		  in.close();
		  out.close();
		  } catch (Exception e) {
		    throw new RuntimeException(e);
		  }
		}
	}

    public static void main (String[] args)
    {

    			Locale.setDefault(Locale.UK);

		int price = 0, tended = 0;
		int caseNumber = 0;
	    Scanner input= new Scanner (System.in);
        try
        {
            price = input.nextInt();
            tended = input.nextInt();
        	while (price > 0)
            {
				System.out.print("Case " + (++ caseNumber) + ": ");
              	ProblemInstance instance = new ProblemInstance(System.out, price, tended);
				instance.crunch();

	            price = input.nextInt();
    	        tended = input.nextInt();
          }
        }
        catch (java.util.NoSuchElementException iox)
        {
        }
    }  // end main
}	//   end class vending

class ProblemInstance
{
	int price, tended;
	PrintWriter out;
	public ProblemInstance(PrintWriter out, int p, int t)
	{
	        this.out = out;
		price = p;
		tended = t;
	}
	public void crunch()
	{
		int change = tended - price;
		int tens = change / 10;
		int afterTens = change % 10;
		int fives = afterTens / 5;
		int ones = afterTens % 5;

		out.print(change + " = ");
		out.print (tens + " * 10 + ");
		out.print (fives + " * 5 + ");
		out.println (ones + " * 1");
	}
}