#include <stdio.h>
#include <algorithm>
using namespace std;

#define MAXN 100005

//USACO 2005 Feb Aggressive cows - http://ace.delos.com/FEB05.htm
//http://moodle.openfmi.net/mod/resource/view.php?id=3322
//http://infoman.musala.com/index.html?42+4+%u0441%u043F%u0438%u0441%u0430%u043D%u0438%u0435%u0442%u043E%20%26gt%3B%20%u0442%u0435%u043A%u0443%u0449%20%u0431%u0440%u043E%u0439%20%26gt%20%u0424%u0435%u0432%u0440%u0443%u0430%u0440%u0441%u043A%u043E%20%u0441%u044A%u0441%u0442%u0435%u0437%u0430%u043D%u0438%u0435%20%u043D%u0430%20USACO%2C%202005+http://infoman.musala.com/magazine/archive/issue27/2005_usaco_feb_gold3.html

int d[MAXN];
int t, n, c, best;

bool check(const int &p)
{
    int br = c - 1, lpos = d[0];
    for (int i = 1;i < n;i++)
	{
		if(d[i] - lpos >= p)
		{
		    br--;
		    lpos = d[i];
		}
    }

	return br <= 0 ? 1 : 0;
}

void solve() 
{
	sort(d, d + n);

    int l = 0, r = 1000000000, mid;
    while (l <= r)
	{
		mid = (r + l) / 2;
		if(check(mid))
		{
			best = mid;
			l = mid + 1;
		} 
		else 
		{
			r = mid - 1;
		}
    }
}

int main()
{
	scanf("%d", &t);
	while(t--)
	{
        scanf("%d %d",&n,&c);
		for(int i = 0;i < n;i++) 
			scanf("%d", d + i);
		
		solve();
		printf("%d\n", best);
	}
    return 0;
}

