#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

//task 1 from http://www.hsin.hr/coci/contest4_tasks.pdf

int main()
{
    int L, N, br = 0;
    ios::sync_with_stdio(false);

	while(true)
	{
		cin >> L >> N;
		if(L == 0 && N == 0)
			break;

		int emax = -1, ebest = -1;
		int amax = -1, abest = -1;

		vector<bool> taken(L);
		for (int i = 1; i <= N; i++)
		{
			int p, k;
			cin >> p >> k;
			int e = k - p + 1;
			if (e > emax)
			{
				emax = e;
				ebest = i;
			}
			int a = 0;
			for (int j = p; j <= k; j++)
			{
				if (!taken[j])
					a++;
				taken[j] = true;
			}
			if (a > amax)
			{
				amax = a;
				abest = i;
			}
		}

		if(br++ > 0)
			cout<< "\n";
		cout << ebest << '\n' << abest << '\n';
	}

    return 0;
}
