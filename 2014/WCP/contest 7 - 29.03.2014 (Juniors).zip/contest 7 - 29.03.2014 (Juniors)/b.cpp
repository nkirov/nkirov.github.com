#include <iostream>
#include <algorithm>

const int max_nodes = 32;
const int max_value = 2000000000;
bool visited[max_nodes];
int a[max_nodes][max_nodes];
int n, m, s;
int depth, cur_length, min_length;

void DFS(int node)
{
	visited[node] = true;

	if(depth == n-1 && a[node][s] && cur_length + a[node][s] < min_length)
		min_length = cur_length + a[node][s];

	for(int i = 1; i <= n; i++)
		if(a[node][i] && !visited[i] && cur_length + a[node][i] < min_length)
		{
			cur_length += a[node][i];
			depth++;
			DFS(i);
			depth--;
			cur_length -= a[node][i];
		}

	visited[node] = false;
}

int main()
{
	int tests;
	std::cin >> tests;
	for(int t = 0; t < tests; t++)
	{
		std::fill(*a, *a + max_nodes*max_nodes, 0);
		std::cin >> n >> m >> s;
		for(int i = 0; i < m; i++)
		{
			int x, y, z;
			std::cin >> x >> y >> z;
			if(!a[x][y] || a[x][y] > z)
				a[x][y] = a[y][x] = z;
		}

		min_length = max_value;
		depth = cur_length = 0;
		DFS(s);

		if(min_length == max_value)
			std::cout << "-1\n";
		else
			std::cout << min_length << std::endl;
	}

	return 0;
}

