#include <iostream>
using namespace std;

//Task SAHOVNICA - http://www.hsin.hr/coci/contest3_tasks.pdf, COCI 2012/2013
//3rd round, December 15th, 2012
//solution - http://www.hsin.hr/coci/contest3_solutions.zip

int r, s, a, b;
int main() 
{
	while(cin >> r >> s >> a >> b)
	{
		for (int i = 0; i < r * a; ++i) {
			for (int j = 0; j < s * b; ++j)
				cout << ((i / a + j / b) % 2 == 0? 'X' : '.');
			cout << endl;
		}
	}

	return 0;
}
