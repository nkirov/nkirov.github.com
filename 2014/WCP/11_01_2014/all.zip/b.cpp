﻿#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

//http://www.informatika.bg/interviews#TwoCharSubstring

char line[10050];

// Връща началото на подстринга с максимална дължина.
void longestKCharSubstring(const char* str, int n, int k, int t) 
{
	int best = 0, startAt = 0;

	int cnt[256] = {0}, in = 0;
	for (int left = 0, right = 0; right < n; right++) 
	{
    	// Вкарваме символа в прозореца и увеличаваме броя различни символи ако е нов.
    	if (cnt[str[right]]++ == 0)
        	in++;
   	 
    	// Ако имаме повече от k различни символа в прозореца трябва
    	// да го скъсим отляво докато останат само k.
    	while (in > k) 
        	if (--cnt[str[left++]] == 0)
            	in--;

    	// Ако текущият прозорец е по-дълъг от най-добрия до сега, ъпдейтваме отговора.
    	if (best < right - left + 1)
        	best = right - left + 1, startAt = left;
	}

	printf("Test case #%d: ", t);
	if(in != k)
		printf("Impossible!\n");
	else
		printf("%d %d\n", best, startAt);
}

int main() 
{
	int k, t = 0;
		
	while(!feof(stdin))
	{
		gets(line);
		char* p = strtok(line, " ");
		if(p == NULL)
			return 0;

		char* s = p;
		k = atoi(strtok(NULL, " "));

		longestKCharSubstring(s, strlen(s), k, ++t);
	}

	return 0;
}