#include <iostream>
#include <cstdlib>
using namespace std;

int a[100][100];
int c[100][100];

int num, m, n;

void print()
{
     for (int i=0; i<m; i++)
     {
             for (int j=0; j<n; j++) cout << c[i][j] << " ";
             cout << endl;
     }  
     cout << endl;  
}     

int min3(int i, int j)
{
    int c1 = 1000, c2 = 1000, c3 = 1000;
    c1 = c[i-1][j] + 1;
    c2 = c[i][j-1] + 1;
    c3 = c[i-1][j-1] + 1;
    if ( c2 < c1 ) c1 = c2; 
    if ( c3 < c1 ) c1 = c3;
    return c1;
}    
void solver()
{
    cin >> num;
    for( int k = 0; k < num; k++)
    { 
         cin >> m >> n;
         for (int i=0; i<m; i++)
             for (int j=0; j<n; j++) 
         {
             cin >> a[i][j];
             c[i][j] = 0;
         }
//         int c[100][100] = {0};
//         print();
         for (int i=1; i<m; i++) 
         {
             if ( a[i][0] == 0 && a[i-1][0] == 0 ) c[i][0] = c[i-1][0] + 1;
             else c[i][0] = 1000;
         }         
//                print();  
         for (int j=1; j<n; j++)
         {
             if ( a[0][j] == 0 && a[0][j-1] == 0 ) c[0][j] = c[0][j-1] + 1;
             else c[0][j] = 1000;
         }   
//                print();  
                
         for (int i=1; i<m; i++)
             for (int j=1; j<n; j++)    
          {   
                 if( a[i][j] == 0 ) c[i][j] = min3(i,j);
                 else c[i][j] = 1000;
//                 print();
          }      
//         print(); 
         if ( c[m-1][n-1] > m + n ) cout << 0 << endl;    
         else cout << c[m-1][n-1]*1000 << endl;
     
         
    }
}

void generate()
{
     m = 50; n = 50;
     cout << m << " " << n << endl;
     for (int i=0; i < m; i++)
     {
      for (int j=0; j < n/2; j++) 
          if ( i==0 && j==0) cout << "0 1 ";
          else cout << rand()%2 << " 0 ";
      cout << endl;    
     }     
}

int main()
{
//    generate();
  solver();
    return 0;
}

