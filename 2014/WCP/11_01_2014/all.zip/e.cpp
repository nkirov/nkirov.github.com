///Task no112B
///Author: Krasimir Manev

//http://www.math.bas.bg/infos/files/2013-04-01-sol-B3.pdf

#include <stdio.h>
#include <string.h>
#define MAXN 1001

int U[MAXN+1],G[MAXN][MAXN],N,M;
int Q[MAXN],b,e;
void make_empty(){b=0;e=-1;}
void push(int x){Q[++e]=x;}
int pop(){return Q[b++];}
bool is_empty(){return b>e;}

void BFS(int r) {
  int  x,y,i;
   make_empty();push(r);U[r]=r;
  while(!is_empty())
  {  x=pop();
     for(i=1;i<=G[x][0];i++)
     {  y=G[x][i];
        if(!U[y]) {push(y);U[y]=r;}
     }
  }
}

int find(int x)
{
    int y=x;
    while(U[y]!=y) y=U[y];
    while(x!=y){int z=U[x];U[x]=y;x=z;}
    return y;
}
void join(int x,int y)
{  U[x]=y; }

int main()
{
    int i,j,k,q,R,t;
	scanf("%d",&t);
	while(t--)
	{
		memset(G, 0, sizeof G);
		memset(U, 0, sizeof U);
		memset(Q, 0, sizeof Q);

		scanf("%d %d",&N,&M);
		for(i=1;i<=N;i++) {G[i][0]=U[0]=0;}
		for(i=1;i<=M;i++)
		{  scanf("%d %d",&j,&k);
		   G[j][++G[j][0]]=k;
		   G[k][++G[k][0]]=j;
		}
		for(i=1;i<=N;i++)
		   if(U[i]==0) BFS(i);
		scanf("%d",&R);
		for(i=1;i<=R;i++)
		{  scanf("%d %d %d",&q,&j,&k);
		   switch (q) {
		   case 1: if(find(j)==find(k)) printf("1");
					 else printf("0");
					 break;
		   case 2: j=find(j); k=find(k);
					 if(j!=k) join(j,k);
		   }
		}
		printf("\n");
	}

    return 0;
}
