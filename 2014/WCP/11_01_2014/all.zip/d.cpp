﻿#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

//dean-cup-2008-a-tiles

int main() 
{
	while(!feof(stdin))
	{
		string line;
		cin>>line;
		vector<int> c(256, 0);
		for(int i = 0; i < line.size(); i++) 
			c[line[i]]++;
		
		int max = -1;
		for(int i = 0;i < c.size();i++)
			if(c[i] > max)
				max = c[i];

		cout << max << endl;
	}

	return 0;
}