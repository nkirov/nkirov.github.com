﻿#include <iostream>
#include <algorithm>
#include <set>
using namespace std;

//task #4 - lopov from http://hsin.hr/coci/contest1_tasks.pdf

typedef long long LL;
typedef pair <int, int> PII; 

const int maxN = 300 * 1000 + 5;

PII p[maxN];
int n, k, t, tc;

int main()
{
	ios_base::sync_with_stdio(false);

	cin>>tc;

	while(tc--)
	{
		cin >> n >> k;
		for (int i = 0; i < n; i++)
			cin >> p[i].second >> p[i].first;

		multiset <int> ms;

		for (int i = 0; i < k; i++)
		{
			cin >> t;
			ms.insert(t);
		}

		sort(p, p + n, greater<PII>());

		LL ans = 0;
		for (int i = 0; i < n; i++)
		{
			multiset<int>::iterator it = ms.lower_bound(p[i].second);
			if (it == ms.end()) 
				continue;

			ms.erase(it);
			ans += p[i].first;
		}

		cout << ans << endl;
	}

	return 0;
}