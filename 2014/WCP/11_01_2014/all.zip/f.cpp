﻿///Task: bestans
///Author: Vladimir Vladimirov
//http://www.math.bas.bg/infos/files/2013-01-06-B3.pdf
//http://www.math.bas.bg/infos/files/2013-01-06-sol-B3.pdf

#include <iostream>
#include <cstring>
#include <queue>
using namespace std;

int level[1000000];
int P, A, B, R, N;

void bfs(int n)
{
	queue <int> q;
    q.push (n % P);
    
    while (!q.empty())
    {
        int currN = q.front();     
		q.pop();
        
        if (currN == R && level[currN]) 
			break;
        
        if (!level[(currN + A) % P])
        {
            level[(currN + A) % P] = level[currN] + 1;
            q.push((currN + A) % P);
        }

        if (!level[(currN+B) % P])
        {
            level[(currN + B) % P] = level[currN] + 1;
            q.push((currN + B) % P);
        }
    }
}

int main()
{
    while(cin >> N >> P >> A >> B >> R)
	{ 
		memset(level, 0, sizeof(level));    

		bfs(N);
		
		if(level[R] != 0)
			cout << level[R] << endl;
		else
			cout << -1 << endl;
	}

    return 0;
}
