
import java.math.BigInteger;
import java.util.Scanner;

//http://www.informatika.bg/interviews#DigitalRoot
	
public class c {
	
	private static Scanner in;

	private static BigInteger digitalRoot(BigInteger X) 
	{
		while (X.compareTo(BigInteger.TEN) >= 0) // X >= 10
		{
	    	BigInteger nX = BigInteger.ZERO;
	    	
	    	while (X.compareTo(BigInteger.ZERO) > 0) // X > 10
	    	{
	        	nX = nX.add(X.mod(BigInteger.TEN)); //nX += X % 10
	        	X = X.divide(BigInteger.TEN); //X /= 10
	    	}
	    	
	    	X = nX;
		}
	
		return X;
	}
	
	public static void main(String[] args) 
	{
		in = new Scanner(System.in);
		
		while(true)
		{
			BigInteger X = in.nextBigInteger();
			if(X.compareTo(BigInteger.ONE.negate()) == 0) break;
			
			System.out.printf("Digital root of %s is %d\n", X.toString(), digitalRoot(X));
		}
	}
}
