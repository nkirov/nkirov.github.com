#include <iostream>
using namespace std;

void solve()
{
    int N, K, a[1000];
    cin>> N >> K;
    for (int i = 0; i < N; i++)
        cin >> a[i];
    
    int maxx = a[0], sum; 
    for (int i = 0; i <= N - K; i++)
    { 
        sum = 0;
        for (int j = i; j < i + K; j++)
            sum += a[j];
        if (sum>=maxx) maxx=sum;
    }
    
    cout << maxx <<endl;
    
}

int main()
{
  int nt; cin >> nt;
  for(int i=1; i<=nt; i++)
   solve();   
    
     
}
