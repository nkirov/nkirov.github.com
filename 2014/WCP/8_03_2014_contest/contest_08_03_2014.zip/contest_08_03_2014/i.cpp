#include <iostream>
#include <string>
using namespace std;

int main()
{
    int n, a, b, c;
    while (cin >> n)
    {
          int min = 0, max = 0;
          if (n > 3) 
          {
                cin >> a; cin >> b;
                for (int i = 2; i < n; ++i)
                {
                    cin >> c;
                    if (a > b && c > b) min++;
                    else if (a < b && c < b) max++;  
                    a = b; b = c;         
                }
          }
          cout << min << " " << max << endl; 
    }
	return 0;
}
