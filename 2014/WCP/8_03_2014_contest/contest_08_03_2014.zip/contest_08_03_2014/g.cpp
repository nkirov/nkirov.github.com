#include <iostream>
using namespace std;

string s;
int c[10001];

int solve()
{
  cin >> s;
  int d=0;
  for(int i=0;i<s.size();i++)
  {
     if(s[i]=='1') {c[d]=1; d=0;}
     else d++;   
  }     
  c[d]=1;  
  
  int b=0;
  
  for(int i=1;i<=s.size();i++) b += c[i];
  
  cout << b << endl;
}

int main()
{
  int nt; cin >> nt;
  for(int t=1; t<=nt; t++)
  {
    for(int i=0;i<=10001;i++) c[i]=0;        
    solve();
  } 
}
