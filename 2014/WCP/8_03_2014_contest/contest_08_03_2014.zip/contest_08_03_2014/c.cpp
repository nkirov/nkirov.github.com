﻿#include <cstdio>
#include <algorithm>
#define LARGE (1e7)
using namespace std;

//USACO 2014 January Contest, Bronze
//Problem 3. Balanced Teams - http://www.usaco.org/index.php?page=viewproblem2&cpid=378
//Analysis - http://www.usaco.org/current/data/sol_bteams

int arr[12];
int order[] = {0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3};
int ans;
int score[4];
 
int main()
{
	while(true)
	{
		scanf("%d", &arr[0]);
		if(arr[0] == -1)
			break;

		for(int x = 1;x < 12;x++)
			scanf("%d", &arr[x]);
    
		ans = LARGE;
		sort(arr, arr + 12);
		
		do
		{
			for(int x = 0;x < 4;x++) 
				score[x] = 0;
			
			for(int x = 0;x < 12;x++) 
				score[order[x]] += arr[x];

			int min = LARGE, max = 0;
			for(int x = 0;x < 4;x++)
			{
				if(score[x] < min) 
					min = score[x];
				if(score[x] > max) 
					max = score[x];
			}
			if(max - min < ans)
				ans = max - min;
 
 
		} 
		while(next_permutation(order, order + 12));

		printf("%d\n",ans);
	}

    return 0;
}