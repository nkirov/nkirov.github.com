#include<iostream>
using namespace std;

long long int c[100001];
int n;
long long int mod;

int catalan()
{
  c[0] = 1;
  c[1] = 1;
  for(int k = 1;k < n;k++)
  {
    long long int s = 0;
    for(int i = 0;i <= k;i++) 
       s = (s + (c[i] * c[k - i]) % mod) % mod;
    c[k+1] = s % mod;
  }   
 
} 

int main()
{
 int nt; cin >> nt;
 for(int t=1; t<=nt; t++)
 {
  for(int j=0;j<=100001;j++) c[j]=0;
  cin >> n >> mod;
  n = n/2;
  catalan();
  cout << c[n] << endl;
 }
}
