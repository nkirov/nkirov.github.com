#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

//USACO 2014 January Contest, Bronze
//Problem 2. Bessie Slows Down - http://www.usaco.org/index.php?page=viewproblem2&cpid=376
//Analysis - http://www.usaco.org/current/data/sol_slowdown.html

int N, t;
double currentD, currentT;
int speedValue; // 1/speed

int main()
{
	cin >> t;
	while(t--)
	{
		cin >> N;

		priority_queue<int, vector<int>, greater<int> > timeEvents;
		priority_queue<int, vector<int>, greater<int> > distanceEvents;
		
		for (int i = 0; i < N; i++)
		{
			char c;
			int x;
			cin >> c >> x;
			if (c == 'T')
				timeEvents.push(x);
			else
				distanceEvents.push(x);
		}

		distanceEvents.push(1000);
    
		currentT = currentD = 0.0;
		speedValue = 1;
    
		while(!timeEvents.empty() || !distanceEvents.empty())
		{
			bool isNextTime = false;
        
			if(distanceEvents.empty())
				isNextTime = true;
			else if(!distanceEvents.empty() && !timeEvents.empty())
				if (timeEvents.top() < (currentT + (distanceEvents.top() - currentD)*speedValue))
					isNextTime = true;
			        
			if(isNextTime)
			{
				currentD += (timeEvents.top() - currentT) / (speedValue + 0.0);
				currentT = timeEvents.top();
				timeEvents.pop();
			}
			else
			{
				currentT += (distanceEvents.top() - currentD) * speedValue;
				currentD = distanceEvents.top();
				distanceEvents.pop();
			}
        
			speedValue++;
		}
    
		int currentTime = (int) currentT;
		double fraction = currentT - currentTime;
    
		if(fraction < 0.5)
			cout << currentTime << "\n";
		else
			cout << currentTime + 1 << "\n";

	}
    return 0;
}
