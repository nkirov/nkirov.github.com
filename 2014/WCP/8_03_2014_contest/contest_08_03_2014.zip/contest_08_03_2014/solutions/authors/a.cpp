#include <iostream>
#include <string>
using namespace std;

//USACO 2014 January Contest, Bronze
//Problem 1. Ski Course Design - http://www.usaco.org/index.php?page=viewproblem2&cpid=376
//Analysis - http://www.usaco.org/current/data/sol_skidesign.html

int n,hills[1000];

int main()
{
	while(cin >> n && n != -1)
	{
		for (int i = 0; i < n; i++)
			cin >> hills[i];

		// brute-force search
		// try all elevation intervals from (0,17) to (83,100)
		int mincost = 1000000000;
		for (int i = 0; i <= 83; i++)
		{
			// calculate the cost for elevation interval (i,i+17)
			int cost = 0, x;
			for (int j = 0; j < n; j++)
			{
				// if hill is below the interval
				if (hills[j] < i)
					x = i - hills[j];
				// if hill is above the interval
				else if (hills[j] > i + 17)
					x = hills[j] - (i + 17);
				// if hill is int the interval
				else
					x = 0;

				cost += x * x;
			}

			// update the minimum cost
			mincost = min(mincost,cost);
		}

		cout << mincost << "\n";
	}
}
