#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
#include <bitset>
#define NUM 12
using namespace std;
int a;
int main()
{
    while(true){
        cin >> a;
        bitset<64> b(a);
        int c = b.count();
        if(c == 0){
            break;
        }
        cout << b.count() << " ";
    }
    return 0;
}
