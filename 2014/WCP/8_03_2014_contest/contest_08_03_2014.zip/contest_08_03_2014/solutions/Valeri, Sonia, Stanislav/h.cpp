#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
using namespace std;
int TC,n,k;
vector<int> v;
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\08.03.14\\bin\\Debug\\in.txt", "r" , stdin);
    scanf("%d", &TC);
    while(TC--){
        v.clear();
        scanf("%d %d", &n, &k);

        while(n--){
            int x;
            scanf("%d", &x);
            v.push_back(x);

        }
        int maxSum = 0;
        for(int i =0; i<k; ++i){
            maxSum+= v[i];
        }
        int currentSum= maxSum;
        for(int j = 0, i = k; i< v.size(); j++, ++i){
            currentSum = currentSum - v[j] + v[i];
            //printf("K %d %d\n", v[j], v[i]);
            //printf("%d\n", currentSum);
            maxSum = max(currentSum, maxSum);
        }
        printf("%d\n", maxSum);
    }

       return 0;
}
