#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
#include <bitset>
#define NUM 12
using namespace std;
int a;
int main()
{
    int N, minn, maxn;

    while(scanf("%d", &N) == 1){


        int a[N];
        minn = 0;
        maxn = 0;
        for(int i = 0; i < N; i++)
        {
            scanf("%d", &a[i]);

        }
        for(int i = 0; i < N-2; i++)
        {
            if(a[i] < a[i+1] && a[i+1] > a[i+2])
                maxn++;
            if(a[i] > a[i+1] && a[i+1] < a[i+2])
                minn++;
        }
        printf("%d %d\n", minn, maxn);

    }
    return 0;
}
