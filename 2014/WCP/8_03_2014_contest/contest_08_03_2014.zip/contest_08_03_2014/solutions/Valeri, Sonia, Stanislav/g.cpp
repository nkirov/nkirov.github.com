#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
using namespace std;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\08.03.14\\bin\\Debug\\in.txt", "r" , stdin);

    int tc;
    cin >> tc;
    vector<int> pos(10000);

    while(tc--)
    {
        string curr;
        cin >> curr;

        int len = curr.size();

        int nulls = 0;

    bool found_zero = false;
        for(int i = 0; i < len; i++)
        {

            if(i == len - 1&& curr[i] == '0')
            {
                nulls++;
                pos[nulls] = 1;
                //cout << nulls <<endl;
                nulls = 0;
            }
            else if(curr[i] == '0')
            {
                found_zero = true;
                nulls++;
            }
            else if(found_zero && curr[i] == '1')
            {
                pos[nulls] = 1;
                found_zero = false;
                //cout << nulls <<endl;
                nulls = 0;
            }
        }


        int cnt = 0;

        for(int i = 0; i < 10000; i++)
        {
            if(pos[i])
            {
                cnt++;
            }
        }

        cout <<cnt << endl;
        pos.clear();
        pos.resize(10000);
    }
       return 0;
}
