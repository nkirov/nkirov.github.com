#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
using namespace std;
int N,M;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\08.03.14\\bin\\Debug\\in.txt", "r" , stdin);
    while(scanf("%d %d", &N, &M)==2){
        int x = 1, y=1;
        int px = 1, py= 1;
        int counter = 0;
        while(true){
            if((x == 0 && y ==0) || (x==M-1 && y==0) || (x==0 && y == N-1) || (x==M-1 && y == N-1)){
                // finish
                printf("%d\n", counter+1);
                break;
            }else {
                if(x==0 || x==M-1){
                    px = -px;
                    counter++;
                } else if(y==0 || y==N-1) {
                    py = -py;
                    counter++;
                }
            x+=px;
            y+=py;
            }

        }

    }

    return 0;
}
