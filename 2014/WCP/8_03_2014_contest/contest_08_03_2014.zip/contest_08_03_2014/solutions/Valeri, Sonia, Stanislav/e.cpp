#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
using namespace std;

int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\08.03.14\\bin\\Debug\\in.txt", "r" , stdin);

    while(!feof(stdin))
    {
        long long a,b,v;
        cin >> a >> b >>v;

        int test = ((v-b)/(a-b));
        if((v-b)%(a-b) != 0)
        {
            test++;
        }

        cout <<  test << endl;
    }
       return 0;
}
