import java.math.BigInteger;
import java.util.Scanner;

public class F {
	public static BigInteger f(int m){
		BigInteger res = BigInteger.ONE;
		for(int i= 1; i<=m; ++i){
			int o1 = 2*i*(2*i-1);
			int o2 = (i+1)*i;
			res = res.multiply(BigInteger.valueOf(o1)).divide(BigInteger.valueOf(o2));
		}
		return res;
	}
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int TC = scanner.nextInt();
		for(int i=0; i<TC; ++i){
			int n = scanner.nextInt();
			int m = scanner.nextInt();
			System.out.println( f(n/2).mod(BigInteger.valueOf(m)) ) ;
		}
		scanner.close();
	}
}
