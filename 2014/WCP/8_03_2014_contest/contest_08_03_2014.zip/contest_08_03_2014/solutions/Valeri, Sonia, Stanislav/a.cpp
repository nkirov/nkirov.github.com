#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<set>
#include<queue>
#include<map>
#include<algorithm>
#include<cstring>
#include<string>
#include<iomanip>
#include<cmath>
#define NUM  12
using namespace std;

vector<int> nums;
int main()
{
    //freopen("C:\\Users\\Administrator\\Desktop\\08.03.14\\bin\\Debug\\in.txt", "r" , stdin);
   int curr;
   cin.sync_with_stdio(false);

    cin >> curr;
    while(curr != -1)
    {
        int nu;
        int maxel = -1;
        int k = curr;
        while(curr--)
        {
                cin >> nu;
                nums.push_back(nu);
                maxel = max(maxel,nu);
        }

        int intervals = maxel - 17;
        int mincost = 1000000;
        int cost = 0;
        for(int i = 0; i <= intervals; i++)
        {
            cost = 0;
            for(int j = 0; j<k; j++)
            {
                if(nums[j] < i)
                {
                    cost+=(i-nums[j])*(i-nums[j]);
                }
                else if(nums[j] > i + 17)
                {
                    cost+=(nums[j] - (i+17))*(nums[j] - (i+17));
                }
            }
            mincost = min(mincost,cost);
        }
        mincost = min(mincost,cost);
        cout << mincost << endl;
        nums.clear();
        cin >>curr;
    }

    return 0;
}
