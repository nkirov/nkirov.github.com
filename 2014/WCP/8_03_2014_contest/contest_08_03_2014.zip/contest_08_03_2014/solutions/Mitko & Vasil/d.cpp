#include <iostream>
#include <algorithm>
#include <cstdio>
#include <vector>
using namespace std;

int dx[2][4] = {
    /* dd, dl, gl, gd, */
    {   1,  1, -1, -1, },
    {   1, -1, -1,  1, }
};
int N, M;

inline int next_dir(int r, int c, int dir)
{
    if(c == M - 1 || c == 0)
    {
        if(dir == 1) return 0; //dl - dd
        if(dir == 0) return 1; //dd - dl
        if(dir == 2) return 3;
        if(dir == 3) return 2;

    }
    if(r == N - 1 || r == 0)
    {
        if(dir == 3) return 0;
        if(dir == 0) return 3;
        if(dir == 2) return 1;
        if(dir == 1) return 2;
    }
}
inline bool is_edge(int r, int c)
{
    return r == 0 || r == N - 1 || c == 0 || c == M - 1;
}

inline bool is_end(int r, int c)
{
    return (r == 0 && c == 0)
        || (r == 0 && c == M - 1)
        || (r == N - 1 && c == 0)
        || (r == N - 1 && c == M - 1);
}
void print_dir(int dir)
{
    if(dir == 0) printf("dolen desen diagonal");
    else if(dir == 1) printf("dolen lqv diagonal");
    else if(dir == 2) printf("goren lqv diagonal");
    else if(dir == 3) printf("goren desen diagonal");
    printf("\n");
}

int main()
{
    while(cin >> N >> M)
    {
//        cout << N << endl;
//        cout << M<< endl;
        int cur_r = 0, cur_c = 0;
        int dir = 0;
//        print_dir(dir);
        bool hasStarted = true;
        int cnt = 0;
        while(!is_end(cur_r, cur_c) || hasStarted)
        {
            hasStarted = false;
            cur_r += dx[0][dir];
            cur_c += dx[1][dir];
//            cout << "moving to (" << cur_r << "," << cur_c << ")..." << endl;
            while(!is_edge(cur_r, cur_c))
            {
                cur_r += dx[0][dir];
                cur_c += dx[1][dir];

//                cout << "moving to (" << cur_r << "," << cur_c << ")..." << endl;
            }
            cnt++;
            dir = next_dir(cur_r, cur_c, dir);
//            cout << "edge at (" << cur_r << "," << cur_c << ")..." << endl << endl;
//            print_dir(dir);
        }
//        cout << "end at (" << cur_r << "," << cur_c << ")..." << endl << endl;
        cout << cnt << endl;
    }
    return 0;
}
