#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;



int main()
{

    int t, n, m;
    cin >> t;
    while(t--)
    {
        int dp[20500] = { 0 };

        cin >> n >> m;

        dp[0] = 1;
        dp[2] = 1;
        dp[4] = 2;

        for(int i = 6; i <= n; i += 2)
        {
//            cout << "Enter: " << i << endl;
            for(int j = 2; j <= i; j += 2)
            {
                int inTheRight = i - j;
                int inTheLeft = i - inTheRight - 2;
//                cout << "left=" << inTheLeft << ", right=" << inTheRight << "adding=" << (dp[inTheLeft] * dp[inTheRight]) % m << endl;
                dp[i] += (dp[inTheLeft] * dp[inTheRight]);
                dp[i] %= m;
            }
//            cout << endl;
        }
        cout << dp[n] << endl;
    }
    return 0;
}
