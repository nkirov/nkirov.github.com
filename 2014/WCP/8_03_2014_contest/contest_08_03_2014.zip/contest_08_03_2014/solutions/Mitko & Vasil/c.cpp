#include <iostream>
#include <algorithm>
#include <vector>
#define MIN(x, y) (x < y ? x : y)
#define MAX(x, y) (x > y ? x : y)
using namespace std;

int main()
{
    int A[12] = { 0 };
    int S[4];
    cin.sync_with_stdio(false);

    int OR[12] = { 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3 };

    while(cin >> A[0] && A[0] != -1)
    {
        for(int i = 1; i < 12; i++) cin >> A[i];

//        sort(OR, OR + 12);
        int minDif = 2000000000, minValue, maxValue;
        do
        {
            S[0] = S[1] = S[2] = S[3] = 0;
            for(int i = 0;i < 12; i++)
            {
                S[ OR[i] ] += A[i];
            }

            maxValue = minValue = S[0];
            minValue = MIN(S[1], minValue);
            maxValue = MAX(S[1], maxValue);
            minValue = MIN(S[2], minValue);
            maxValue = MAX(S[2], maxValue);
            minValue = MIN(S[3], minValue);
            maxValue = MAX(S[3], maxValue);

            minDif = MIN(minDif, maxValue - minValue);
        }while(next_permutation(OR, OR + 11));

        cout << minDif << endl;
    }
    return 0;
}
