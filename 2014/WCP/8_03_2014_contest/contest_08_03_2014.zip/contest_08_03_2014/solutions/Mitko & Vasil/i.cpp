#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;



int main()
{


   int N;
   while (cin>>N)
   {


   vector<int> vec;
   for(int i = 0 ; i < N ; i++)
   {
       int tmp;
       cin>>tmp;
       vec.push_back(tmp);
   }
    int m =0;
    int M =0;
    for(int i = 1 ; i < N - 1 ; i++)
    {
        if (vec[i] > vec[i+1] && vec[i]> vec[i-1])
        {
            M++;
        }
        if (vec[i] < vec[i-1] && vec[i] < vec[i+1])
        {
            m++;
        }

    }

    cout<<m<<" "<<M<<endl;
}
   return 0;
}
