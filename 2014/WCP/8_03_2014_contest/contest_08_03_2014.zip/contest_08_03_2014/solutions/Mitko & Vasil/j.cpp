#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cmath>
#include <bitset>
using namespace std;


int main()
{
    cin.sync_with_stdio(false);
    int n;
    vector<int> v;
    while(cin >> n && n)
    {
        v.push_back(n);
    }

    for(int i = 0; i < v.size(); i++)
    {
        bitset<32> b(v[i]);
        cout << b.count();
        if(i != v.size() -1 ) cout << " ";

    }

    return 0;
}
