#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cmath>
using namespace std;

void Testcase()
{
    int N;
    cin>>N;

    vector<int> T,D;

    for(int i = 0 ; i < N ; i++)
    {
        char type;
        int value;
        cin>>type>>value;
        if (type == 'T')
            T.push_back(value);
        else
            D.push_back(value);
    }

    sort(T.begin() , T.end());
    sort(D.begin(), D.end());
    D.push_back(1000);

    double vel = 1;
    int velCount = 1;
    double dist = 0;
    double resultT = 0;

    int di = 0 , j = 0;
    while(di < D.size() && j < T.size())
    {
        double curD = D[di];
//        printf("curD=%.5lf\n", curD);
        double curT = T[j];
//        printf("curT=%.5lf\n", curT);

        //double nextDist = dist; // + min(curD, f(curT, vel, dist))
        double d1 = curD - dist;
//        printf("d1=%.5lf\n", d1);
        double d2 = vel * (curT - resultT);
//        printf("d2=%.5lf\n", d2);
        if (d1<d2)
        {
            dist +=d1;
            resultT += d1/vel;
            di++;
        }
        else
        {
            dist+=d2;
            resultT = curT;
            j++;
        }

//        printf("dist=%.5lf\n", dist);
//        printf("resultT=%.5lf\n", resultT);
        vel = 1.0 / ++velCount;
//        printf("vel=1/%d (%.5lf)\n", velCount, vel);
    }
    while(di < D.size())
    {
        double curD = D[di];
//        printf("curD=%.5lf\n", curD);
        double d1 = curD - dist;
//        printf("d1=%.5lf\n", d1);
        dist +=d1;
        resultT += d1/vel;
        di++;
        vel = 1.0 / ++velCount;

//        printf("dist=%.5lf\n", dist);
//        printf("resultT=%.5lf\n", resultT);
//        printf("vel=1/%d (%.5lf)\n", velCount, vel);
    }
    cout << (int)floor(resultT + 0.5) << endl;
}

int main()
{
    cin.sync_with_stdio(false);
    int tests = 0;
    cin>>tests;
    while(tests--)
    {
        Testcase();
    }
}
