#include <iostream>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;

int A[10001];

int main()
{
    cin.sync_with_stdio(false);
    int n;
    cin>>n;
    string c;
    for(int i = 0 ; i < n ; i++)
    {
        for(int w = 1 ; w < 10001; w++)
        {
           A[w] = 0;
        }

        cin>>c;
        int q=0;
        for(int s = 0 ; s < c.size() ; s++)
        {
            if (c[s] == '0')
            {
                q++;
            }
            else
            {
                A[q]++;
                q = 0;
            }
        }
        A[q]++;
        int c2 = 0;
        for(int w = 1 ; w < 10001; w++)
        {
            c2 += ( A[w] !=0 );
        }
        cout<<c2<<endl;
    }


    return 0;
}
