#include <iostream>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;

int main()
{
    long long A, B, V;
    while(cin >> A >> B >> V)
    {
        cout << (int)ceil((double)(V - B) / (A - B)) << endl;
    }

    return 0;
}
