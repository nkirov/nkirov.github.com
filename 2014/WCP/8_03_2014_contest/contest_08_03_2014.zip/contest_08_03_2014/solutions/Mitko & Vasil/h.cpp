#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int A[2000];
int main()
{
    int t, n, k;
    cin.sync_with_stdio(false);
    cin >> t;
    while(t--)
    {
        cin >> n >> k;
        for(int i = 0; i < n; i++)
        {
            cin >> A[i];
        }
        int S = 0, b = 0, e = 0;
        for(e = 0; e < k; e++) S += A[e];
//        cout << "First = " << S << endl;

        int maxS = S;
        while(e < n)
        {
            S -= A[b++];
            S += A[e++];

            maxS = max(maxS, S);
//            cout << "b = " << b << ", e = " << e << ", S = " << S << endl;
        }
        cout << maxS << endl;
    }
}
