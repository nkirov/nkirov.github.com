//Task: http://www.math.bas.bg/infos/files/2013-03-02-D1.pdf
//Analysis :http://www.math.bas.bg/infos/files/2013-03-02-sol-D1.pdf

#include<iostream>
using namespace std;

int main()
{
    int N, M;
    
    while(cin >> N >> M)
	{
		int posoka = 4;
		int x = 0, y = 0, br = 0;

		while(true)
		{
			if(posoka == 1)
			{
				if(x - 1 < 0 || y + 1 >= M)
				{
					if(x - 1 < 0 && y + 1 < M) { br++; posoka = 4; }
					else if(x - 1 >= 0 && y + 1 >= M){ br++; posoka = 2; }
					else posoka = 0;
				}
				else { x--; y++; }
			}
			else if(posoka == 2)
			{
				if(x - 1 < 0 || y - 1 < 0)
				{
					if(x - 1 < 0 && y - 1 >= 0) { br++; posoka = 3; }
					else if(x - 1 >= 0 && y - 1 < 0) { br++; posoka = 1; }
					else posoka = 0;
				}
				else { x--; y--; }
			}
			else if(posoka == 3)
			{
				if(x + 1 >= N || y - 1 < 0)
				{
					if(x + 1 >= N && y - 1 >= 0) { br++; posoka = 2; }
					else if(x + 1 < N && y - 1 < 0) { br++; posoka = 4; }
					else posoka = 0;
				}
				else { x++; y--; }
			}
			else if(posoka == 4)
			{
				if(x + 1 >= N || y + 1 >= M)
				{
					if(x + 1 >= N && y + 1 < M) { br++; posoka = 1; }
					else if(x + 1 < N && y + 1 >= M) { br++; posoka = 3; }
					else posoka = 0;
				}
				else { x++; y++; }
			}
			if(posoka == 0) { br++; break; }
		}

		cout<<br<<endl;
	}

    return 0;
}
