﻿#include <iostream>
#include <string>
#include <cstdio>
#include <vector>
using namespace std;

//USACO 2014 February Contest, Bronze
//Problem 1. Mirror Field - http://www.usaco.org/index.php?page=viewproblem2&cpid=394
//Analysis - http://www.usaco.org/current/data/sol_mirror.html

// direction: 0  1   2   3 
int dr[] =   {1, 0, -1,  0};
int dc[] =   {0, 1,  0, -1};

// new direction after hitting / mirror
int bounce1[] = {3, 2, 1, 0}; 

// new direction after hitting \ mirror 
int bounce2[] = {1, 0, 3, 2}; 

int N, M;
string A[1010];

int trace(int r, int c, int dir)
{
	int result = 0;
	while(0 <= r && r < N && 0 <= c && c < M) 
	{
		if(A[r][c] == '/') 
			dir = bounce1[dir];
		else 
			dir = bounce2[dir];
    
		r += dr[dir];
		c += dc[dir];
		result++;
	}
	
	return result;
}

int main() 
{
	cin.sync_with_stdio(false);

	while(cin >> N >> M && N)
	{
		for(int i = 0; i < N; i++) 
			cin >> A[i];

		int best = 0;
		for(int i = 0; i < N; i++) 
		{
			best = max(best, trace(i, 0, 1));
			best = max(best, trace(i, M - 1, 3));
		}

		for(int i = 0; i < M; i++) 
		{
			best = max(best, trace(0, i, 0));
			best = max(best, trace(N - 1, i, 2));
		}
		
		cout << best << endl;
	}
	
	return 0;
}