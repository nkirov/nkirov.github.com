#include<iostream>
using namespace std;

long long int n,m;
long long int a[2][2];

void init()
{
 a[0][0]=1;
 a[0][1]=0;
 a[1][0]=0;
 a[1][1]=1;    
}

void mula()
{
 long long int r00=a[0][0]*a[0][0]+a[0][1]*a[1][0];
 long long int r10=a[1][0]*a[0][0]+a[1][1]*a[1][0];
 long long int r01=a[0][0]*a[0][1]+a[0][1]*a[1][1];
 long long int r11=a[1][0]*a[0][1]+a[1][1]*a[1][1];
 a[0][0]=r00%m;
 a[1][0]=r10%m;
 a[0][1]=r01%m;
 a[1][1]=r11%m;
}

void mulp()
{
 long long int r00=a[0][0]+a[1][0];
 long long int r10=a[0][0];
 long long int r01=a[0][1]+a[1][1];
 long long int r11=a[0][1];
 
 a[0][0]=r00%m;
 a[1][0]=r10%m;
 a[0][1]=r01%m;
 a[1][1]=r11%m;
}

void power(long long int n)
{
 if (n > 1) {power(n/2); mula();}
 if (n%2==1) mulp();
}


void run()
{
  cin >> n >> m;
  init();
  power(n-1);
  cout << a[0][0]%m << endl;
} 

int main()
{
 int nt;
 cin >> nt;
 for(int i=1;i<=nt;i++) run();
}






