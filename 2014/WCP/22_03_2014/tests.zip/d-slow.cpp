#include<cstdio>
#include<deque>
#include<cassert> // not needed
#include<cstring> // not needed
using namespace std;

int N, L;
char S[int(1e7) + 2];

int ans = 0;

void solve(int x, int end, int step) {
  do {
    int h=0;
    for (int to=x; to != end; to += step) {
      h += (S[to] == '-') == (step == +1) ? -1 : +1;
      if (h>=0 || step*(to+step-x) > L) break;
      ans ++;
    }
  } while( (x+=step) != end );
}

int main() {
  scanf("%d%d", &N, &L);
  scanf("%s", S);
  assert((int)strlen(S) == N);

  solve(0, N, +1);
  solve(N-1, -1, -1);

  printf("%d\n", ans);

  return 0;
}


