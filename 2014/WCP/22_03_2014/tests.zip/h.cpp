#include <stdio.h>
#define MAXN 5001
char map[MAXN][MAXN],nb[MAXN][MAXN];
struct cell {short int x,y,ct;} cellarr[MAXN*MAXN];
int N,arrb,arre,time;
void push(int x,int y)
{ //printf("push %d %d %d\n",x,y,time+1);
  cellarr[arre].x=x;
  cellarr[arre].y=y;
  cellarr[arre].ct=time+1;
  arre++;
}
int main()
{  int i,j,k;
   int t,T;
scanf("%d",&T);
for(t=1;t<=T;t++)
{
   scanf("%d",&N);
   for(i=0;i<N;i++)
   { scanf("%s",map[i]);
     for(j=0;j<N;j++) map[i][j]-='0';
   }
   arrb=arre=time=0;
   for(i=1;i<N-1;i++)
      for(j=1;j<N-1;j++)
      {  if(map[i][j]!=0)
         {  k=map[i-1][j]+map[i][j-1]+map[i][j+1]+map[i+1][j];
            nb[i][j]=k;
            if(k<=2) push (i,j);
         }
      }
   time=1;
   while(arrb<arre) // като при обх. в ширина
   {  if(cellarr[arrb].ct==time) //topi se v tozi takt
      { int x=cellarr[arrb].x;
        int y=cellarr[arrb].y;
        map[x][y]=0;arrb++; //pop
//        printf("pop %d %d %d\n",x,y,time);
        if(map[x-1][y]&&nb[x-1][y]>2)
        {  nb[x-1][y]--; if(nb[x-1][y]==2) push(x-1,y);}
        if(map[x][y+1]&&nb[x][y+1]>2)
        {  nb[x][y+1]--; if(nb[x][y+1]==2) push(x,y+1);}
        if(map[x+1][y]&&nb[x+1][y]>2)
        {  nb[x+1][y]--; if(nb[x+1][y]==2) push(x+1,y);}
        if(map[x][y-1]&&nb[x][y-1]>2)
        {  nb[x][y-1]--; if(nb[x][y-1]==2) push(x,y-1);}
      }
      else time++;
   }
   printf("%d\n",time);

}
   return 0;
}
