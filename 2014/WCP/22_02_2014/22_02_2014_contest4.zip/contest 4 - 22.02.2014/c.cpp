#include <iostream>
#include <cstdio>
#include <string>
using namespace std;

//http://www.math.bas.bg/infos/files/2013-04-01-C3.pdf
//http://www.math.bas.bg/infos/files/2013-04-01-sol-C3.pdf

char s[1000000];
int ans[32768];

bool read()
{
    int i, sz;
    if(feof(stdin))
        return false;

    scanf("%s\n", &s);

    sz = strlen(s);
    ans[1] = 1;
    for (i = 1; i < sz; i++)
		ans[i + 1] = (s[i] < s[i - 1]) ? ans[i] + 1 : ans[i];
        
	return true;
}

void solve ()
{
    int i, q, x, y;
    scanf ("%d",&q);
    for (i = 1; i <= q; i++)
    {
        scanf ("%d%d",&x, &y);
        if (ans[x] == ans[x - 1]) 
			printf("%d\n",(ans[y] - ans[x - 1]) + 1);
        else 
			printf("%d\n",(ans[y] - ans[x-1]));
    }
}
int main()
{
    cin.sync_with_stdio(false);
    
	while(read())
		solve();

    return 0;
}
