#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

#define INF 1000000000000000000ll
#define MAXN 20001
#define MAXK 501

#define REGULAR 0
#define INVERSE 1

//USACO 2013 December Contest, Gold - Vacation Planning (gold)
//http://www.usaco.org/index.php?page=viewproblem2&cpid=364
//http://www.usaco.org/current/data/sol_vacationgold.html

// g[1]: graph with inverse edges
vector<pair<int,int> > g[2][MAXN];

int n, m, k, q, hubs[MAXK], cnt;
long long dist[2][MAXK][MAXN],sum;

// shortest path with Dijkstra
// t = {0 - regular graph, 1 - graph with inverse edges} 
void spath(int h, int t)
{
	vector<bool> mark(n, false);
	fill(dist[t][h], dist[t][h] + n, INF);

	dist[t][h][hubs[h]] = 0;
	priority_queue<pair<long long, int> > pq;
	pq.push(make_pair(0, hubs[h]));

	while (!pq.empty())
	{
		int from = pq.top().second;
		pq.pop();

		if (mark[from]) 
			continue;
		
		mark[from] = true;

		for (int j = 0; j < g[t][from].size(); j++)
		{
			int to = g[t][from][j].first;
			int cost = g[t][from][j].second;
			if (dist[t][h][from] + cost < dist[t][h][to])
			{
				dist[t][h][to] = dist[t][h][from] + cost;
				pq.push(make_pair(-(dist[t][h][from] + cost), to));
			}
		}
	}
}

int main()
{
	ios_base::sync_with_stdio(false);

	int tc;
	cin>>tc;
	while(tc--)
	{
		cin >> n >> m >> k >> q;

		for(int i = 0;i < n;i++)
		{
			g[REGULAR][i].clear();
			g[INVERSE][i].clear();
		}

		int u, v, d;
		for (int i = 0; i < m; i++)
		{
			cin >> u >> v >> d;
			g[REGULAR][u-1].push_back(make_pair(v - 1, d));
			g[INVERSE][v-1].push_back(make_pair(u - 1, d));
		}

		// compute minimum costs only for hubs
		for (int i = 0; i < k; i++)
		{
			cin >> hubs[i];
			--hubs[i];
			spath(i, REGULAR);
			spath(i, INVERSE);
		}
		
		cnt = sum = 0;
		for (int i = 0; i < q; i++)
		{
			cin >> u >> v;
			long long cost = INF;
			 
			// mincost(u, v) = min_x { mincost(u, j) + mincost(j, v) }
			for (int j = 0; j < k; j++)
				cost = min(cost, dist[INVERSE][j][u - 1] + dist[REGULAR][j][v - 1]);

			if (cost != INF) 
			{
				cnt++;
				sum += cost;
			}
		}

		cout << cnt << "\n" << sum << "\n";
	}
}
