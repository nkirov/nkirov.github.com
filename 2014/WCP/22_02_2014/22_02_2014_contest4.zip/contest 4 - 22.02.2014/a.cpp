#include <stdio.h>
#include <vector>
#include <queue>
using namespace std;

//credits: http://www.csd.uoc.gr/~hy583/reviewed_notes/dfs_dags.pdf

#define INF 1000000000

typedef pair<int, int> pi;
typedef vector<pi> vi;
typedef vector<vi> vii;

vector<vector<pi> > adj;
deque<int> topSort;
vector<bool> vis;
vector<int> longestDist;
vector<int> shortestDist;
vector<int> longestParent;
vector<int> shortestParent;

int V, E, s, f;

void init()
{
	adj.assign(V, vi());
	vis.assign(V, 0);
	longestDist.assign(V, -1);
	shortestDist.assign(V, INF);
	longestParent.assign(V, -1);
	shortestParent.assign(V, -1);
	topSort.clear();
}

void dfs(int par)
{
	if(vis[par]) return;
	vis[par] = true;

	for(int i = 0;i < adj[par].size();i++)
		dfs(adj[par][i].first);

	topSort.push_back(par);
}

void calcDist()
{
	//do topological sort
	dfs(s);

	longestDist[s] = 0;
	shortestDist[s] = 0;

	while(!topSort.empty())
	{
		int from = topSort.back();
		topSort.pop_back();

		for(int i = 0;i < adj[from].size();i++)
		{
			int to = adj[from][i].first;
			int cost = adj[from][i].second;
			if(longestDist[to] < longestDist[from] + cost)
			{
				longestDist[to] = longestDist[from] + cost;
				longestParent[to] = from;
			}

			if(shortestDist[to] > shortestDist[from] + cost)
			{
				shortestDist[to] = shortestDist[from] + cost;
				shortestParent[to] = from;
			}
		}
	}
}

void printLongestPath(int u) 
{    
	if (u == s) 
	{ 
		printf("%d", u + 1); 
		return; 
	}
	
	printLongestPath(longestParent[u]);
	printf(" %d", u + 1); 
}

void printShortestPath(int u) 
{    
	if (u == s) 
	{ 
		printf("%d", u + 1); 
		return; 
	}
	
	printShortestPath(shortestParent[u]);
	printf(" %d", u + 1); 
}

void print()
{
	int max = -1, maxV = -1;
	int min = INF, minV = -1;

	for(int i = 0;i < V;i++)
	{
		if(i == s)
			continue;
		
		if(longestDist[i] > max)
			max  = longestDist[i], maxV = i;

		if(shortestDist[i] < min)
			min = shortestDist[i], minV = i;
	}

	printf("the shortest path from %d ends in %d, cost: %d\n", s + 1, minV + 1, min); 
	printShortestPath(minV);
	printf("\n");

	printf("the longest path from %d ends in %d, cost: %d\n", s + 1, maxV + 1, max); 
	printLongestPath(maxV);
	printf("\n");
}

int main()
{
	int u, v, c;
	while(true)
	{
		scanf("%d%d", &V, &E);
		if(V == 0)
			break;

		init();

		for(int i = 0;i < E;i++)
		{
			scanf("%d%d%d", &u, &v, &c);
			adj[u - 1].push_back(make_pair(v - 1, c));
		}

		scanf("%d", &s);
		s--;

		calcDist();
		print();
	}
	
	return 0;
}
