#include <string> 
#include <cstdio> 
#include <cmath> 
using namespace std;

//http://community.topcoder.com/tc?module=ProblemDetail&rd=6519&pm=3561
//http://community.topcoder.com/tc?module=Static&d1=match_editorials&d2=srm230

char str[100];
int c, t;

inline double ln2(double x) 
{
	return log(x) / log(2.0);
}
 
double sol1(int c, int time) 
{
	double ret = 0, inc = 2000000000;
	while (inc > 1e-20)
	{
		if (c * (ret + inc) * ln2(ret + inc) <= (double)time)
			ret += inc;
		inc /= 2;
	}
	
	return ret;
}

double sol2(int c, int time) 
{ 
	double ret, lo = 0, hi = 1e20; 
	
	for(int i = 0; i < 500; i++) 
	{ 
		ret = (hi + lo) / 2; 
		if(ret * log(ret) / log(2.0) * c <= time) 
			lo = ret; 
		else 
			hi = ret; 
	} 

	ret = (hi+lo) / 2; 
	return ret; 
}

int main()
{
	while (true)
    {
		gets(str);
		if(str[0] == 'e')
			break;

		char *p = strtok(str, " ");
		c = atoi(p);

		p = strtok(NULL, " ");
		t = atoi(p);

		//double ans = sol1(c, t);
		double ans = sol2(c, t);
		printf("%.12lf\n", ans);
    }
		
    return 0;
}
