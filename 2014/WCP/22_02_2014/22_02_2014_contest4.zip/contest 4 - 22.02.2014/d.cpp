#include <iostream>
using namespace std;

//http://www.math.bas.bg/infos/files/2013-01-06-sol-B1.pdf

int a, b, c, d, p, sol;

int main()
{
    while(cin >> p && p)
	{
		sol = a = b = 0; c = 1;                                  
    
		for(int i = 3; ; i++)
		{
			d = (a + b + c) % p;      
			a = b; 
			b = c; 
			c = d;
              
			if (a == 0 && b == 0 && c == 1)     
			{
				sol = i - 2;
				break;
			}
		}
    
		cout << sol << endl;
	}

    return 0;
}
