#include <iostream>
#include <string>
#include <cstring>
#include <cassert>
using namespace std;

#define DEB(x) //cerr << #x << ":\t" << x << " at" << __LINE__ << endl;

const int SIZE = 4*1024*1024;

char a[SIZE];
int N;

// hash of some seq is sum(c_(N-i+1) * P**i)

typedef int ht; //hash type
typedef long long dht; //can handle ht*MUL
const int MOD = 2000000011;
//typedef int dht;
//const int MOD = 60000011;//30000001;//2000003;
const int P = 29;

ht h[SIZE]; //h[C] - hash of the prefix of len C
ht pows[SIZE];
void InitHash(){
	h[0] = 0;
	pows[0] = 1;
	for(int i = 0; i < N; ++i){
		h[i+1] = (ht)(((dht)h[i] * P + a[i]) % MOD);
		pows[i+1] = (ht)((dht)pows[i]*P % MOD);
		//DEB(i);
		//DEB(pows[i]);
		//DEB(h[i]);
	}
}

// hash of substring starting from p with length l
ht Hash(int p, int l){
	//DEB(p);
	//DEB(l);
	
	ht res = (ht)(((dht)h[p+l] - ((dht)h[p] * pows[l] % MOD) + MOD) % MOD);
	//DEB(res);
	return res;
}




int main(int argc, char** argv){
	bool brute = (argc > 1 && strcmp(argv[1], "brute") == 0);

while(cin >> a){
	N = strlen(a);
	DEB(a);
	DEB(N);
	assert(N <= 4*1000*1000);
	assert(N >= 2);
	bool done = false;
	if(brute) goto brute_force;
	InitHash();
	for(int l = N/2; l > 0 && !done; --l){
		ht prev = Hash(0, l);
		for(int p = l; p <= N - l; p+=l){
			ht next = Hash(p, l);
			if(next == prev && 0 == strncmp(a+p-l, a+p, l)){
				cout << p-l << " " << l << endl;
				done = true;
				break;
			}
			if(next == prev) cerr << "false negative!\n";
			prev = next;
		}
	}
	continue;
	brute_force:
	//brute check
	done = false;
	for(int l = N/2; l > 0 && !done; --l){
		for(int p = l; p <= N - l; p+=l){
			if(0 == strncmp(a+p-l, a+p, l)){
				cerr << "brute:" << p-l << " " << l << endl;
				done = true;
				break;
			}
		}
	}
}
	// hash em
}
