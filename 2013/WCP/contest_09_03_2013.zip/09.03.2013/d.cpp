#include<cstdio>
#include<cstring>
long long n,m;
long long num,res,d[1000001];

int main() 
{ 
  while(scanf("%lld %lld",&n,&m),n+m>0)
  {
    memset(d,0,sizeof(d));
    scanf("%lld",&d[0]);
    for(int i=1;i<n;i++)
    {
      scanf("%lld",&num);
      d[i] = (d[i-1] * num) % m; 
      for(int j=i-1;j>0;j--) d[j] = (d[j-1]*num+d[j]) % m;
      d[0] = (d[0] + num) % m;
      //for(int j=0;j<=n;j++) printf("%lld ",d[j]);
      //printf("\n");
    }
    res = d[0];
    for(int i=1;i<n;i++) if (d[i] > res) res = d[i];
    printf("%lld\n",res);
  }
}
