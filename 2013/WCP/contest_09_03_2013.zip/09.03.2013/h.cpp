#include <iostream>
#include <utility>
#include <vector>
#include <cassert>
using namespace std;

const int MAX = 2 * 1024;
typedef vector<short> hyper;

int gcd(int a, int b){
	if(a < b) swap(a, b);
	while(b != 0){
		int t = a % b;
		a = b;
		b = t;
	}
	return a;
}

hyper fm[MAX];

int main(){
	fm[1] = vector<short>(1, 1);
	for(int i = 2; i < MAX; ++i){
		hyper& c = fm[i];
		c = fm[i-1];
		hyper& a = fm[i-2];
		int r = 0;
		for(int j = 0; j < c.size(); ++j){
			short d = (j < a.size() ? a[j] : 0);
			r += c[j] + d;
			c[j] = r % 10;
			r /= 10;
		}
		if(r > 0) c.push_back(r);
	}
	int a, b;
	while(cin >> a >> b){
		assert(a <= 2000 && b <= 2000);
		if(a == 0 && b == 0) break;
		hyper& r = fm[gcd(a, b)]; 
		if(r.size() == 0) cout << "0";
		else for(int i = r.size()-1; i >= 0; --i) cout << r[i];
		cout << "\n";		
	}
	return 0;
}
