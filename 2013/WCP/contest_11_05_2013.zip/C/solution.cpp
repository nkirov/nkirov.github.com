#include <stdio.h>
#include <string.h>

char a[20001][32];
int b[20001][32];
int N,i,j,m,err;
char c, buf[32];
int chekdict(int x)
{
    int l=1,r=m,k;
    while(l<=r)
    {
       k=(l+r)/2;
       if(strcmp(buf,a[k])==0) break;
       else if(strcmp(buf,a[k])<0) r=k-1;
       else l=k+1;
    }
    if(l>r) return 0;
    if(b[k][x]==1) return 0;
    return 1;
      
}
int main()
{
    
    
    while(1)
    {
       scanf("%d",&N);
       for(i=1;i<=N;i++)
          for(j=0;j<30;j++) b[i][j]=0;
       if(N==-1) break;
       m=0; 
       for(i=1;i<=N;i++)
       {
          scanf("%s",buf);
      
          j=0;
          while(buf[j]>='a'&&buf[j]<='z') j++;
          buf[j]+='a'-'A';
          if(m==0||strcmp(buf,a[m])!=0)
          {m++;strcpy(a[m],buf);}                    
          b[m][j]=1;                 
       }
/*       for(i=1;i<=m;i++)
       {
          printf("%s ",a[i]);
          for(j=0;j<=5;j++) printf("%d ",b[i][j]);
          printf("\n");                 
       }*/
       err=0;int p;
       scanf("%c",&c);
       do
       {
          j=-1;i=0;
          do 
          {
             scanf("%c",&buf[++j]);
             if(buf[j]>='A'&&buf[j]<='Z') {i++;p=j;buf[j]+='a'-'A';} 
          } while (buf[j]!=' '&&buf[j]!='\n');
          c=buf[j];buf[j]='\0';
//printf("%s %d %d\n",buf,i,p);    
          
          if(i!=1) err++; else if(m>0) err+=chekdict(p); 
          
       } while(c!='\n');
       printf("%d\n",err);        
    }
    
}
