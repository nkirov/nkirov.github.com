 #include <cstring>
#include <cstdio>
#include <cctype>
using namespace std;

const int N = (1 << 21);

char str[N];

int main()
{
        //freopen("G.txt", "r", stdin);
        while (fgets(str, N - 1, stdin))
        {
                //printf("%s -> ", str);
                char last = str[0];
                int len = strlen(str);
                if (isspace(str[len - 1])) len --;
                int cnt = 0;
                bool flag = (str[0] != str[1]);
                if (flag) printf("1");
                for (int pos = 0; pos < len; ++ pos)
                {
                        if (str[pos] == last)
                        {
                                ++ cnt;
                                if (cnt > 1 && flag)
                                {
                                        printf("1");
                                        flag = false;
                                }
                                if (cnt == 9)
                                {
                                        printf("9%c", last);
                                        cnt = 0;
                                        last = 0;
                                        continue;
                                }
                        }
                        else
                        {
                                if (cnt == 1 && !flag)
                                {
                                        printf("1");
                                        flag = 1;
                                }
                                if (flag)
                                {
                                        if (last == '1') printf("11");
                                        else printf("%c", last);
                                }
                                else
                                {
                                        if (cnt) printf("%d%c", cnt, last);
                                }
                                last = str[pos];
                                cnt = 1;
                        }
                }
                if (cnt == 1)
                {
                        if (last == '1') printf("11");
                        else printf("%c", last);
                        printf("1");
                }
                else
                {
                        printf("%d%c", cnt, last);
                }
                printf("\n");
                memset(str, 0, len + 2);
        }
        return 0;
}
