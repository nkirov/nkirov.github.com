#include <stdio.h>
#define MAXN 60001
int dp[MAXN]={0};

int main()
{
   int i,j,t,T,N;
   for(i=1;i<=MAXN;i++) dp[i]=1;
   for(i=2;i<=MAXN;i++)
   { 
      for(j=2;j<=MAXN/i;j++)
        dp[i*j-1]+=dp[i-1];
   }      
   scanf("%d",&T);
   for(t=1;t<=T;t++)
   {
      scanf("%d",&N);
      printf("%d\n",dp[N]);                 
   }          
   return 0; 
} 
