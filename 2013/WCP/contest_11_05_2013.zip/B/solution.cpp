#include <stdio.h>

int skl[4],nt[4];
int max(int a,int b)
{return a>b?a:b;}
int count(int i,int j)
{return (skl[1]/nt[i])*(skl[2]/nt[j])*(skl[3]/nt[6-i-j]);}

int main()
{
    int t,T;
    int i,j,m;
    scanf("%d",&T);
    for(t=1;t<=T;t++)
    {
       scanf("%d %d %d %d %d %d",&skl[1],&skl[2],&skl[3],&nt[1],&nt[2],&nt[3]);
       m=0;
       for(i=1;i<=3;i++)
          for(j=1;j<=3;j++)
             if(i!=j) m=max(m,count(i,j));
       printf("%d\n",m);                       
    }
    return 0;   
}
