#include <stdio.h>

int main(int argc, char** argv)
{
    
    FILE *in,*ou,*log;
    int i,j,t,T; char ans[10];
    int N,M,ex,col,tab[32][32],res[32][32];
    
    in=fopen(argv[1],"r");
    ou=fopen(argv[3],"r");
    log=fopen(argv[2],"r");
    
    if (in == NULL) {printf("INPUT FILE NOT FOUND!\n");return 1;}
    if (ou == NULL) {printf("OUTPUT FILE NOT FOUND!\n");return 1;}
    if (log == NULL) {printf("LOG FILE NOT FOUND!\n");return 1;}
    fscanf(in,"%d",&T); 
    for(t=1;t<=T;t++)
    {
       fscanf(in,"%d %d",&N,&M);
       for(i=1;i<=N;i++)
          for(j=1;j<=M;j++)
          {   fscanf(in,"%d",&tab[i][j]);
              if(tab[i][j]<0||tab[i][j]>3)
              {printf("WRONG COLOR IN CELL!\n");return 1;}
          }
          
       fscanf(log,"%d",&ex);
     
       if(ex==0)
       {  fscanf(ou,"%s",&ans);
          if(ans[0]!='N'||ans[1]!='O') {printf("WRONG ANSWER!\n");return 1;}
       }
       else
       {
          for(i=1;i<=N;i++)
             for(j=1;j<=M;j++)
                res[i][j]=0;
          for(i=1;i<=N;i++)
          {  fscanf(ou,"%d",&col);
             if(col<0||col>2) {printf("WRONG ROW COLORING!\n");return 1;}
             for(j=1;j<=M;j++) if(res[i][j]!=col) res[i][j]+=col;
          }
          for(j=1;j<=M;j++)
          {  fscanf(ou,"%d",&col);
             if(col<0||col>2) {printf("WRONG COLUMN COLORING!\n");return 1;}
             for(i=1;i<=N;i++) if(res[i][j]!=col) res[i][j]+=col;
          } 
            
          for(i=1;i<=N;i++)
             for(j=1;j<=M;j++)
                if(tab[i][j]!=0&&tab[i][j]!=res[i][j])
                {printf("WRONG COLORED CELL! Test %d!\n",t);return 1;} 
                     
       }
    }
    printf("OK\n");
    return 0;         
}
