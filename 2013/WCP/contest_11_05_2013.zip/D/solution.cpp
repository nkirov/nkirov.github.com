#include <stdio.h>

int main()
{
    
    int i,j,t,T; char ans[10];
    int N,M,flag,col,tab[32][32],rowcol[32],colcol[32];
    
    scanf("%d",&T); 
    for(t=1;t<=T;t++)
    {
       scanf("%d %d",&N,&M);
       for(i=1;i<=N;i++)
          for(j=1;j<=M;j++)
             scanf("%d",&tab[i][j]);
       for(i=1;i<=N;i++) rowcol[i]=0;
       for(i=1;i<=M;i++) colcol[i]=0;
       flag=0;
       for(i=1;i<=N;i++)
          for(j=1;j<=M;j++)
          {
             if(tab[i][j]==1)
             {
                if(rowcol[i]==0) rowcol[i]=1;
                if(rowcol[i]==2) {rowcol[i]= -1;flag=1;}
                if(colcol[j]==0) colcol[j]=1; 
                if(colcol[j]==2) {colcol[j]= -1;flag=1;}               
             } 
             if(tab[i][j]==2)
             {
                if(rowcol[i]==0) rowcol[i]=2;
                if(rowcol[i]==1) {rowcol[i]= -1;flag=1;}
                if(colcol[j]==0) colcol[j]=2; 
                if(colcol[j]==1) {colcol[j]= -1;flag=1;}               
             }                
          }
       if(flag) {printf("NO\n");continue;}
         for(i=1;i<N;i++) printf("%d ",rowcol[i]);printf("%d\n",rowcol[N]);
         for(i=1;i<M;i++) printf("%d ",colcol[i]);printf("%d\n",colcol[M]);       
       for(i=1;i<=N;i++)
          for(j=1;j<=M;j++)
          {
             if(tab[i][j]==3)
             {
                if(rowcol[i]==0&&colcol[j]==0) {rowcol[i]=1;colcol[j]=2;}             
                else if(rowcol[i]==0&&colcol[j]==1) rowcol[i]=2;
                     else if(rowcol[i]==0&&colcol[j]==2) rowcol[i]=1;
                          else if(rowcol[i]==1&&colcol[j]==0) colcol[j]=2;
                               else if(rowcol[i]==1&&colcol[j]==1) {rowcol[i]=colcol[j]= -1;flag=1;}
                                    else if(rowcol[i]==2&&colcol[j]==0) colcol[j]=1;
                                         else if(rowcol[i]==2&&colcol[j]==2) {rowcol[i]=colcol[j]= -1;flag=1;}                
             } 
          }         
          if(flag) {printf("NO\n");/*continue;*/}
          for(i=1;i<N;i++) printf("%d ",rowcol[i]);printf("%d\n",rowcol[N]);
          for(i=1;i<M;i++) printf("%d ",colcol[i]);printf("%d\n",colcol[M]);
    }         
    
    return 0;         
}
