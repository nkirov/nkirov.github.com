#include <cstdio>
#include <cstring>
#include <algorithm>
#define MAXN (1 << 10)
using namespace std;

int n, k, sum;
int a[MAXN];

int dp[MAXN];

inline void solve() {
    memset(dp, 0x7f, sizeof(dp));
    int maxx = dp[0];

    for (int i=0; i < n; ++i) {
        for (int j=0; j < k; ++j)
            if (dp[j] != maxx) {
                int id = (j+a[i]) % k;
                dp[id] = min(dp[id], dp[j] + 1);
            }

        dp[ a[i] ] = 1;
    }
    dp[0] = 0;

    if (dp[sum] == maxx) printf("%d\n", 0);
    else printf("%d\n", n - dp[sum]);
}

inline int read() {
    scanf("%d", &n);
    if (!n) return 0;
    scanf("%d", &k);

    sum = 0;
    for (int i=0; i < n; ++i) {
        scanf("%d", &a[i]);
        a[i] %= k;
        sum += a[i];
        sum %= k;
    }

    return 1;
}

int main() {
    while (read()) {
        solve();
    }

    return 0;
}
