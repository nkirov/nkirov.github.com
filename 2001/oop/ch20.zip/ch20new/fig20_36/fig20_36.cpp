// Fig. 20.36: fig20_36.cpp
// Demonstrates lower_bound, upper_bound and equal_range for
// a sorted sequence of values.
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
   const int SIZE = 10;
   int a1[] = { 2, 2, 4, 4, 4, 6, 6, 6, 6, 8 };
   vector< int > v( a1, a1 + SIZE );
   ostream_iterator< int > output( cout, " " );

   cout << "Vector v contains:\n";
   copy( v.begin(), v.end(), output );

   vector< int >::iterator lower;
   lower = lower_bound( v.begin(), v.end(), 6 );
   cout << "\n\nLower bound of 6 is element " 
        << ( lower - v.begin() ) << " of vector v";

   vector< int >::iterator upper;
   upper = upper_bound( v.begin(), v.end(), 6 );
   cout << "\nUpper bound of 6 is element " 
        << ( upper - v.begin() ) << " of vector v";

   pair< vector< int >::iterator, vector< int >::iterator > eq;
   eq = equal_range( v.begin(), v.end(), 6 );
   cout << "\nUsing equal_range:\n"
        << "   Lower bound of 6 is element "
        << ( eq.first - v.begin() ) << " of vector v";
   cout << "\n   Upper bound of 6 is element "
        << ( eq.second - v.begin() ) << " of vector v";

   cout << "\n\nUse lower_bound to locate the first point\n"
        << "at which 5 can be inserted in order";
   lower = lower_bound( v.begin(), v.end(), 5 );
   cout << "\n   Lower bound of 5 is element " 
        << ( lower - v.begin() ) << " of vector v";

   cout << "\n\nUse upper_bound to locate the last point\n"
        << "at which 7 can be inserted in order";
   upper = upper_bound( v.begin(), v.end(), 7 );
   cout << "\n   Upper bound of 7 is element " 
        << ( upper - v.begin() ) << " of vector v";

   cout << "\n\nUse equal_range to locate the first and\n"
        << "last point at which 5 can be inserted in order";
   eq = equal_range( v.begin(), v.end(), 5 );
   cout << "\n   Lower bound of 5 is element "
        << ( eq.first - v.begin() ) << " of vector v";
   cout << "\n   Upper bound of 5 is element "
        << ( eq.second - v.begin() ) << " of vector v" 
        << endl;            
   return 0;
}
