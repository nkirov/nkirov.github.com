// Fig. 20.18: fig20_18.cpp
// Testing Standard Library class deque
#include <iostream>
#include <deque>
#include <algorithm>

using namespace std;

int main()
{ 
   deque< double > values;
   ostream_iterator< double > output( cout, " " );

   values.push_front( 2.2 );
   values.push_front( 3.5 );
   values.push_back( 1.1 );

   cout << "values contains: ";

   for ( int i = 0; i < values.size(); ++i )
      cout << values[ i ] << ' ';

   values.pop_front();
   cout << "\nAfter pop_front values contains: ";
   copy ( values.begin(), values.end(), output );

   values[ 1 ] = 5.4;
   cout << "\nAfter values[ 1 ] = 5.4 values contains: ";
   copy ( values.begin(), values.end(), output );
   cout << endl;
   return 0;
}
