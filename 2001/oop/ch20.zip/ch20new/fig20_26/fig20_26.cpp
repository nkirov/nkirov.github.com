// Fig. 20.26: fig20_26.cpp
// Demonstrating fill, fill_n, generate, and generate_n
// Standard Library methods. 
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

char nextLetter();

int main()
{
   vector< char > chars( 10 );
   ostream_iterator< char > output( cout, " " );

   fill( chars.begin(), chars.end(), '5' );
   cout << "Vector chars after filling with 5s:\n";
   copy( chars.begin(), chars.end(), output );

   fill_n( chars.begin(), 5, 'A' );
   cout << "\nVector chars after filling five elements"
        << " with As:\n";
   copy( chars.begin(), chars.end(), output );

   generate( chars.begin(), chars.end(), nextLetter );
   cout << "\nVector chars after generating letters A-J:\n";
   copy( chars.begin(), chars.end(), output );

   generate_n( chars.begin(), 5, nextLetter );
   cout << "\nVector chars after generating K-O for the"
        << " first five elements:\n";
   copy( chars.begin(), chars.end(), output );

   cout << endl;
   return 0;
}

char nextLetter()
{
   static char letter = 'A';
   return letter++;
}
