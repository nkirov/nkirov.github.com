// Fig. 20.5: fig20_05.cpp
// Demonstrating input and output with iterators.
#include <iostream>
#include <iterator>

using namespace std;

int main()
{
   cout << "Enter two integers: ";

   istream_iterator< int > inputInt( cin );
   int number1, number2;

   number1 = *inputInt;  // read first int from standard input
   ++inputInt;           // move iterator to next input value
   number2 = *inputInt;  // read next int from standard input

   cout << "The sum is: ";

   ostream_iterator< int > outputInt( cout );

   *outputInt = number1 + number2;  // output result to cout
   cout << endl;
   return 0;
}
