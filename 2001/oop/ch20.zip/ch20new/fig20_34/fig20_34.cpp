// Fig. 20.34: fig20_34.cpp
// Demonstrates miscellaneous functions: inplace_merge,
// reverse_copy, and unique_copy.
#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using namespace std;

int main()
{
   const int SIZE = 10;
   int a1[ SIZE ] = { 1, 3, 5, 7, 9, 1, 3, 5, 7, 9 };
   vector< int > v1( a1, a1 + SIZE );

   ostream_iterator< int > output( cout, " " );

   cout << "Vector v1 contains: ";
   copy( v1.begin(), v1.end(), output );

   inplace_merge( v1.begin(), v1.begin() + 5, v1.end() );
   cout << "\nAfter inplace_merge, v1 contains: ";
   copy( v1.begin(), v1.end(), output );
   
   vector< int > results1;
   unique_copy( v1.begin(), v1.end(), 
                back_inserter( results1 ) );
   cout << "\nAfter unique_copy results1 contains: ";
   copy( results1.begin(), results1.end(), output );
   
   vector< int > results2;
   cout << "\nAfter reverse_copy, results2 contains: ";
   reverse_copy( v1.begin(), v1.end(), 
                 back_inserter( results2 ) );
   copy( results2.begin(), results2.end(), output );

   cout << endl;
   return 0;
}