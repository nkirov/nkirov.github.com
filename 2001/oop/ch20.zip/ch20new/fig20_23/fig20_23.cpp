// Fig. 20.23: fig20_23.cpp
// Testing Standard Library class stack
#include <iostream>
#include <stack>
#include <vector>
#include <list>

using namespace std;

template< class T >
void popElements( T &s );

int main()
{
   stack< int > intDequeStack; // default is deque-based stack
   stack< int, vector< int > > intVectorStack;
   stack< int, list< int > > intListStack;

   for ( int i = 0; i < 10; ++i ) {
      intDequeStack.push( i );
      intVectorStack.push( i );
      intListStack.push( i );
   }

   cout << "Popping from intDequeStack: ";
   popElements( intDequeStack );
   cout << "\nPopping from intVectorStack: ";
   popElements( intVectorStack );
   cout << "\nPopping from intListStack: ";
   popElements( intListStack );

   cout << endl;
   return 0;
}

template< class T >
void popElements( T &s )
{
   while ( !s.empty() ) {
      cout << s.top() << ' ';
      s.pop();
   }
}