// Fig. 20.20: fig20_20.cpp
// Testing Standard Library class set
#include <iostream>
#include <set>
#include <algorithm>

using namespace std;

int main()
{
   typedef set< double, less< double > > double_set;
   const int SIZE = 5;
   double a[ SIZE ] = { 2.1, 4.2, 9.5, 2.1, 3.7 };   
   double_set doubleSet( a, a + SIZE );;
   ostream_iterator< double > output( cout, " " );

   cout << "doubleSet contains: ";
   copy( doubleSet.begin(), doubleSet.end(), output );

   pair< double_set::const_iterator, bool > p;

   p = doubleSet.insert( 13.8 ); // value not in set
   cout << '\n' << *( p.first ) 
        << ( p.second ? " was" : " was not" ) << " inserted";
   cout << "\ndoubleSet contains: ";
   copy( doubleSet.begin(), doubleSet.end(), output );

   p = doubleSet.insert( 9.5 );  // value already in set
   cout << '\n' << *( p.first ) 
        << ( p.second ? " was" : " was not" ) << " inserted";
   cout << "\ndoubleSet contains: ";
   copy( doubleSet.begin(), doubleSet.end(), output );

   cout << endl;
   return 0;
}
