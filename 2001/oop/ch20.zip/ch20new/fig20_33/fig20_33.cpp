// Fig. 20.33: fig20_33.cpp
// Demonstrates miscellaneous functions: copy_backward, merge,
// unique and reverse.
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
   const int SIZE = 5;
   int a1[ SIZE ] = { 1, 3, 5, 7, 9 };
   int a2[ SIZE ] = { 2, 4, 5, 7, 9 };
   vector< int > v1( a1, a1 + SIZE );
   vector< int > v2( a2, a2 + SIZE );

   ostream_iterator< int > output( cout, " " );

   cout << "Vector v1 contains: ";
   copy( v1.begin(), v1.end(), output );
   cout << "\nVector v2 contains: ";
   copy( v2.begin(), v2.end(), output );

   vector< int > results( v1.size() );
   copy_backward( v1.begin(), v1.end(), results.end() );
   cout << "\n\nAfter copy_backward, results contains: ";
   copy( results.begin(), results.end(), output );
   
   vector< int > results2( v1.size() + v2.size() );
   merge( v1.begin(), v1.end(), v2.begin(), v2.end(),
          results2.begin() );
   cout << "\n\nAfter merge of v1 and v2 results2 contains:\n";
   copy( results2.begin(), results2.end(), output );
   
   vector< int >::iterator endLocation;
   endLocation = unique( results2.begin(), results2.end() );
   cout << "\n\nAfter unique results2 contains:\n";
   copy( results2.begin(), endLocation, output );
   
   cout << "\n\nVector v1 after reverse: ";
   reverse( v1.begin(), v1.end() );
   copy( v1.begin(), v1.end(), output );

   cout << endl;
   return 0;
}