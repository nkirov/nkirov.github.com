// Fig. 20.38: fig20_38.cpp
// Demonstrating min and max
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
   cout << "The minimum of 12 and 7 is: " << min( 12, 7 );
   cout << "\nThe maximum of 12 and 7 is: " << max( 12, 7 );
   cout << "\nThe minimum of �G� and �Z� is: " 
        << min( �G�, �Z� );
   cout << "\nThe maximum of �G� and �Z� is: " 
        << max( �G�, �Z� ) << endl;
   return 0;
}