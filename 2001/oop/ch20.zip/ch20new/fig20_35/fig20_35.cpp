// Fig. 20.35: fig20_35.cpp
// Demonstrates includes, set_difference, set_intersection, 
// set_symmetric_difference and set_union.
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
   const int SIZE1 = 10, SIZE2 = 5, SIZE3 = 20;
   int a1[ SIZE1 ] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
   int a2[ SIZE2 ] = { 4, 5, 6, 7, 8 };
   int a3[ SIZE2 ] = { 4, 5, 6, 11, 15 };
   ostream_iterator< int > output( cout, " " );

   cout << "a1 contains: ";
   copy( a1, a1 + SIZE1, output );
   cout << "\na2 contains: ";
   copy( a2, a2 + SIZE2, output );
   cout << "\na3 contains: ";
   copy( a3, a3 + SIZE2, output );

   if ( includes( a1, a1 + SIZE1, a2, a2 + SIZE2 ) )
      cout << "\na1 includes a2";
   else
      cout << "\na1 does not include a2";
      
   if ( includes( a1, a1 + SIZE1, a3, a3 + SIZE2 ) )
      cout << "\na1 includes a3";
   else
      cout << "\na1 does not include a3";

   int difference[ SIZE1 ];
   int *ptr = set_difference( a1, a1 + SIZE1, a2, a2 + SIZE2, 
                              difference );
   cout << "\nset_difference of a1 and a2 is: ";
   copy( difference, ptr, output );

   int intersection[ SIZE1 ];
   ptr = set_intersection( a1, a1 + SIZE1, a2, a2 + SIZE2, 
                           intersection );
   cout << "\nset_intersection of a1 and a2 is: ";
   copy( intersection, ptr, output );

   int symmetric_difference[ SIZE1 ];
   ptr = set_symmetric_difference( a1, a1 + SIZE1, 
            a2, a2 + SIZE2, symmetric_difference );
   cout << "\nset_symmetric_difference of a1 and a2 is: ";
   copy( symmetric_difference, ptr, output );

   int unionSet[ SIZE3 ];
   ptr = set_union( a1, a1 + SIZE1, a3, a3 + SIZE2, unionSet );
   cout << "\nset_union of a1 and a3 is: ";
   copy( unionSet, ptr, output );
   cout << endl;
   return 0;
}