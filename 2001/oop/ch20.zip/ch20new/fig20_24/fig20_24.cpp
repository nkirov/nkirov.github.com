// Fig. 20.24: fig20_24.cpp
// Testing Standard Library adapter class template queue
#include <iostream>
#include <queue>

using namespace std;

int main()
{
   queue< double > values;
   
   values.push( 3.2 );
   values.push( 9.8 );
   values.push( 5.4 );

   cout << "Popping from values: ";
   
   while ( !values.empty() ) {
      cout << values.front() << ' ';  // does not remove
      values.pop();                   // removes element
   }

   cout << endl;
   return 0;
}