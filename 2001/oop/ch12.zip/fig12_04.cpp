// Fig. 12.4: fig12_04.cpp
// Test driver for Stack template.
// Function main uses a function template to manipulate
// objects of type Stack< T >.
#include <iostream.h>
#include "tstack1.h"

// Function template to manipulate Stack< T >
template< class T >
void testStack( 
   Stack< T > &theStack,   // reference to the Stack< T >
   T value,                // initial value to be pushed
   T increment,            // increment for subsequent values
   const char *stackName ) // name of the Stack < T > object
{
   cout << "\nPushing elements onto " << stackName << '\n';

   while ( theStack.push( value ) ) { // success true returned
      cout << value << ' ';
      value += increment;
   }

   cout << "\nStack is full. Cannot push " << value 
        << "\n\nPopping elements from " << stackName << '\n';

   while ( theStack.pop( value ) )  // success true returned
      cout << value << ' ';

   cout << "\nStack is empty. Cannot pop\n";
}

int main()
{
   Stack< double > doubleStack( 5 );   
   Stack< int > intStack;

   testStack( doubleStack, 1.1, 1.1, "doubleStack" );
   testStack( intStack, 1, 1, "intStack" );

   return 0;
}

