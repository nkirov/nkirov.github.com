// Fig. 14.12: fig14_12.cpp
// Writing to a random access file
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include "clntdata.h"

int main()
{
   ofstream outCredit( "credit.dat", ios::ate );

   if ( !outCredit ) {
      cerr << "File could not be opened." << endl;
      exit( 1 );
   }

   cout << "Enter account number "
        << "(1 to 100, 0 to end input)\n? ";

   clientData client;
   cin >> client.accountNumber;

   while ( client.accountNumber > 0 && 
           client.accountNumber <= 100 ) {
      cout << "Enter lastname, firstname, balance\n? ";
      cin >> client.lastName >> client.firstName 
          >> client.balance;

      outCredit.seekp( ( client.accountNumber - 1 ) * 
                       sizeof( clientData ) );
      outCredit.write( 
         reinterpret_cast<const char *>( &client ), 
         sizeof( clientData ) );

      cout << "Enter account number\n? ";
      cin >> client.accountNumber;
   }

   return 0;
}

