// Fig. 14.11: fig14_11.cpp
// Creating a randomly accessed file sequentially
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include "clntdata.h"

int main()
{
   ofstream outCredit( "credit.dat", ios::out );

   if ( !outCredit ) {
      cerr << "File could not be opened." << endl;
      exit( 1 );
   }

   clientData blankClient = { 0, "", "", 0.0 };

   for ( int i = 0; i < 100; i++ )
      outCredit.write( 
         reinterpret_cast<const char *>( &blankClient ), 
         sizeof( clientData ) );
   return 0;
}

