// Fig. 14.11: clntdata.h
// Definition of struct clientData used in 
// Figs. 14.11, 14.12, 14.14 and 14.15.
#ifndef CLNTDATA_H
#define CLNTDATA_H

struct clientData {
   int accountNumber;
   char lastName[ 15 ];
   char firstName[ 10 ];
   float balance;
};

#endif