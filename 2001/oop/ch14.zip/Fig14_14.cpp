// Fig. 14.14: fig14_14.cpp
// Reading a random access file sequentially
#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#include <stdlib.h>
#include "clntdata.h"

void outputLine( ostream&, const clientData & );

int main()
{
   ifstream inCredit( "credit.dat", ios::in );

   if ( !inCredit ) {
      cerr << "File could not be opened." << endl;
      exit( 1 );
   }

   cout << setiosflags( ios::left ) << setw( 10 ) << "Account"
        << setw( 16 ) << "Last Name" << setw( 11 )
        << "First Name" << resetiosflags( ios::left )
        << setw( 10 ) << "Balance" << endl;

   clientData client;

   inCredit.read( reinterpret_cast<char *>( &client ), 
                  sizeof( clientData ) );

   while ( inCredit && !inCredit.eof() ) {

      if ( client.accountNumber != 0 )
         outputLine( cout, client );

      inCredit.read( reinterpret_cast<char *>( &client ),
                     sizeof( clientData ) );
   }

   return 0;
}

void outputLine( ostream &output, const clientData &c )
{
   output << setiosflags( ios::left ) << setw( 10 ) 
          << c.accountNumber << setw( 16 ) << c.lastName 
          << setw( 11 ) << c.firstName << setw( 10 ) 
          << setprecision( 2 ) << resetiosflags( ios::left )
          << setiosflags( ios::fixed | ios::showpoint ) 
          << c.balance << '\n';
}

