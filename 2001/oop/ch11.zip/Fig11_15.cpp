// Fig. 11.15: fig11_15.cpp 
// Unformatted I/O with read, gcount and write.
#include <iostream.h>

int main()
{
   const int SIZE = 80;
   char buffer[ SIZE ];

   cout << "Enter a sentence:\n";
   cin.read( buffer, 20 );
   cout << "\nThe sentence entered was:\n";
   cout.write( buffer, cin.gcount() );
   cout << endl;
   return 0;
}


