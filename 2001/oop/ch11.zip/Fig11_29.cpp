// Fig. 11.29: fig11_29.cpp 
// Testing error states.
#include <iostream.h>

int main()
{
   int x;
   cout << "Before a bad input operation:"
        << "\ncin.rdstate(): " << cin.rdstate()
        << "\n    cin.eof(): " << cin.eof() 
        << "\n   cin.fail(): " << cin.fail()
        << "\n    cin.bad(): " << cin.bad() 
        << "\n   cin.good(): " << cin.good()
        << "\n\nExpects an integer, but enter a character: ";
   cin >> x;

   cout << "\nEnter a bad input operation:" 
        << "\ncin.rdstate(): " << cin.rdstate() 
        << "\n    cin.eof(): " << cin.eof()
        << "\n   cin.fail(): " << cin.fail()
        << "\n    cin.bad(): " << cin.bad() 
        << "\n   cin.good(): " << cin.good() << "\n\n";

   cin.clear();
  
   cout << "After cin.clear()" 
        << "\ncin.fail(): " << cin.fail() 
        << "\ncin.good(): " << cin.good() << endl;
   return 0;
}


