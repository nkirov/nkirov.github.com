// Fig. 11.7: fig11_07.cpp
// Cascading the overloaded << operator.
#include <iostream.h>

int main()
{
   cout << "47 plus 53 is " << ( 47 + 53 ) << endl;

   return 0;
}


