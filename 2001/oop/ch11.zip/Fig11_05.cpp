// Fig. 11.5: fig11_05.cpp
// Using the endl stream manipulator.
#include <iostream.h>

int main()
{
   cout << "Welcome to ";
   cout << "C++!";
   cout << endl;   // end line stream manipulator

   return 0;
}


