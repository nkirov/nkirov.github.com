// Fig. 11.6: fig11_06.cpp
// Outputting expression values.
#include <iostream.h>

int main()
{
   cout << "47 plus 53 is ";

   // parentheses not needed; used for clarity
   cout << ( 47 + 53 );      // expression
   cout << endl;

   return 0;
}


