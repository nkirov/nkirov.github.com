// Fig. 11.4: fig11_04.cpp
// Outputting a string using two stream insertions.
#include <iostream.h>

int main()
{
   cout << "Welcome to ";
   cout << "C++!\n";

   return 0;
}


