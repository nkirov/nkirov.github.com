// Fig. 11.8: fig11_08.cpp
// Printing the address stored in a char* variable
#include <iostream.h>

int main()
{
   char *string = "test";

   cout << "Value of string is: " << string
        << "\nValue of static_cast< void *>( string ) is: " 
        << static_cast< void *>( string ) << endl;
   return 0;
}


