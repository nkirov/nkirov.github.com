// Fig. 11.9: fig11_09.cpp
// Calculating the sum of two integers input from the keyboard 
// with the cin oct and the stream-extraction operator.
#include <iostream.h>

int main()
{
   int x, y;

   cout << "Enter two integers: ";
   cin >> x >> y;
   cout << "Sum of " << x << " and " << y << " is: " 
        << ( x + y ) << endl;

   return 0;
}


