// fIG. 11.21: fig11_21.cpp 
// Controlling the printing of trailing zeros and decimal 
// points for floating-point values.
#include <iostream.h>
#include <iomanip.h>
#include <math.h>

int main()
{      
   cout << "Before setting the ios::showpoint flag\n"
        << "9.9900 prints as: " << 9.9900 
        << "\n9.9000 prints as: " << 9.9000
        << "\n9.0000 prints as: " << 9.0000
        << "\n\nAfter setting the ios::showpoint flag\n";
   cout.setf( ios::showpoint );
   cout << "9.9900 prints as: " << 9.9900 
        << "\n9.9000 prints as: " << 9.9000
        << "\n9.0000 prints as: " << 9.0000 << endl;
   return 0;
}


