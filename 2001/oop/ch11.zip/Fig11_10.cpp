// Fig. 11.10: fig11_10.cpp 
// Avoiding a precedence problem between the stream-insertion 
// operator and the conditional operator.
// Need parentheses around the conditional expression.
#include <iostream.h>

int main()
{
   int x, y;

   cout << "Enter two integers: ";
   cin >> x >> y;
   cout << x << ( x == y ? " is" : " is not" ) 
        << " equal to " << y << endl;

   return 0;
}


