// Fig. 11.3: fig11_03.cpp
// Outputting a string using stream insertion.
#include <iostream.h>

int main()
{
   cout << "Welcome to C++!\n";

   return 0;
}


