// Fig. 6.7: fig06_07.cpp
// Demonstrating a utility function
// Compile with salesp.cpp
#include <iostream.h>
#include "salesp.h"

int main()
{
   SalesPerson s;         // create SalesPerson object s
   
   s.getSalesFromUser();  // note simple sequential code
   s.printAnnualSales();  // no control structures in main
   return 0;
}


