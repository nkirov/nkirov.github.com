for (i = 0; i < m; i++)
  for (j = 0; j < n; j++) C[i][j] = A[i][j] + B[i][j];
