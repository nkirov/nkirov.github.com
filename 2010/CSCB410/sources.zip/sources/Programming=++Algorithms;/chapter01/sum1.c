unsigned sum(unsigned n)
{ unsigned i, s = 0;
  for (i = 1; i <= n; i++) s += i;
  return s;
}
