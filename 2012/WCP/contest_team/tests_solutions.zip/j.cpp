//http://tjsct.wikidot.com/usaco-nov08-silver
//http://ace.delos.com/TESTDATA/NOV08.mtime.htm

#include <stdio.h>
#include <algorithm>
#include <ctime>
using namespace std;

#define MAXN 1005

struct job{
	int t, s;
	bool operator < (const job &j) const { return s > j.s; }
}jobs[MAXN];

int i, j, n, lastTime;

int main()
{
	clock_t beg = clock();
	
	while(true)
	{
		scanf("%d", &n);
		if(n == -1)
			break;

		for(i = 0;i < n;i++)
			scanf("%d%d", &jobs[i].t, &jobs[i].s);

		// sort jobs from largest to smallest with respect to their deadlines
		sort(jobs, jobs + n);	

		lastTime = 1000000;		  

		for (j = 0;j < n;j++)
			lastTime = min(jobs[j].s, lastTime) - jobs[j].t;

		printf("%d\n", lastTime < 0 ? -1 : lastTime);
	}

	printf("*** time: %.3lf ***\n",1.0*(clock() - beg)/CLOCKS_PER_SEC);

	return 0;
}
