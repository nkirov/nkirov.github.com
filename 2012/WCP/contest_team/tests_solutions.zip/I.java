import java.math.BigInteger;
import java.util.Scanner;

public class I 
{
	final static int MAXN = 10000;
	static int N, T, Q, I, K, S, R, L;
	static BigInteger P;
	static BigInteger []tree = new BigInteger[MAXN + 10];
	static BigInteger []allFibTree = new BigInteger[MAXN + 10];
	static String nextLine, q;
	static String [] values;
	static Scanner s;
	
	private static void precompute()
	{
		for(int i = 0;i <= MAXN;i++)
			allFibTree[i] = tree[i] = BigInteger.ZERO;
		
		BigInteger f0 = BigInteger.ZERO;
		BigInteger f1 = BigInteger.ONE;
		BigInteger f;

		updateInitialFibTree(1, f1);

		for(int i = 2;i <= MAXN; i++)
		{
			f = f1.add(f0);
			f0 = f1;
			f1 = f;
			updateInitialFibTree(i, f);
		}
	}
	
	private static void updateInitialFibTree(int index, BigInteger value)
	{
	    if (index == 0)
		 return;

	    while (index <= MAXN)
	    {
	    	allFibTree[index] =  allFibTree[index].add(value);
	        index += (index & -index);
	    }
	}
	
	private static void update(int index, BigInteger value)
	{
	    if (index == 0)
		 return;

	    while (index <= N)
	    {
	        tree[index] =  tree[index].add(value);
	        index += (index & -index);
	    }
	}
	
	private static BigInteger query(int index) 
	{
		BigInteger res = BigInteger.ZERO;
	    
	    while (index > 0)
	    {
	    	res = res.add(tree[index]);
	    	index -= (index & -index);
	    }
	    
	    return res;
	}

	private static BigInteger query(int start, int end)
	{
	    return query(end).subtract(query(start - 1));
	}
	
	private static void parseNexLine()
	{
		nextLine = s.nextLine().trim();
		values = nextLine.split(" ");
	}
	
	public static void main(String[] args) 
	{
		long startTime = System.currentTimeMillis();
		
		s = new Scanner(System.in);

		precompute();

		parseNexLine();
		T = Integer.parseInt(values[0]);
		
		while(T-- > 0)
		{
			parseNexLine();
			
			N = Integer.parseInt(values[0]);
			Q = Integer.parseInt(values[1]);
			
			for(int i = 0;i <= N;i++)
				tree[i] = allFibTree[i];
			
			for(int i = 0;i < Q;i++)
			{
				parseNexLine();
				
				q = values[0];
				
				if(q.equalsIgnoreCase("add"))
				{
					I = Integer.parseInt(values[1]);
					K = Integer.parseInt(values[2]);
					BigInteger P = new BigInteger(values[3], K);
					update(I, P);
				}
				else if(q.equalsIgnoreCase("get"))
				{
					L = Integer.parseInt(values[1]);
					R = Integer.parseInt(values[2]);
					S = Integer.parseInt(values[3]);
					K = Integer.parseInt(values[4]);
				
					String ans = query(L, R).toString(K);
					int len = ans.length();
					if(S >= len)
						System.out.println(ans);
					else
					{
						for(int j = len - S;j < len;j++)
							System.out.print(ans.charAt(j));
						System.out.println();
					}
				}
			}
		}
		
		long endTime = System.currentTimeMillis();
		System.out.println(String.format("time: %d\n", endTime - startTime));
	}
}
