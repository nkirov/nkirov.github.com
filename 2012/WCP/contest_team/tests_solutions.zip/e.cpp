#include<cstdio>
using namespace std;

void run (){
    int r=0, n;
    scanf("%d",&n);
    for (int i=1;i<=2*n;i++)
    {
        r*=10;
        if (i<n)r+=9;
        else if (i==n)r+=8;
        else if (i==2*n)r+=1;
        if (i>1)printf("%c",48+r/81);
        r%=81;     
    }
    printf("\n");
}

int main()
{
 int nt;
 scanf("%d",&nt);
 for(int i=1;i<=nt; i++) run();    
}
