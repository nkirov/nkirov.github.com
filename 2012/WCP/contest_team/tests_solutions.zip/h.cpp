#include <algorithm>
#include <cstdio>
#include <ctime>
using namespace std;

#define MAXN 20005

int N, S, total;
int height [MAXN];

// finds the index of the first position whose height is <= value
inline int binsearch (int value)
{
    int lo = 0, hi = N - 1, mid;

    while (lo < hi)
    {
		mid = (lo + hi + 1) >> 1;

		if (height [mid] <= value)
			lo = mid;
		else
			hi = mid - 1;
    }

    return lo;
}

int main ()
{
	clock_t beg = clock();

	while(true)
	{
		scanf("%d %d", &N, &S);
		if(N == 0 && S == 0)
			break;

		for (int i = 0; i < N; i++)
			scanf("%d", height + i);

		sort (height, height + N);
		total = 0;

		for (int i = 0; i < N; i++)
		{
			// query the largest index satisfying the conditions
			int ind = binsearch (S - height [i]);

			// only count if ind > i
			if (ind > i)
				total += ind - i;
			else 
				break;
		}

		printf("%d\n", total);
	}

	printf("*** time: %.3lf ***\n",1.0*(clock() - beg)/CLOCKS_PER_SEC);

    return 0;
}

