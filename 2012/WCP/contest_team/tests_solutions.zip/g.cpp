#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>
#include <ctime>
using namespace std;

int cmp(string a, string b) 
{
	if(a.length() != b.length()) 
		return a.length() < b.length();
	return a < b;
}

int n, tc;
char c;
char *str;

int main() 
{
	clock_t beg = clock();

	scanf("%d" , &tc);
	
	while(tc--)
	{
		vector <string> nums;
		str = new char[105];

		scanf("%d" , &n);
		for(int i = 0;i < n;i++)
		{
			scanf("%s",str);
			int len = strlen(str);
			str[len] = 'a';
			string num;
			for(int j = 0;j <= len;j++)
				if(str[j] >= '0' && str[j] <= '9') 
					num += str[j];
				else if(num != "") 
				{
					// remove all leading zeroes
					string toadd;
					int k;
					for(k = 0;k + 1 < num.length();k++)
						if(num[k] != '0') 
							break;
					for(;k < num.length();k++) 
						toadd += num[k];
					nums.push_back(toadd);
					num = "";
			}
		}
	
		if(nums.size() == 0)
			continue;

		sort(nums.begin() , nums.end() , cmp);
		for (int i = 0; i < nums.size(); i++)
			printf("%s\n" , nums[i].c_str());

		if(tc != 0)
			printf("~\n");
	}

	printf("*** time: %.3lf ***\n",1.0*(clock() - beg)/CLOCKS_PER_SEC);

	return 0;
}
