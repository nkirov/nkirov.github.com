#include <stdio.h>
#include <string>
#include <iostream>
#include <set>
#include <algorithm>
using namespace std;

char str[5000];
string s;

int main()
{
	while (!feof(stdin))
	{
		gets(str);
		char *p = strtok(str, " ");
		if(p == NULL)
			continue;
		
		set<string> A;

		while(p != NULL)
		{
			s = string(p);
			sort(s.begin(), s.end());
			A.insert(s);
			p = strtok(NULL, " ");
		}

		printf("%d\n", A.size());
	}

	return 0;
}