#include<iostream>
using namespace std;

int n;
long long int b[1024];


void run()
{
      
 memset(b,1024,0);
 cin >> n;
 b[1]=2;
 b[2]=4;
 b[3]=7;
 
 for(int i=4;i<=n;i++) b[i]=b[i-3]+b[i-2]+b[i-1];
 
 cout << b[n] << endl;
    
}

int main()
{
 int t; cin >> t;
 for(int i=1;i<=t;i++) run();
}



