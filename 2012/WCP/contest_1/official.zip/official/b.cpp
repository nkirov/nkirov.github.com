#include <stdio.h>
#include <set>
#include <algorithm>
#include <cmath>
#include <ctime>
using namespace std;

#define px second
#define py first

#define MAXN 25000
#define MAXDIST 1500000000

typedef long long ll;
typedef pair<ll, ll> pairll;
ll x, y;

int n;
pairll pnts [MAXN + 100];

double best;
int compx(pairll a, pairll b) { return a.px < b.px; }

inline double dist(pairll &a, pairll &b)
{
	return (a.px - b.px) * (a.px - b.px) + (a.py - b.py) * (a.py - b.py);
}

double slow()
{
	double mdist = MAXDIST;
	int i, j;
	for (i = 0; i < n - 1; i++)
	{
			for (j = i + 1; j < n; j++) 
			{
					int t = dist(pnts[i], pnts[j]);
					if (t < mdist) 
						mdist = t;
			}
	}

	return sqrt(mdist);
}

void gentest(int k)
{
	srand ( time(NULL) );
	FILE *f = fopen("CL.in", "w");
	int x, y;
	int m = 5;
	for(int i = 1;i <= k;i++)
	{
		m += 10;

		x = rand() % m;
		y = rand() % m;
		if(i % 3)
		{
			if(x != 1)
				x *= -1;
			y *= -1;
		}

		if(i % 7)
			y *= -1;

		
		if(i % 8 && x != 1)
			x *= -1;

		fprintf(f, "%d %d\n", x, y);
	}
	
	fprintf(f, "%d\n", -1);

	fclose(f);
}

int main () 
{
	clock_t begin = clock();
	while(!feof(stdin))
	{
		set<pairll> box;
		best = MAXDIST;
		n = 0;

		while(true)
		{
			scanf("%lld", &x);
			if(x == -1)
				break;

			scanf("%lld", &y);
			pnts[n].px = x, pnts[n].py = y;
			n++;
		}

		if(feof(stdin) && n == 0)
		{
			printf("time: %d\n", clock() - begin);
			return 0;
		}

		//printf("slow %.5f\n", slow());

		sort(pnts, pnts + n, compx); 
		
		box.insert(pnts[0]);
		int left = 0;
		for (int i = 1;i < n;++i)
		{
			while (left < i && pnts[i].px - pnts[left].px > best)  
				box.erase(pnts[left++]);

			set<pairll>::iterator it = box.lower_bound(make_pair(pnts[i].py - best, pnts[i].px - best));
			for (; it != box.end() && pnts[i].py + best >= it->py; it++)
				 best = min(best, dist(pnts[i], *it));
			box.insert(pnts[i]);
		}

		printf("%.5f\n", sqrt(best));
	}
    return 0;
}
