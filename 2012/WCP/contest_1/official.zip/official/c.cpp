#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <queue>
using namespace std;

#define MAX 100005
#define MP(x, y) make_pair((x), (y))
#define MAXINT 2147483647

int E, V, S, F1, F2, dist[MAX], parent[MAX];
bool vis[MAX];
vector < pair <int,int > > edges[MAX];

void init()
{
	for(int i = 0;i < E;i++)
	{
		dist[i] = MAXINT;
		vis[i] = false;
		parent[i] = 0;
	}
}

void dijkstra(int s)
{
	int i, u, v, w;

	dist[s] = 0;
	parent[s] = -1;

	priority_queue<pair<int,int> > pq;
	pq.push(MP(-dist[s], s));

	while (!pq.empty())
	{
		u = pq.top().second;
		pq.pop();
		if (vis[u])
			continue;

		vis[u] = true;
		for(i = 0; i < edges[u].size(); i++)
		{
			v = edges[u][i].first;
			w = edges[u][i].second;

			if (dist[u] + w < dist[v])
			{
				dist[v] = dist[u] + w;
				parent[v] = u;
				pq.push(MP(-dist[v], v));
			}
		}
	}
}

bool containF = false;

void printPath(int s, int j, int k)
{
	if (parent[j] != s) 
			printPath(s, parent[j], k);
		if(j == k)
		{
			
			containF = true;
			return;
		}
}

int solve()
{
	int minToF1 = 0, minToF2 = 0;
	init(); dijkstra(F2);
	if(dist[S] != MAXINT)
		minToF1 += dist[S];
	containF = false;
	printPath(F2, S, F1);

	if(!containF)
	{	
		if(dist[F1] != MAXINT)
			minToF1 += dist[F1];
		else
			minToF1 = MAXINT;
	}

	init(); dijkstra(F1);
	if(dist[S] != MAXINT)
		minToF2 += dist[S];
	containF = false;
	printPath(F1, S, F2);

	if(!containF)
	{	
		if(dist[F2] != MAXINT)
			minToF2 += dist[F2];
		else
			minToF2 = MAXINT;
	}
	
	return minToF1 > minToF2 ? minToF2 : minToF1;
}

char *buff;

int main()
{
	int t, u, v, c, outBase, inpBase;
	scanf("%d\n", &t);
	while(t--)
	{
		scanf("%d%d%d%d%d%d\n", &V, &E, &S, &F1, &F2, &outBase);
		S--, F1--, F2--;

		for(int i = 0;i < V;i++)
		{
			buff = new char[50];
			scanf("%d %d %d %s\n", &u, &v, &inpBase, buff); 
			c = strtol (buff, &buff, inpBase);

			u--; v--;

			edges[u].push_back(MP(v, c));
			edges[v].push_back(MP(u, c)); 
		}

		printf("%s\n", itoa(solve(), buff, outBase));
		if(t != 0)
		{
			for(int i = 0;i < E;i++)
				edges[i].clear();
		}
	}
	return 0;
}



