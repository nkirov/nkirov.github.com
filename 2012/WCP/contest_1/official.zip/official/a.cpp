#include <stdio.h>
#include <vector>
#include <ctime>
#include <algorithm>
#include <string>
using namespace std;

#define MAXN 100000000

int t, a, b;
int lp[MAXN + 100];
vector<int> pr;
vector<int>::iterator low, up;
char q;
char c[100];

//2.5 slower
//char sieve[N];
//void eratosten()
//{ 
//	clock_t beg = clock();
//
//	int j, i = 2;
//	while (i <= N) 
//	{
//		if (sieve[i] == 0) 
//		{
//			j = i;
//			while (j <= N)
//			{
//				sieve[j] = 1;
//				j += i;
//			}
//		}
//		i++;
//	}
//
//	printf("*** Precompute time O(n log log n): %.3lf ***\n",1.0*(clock()-beg)/CLOCKS_PER_SEC);
//}

//Prime Sieve of Eratosthenes O(n) - http://e-maxx.ru/algo/prime_sieve_linear
void precompute()
{
	clock_t beg = clock();

	for (int i = 2; i < MAXN; i++)
	{
		if (lp[i] == 0) 
		{
			lp[i] = i;
			pr.push_back (i);
		}
		for (int j = 0; j < (int)pr.size() && pr[j] <= lp[i] && i * pr[j] < MAXN; j++)
			lp[i * pr[j]] = pr[j];
	}

	//printf("*** Precompute time O(n): %.3lf ***\n",1.0*(clock()-beg)/CLOCKS_PER_SEC);
}

inline bool isPrime(int &a)
{
	return binary_search(pr.begin(), pr.end(), a) ? 1 : 0;
}

int main()
{
	precompute();
	//eratosten();
	clock_t beg = clock();

	while(true)
	{
		scanf("%c", &q);
		q = towlower(q);
		switch(q)
		{
			case 'a' :
				scanf("%d%d\n", &a, &b);
				low = lower_bound (pr.begin(), pr.end(), a);
				up = upper_bound (pr.begin(), pr.end(), b); 
				printf("%d\n", (int)(up - low));
				break;
			case 'b' :
				scanf("%d\n", &a);
				printf("%d\n", lp[a]);
				break;
			case 'c' :
				scanf("%d %d\n", &a);
				printf("%d\n", isPrime(a));
				break;
			case 'd' :
				scanf("%s\n", &c);
				reverse(c, c + strlen(c));
				a = atoi(c);
				printf("%d\n", isPrime(a));
				break;
			case 'e' :
				scanf("%d\n", &a);
				if(isPrime(a))
					printf("%d\n", a);
				else
				{
					low = lower_bound (pr.begin(), pr.end(), a);
					up = upper_bound (pr.begin(), pr.end(), a); 
					--low;
					int distToLow = a - *low;
					if(up == pr.end())
						--up;

					int distToUp = *up - a;
					if(distToLow == distToUp)
						printf("%d %d\n", *low, *up);
					else 
						printf("%d\n", distToLow < distToUp ? *low : *up);
				}
				break;
			case 'f' :
				scanf("%d\n", &a);
				low = lower_bound (pr.begin(), pr.end(), a);
				printf("%d\n", low - pr.begin());
				break;
			case 'q' :
				//printf("*** rest: %.3lf ***\n",1.0*(clock()-beg)/CLOCKS_PER_SEC);
				return 0;
		}
	}

	return 0;
}