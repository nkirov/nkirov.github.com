#include <iostream>
#include <set>
#include <string>
#include <cstdlib>
using namespace std;

const int MAX = 9999; // number of strings
const int L = 99;  // length of strings
const int C = 999;  // number of sorting
const int OUT = 4; // max number of outputs;

string a[MAX];
string s;

int main()
{
    cout << MAX << endl;
    for (int i=0; i < MAX; ++i) 
    {
        string s;
        int jj = 0;
        for (; jj < L - 10; ++jj) s.push_back('z');
        
        for (int j = jj; j < L; ++j)
        {
            char ch = static_cast<char>('a' + rand()%26);
            s.push_back(ch);
        }
        cout << s << endl;
    }
    cout << C << endl;
    for (int i=0; i < C; ++i) 
    {
        int num = rand()%OUT + 1;
        cout << rand()%L << " " << num << endl;
        for (int j=0; j<num; j++) cout << rand()%MAX + 1 << " ";
        cout << endl;
    }
    return 0;
}
