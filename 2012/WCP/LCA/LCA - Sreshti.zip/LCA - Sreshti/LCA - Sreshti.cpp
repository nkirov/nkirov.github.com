#include <cstdio>
#include <cmath>
#include <vector>
#include <queue>
#include <memory.h>
/* maximalen broi vyzli v dyrvoto */
#define MAXN 100000 
using namespace std;

//ako v testovete moje da se podava 1 rebro pove4e ot 1 pyt moje da se izpolzva set<int>
vector< vector<int> > tree;
bool visited[MAXN];
int parents[MAXN][MAXP];
int level[MAXN];

//obhojdane na graf(v slu4aq dyrvo) v shirina
void bfs(int start, int p)
{
	queue<int> q;
	q.push(start);
	visited[start] = true;
	for(int i = 0; i <= p; i++)
	{
		parents[start][i] = -1;
	}

	int current, child;
	while(!q.empty())
	{
		current = q.front(); q.pop();
		for(int i = 0; i < tree[current].size(); ++i)
		{
			child = tree[current][i];
			//tazi proverka garantira, 4e za vseki vryh obhojdame samo childovete mu, bez da pose6tavame parenta
			if(visited[child])
				continue;

			//iz4islqvame dylbo4inata na vyrha v dyrvoto
			level[child] = 1 + level[current];

			//presmqtame tablicata parents za syotvetniq vryh
			for(int i = 0; i <= p; i++)
			{
				if(level[current] % ( 1 << i ) == 0)
					parents[child][i] = current;
				else
					parents[child][i] = parents[current][i];
			}
			
			q.push(child);
			//markirame kato poseten
			visited[child] = true;
		}
	}
}

//namirame pred6estvenika na u, koito e na nivoto na v
int lift(int u, int v, int p)
{
	int ancestor, candidate;
	for(int i = p; i >= 0; i--)
	{
		candidate = parents[u][i];
		if(level[candidate] == level[v])
		{
			ancestor = candidate;
			break;
		}
		else if(level[candidate] > level[v])
		{
			u = candidate;
		}
	}
	return ancestor;
}

int lca(int u, int v, int p)
{
	//izravnqvame nivata na u i v kato na tozi s po-visoka dylbo4ina namirame pred6estvenika na dylbo4ina ravna na po-niskata
	if(level[u] > level[v])
		u = lift(u, v, p);
	else if(level[v] > level[u])
		v = lift(v, u, p);

	//ako stanat 1 i sy6t vryh zadachata e re6ena
	if(u == v)
		return u;

	//namirame pyrviq ne-obsht vryh
	for(int i = p; i >= 0; i--)
	{
		if(parents[u][i] != parents[v][i])
		{
			u = parents[u][i];
			v = parents[v][i];
		}
	}
	return parents[u][0];
}

int main()
{
	//chetem N dokato N e razli4no ot -1
	int N, M;
	while(scanf("%d", &N) == 1 && N != -1)
	{
		scanf("%d", &M);
		//iz4istvame strukturite predi vseki test
		memset(level, 0, sizeof(level));
		memset(parents, 0, sizeof(parents));
		memset(visited, 0, sizeof(visited));
		tree = vector< vector< int > >(N + 1);

		//postroqvame dyrvoto
		int v;
		for(int u = 1; u <= N; u++)
		{
			scanf("%d", &v);
			tree[u].push_back(v);
			tree[v].push_back(u);
		}

		//p = floor(Log2(n-1))
		int p = 0, p2 = 1;
		while(p2 * 2 < N) { p++; p2 *= 2; }

		//preiz4islqvame tablicata parents
		bfs(0, p);

		//otgovarqme na zaqvkite
		int x, y;
		for(int q = 0; q < M; q++)
		{
			scanf("%d%d", &x, &y);
			printf("%d\n", lca(x, y, p));
		}
	}
}
