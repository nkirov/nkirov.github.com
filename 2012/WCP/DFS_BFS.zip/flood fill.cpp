#include <stdio.h>
#include <vector>
#include <bitset>
using namespace std;

//In order to increase the size of a stack and to avoid its overflow 
//when using a "deep" recursion, you should use a special directive 
//(in the example, the size of the stack is set to be 16 MB):
#pragma comment(linker, "/STACK:16777216")

#define MAX 10005
int n, m, t, ans, numComponents;

vector < vector <int> > p;
vector < int > topol;
vector < int > dfsColor;

void floodFill(int from, int color)
{
	//маркираме текущия връх за посетен и му задаваме цвят
	dfsColor[from] = color;

	//за всеки негов непосетен съсед
	for(int i = 0;i < p[from].size();i++)
		if(!dfsColor[p[from][i]])
			floodFill(p[from][i], color);//стартираме обхождане в дълбочина 
}

void solve()
{
	numComponents = 0; //зануляваме
	for(int i = 0;i < n;i++)
		if(!dfsColor[i])//за всеки непосетен връх
			floodFill(i, ++numComponents);//стартираме обхождане в дълбочина 

	for(int i = 0;i < n;i++)
		printf("Vertex %d has color %d\n", i, dfsColor[i]);
}

void init()
{
	p.clear();
	p.resize(n);
	topol.clear();
	dfsColor.clear();
	dfsColor.resize(n);
	ans = -1;
}

void read()
{
	int u, v;
	scanf("%d %d\n", &n, &m);

	init(); //зануляваме нужните структури и променливи

	for(int i = 0;i < m;i++)
	{
		scanf("%d%d", &u, &v);
		u--, v--;
		//графа е двойно-свързан
		p[u].push_back(v);//ребро от u към v 
		p[v].push_back(u);//ребро от v към u
	}
}

int main()
{
	scanf("%d\n", &t);
	while(t--)
	{
		read(); //изчитаме входните данни
		solve();//решаваме задачата
		printf("%d\n", ans);//извеждаме резултата
	}

	return 0;
}