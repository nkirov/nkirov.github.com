﻿#include <stdio.h>
#include <vector>
#include <bitset>
using namespace std;

//In order to increase the size of a stack and to avoid its overflow 
//when using a "deep" recursion, you should use a special directive 
//(in the example, the size of the stack is set to be 16 MB):
#pragma comment(linker, "/STACK:16777216")

#define MAX 10005
int n, k;

vector < vector <int> > p;
vector < int > topol;
bitset < MAX > vis;

void dfs(int from)
{
	//маркираме текущия връх за посетен
	vis[from] = true;

	//за всеки негов непосетен съсед
	for(int i = 0;i < p[from].size();i++)
		if(!vis[p[from][i]])
			dfs(p[from][i]);//стартираме обхождане в дълбочина 

	//при изплуване от рекурсията запазваме стартовия връх
	topol.push_back(from);
}

void solve()
{
	for(int i = 0;i < n;i++)
		if(!vis[i])//за всеки непосетен връх
			dfs(i);//стартираме обхождане в дълбочина 
}

void init()
{
	p.clear(); p.resize(n);
	topol.clear();
	vis.reset();
}

void read()
{
	for(int i = 0;i < n;i++)
		while(scanf("%d", &k) && k)
			p[i].push_back(k - 1);
}

void print()
{
	//върховете са топологически сортирани, но са
	//в обратен ред, за това ги отпечатваме отзад-напред
	int sz = topol.size();
	printf("%d", topol[sz - 1] + 1);
	for(int i = sz - 2;i >= 0;i--)
		printf(" %d", topol[i] + 1);
	printf("\n");
}

int main()
{
	while(scanf("%d", &n) && n >= 1 && n <= 10000)
	{
		init(); //зануляваме нужните структури и променливи
		read(); //изчитаме на входните данни
		solve();//решаваме задачата
		print();//извеждаме резултата
	}

	return 0;
}