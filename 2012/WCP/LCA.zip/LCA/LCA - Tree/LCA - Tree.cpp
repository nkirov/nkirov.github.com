#include <cstdio>
#include <cmath>
#include <vector>
#include <queue>
#include <memory.h>
/* maximalen broi vyzli v dyrvoto */
#define MAXN 100000 
using namespace std;

//ako v testovete moje da se podava 1 rebro pove4e ot 1 pyt moje da se izpolzva set<int>
vector< vector<pair<int, long long> > > tree;
bool visited[MAXN];
int parents[MAXN][MAXP];
int level[MAXN];
long long dist[MAXN];

//namirane na floor(log(n))
int Log2(int val)
{
	int ret = 0;
	while (val >>= 1) 
		++ret;
	return ret;
}

//obhojdane na graf(v slu4aq dyrvo) v shirina
void bfs(int start, int p)
{
	queue<int> q;
	q.push(start);
	visited[start] = true;
	for(int i = 0; i <= p; i++)
	{
		parents[start][i] = -1;
	}

	int current, child, weight;
	while(!q.empty())
	{
		current = q.front(); q.pop();
		for(int i = 0; i < tree[current].size(); ++i)
		{
			child = tree[current][i].first;
			weight = tree[current][i].second;
			//tazi proverka garantira, 4e za vseki vryh obhojdame samo childovete mu, bez da pose6tavame parenta
			if(visited[child])
				continue;

			//iz4islqvame dylbo4inata na vyrha v dyrvoto
			level[child] = 1 + level[current];
			
			//iz4islqvame razstoqnieto na teku6tiq ot vyrha na dyrvoto
			dist[child] = dist[current] + weight;

			//presmqtame tablicata parents za syotvetniq vryh
			for(int i = 0; i <= p; i++)
			{
				if(level[current] % ( 1 << i ) == 0)
					parents[child][i] = current;
				else
					parents[child][i] = parents[current][i];
			}
			
			q.push(child);
			//markirame kato poseten
			visited[child] = true;
		}
	}
}

//namirame pred6estvenika na u, koito e na nivoto na v
int lift(int u, int v, int p)
{
	int ancestor, candidate;
	for(int i = p; i >= 0; i--)
	{
		candidate = parents[u][i];
		if(level[candidate] == level[v])
		{
			ancestor = candidate;
			break;
		}
		else if(level[candidate] > level[v])
		{
			u = candidate;
		}
	}
	return ancestor;
}

int lca(int u, int v, int p)
{
	//izravnqvame nivata na u i v kato na tozi s po-visoka dylbo4ina namirame pred6estvenika na dylbo4ina ravna na po-niskata
	if(level[u] > level[v])
		u = lift(u, v, p);
	else if(level[v] > level[u])
		v = lift(v, u, p);

	//ako stanat 1 i sy6t vryh zadachata e re6ena
	if(u == v)
		return u;

	//namirame pyrviq ne-obsht vryh
	for(int i = p; i >= 0; i--)
	{
		if(parents[u][i] != parents[v][i])
		{
			u = parents[u][i];
			v = parents[v][i];
		}
	}
	return parents[u][0];
}

int main()
{
	int N;
	scanf("%d", &N);
	//iz4istvame strukturite predi vseki test
	memset(level, 0, sizeof(level));
	memset(parents, 0, sizeof(parents));
	memset(visited, 0, sizeof(visited));
	memset(dist, 0, sizeof(dist));
	tree = vector< vector<pair<int, long long> > > (N);

	//postroqvame dyrvoto
	int u, v;
	long long w;
	for(int i = 0; i < N - 1; i++)
	{
		scanf("%d%d%lld", &u, &v, &w);
		tree[u].push_back(make_pair(v, w));
		tree[v].push_back(make_pair(u, w));
	}

	//p = floor(Log2(n-1))
	int p = 0, p2 = 1;
	while(p2 * 2 < N) { p++; p2 *= 2; }

	//preiz4islqvame tablicata parents
	bfs(0, p);

	//otgovarqme na zaqvkite
	int M;
	scanf("%d", &M);
	int x, y, ancestor, ans;
	for(int q = 0; q < M; q++)
	{
		scanf("%d%d", &x, &y);
		ancestor = lca(x, y, p);
		ans = dist[x] + dist[y] - 2 * dist[ancestor];
		printf("%d\n", ans);
	}
	return 0;
}
