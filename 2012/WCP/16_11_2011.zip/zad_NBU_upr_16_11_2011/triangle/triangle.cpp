#include<cstdio>

int n;
int x[200], y[200];
int mcount;

int ccw(int i0, int i1, int i2)
{
 int dx1=x[i1]-x[i0]; int dy1=y[i1]-y[i0];
 int dx2=x[i2]-x[i0]; int dy2=y[i2]-y[i0];
 int v=dx1*dy2-dy1*dx2;
 if(v>0)return 1;
 if(v<0)return -1;
 else return 0;
}

bool inside(int i, int i1, int i2, int i3)
{
  int e=ccw(i1,i2,i3);
  if(ccw(i1,i2,i)!=e) return false;
  if(ccw(i2,i3,i)!=e) return false;
  if(ccw(i3,i1,i)!=e) return false;
  return true;
}

void check(int i1, int i2, int i3)
{
  int c=0;
  for(int i=1;i<=n;i++)
  if(i!=i1)if(i!=i2)if(i!=i3)
  if(inside(i,i1,i2,i3)) c++;
  if(c>mcount)mcount=c;
}


int run()
{
  
  mcount=0;
  scanf("%d",&n);
  for(int i=1;i<=n;i++) scanf("%d%d",&x[i],&y[i]);
  
  for(int i1=1;i1<=n-2;i1++)
  for(int i2=i1+1;i2<=n-1;i2++)
  for(int i3=i2+1;i3<=n;i3++)
   check(i1,i2,i3);
   
  printf("%d\n",mcount);
}

int main()
{
 int t; scanf("%d",&t);
 for(int i=1;i<=t;i++) run();    
}
