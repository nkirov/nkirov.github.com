#include<iostream>
using namespace std;

int a[501];
int n;
bool b[501][50001];

int solve()
{
    
    
  cin >> n;
  for(int i=1;i<=n;i++) cin >> a[i];
  
  int maxS=100*n;
  memset(b,0,sizeof(b));
  //for(int j=1;j<=maxS;j++) b[1][j]=false;
  b[1][a[1]]=true;
  
  for(int i=2;i<=n;i++)
  for(int j=1;j<=maxS;j++)
  {
    bool t=false;
    if(b[i-1][j]) t=true;    
    else 
     {if(a[i]==j) t=true;
      else if(a[i]<j) t=b[i-1][j-a[i]];
     }
    b[i][j]=t;
  }

 int s=0;
 for(int j=1;j<=maxS;j++)
  if(b[n][j]) s++;
 
 cout << s << endl;  
}

int main()
{
  int t;
  cin >> t;
  for(int i=1;i<=t;i++) solve();
}

