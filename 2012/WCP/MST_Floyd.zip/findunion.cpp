#include <stdio.h>
#define N 1000
int id[N], p, q;

void algo1()
{
	for(int i = 0;i < N;i++)
		id[i] = i;

	while(scanf("%d%d", &p, &q) == 2)
	{
		if(id[p] == id[q])
			continue;

		for(int j = id[p], i = 0;i < N;i++)
			if(id[i] = j)
				id[i] = id[q];

		printf("%d %d are now connected\n", p, q);
	}
}

void algo2()
{
	int i, j;
	for(i = 0;i < N;i++)
		id[i] = i;

	while(scanf("%d%d", &p, &q) == 2)
	{
		for(i = p;i != id[i];i = id[i]);
		for(j = q;j != id[j];j = id[j]);
		if(i == j)
			continue;

		id[i] = j;
		printf("%d %d are now connected\n", p, q);
	}
}

void algo3()
{
	int i, j, sz[N];
	for(i = 0;i < N;i++)
		id[i] = i, sz[i] = 1;

	while(scanf("%d%d", &p, &q) == 2)
	{
		for(i = p;i != id[i];i = id[i]);
		for(j = q;j != id[j];j = id[j]);
		if(i == j)
			continue;
		if(sz[i] < sz[j])
			id[i] = j, sz[j] + sz[i];
		else
			id[j] = i, sz[i] + sz[j];

		printf("%d %d are now connected\n", p, q);
	}
}

void algo4()
{
	int i, j, sz[N];
	for(i = 0;i < N;i++)
		id[i] = i, sz[i] = 1;

	while(scanf("%d%d", &p, &q) == 2)
	{
		for(i = p;i != id[i];i = id[i])
			id[i] = id[id[i]];
		for(j = q;j != id[j];j = id[j])
			id[j] = id[id[j]];

		if(i == j)
			continue;
		if(sz[i] < sz[j])
			id[i] = j, sz[j] + sz[i];
		else
			id[j] = i, sz[i] + sz[j];

		printf("%d %d are now connected\n", p, q);
	}
}
int main()
{
	//algo1();
	//algo2();
	//algo3();
	//algo4();
	return 0;
}