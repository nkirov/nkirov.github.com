#include <stdio.h>
#include <vector>
#include <algorithm>
#include <memory.h>
using namespace std;

#define NO_PARENT -1
#define MAXV 10005
#define MAXE 100100

int V, E, t, mst;
vector <pair <int, int> > T;
int prev[MAXV];

struct Eg{
	int u, v, cost;
	bool operator <(const Eg &e) const { return cost < e.cost;	}
}edg[MAXE];

void init()
{
	mst = 0;
	T.clear();
	memset(prev, -1, sizeof prev);
}

void read()
{
	scanf("%d%d", &V, &E);
	for(int i = 0;i < E;i++)
		scanf("%d%d%d", &edg[i].u, &edg[i].v, &edg[i].cost);
}

int getRoot(int i)
{
	int r;
	for(r = i;r != prev[r];r = prev[r])
		prev[r] = prev[prev[r]];
	return r;
}

void solve()
{
	sort(edg, edg + E);

	for(int i = 0;i < V;i++)
		prev[i] = i;

	int r1, r2, e, cnt = 0;
	for(e = 0;e < E;e++)
	{
		r1 = getRoot(edg[e].u);
		r2 = getRoot(edg[e].v);
		if(r1 == r2)
			continue;

		prev[r2] = r1;

		mst += edg[e].cost;
		T.push_back(make_pair(p, q));

		if(cnt++ == V - 1)
			break;
	}

	if(cnt != V - 1)
		printf("-1\n");
	else
	{
		printf("%d\n", mst);
		for(int i = 0;i < T.size();i++)
			printf("%d %d\n", T[i].first + 1, T[i].second + 1);
	}
}

int main()
{
	scanf("%d", &t);
	while(t--)
	{
		init();
		read();
		solve();
	}
}