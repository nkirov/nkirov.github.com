#include <stdio.h>
#include <math.h>

#define MAXN 10010

struct Point{
	int x, y;
}ps[MAXN];


int n, tc;
int gcd(int a, int b)
{
	int t;
	while (b){
		t = b;
		b = a % b;
		a = t;
	}
	return a;
}

int border()
{
	int i, b;
	for (i = b = 0; i < n; i++)
		b += gcd(abs(ps[i].x - ps[i+1].x), abs(ps[i].y - ps[i+1].y));
	return b;
}

int area2()
{
	int i, a;
	for (i = a = 0; i < n; i++)
		a += (ps[i].x - ps[i+1].x) * (ps[i].y + ps[i+1].y);
	return abs(a);
}

void solve()
{
	int i, a2, b;
	ps[n] = ps[0];

	a2 = area2();
	b = border();
	i = (a2 - b + 2) / 2;

	printf("%d\n", b + i);
}


int main()
{
	while(true)
	{
		scanf("%d", &n);
		if(n == 0)
			break;
		for (int i = 0; i < n; i++)
			scanf("%d%d", &ps[i].x, &ps[i].y);
		solve();
	}
	return 0;
}
