#include <stdio.h>
#include <memory.h>

#define MAX 256
#define INF 100000000

typedef long long ull;

int n, m, u, v, c, t, v1, v2, v3, v4;
ull A[MAX][MAX], V[MAX];

inline void min (ull &a, ull b)
{ 
	if (b < a) 
		a = b; 
}

void floyd()
{
	int i, j, k;
	for (k = 0; k < n; k++)
		for (i = 0; i < n; i++)
			if (A[i][k] < INF)
				for (j = 0; j < n; j++)
					min(A[i][j], A[i][k] + A[k][j] + V[k]);
}

void init()
{
	for (int i = 0; i <= n; i++)
		for (int j = 0; j <= n; j++)
			A[i][j] = INF;

	memset (V, 0, sizeof V);
}

void read()
{
	scanf("%d%d\n", &n, &m);

	init();
	
	for(int i = 0;i < n;i++)
		scanf("%u", &V[i]);

	for(int i = 0;i < m;i++)
	{
		scanf("%d%d%d", &u, &v, &c);
		u--, v--;
		if(A[u][v] > c)
			A[u][v] = A[v][u] = c;
	}
}

void solve()
{
	floyd();

	int i, j, k, l;
	ull dmin = INF, cur, d;

	for(i = 0;i < n;i++)
	{
		for(j = i + 1;j < n;j++)
		{
			if(A[i][j] >= dmin)
				continue;

			for(k = j + 1;k < n;k++)
			{
				d = A[i][j] + A[j][k] + A[i][k];
				if(d >= dmin)
					continue;

				for(l = k + 1;l < n;l++)
				{
					cur = d + A[i][l] + A[j][l] + A[k][l];
					if(cur < dmin)
					{
						dmin = cur;
						v1 = i;
						v2 = j;
						v3 = k;
						v4 = l;
					}
				}
			}
		}
	}

	if(dmin == INF)
		printf("No solution\n");
	else
	{
		printf("%lld\n", dmin);
		printf("%d %d %d %d\n", v1 + 1, v2 + 1, v3 + 1, v4 + 1);
	}
}

int main()
{
	scanf("%d\n", &t);
	while(t--)
	{
		read();
		solve();
	}
	return 0;
}