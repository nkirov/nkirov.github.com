// pic.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <fstream>
#include <iostream>
#include <conio.h>
using namespace std;
unsigned int big[1502][1502];
unsigned int small[152][152];
int A,B,C,D;

bool check_for_all(int _a, int _b)
{ 	int c=_a,d=_b;
   for(int b=0; b<B; b++)
   {d=_b;
	   for(int a=0; a<A; a++)
		{   if(small[b][a]!=big[c][d]) return false;
//			cout << small[b][a] <<" " << big[d][c] << "\n";
			d++;
		}	
     c++;
   }
   return true;
}

int get()
{  int count = 0;
 for(int a=0; a<D-B+2; a++)
      for(int b=0; b < C-B+2; b++)
      { if(small[0][0] == big[a][b])
		{
		  if(check_for_all(a,b)) { count++;} //cout << a << " "<<b << "\n"; getch();} 
		}
      }
   return count;
}

void input()
{  fstream in("pic.inp",ios::in);
   fstream out("pic.out",ios::out);
   while(1)
   { in >> A >> B >> C >> D;
   
     if(A == 0 && B == 0 && C == 0 && D == 0 ) break;
     for(int a=0; a<B; a++)
     {  for(int b=0; b<A; b++)
		{  in >> small[a][b];
		}
     }

     for( a=0; a<D-B+2; a++)
     {  for(int b=0; b<C-A+2; b++)
		{  in >> big[a][b];
		}
     }
     out << get() << "\n";
   }
   in.close(); out.close();
}

void main()
{ input();
}
