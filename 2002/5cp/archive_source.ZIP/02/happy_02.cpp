#include <fstream.h>
//#include <conio.h>
#include <ccc_ansi.h>
fstream in("happy.inp",ios::in);
fstream out("happy.out",ios::out);
vector<char> get_2(int n)
{ vector<char> ret;
  while(n > 0)
  {   char t;
       int m = n%2;
       if(m == 1)
       { ret.push_back('1');
//	 cout << 1;
       }
       else
       { ret.push_back('0');
//	 cout << 0;
       }
       n = n/2;

  }
  return ret;
}
int is_happy(int n)
{  vector<char> p = get_2(n);
   int n1 = 0,n0 = 0;
   for(int i=0; i < p.size(); i++)
   {//   cout << p[i];
      if(p[i] == '1' ) n1++;
      else n0++;
   }
  if( n1 == n0 ) return 1;
  return 0;
}
int get_happy(int beg, int end)
{ int count = 0;
  if(beg ==0) beg++;
  int found = 0;
 for(int i=beg ; i <=end; i++)
   { if(is_happy(i))
     { out << i << "\n";
       found = 1;
     }
   }
   if(found == 0)  out << 0 << "\n";
 return count;
}
void main()
{
   int beg=0,end=0;
   int nl = 0;
   while(1)
   { in >> beg; in >> end;
     if(end==0 && beg ==0) break;
     get_happy(beg,end);
     out << endl;
     nl == 1;
   }
   out.close();
   in.close();
}