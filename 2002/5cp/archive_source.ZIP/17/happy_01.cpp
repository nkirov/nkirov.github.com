#include "ccc_ansi.cpp"

string dectobin(long val){
  string s="";
  long b=val;
  if(!val) s="0";
  while (b) {
     if((b%2)==1) s=s+'1';
     else s=s+'0';
     b=b/2;
  }
  return s;
}

long count(string s, char c){
   long cnt=0;
   for(long br=0; br<s.length(); br++)
     if (s[br]==c) cnt++;
   return cnt;
}

int ishappy(long val){
  string s;
  s=dectobin(val);
  if(count(s,'1')==count(s,'0')) return 1;
  return 0;
}

void main(){
   fstream fr, fw;
   long v1, v2, br, fnd, pr, more=1;
   char ch;
   fr.open("happy.inp", ios::in);
   fw.open("happy.out", ios::out);
   pr=0;
   do{
     pr++;
     fr>>v1; fr>>v2;
     fnd=0;
     if (v1==0){
       if(v2==0){
	 more=0;
       }
     }
     if(more){
     for(br=v1; br<=v2; br++){
       if(ishappy(br)) {
	 fw<<br<<'\n';
	 fnd=1;
       }
     }
     }
     if(fnd) fw<<'\n';
   } while (more);


   fr.close();
   fw.close();
}