#include<stdio.h>

FILE *mrun,*blah;
int broj,count=0;
int chisla[1000],temp[999];

int check(int length)
{
 int i,fd;
 count=0;
 if(length==1)
  {
	for(i=1;i<broj;i++)if(chisla[0]!=chisla[i])return 0;
	return 1;
  }
 else
  {
	for(i=0;i<length;i++)temp[i]=chisla[i];
	for(i=length;i<broj;i++)
	 {//printf("\n %d, %d",chisla[i],temp[i%length]);
	  if(chisla[i]!=temp[i%length])count--;
	 }
  //	printf("\ncount = %d",count);
	if(count==0)return length;
	else return 0;
 }
}

void do_it()
{
 while(1)
  {
	fscanf(mrun,"%d",&broj);
	if(broj==0)return;
	int i,m;
	for(i=0;i<broj;i++)fscanf(mrun,"%d ",&(chisla[i]));
	for(i=1;i<broj/2;i++)//broj/2
	 {
	  m=check(i);
	  if(m!=0)
		{
		 fprintf(blah,"%d\n",m);
		 break;
		}
	 }
	if(m==0)fprintf(blah,"0\n");
	m=0;
  }
}

void main()
{
 mrun=fopen("period.inp","r");
 blah=fopen("period.out","w");
 do_it();
 fclose(blah);
 fclose(mrun);
// printf("%d\n",check(2));
}