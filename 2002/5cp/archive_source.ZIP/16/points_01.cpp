#include <fstream.h>
#include <math.h>

int koord[1001][2];
//int veche[1001][1001];
      
int dali(int a,int b,int d);

void main()
{	ifstream in("points.inp");
	ofstream out("points.out");

	int N,d,count = 0 ;

	do
	{  in >> N >> d;
		if(N == 0) break;
		count = N;
		int i,j;
		for( i = 0; i < N ; i++ )
			for( j = 0 ; j < 2 ; j++ )
			{	in >> koord[i][j];
			  //	veche[i][j] = 0;
			}
		for( i = 0; i < N -1 ; i++ )
			for( j = i + 1 ; j < N ; j++)
				if( dali(i,j,d)/* && !veche[i][j]*/ ) count--;

		out << count << endl;
		count = 0;
	}while(1);

	in.close();
	out.close();
}

int dali(int a,int b,int d)
{	int x1 = koord[a][0];
	int y1 = koord[a][1];
	int x2 = koord[b][0];
	int y2 = koord[b][1];

	double res = sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) );
	if( res <= d )
	{	//veche[a][b] = 1;
		return 1;
	}
	else return 0;
}