#include <fstream.h>
#include <math.h>

double koord[1001][2];
int search(int mas[][2],int a,int b,int s);
int dali(int mas[][2],int a,int b,int d,int &s);

int main()
{	ifstream in("points.inp");
	ofstream out("points.out");
	int veche[16000][2];
	int N,s_v,count = 0 ;

	double d;

	do
	{  in >> N >> d;
		if(N == 0) return 0;
		count = N;
		s_v = 0;
		int i,j;
		for( i = 0; i < N ; i++ )
			for( j = 0 ; j < 2 ; j++ ) in >> koord[i][j];
		for( i = 0; i < N - 1 ; i++ )
			for( j = i + 1 ; j < N ; j++)
				if( dali(veche,i,j,d,s_v) && !search(veche,i,j,s_v) ) count--;
	  out << count << endl;

	}while(1);
	in.close();
	out.close();
	return 0;
}
int dali(int mas[][2],int a,int b,int d,int &s)
{	double res = sqrt( (koord[b][0]-koord[a][0])*(koord[b][0]-koord[a][0])
					+ (koord[b][1]-koord[a][1])*(koord[b][1]-koord[a][1]) );
	if( res <= d )
	{	mas[s][0] = a;
		mas[s][1] = b;
		s++;
		return 1;
	}
	else return 0;
}
int search(int mas[][2],int a,int b,int s)
{	int i;
	for( i = 0 ; i < s ; i++ )
		if( mas[i][0] < a )
			if( mas[i][1] == b) return 1;
	return 0;
}




