#include<stdio.h>
FILE *mrun, *blah;
int mr,mk,gr,gk,sizer,sizek,count=0;
short int golqma[170][170],malka[51][51];

int check(int l,int m)
{
 int f,d;
 for(f=0;f<mr;f++)
  for(d=0;d<mk;d++)
	if(malka[f][d]!=golqma[f+l][d+m])return 0;
 return 1;
}

void do_it()
{
 while(1){
 fscanf(mrun,"%d %d %d %d",&mk,&mr,&gk,&gr);
 if(mr==0 && mk==0 && gr==0 && gk==0)return;
 int i,j;
 for(i=0;i<mr;i++)
  for(j=0;j<mk;j++)fscanf(mrun,"%d",&(malka[i][j]));
 for(i=0;i<gr;i++)
  for(j=0;j<gk;j++)fscanf(mrun,"%d",&(golqma[i][j]));
 sizer=gr-mr+1;
 sizek=gk-mk+1;
 for(i=0;i<sizer;i++)
  for(j=0;j<sizek;j++)if(golqma[i][j]==malka[0][0])if(check(i,j))count++;
 fprintf(blah,"%d\n",count);
 count=0;}
}

void main()
{
 mrun=fopen("pic.inp","r");
 blah=fopen("pic.out","w");
 do_it();
 fclose(blah);
 fclose(mrun);
}