#include<fstream.h>
#include<stdio.h>

int first, second,count=0,ostatyk;
FILE *mrun, *blah;

int is_happy(int f)
{
 count=0;
 do
  {
   ostatyk=f%2;
   if(ostatyk==1)count++;
   else count--;
   f/=2;
  }while(f!=0);
 if(count==0)return 1;
 else return 0;
}

void do_it()
{
 while(1)
  {
   fscanf(mrun,"%d %d",&first,&second);
   if((first==0)&&(second==0))return;
   int i;
   for(i=first;i<=second;i++)
    {
     if(is_happy(i)==1)fprintf(blah,"%d\n",i);
     count==0;
    }
   fprintf(blah,"\n");
  }
}

void main()
{
 mrun=fopen("happy.inp","r");
 blah=fopen("happy.out","w");
 do_it();
 fclose(blah);
 fclose(mrun);
}