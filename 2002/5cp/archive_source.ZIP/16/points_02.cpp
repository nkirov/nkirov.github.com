#include <fstream.h>
#include <math.h>

double koord[1001][2];

int dali(int a,int b,int d);

int main()
{	ifstream in("points.inp");
	ofstream out("points.out");

	int N,count = 0 ;
	double d;

	do
	{  in >> N >> d;
		if(N == 0) return 0;
		count = N;
		int i,j;
		for( i = 0; i < N ; i++ )
			for( j = 0 ; j < 2 ; j++ ) in >> koord[i][j];

		for( i = 0; i < N - 1 ; i++ )
			for( j = i + 1 ; j < N ; j++)
				if( dali(i,j,d) ) count--;

	  out << count << endl;

	}while(1);

	in.close();
	out.close();
	return 0;
}

int dali(int a,int b,int d)
{	double res = sqrt( (koord[b][0]-koord[a][0])*(koord[b][0]-koord[a][0])
					+ (koord[b][1]-koord[a][1])*(koord[b][1]-koord[a][1]) );
	if( res <= d )	return 1;
	else return 0;
}