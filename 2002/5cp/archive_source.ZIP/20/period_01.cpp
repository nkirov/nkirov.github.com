#include<fstream.h>
int a[1000],b[1000];

 int cmp(int z,int m)
 {
   int f=0;
   int k;
     for (int j = 0;j<m;j++)
    {
      k=j%z;
      if(a[j]!=b[k])
      {
       f=1;break;
      }
   }
   return f;
 }
 void main()
 {
  ifstream fi("period.inp");
  ofstream fo("period.out");

  int m;
  int n;
  fi>>m;
  while(m!=0){

  for(int i=0;i<m;i++)
   fi>>a[i];

    n=1;
    b[0]=a[0];
    while(a[n]!=a[0])
    {
	 b[n]=a[n];
	 n++;
    }
    if(!cmp(n,m))fo<<n<<endl;
     else fo<<0<<endl;
  fi>>m;
  }
 }