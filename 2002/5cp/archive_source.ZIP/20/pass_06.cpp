#include <fstream.h>
#include <string.h>

int N, M;
int delta [1002][10];
int ending[1002];
int visited[1002];
char ch[1002];
int chi;
char minch[1002];
int minchi;
int found = 0;

void min(int p){
  if(ending[p]){
    found = 1;
    ch[chi]=0;
    if (strcmp(ch,minch)<0){
      minchi=chi;
      strcpy(minch,ch);
    }
  }
  visited[p] = 1;
  for (int i = 1; i <=M; i++){
   int q =delta[p][i];
   if (!visited[q])
   {
     ch[chi++] = i;
     if(chi<minchi || (chi==minchi && i<=minch[chi]))
       min(q);

     chi--;
   }
 }
 visited[p] = 0;
}

void main(){
  ifstream fi ("pass.inp");
  ofstream fo ("pass.out");
  fi>>N>> M;
  for (int i = 0; i <N; i++)
     for (int j=1;j<=M; j++)
     {  fi >> delta[i][j];
       ending [i] = 0;
       visited[i] = 0;
     }
  int e, p;
  fi >> e;
  for (i=0; i<e; i++){
    fi>>p;
    ending[p] = 1;
  }

  for (i= 0; i<N; i++)
    minch[i] = 9;
  minch[N] = 0;
  minchi = N;
  chi=0;
  min(0);

  if(!found)
    fo<<0;
  else
    for (i=0; i <minchi; i++){
      fo<<(int)minch[i];
      if((i+1)%50==0) fo<<endl;
    }
  fi.close();
  fo.close();
}