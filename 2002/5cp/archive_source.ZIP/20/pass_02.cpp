#include <fstream.h>

int N, M;
int delta [1001][10];
int ending[1001];
int visited[1001];
int ch[1001], chi;
float minch[1001], minchi;
int found = 0;

void min(int p){
  if(ending[p]){
    found = 1;
    if(chi>minchi)
      return;
    int t1=0, t2 =0;
    if(chi<minchi) t1 = 1;
    int j = chi;
    while (ch[j]==minch[j])j++;
    if(j<chi-1)
      t2 = ch[j]<minch[j];
    if (t1||t2){
      minchi= chi;
      for (j=0; j<minchi; j++)
	minch[j] = ch[j];
    }
  }
  visited[p] = 1;
  for (int i = 1; i <=M; i++){
   int q =delta[p][i];
   if (!visited[q])
   {
     ch[chi++] = i;
     if(chi<minchi || (chi==minchi && i<=minch[chi]))
       min(q);

     chi--;
   }
 }
 visited[p] = 0;
}

void main(){
  ifstream fi ("pass.inp");
  ofstream fo ("pass.out");
  fi>>N>> M;
  for (int i = 0; i <N; i++)
     for (int j=1;j<=M; j++)
     {  fi >> delta[i][j];
       ending [i] = 0;
       visited[i] = 0;
     }
  int e, p;
  fi >> e;
  for (i=0; i<e; i++){
    fi>>p;
    ending[p] = 1;
  }

  for (i= 0; i<N; i++)
    minch[i] = 9;
  minchi = N;
  chi=0;
  min(0);

  if(!found)
    fo<<0;
  else
    for (i=0; i <minchi; i++){
      fo<<minch[i];
      if((i+1)%50==0) fo<<endl;
    }


  fi.close();
  fo.close();
}