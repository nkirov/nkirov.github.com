#include <fstream.h>
#include <math.h>

struct {float x; float y;} ps[1001];
int N;
float D;
int cnt =0;
int mark[1001];

#define sqr(x) ((x)*(x))
int lessD (float x1, float y1, float x2, float y2){
  return sqrt (sqr(x1-x2)+sqr(y1-y2)) < D;
}

void DFS(int p){
  for (int i = 0; i < N; i++)
   if (!mark[i] && lessD(ps[i].x, ps[i].y, ps[p].x, ps[p].y))
     { mark[i] = 1; DFS(i);}
}

void main(){
  ifstream fi ("points.inp");
  ofstream fo ("points.out");
  fi>>N;
  while(N)
  {
   fi>>D;
   cnt = 0;
   for (int i = 0; i <N; i++){
     fi>> ps[i].x >> ps[i].y;
     mark[i] = 0;
   }
   for (i = 0; i <N;i++)
    if(!mark[i]){
      cnt++; DFS(i);
     }
   fo << cnt << endl;
   fi >> N;
  }
  fi.close();
  fo.close();
}