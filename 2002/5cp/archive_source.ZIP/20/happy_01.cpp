#include <fstream.h>


void cnts(int i, int& cnt0, int& cnt1){
  int bin [16], n;
  if(i==0){
    cnt0 = 1;
    cnt1 = 0;
    return;
  }
  cnt0=0; cnt1=0;
  for (int j = 0; j<16; j++)
    bin[j] = i & (1<<j) ? 1 : 0;
  j=15;
  while (bin[j]==0)j--;
  for (int k = j; k>=0; k--)
  { if (bin[k])
      cnt1++;
    else
      cnt0++;
  }
}

void main(){
  ifstream fi ("happy.inp");
  ofstream fo ("happy.out");
  int c0,c1,count;
  int start=1,end=1;
  fi>>start>>end;
  while(start||end)
  {
   for (int i = start; i <=end;i++){
     cnts(i,c0,c1);
     if(c0==c1) fo<<i<<endl;
   }
   fi>>start>>end;
   fo<<endl;
  }
  fi.close();
  fo.close();
}