#include<fstream.h>

ifstream in("happy.inp");
ofstream out("happy.out");

int dint,gint;

int dvoichno(int a)
 {
  int br1=1,br0=0,ch,ost=0;

  ch=a;
  if(!a) return 0;
  while(ch!=1 && ch!=0)
   {
    ost=ch%2;
    ch/=2;
    if(ost==0) br0++;
     else br1++;
   }
  if(br1==br0) return 1;
   else return 0;
}

void main()
 {
  in>>dint>>gint;
  if (dint == 0 && gint == 0) {in.close();out.close();exit(0);}
  do
 { int b=0;
  for(int i=dint;i<=gint;i++)
    if(dvoichno(i)) {out<<i<<endl;b++;}

  if (!b) out <<"0"<<endl;
  out<<endl;
  in>>dint>>gint;
 }
  while(dint!=0 || gint!=0);

 in.close();
 out.close();
}
