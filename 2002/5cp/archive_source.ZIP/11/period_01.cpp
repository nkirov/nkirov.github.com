#include<fstream.h>
int cikal,i,br,t,m[1001],otg,n;

ifstream in ("period.inp");
ofstream out ("period.out");


void main()
{
 in>>n;
 while(n)
  {
   for(int i=1;i<=n;i++)
    in>>m[i];
    i=2;
    while(i<=n && m[1]!=m[i])
    {
     i++;
    }
    if (i==n)cikal=0;
       else cikal=i-1;
    otg=0;
   if (cikal==1)
   { for(int k=cikal+1;k<=n;k++)
      if(m[k/cikal]==m[k]) otg++;
    }
    else
    {for(int k=cikal+1;k<=n;k++)
      if(m[k%cikal]==m[k]) otg++;
     for(k=2*cikal;k<=n;k+=cikal)
      if(m[cikal]==m[k]) otg++;
    }

    if (otg==n-cikal&&cikal)out<<cikal<<endl;
      else out<<"0"<<endl;
  in>>n;
  }
 in.close();
 out.close();

}