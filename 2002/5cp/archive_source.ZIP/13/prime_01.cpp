#include <stdio.h>
#include <conio.h>
#include <math.h>

#define FINP "prime.inp"
#define FOUT "prime.out"
#define MAX_FP 65536

long primes[MAX_FP];


int isPrime(long L) {
   long k = (long) sqrt((double)L);
//   printf("%d %d\n",L,k); getch();
   for(long i=0; i<k; i++) {
  //    printf("%d %d\n",i,primes[i]); getch();
      if(L%primes[i] == 0){

        return 0;
      }
     }
   return 1;
}
int main(int argc, char *argv[])
{
 FILE * finp=fopen(FINP,"r");
 FILE * fout = fopen(FOUT, "w");


   primes[0]=2;
   primes[1]=3;
   int n,fl,k,j,pos;
   long i,mkxs,mxs,start,end;
   i=3; pos=2; mxs=0;
   if(finp)
   {
   /*while(!feof(finp)){
      fscanf(finp,"%ld %ld",&start,&end);
      if(start==end==0)break;
      if(mxs<end)mxs=end;
   }

    mkxs=(long)sqrt((double)mxs);
    i = 3;
    printf("%d",mkxs); getch();*/
   while(pos<MAX_FP){
    fl=0; i+=2;
    k=(int)sqrt(i);
    for(j=2;j<k;j++){
       if(i%primes[j]==0){
          fl=1;
          break;
       }
    }
    if(!fl){primes[pos++]=i;}
   }

  // printf("%d\n",pos); getch();
   fseek(finp,0,0);
   while(!feof(finp)){
      fscanf(finp,"%ld %ld",&start,&end);
      if(start == 0 && end == 0) break;
      long k,count;
      k = start; count = 0;
      if (k%2 == 0) k++; //printf("%d %d\n",start, end); getch();
      while(k<=end) {
         if(isPrime(k))
            count++;
         k += 2;
      }
      fprintf(fout,"%d\n",count);
   }

   //printf("oo"); getch();
//   while(
   fclose(finp);
   fclose(fout);
  /**/          }
  return 0;
}



