#include <fstream.h>

#define MAXAB 150
#define MAXCD 1500

typedef unsigned long ulong;

void main()
{
 ifstream in("pic.inp");
 ofstream out("pic.out");

 int A, B, C, D;

 int m[MAXAB][MAXAB];
 int n[MAXCD][MAXCD];

 while (1)
 {
  in >> A >> B >> C >> D;
  if ((!A) && (!B) && (!C) && (!D)) break;

  for (int i=0; i<B; i++)
   for (int j=0; j<A; j++)
    in >> m[i][j];

  for (int i=0; i<D; i++)
   for (int j=0; j<C; j++)
    in >> n[i][j];

  ulong count=0;

  for (int i=0; i<D-B+1; i++)
   for (int j=0; j<C-A+1; j++)
   {
    int same = 1;
    for (int k=0; k<B; k++)
     for (int l=0; l<A; l++)
     {
      if (m[k][l] != n[i+k][j+l])
      {
       same = 0; break;
      }
      if (!same) break;
     }
    if (same) count++;
   }
  out << count << endl;
 }

 in.close();
 out.close();
}
