#include <fstream.h>
#include <stdlib.h>

int sort_function( const void *a, const void *b)
{
 int x = *((int*) a);
 int y = *((int*) b);

 return (x-y);
}

typedef unsigned int uint;

void main()
{
 ifstream in("happy.inp");
 ofstream out("happy.out");

 uint a, b;

 uint n[30000];

 while (1)
 {
  in >> a >> b;
  if ((!a) && (!b)) break;

  int count=0;
  for (uint i=a; i<=b; i++)
  {
   int ones = 0, zeros=0, last=0;
   for (int j=0; j<16; j++)
   {
    if ((i>>j) & 1) {last=j;}
   }

   for (int h=0; h<=last; h++)
    if ((i>>h) & 1) ones++; else zeros++;

   if (zeros==ones) n[count++] = i;
  }

  if (!count) out << "0\n"; else
  {
   qsort(n, count, sizeof(uint), sort_function);
   for (int k=0; k<count; k++)
   {
    out << n[k] << endl;
   }
  }
  out << endl;
 }

 in.close();
 out.close();
}