#include <fstream.h>
#include <math.h>

#define MAXN 1002

double x[MAXN], y[MAXN];

double dist(double x1, double y1, double x2, double y2)
{
 return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}

void main()
{
 ifstream in("points.inp");
 ofstream out("points.out");

 int N;
 double D;

 while (1)
 {
  in >> N;
  if (!N) break;

  in >> D;

  int group[MAXN] = {0};

  int z=0;
  for (int i=0; i<N; i++)
  {
   in >> x[i] >> y[i];

   if (!i) group[0]=0; else
   {
    int num=-1;

    for (int j=0; j<i; j++)
     if (dist(x[i], y[i], x[j], y[j]) < D)
     {
      if (num == -1)
       num = group[j]; else
       group[j] = num;
     }
    if (num >= 0)
     group[i] = num; else
     {
      z++; group[i] = z;
     }
   }
  }


  int indices[MAXN] = {0};

  for (i=0; i<N; i++)
   indices[group[i]] = 1;

  int count=0;
  for (int j=0; j<MAXN; j++)
   if (indices[j]==1) count++;

  out << count << endl;
 }

 in.close();
 out.close();
}