#include <stdio.h>

int n;
int a[1024];
int n2;

int findperiod()
{
	int x, i;

	n2 = n >> 1;
	for ( x = 0; x < n2; x++ )
	{
		for ( i = x + 1; i < n; i++ )
		{
			if ( a[i] != a[i % (x + 1)] )
				goto L2;
		}

		return x + 1;

L2:
		;
	}

	return 0;
}

int main( void )
{
	int i;
	FILE * f, * t;

	f = fopen( "period.inp", "r" );
	t = fopen( "period.out", "w" );

	while(1)
	{
		fscanf( f, "%d", &n );
		if ( n == 0 ) break;

		for ( i = 0; i < n; i++ )
			fscanf( f, "%d", a + i );
		
		fprintf( t, "%d\n", findperiod() );
	}

	fclose(f);
	fclose(t);

	return 0;
}