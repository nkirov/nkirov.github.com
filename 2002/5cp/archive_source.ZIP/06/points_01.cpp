#include <stdio.h>

#define MAXN 1010

FILE *f,*t;
int mat[MAXN][MAXN];
int n,c;
double d;
double px[MAXN],py[MAXN];
int vis[MAXN];

inline double dist(int i,int j){
	return (px[i]-px[j])*(px[i]-px[j])+(py[i]-py[j])*(py[i]-py[j]);
}

void obhod(int v){
	int i;
	vis[v]=1;
	for(i=0;i<n;i++) if(!vis[i] && mat[v][i]) obhod(i);
}

void main(){
	f = fopen ("points.inp","r");
	t = fopen ("points.out","w");
	while(1){
		fscanf(f,"%d",&n);
		if(n==0) break;
		fscanf(f,"%lf",&d);
		for(int i=0;i<n;i++) fscanf(f,"%lf%lf",px+i,py+i);
		for(i=0;i<n;i++)
			for(int j=i;j<n;j++)
				if(dist(i,j)<=(d*d)) mat[i][j]=mat[j][i]=1;
				else mat[i][j]=mat[j][i]=0;
		for(i=0;i<n;i++) vis[i]=0;
		c = 0;
		for (i=0;i<n;i++)
			if (!vis[i]){
				c++;obhod(i);
			}
		fprintf(t,"%d\n",c);
	}
	fclose(f);
	fclose(t);
}