#include <stdio.h>

int happy[30001];

int hasequ(int x){
	int ones = 0, zeros = 0;

	while (x)
	{
		if ( x & 1 ) ++ones; else ++zeros;
		x >>= 1;
	}

	return ( ones == zeros );
}

int i,a,b,fl;

void main(){
	for(i=1;i<=30000;i++){
		happy[i] = hasequ(i);
	}


	FILE * f = fopen( "happy.inp", "r" );
	FILE * t = fopen( "happy.out", "w" );

	while(1)
	{
		fscanf( f, "%d %d", &a, &b );
		if ( ( a == 0 ) && ( b == 0 ) ) break;
		fl =0;
		for ( i = a; i <= b; i++ )
			if ( happy[i] ){
				fprintf( t, "%d\n", i );
				fl=1;
			}
		if(!fl) fprintf(t,"0\n");
		fprintf( t, "\n" );
	}

	fclose(t);
	fclose(f);
}