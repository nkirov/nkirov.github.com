#include <stdio.h>
#include <string>

using namespace std;

#define MAX_N 1024
#define MAX_M 10

typedef struct { int links[MAX_M]; } CVertex;

int n, m;

CVertex v[MAX_N];

int queue[MAX_N], ir, iw;
int vis[MAX_N];
int depth[MAX_N];
int parent[MAX_N];
char parentdigit[MAX_N];
int terminal[MAX_N];
int term[MAX_N], t_cnt;

string path_len( int final, int d )
{
	static char s[MAX_N]; int plen = 0;

	for ( plen = 0; plen < d; plen++ )
	{
		s[d - plen - 1] = parentdigit[final];
		final = parent[final];
	}

	s[d] = '\0';

	return s;
}

int termdepth = 1000000;

void pBFS()
{
	int x, i, j, d;
	CVertex * vx;

	ir = 0; iw = 0;
	queue[iw++] = 0;
	parent[0] = -1;

	while ( ir < iw )
	{
		x = queue[ir++];
		vx = v + x;
		d = depth[x] + 1;

		if ( d > termdepth ) break;

		for ( i = 1; i <= m; i++ )
		{
			j = vx->links[i];

			if ( !vis[j] )
			{
				queue[iw++] = j;
				vis[j] = 1;
				parent[j] = x;
				depth[j] = d;
				parentdigit[j] = i + '0';

				if ( terminal[j] )
				{
					termdepth = d;
				}
			}
			else
			if ( d == depth[j] )
			{
				if ( (path_len(x, d) + ((char) (i + '0'))) < path_len(j, d) )
				{
					parent[j] = x;
					parentdigit[j] = i + '0';
				}
			}
		}
	}
}

int main( void )
{
	int i, j, x;
	FILE * f, * t;

	f = fopen( "pass.inp", "r" );
	t = fopen( "pass.out", "w" );

	fscanf( f, "%d %d", &n, &m );

	for ( i = 0; i < n; i++ )
	{
		for ( j = 1; j <= m; j++ )
		{
			fscanf( f, "%d", &x );
			v[i].links[j] = x;
		}
	}

	fscanf( f, "%d", &t_cnt );

	for ( i = 0; i < t_cnt; i++ )
	{
		fscanf( f, "%d", &x );
		terminal[x] = 1;
		term[i] = x;
	}

	if ( t_cnt )
		pBFS();

	if ( (!t_cnt) || ( termdepth == 1000000 ) )
		fprintf( t, "0\n" );
	else
	{
		string s, s1;
		int fl = 0;

		for ( i = 0; i < t_cnt; i++ ) if ( vis[ x = term[i] ] )
		{
			if ( fl == 0 )
			{
				s = path_len( x, depth[x] );
				fl = 1;
			}
			else
			{
				s1 = path_len( x, depth[x] );
				if ( s1 < s )
					s = s1;
			}
		}
		
		while ( s.length() >= 50 )
		{
			fprintf( t, "%s\n", s.substr( 0, 50 ).c_str() );
			s.erase( 0, 50 );
		}

		if ( s.length() )
			fprintf( t, "%s\n", s.c_str() );
	}

	fclose(f);
	fclose(t);

	return 0;
}