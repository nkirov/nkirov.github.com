#include <stdio.h>
#include <stdlib.h>

int A, B, C, D;

int T[1550][1550];
int P[155][155];
int x,y,i1,fl,cnt;

int main( void )
{
	srand(4554654);
	int i, j;
	FILE * f, * t;

	f = fopen( "pic.inp", "r" );
	t = fopen( "pic.out", "w" );

	while (1)
	{
		fscanf( f, "%d %d %d %d", &A, &B, &C, &D );
		if ( A == 0 ) break;


		for ( i = 0; i < B; i++ )
		{
			for ( j = 0; j < A; j++ )
				fscanf( f, "%d", &P[i][j] );
		}


		for ( i = 0; i < D; i++ )
			for ( j = 0; j < C; j++ )
				fscanf( f, "%d", &T[i][j] );
		cnt =0;
		for(i=0;i<(D-B+1);i++)
			for(j=0;j<(C-A+1);j++) if(T[i][j]=P[0][0])
			{
				fl=1;
				for(i1=0;i1<12;i1++){
					x = rand() % B;
					y = rand() % A;
					if(P[x][y]!=T[i+x][j+y]) {fl =0; break;}
				}
				if(fl) cnt++;
			}
		fprintf(t,"%d\n",cnt);
	}

	fclose(f);
	fclose(t);

	return 0;
}