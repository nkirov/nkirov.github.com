#include <stdio.h>
#include <math.h>

#define MAX_N 21

int n, v;
int n2;

int a[MAX_N];

long double res[MAX_N];
long double fact[MAX_N];

int main( void )
{
	char bNotFirst = 0;
	int k;
	int sum;
	int i, j;
	FILE * f, * t;
	long double totalsum;
	long double x;

	fact[0] = 1;
	for ( i = 1; i <= 20; i++ )
		fact[i] = i * fact[i - 1];

	f = fopen( "shsh.inp", "r" );
	t = fopen( "shsh.out", "w" );

	while (1)
	{
		fscanf( f, "%d", &n );
		if ( n == 0 ) break;

		fscanf( f, "%d", &v );

		for ( i = 0; i < n; i++ )
		{
			fscanf( f, "%d", a + i );
			res[i] = 0;
		}

		n2 = 1 << n;

		for ( i = 1; i < n2; i++ )
		{
			sum = 0;
			k = 0;
			for ( j = 0; j < n; j++ )
				if ( i & ( 1 << j ) )
				{
					sum += a[j];
					++k;
				}

			if ( sum >= v )
			{
				for ( j = 0; j < n; j++ )
					if ( i & ( 1 << j ) )
						if ( sum - a[j] < v )
							res[j] += fact[k - 1]*fact[n - k];
			}
		}

		totalsum = fact[n];

		if ( bNotFirst )
			fprintf( t, "\n" );
		else
			bNotFirst = 1;

		for ( i = 0; i < n; i++ )
		{
			x = floor( ( res[i]*100 / totalsum ) * 10 + 0.5 );
			fprintf( t, "%lg\n", x / 10 );
		}
	}

	fclose(f);
	fclose(t);

	return 0;
}