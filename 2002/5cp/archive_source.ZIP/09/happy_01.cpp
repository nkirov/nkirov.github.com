#include <fstream.h>
#include <iostream.h>

int get(int a)
{
  int b,c1,c0;
  do
  {
    b=a%2;
    a>>=1;
    b==0 ? c0++ : c1++;
  }  while(a);
return c0==c1;
}


ifstream fin("happy.inp");
ofstream fout("happy.out");


void main()
{
  int a,b;
  while(1)
  {int k(0);
  fin>>a>>b; 
  if(a==0 && b==0) break;
  else
  {
   for(int i(a); i<=b; i++)
    {
    if(get(i))
     {k++;
      fout<<i<<endl;
     }
    }
    if(!k) fout<<"0"<<endl;
	fout << endl;
  }
  }
  
}
