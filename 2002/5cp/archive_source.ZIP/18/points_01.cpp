#include <fstream.h>
#include <math.h>

long a,b,c,d;

double ptx[1002],pty[1002];
int used[1002];
long nn;

struct lnode{
  lnode * next;
  long id;
};

struct llist{
  lnode * first;
  lnode * last;
  int orig;
}lists[1002];

void ListAdd(llist &l, int d)
{
  lnode * nn = new lnode;
  nn->id = d;
  nn->next = NULL;
  if(l.last) l.last->next=nn;
  else
  {
    lnode * n=l.first;
    if(n)
    {
      while(n->next) n = n->next;
      n->next=nn;
    }
    else l.first=nn;
  }
  l.last=nn;
}

void ListClear(llist &l)
{
  lnode *n,*n2;
  n = l.first;
  while(n)
  {
    n2 = n->next;
    delete n;
    n = n2;
  }
  l.first = NULL;
  l.last = NULL;
  l.orig = 0;
}

void main(){
  long i,j;
  double dd;

  for(i=0;i<1002;i++)
  {
      lists[i].first=NULL;
      lists[i].last=NULL;
      lists[i].orig = 0;
  }


  ifstream fin("points.inp");
  ofstream fout("points.out");
  long np;
  double d;
  int work;
  fin >> np;

  while (np){
    fin >> d;
    dd = d*d;
    nn=0;
    memset(ptx,0,sizeof(ptx));
    memset(pty,0,sizeof(ptx));
    for (i=0;i<1002;i++)used[i]=-1;

    for(i=0;i<1002;i++) ListClear(lists[i]);
    for(i=0;i<np;i++)
    {
      fin >> ptx[i] >> pty[i];
    }
    for(i=0;i<np;i++)
    {
      if(used[i]==-1)
      {
	work = nn;
	nn++;
	ListAdd(lists[work],i);
      }else work = used[i];
      for(j=i+1;j<np;j++)
      {
	if(dd>=(fabs(ptx[i]-ptx[j])*fabs(ptx[i]-ptx[j])+(fabs(pty[i]-pty[j])*fabs(pty[i]-pty[j]))))
	{
	  if((used[j]!=-1)&&(used[j]!=work)) lists[used[j]].orig=work;
	  if(used[j]==-1)
	  {
	    ListAdd(lists[work],j);
	    used[j]=work;
	  }

	}
      }
    }
    long c=0;
    for(i=0;i<nn;i++) if(!lists[i].orig) c++;
    fout << c << "\n";
    fin >> np;
  }
}