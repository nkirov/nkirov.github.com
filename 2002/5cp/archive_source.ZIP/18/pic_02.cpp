#include <fstream.h>

long a,b,c,d;

unsigned char small[153][153];
unsigned char *big[1502];
long count;

unsigned char *search(unsigned char *pat,int pn,unsigned char *text,int n){
  int i,j,k,m,skip[255];

  m=pn;

  if(m==0) return(text);
  for(k=0;k<255;k++)skip[k]=m;
  for(k=0;k<m-1;k++)skip[pat[k]] = m-k-1;

  for(k=m-1;k<n;k+=skip[text[k]&(255-1)]){
    for(j=m-1,i=k;j>=0&&text[i]==pat[j];j--)i--;
    if(j==(-1)) return(text+i+1);
  }
  return(NULL);
}

int match(long xx,long yy){
  long x,y;

  for (y=1;y<b;y++)
    for (x=0;x<a;x++){
      if (small[y][x]!=big[yy+y-1][xx+x]){
        return 0;
      }
    }
  return 1;
}

void solve(){
  long y,yy;
  unsigned char *k;
  long t;
  int f;
  int i;

  for (y=0;y<d-b+1;y++) {
    k=&big[y][0];
    while (k!=NULL){
      k=search(small[0],a,k,c);
      if (k!=NULL) {
        if (match((k-(&big[y][0])),y+1)){
          count++;
        }
        k++;
      }
    }
  }
}



void main(){
  long x,y;
  int t;

  for (y=0;y<=1501;y++) big[y]=new unsigned char[1502];

  ifstream fin("pic.inp");
  ofstream fout("pic.out");

  while (fin >> a >> b >> c >> d){
    if ((a==0)&&(b==0)&&(c==0)&&(d==0)) break;
    for (y=0;y<b;y++) {
      for (x=0;x<a;x++){
        fin >> t;
        small[y][x]=t;
      }
      small[y][a]=0;
    }
    for (y=0;y<d;y++)
      for (x=0;x<c;x++){
        fin >> t;
        big[y][x]=t;
      }
    count=0;
    solve();
    fout << count << "\n";
  }
}