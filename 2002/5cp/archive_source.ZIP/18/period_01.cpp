#include <fstream.h>

unsigned char mas[1001];
unsigned char pat[1001];
ifstream fin("period.inp");
ofstream fout("period.out");


int m;

unsigned char *search(unsigned char *pat,int pn,unsigned char *text,int n){
  int i,j,k,m,skip[100];

  m=pn;

  if(m==0) return(text);
  for(k=0;k<100;k++)skip[k]=m;
  for(k=0;k<m-1;k++)skip[pat[k]] = m-k-1;

  for(k=m-1;k<n;k+=skip[text[k]&(100-1)]){
    for(j=m-1,i=k;j>=0&&text[i]==pat[j];j--)i--;
    if(j==(-1)) return(text+i+1);
  }
  return(NULL);
}

void solve(){
  unsigned char *k;
  unsigned char *k1;
  int l,i,a;

  l=m/2;
  for (i=0;i<=l;i++){
    pat[i]=mas[i];
    k=mas+i+1;
    while(k!=NULL){
      k1=k;
      k=search(pat,i+1,k,m);
      if (k!=k1)
	k=NULL;
      else
	k=k+i+1;
    }
    if((m-(k1-mas))<i+1){
      k=search(k1,(m-(k1-mas)),pat,i+1);
      if ((k!=NULL)||(m-(k1-mas)==0)){
	fout << i+1 << "\n";
	return;
      }
    }
  }
  fout << 0 << "\n";
}

void main(){
  int i;
  int t;


  while (fin >> m){
    if (m==0) break;
    for(i=0;i<m;i++){
     fin >> t;
     mas[i]=t;
    }
    mas[m]=0;
    solve();
  }
}