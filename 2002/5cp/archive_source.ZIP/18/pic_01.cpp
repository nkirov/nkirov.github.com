#include <fstream.h>

long a,b,c,d;

unsigned char small[152][152];
unsigned char *big[1502];
long count;

int match(long xx,long yy){
  long x,y;

  for (y=1;y<=b;y++)
    for (x=1;x<=a;x++){
      if (small[y][x]!=big[yy+y-1][xx+x-1]){
        return 0;
      }
    }
  return 1;
}

void solve(){
  long x,y;

  for (y=1;y<=d-b+1;y++)
    for (x=1;x<=c-a+1;x++){
      if (match(x,y)==1){
        count++;
      }
    }
}

void main(){
  long x,y;
  int t;

  for (y=1;y<=1502;y++) big[y]=new unsigned char[1502];

  ifstream fin("pic.inp");
  ofstream fout("pic.out");

  while (fin >> a >> b >> c >> d){
    if ((a==0)&&(b==0)&&(c==0)&&(d==0)) break;
    for (y=1;y<=b;y++)
      for (x=1;x<=a;x++){
        fin >> t;
        small[y][x]=t;
      }
    for (y=1;y<=d;y++)
      for (x=1;x<=c;x++){
        fin >> t;
        big[y][x]=t;
      }
    count=0;
    solve();
    fout << count << "\n";
  }
}