program Happy;

uses
  Dos;

const
  FIN = 'HAPPY.INP';
  FOUT = 'HAPPY.OUT';

var
  Sec_ST : array [0..16] of Longint;
  D, T : Integer;

  FI, FO : Text;

procedure Gen_ST;
var
  R, I : Longint;
begin
  Sec_ST[0] := 1;
  R := 1;
  for I := 1 to 16 do
    begin
      R := R*2;
      Sec_ST[I] := R;
    end;
end;

procedure Solve;
var
  I, J, N : Longint;
  Br, Z, O : Integer;
begin
  Br := 0;
  for I := D to T do
    begin
      for J := 1 to 16 do
        if I < Sec_ST[J] then
          begin N := J; Break; end;
      if N mod 2 = 0 then
        begin
          Z := 0;
          O := 0;
          for J := 0 to N-1 do
            if (I and Sec_ST[J]) = 0 then Inc(Z)
            else Inc(O);
          if O = Z then
            begin
              Br := Br + 1;
              WriteLn(FO, I);
            end;
        end;
    end;
  if Br = 0 then WriteLn(FO, 0);
  WriteLn(FO);
end;

begin
  Gen_ST;
  Assign(FI, FIN);
  ReSet(FI);
  Assign(FO, FOUT);
  ReWrite(FO);
  while not EOF(FI) do
    begin
      Read(FI, D);
      ReadLn(FI, T);
      if (D = 0) and (T = 0) then
        begin
          Close(FO);
          Close(FI);
          Exit;
        end
      else Solve;
    end;
end.


