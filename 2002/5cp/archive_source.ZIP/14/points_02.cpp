program points;

uses
  Dos;

const
  FIN = 'POINTS.INP';
  FOUT = 'POINTS.OUT';

var
  D : Extended;
  A, A1 : array [1..1001, 1..2] of Extended;
  N : Integer;
  N1 : Integer;
  B : array [1..1001] of Boolean;
  NB : Integer;

  FI, FO : Text;
  I, J, M : Integer;

function L(X, Y, X1, Y1 : Extended) : Extended;
begin
  L := Sqrt(Sqr(X1-X)+Sqr(Y1-Y));
end;

procedure Solve;
var
  BrGr : Integer;
  Bool : Boolean;
begin
  FillChar(B, SizeOf(B), False);
  NB := 0;
  BrGR := 0;
  while NB < N do
    begin
      for I := 1 to N do
        if not B[I] then Break;
      if B[I] then Break;
      B[I] := True;
      Inc(NB);
      Inc(BrGr);
      A1[1] := A[I];
      N1 := 1;
      for J := I+1 to N do
        if (not B[J]) then
          begin
            Bool := True;
            for M := 1 to N1 do
              if (L(A1[M,1], A1[M,2], A[J,1], A[J,2]) <= D) then
                begin
                  Bool := False;
                  Break;
                end;
            if not Bool then
              begin
                Inc(NB);
                B[J] := True;
                Inc(N1);
                A1[N1] := A[J];
              end;
          end;
    end;
  BrGR := BrGR;
  WriteLn(FO, BrGr);
end;

begin
  Assign(FI, FIN);
  Assign(FO, FOUT);
  ReSet(FI);
  ReWrite(FO);
  while not EOF(FI) do
    begin
      Read(FI, N);
      if N = 0 then
        begin
          Close(FO);
          Close(FI);
          Exit;
        end;
      ReadLn(FI, D);
      M := 1;
      for I := 1 to 2*N do
        begin
          if I mod 2 = 1 then Read(FI, A[M, 1])
          else Read(FI, A[M, 2]);
          if I mod 2 = 0 then Inc(M);
        end;
      Solve;
    end;
end.


