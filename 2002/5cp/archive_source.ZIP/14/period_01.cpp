program Period;

uses
  Dos;

const
  FIN = 'PERIOD.INP';
  FOUT = 'PERIOD.OUT';

var
  A : array [1..1000] of Integer;
  N : Integer;

  FI, FO : Text;
  I : Integer;

procedure Solve;
var
  I, J, K, C : Integer;
  GB, B : Boolean;
begin
  for I := 1 to (N div 2) do
    begin
      GB := True;
      for J := 1 to I do
        begin
          K := J;
          C := A[J];
          B := True;
          repeat
            if C <> A[K] then B := False;
            K := K+I;
          until (not B) or (K > N);
          if not B then
            begin
              GB := False;
              Break;
            end;
        end;
      if GB then
        begin
          WriteLn(FO, I);
          Exit;
        end;
    end;
  WriteLn(FO, 0);
end;

begin
  Assign(FI, FIN);
  ReSet(FI);
  Assign(FO, FOUT);
  ReWrite(FO);
  while not EOF(FI) do
    begin
      ReadLn(FI, N);
      if N = 0 then
        begin
          Close(FI);
          Close(FO);
          Exit;
        end;
      for I := 1 to N do
        begin
          Read(FI, A[I]);
        end;
      Solve;
    end;
end.

