program Pass;

uses
  Dos;

const
  FIN = 'PASS.INP';
  FOUT = 'PASS.OUT';

var
  A : array [0..1000, 0..9] of Byte;
  Q : array [1..1000] of Byte;
  BestS, S : array [1..1000] of Byte;
  NS, NBS : Integer;
  NQ, N, M : Integer;

  FI, FO : Text;
  I, J : Integer;

procedure Solve(P : Integer; Prev : Byte);
var
  I : Byte;
  B : Boolean;
begin
  Inc(NS);
  S[NS] := P;
  A[P, 0] := 1;

  B := False;
  for I := 1 to NQ do
    if (Q[I] = P) and (NS < NBS) then
      begin
        BestS := S;
        NBS := NS;
        B := True;
      end;

  if not B then
    for I := 1 to M do
      if A[A[P, I], 0] = 0 then
        Solve(A[P, I], P);

  A[P, 0] := 0;
  Dec(NS);
end;

begin
  Assign(FI, FIN);
  Assign(FO, FOUT);
  ReSet(FI);
  ReWrite(FO);
  Read(FI, N);
  ReadLn(FI, M);
  for I := 1 to N do
    begin
      for J := 1 to M do
      Read(FI, A[I-1, J]);
    end;
  Read(FI, NQ);
  for I := 1 to NQ do Read(FI, Q[I]);
  Close(FI);
  FillChar(BestS, SizeOf(BestS), 0);
  FillChar(S, SizeOf(S), 0);
  NS := 0;
  NBS := MaxInt;
  Solve(0, 0);
  if NBS = MaxInt then WriteLn(FO, 0)
  else
    for I := 1 to NBS-1 do
      begin
        for J := 1 to M do
          if A[BestS[I], J] = BestS[I+1] then
            begin
              Write(FO, J);
              Break;
            end;
        if I mod 50 = 0 then WriteLn(FO);
      end;
  Close(FO);
end.


