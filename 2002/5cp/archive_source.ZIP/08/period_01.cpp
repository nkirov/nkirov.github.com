#include<iostream.h>
#include<fstream.h>
#include<stdlib.h>
void main()
{ int n;
  ofstream fout("period.out");
  ifstream fin("period.inp");

  
 while (!fin.eof())
  { fin>>n;
    if (!n) break;
    char *p=new char[n];
	
	for(int i=0;i<n;i++)
	{ fin>>p[i];
	}
	int z=(n / 2)+2;
	for(i=1;i<z;i++)
	{ bool t=1;
	  
	  for(int j=0; j<i;j++)
	  {
	    for(int a=j+i;a<n;a+=i)
		{ if(!(p[j]==p[a]))
		     t=0;
		if(!t) break;

		}
	   if(!t) break;
	  }
      if (t) 
	  {fout<<i<<endl;
	  break;
	  }
	  else if (i==z-1) fout<<0<<endl;
	}

  }

  fin.close();
  fout.close();

}