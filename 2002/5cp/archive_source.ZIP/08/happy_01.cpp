#include<iostream.h>
#include<fstream.h>

void main()
{ 
  int a,b;
  
  ofstream fout("happy.out");
  ifstream fin("happy.inp");
  
  while (!fin.eof())
  {   
	  bool flag=0;

		fin>>a>>b;
		if((a==0)&&(b==0)) break;
		
		for(int i=a;i<=b;i++)
		{ unsigned int mask=1;
			int r=0;
		  if ((i>=2)&&(i<=3)) r=2;
		  else
			  if ((i>=8)&&(i<=15)) r=4;
			  else
				  if ((i>=32)&&(i<=63)) r=6;
				  else
					  if ((i>=128)&&(i<=255)) r=8; 
					  else
						  if ((i>=512)&&(i<=1023)) r=10; 
						  else
							  if ((i>=2048)&&(i<=4095)) r=12;
							  else
								  if ((i>=8192)&&(i<=16383)) r=14; 
		
		  if (r)
		  {
			int m=0;
		    for(int c=0; c<r; c++)
			{ if (mask&i) m++;
		    else m--;
			mask<<=1;
			}
		  
			if (m==0) {fout<<i<<endl; flag=1;}
		  }
		  
		}

		if (!flag) fout<<0<<endl;
		fout<<endl;
	}
  fin.close();
  fout.close();
}