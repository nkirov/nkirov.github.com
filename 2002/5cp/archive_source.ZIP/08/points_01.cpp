#include<iostream.h>
#include<fstream.h>
#include<stdlib.h>
#include<math.h>

class point
{ public:
    double x,y;
	int group;
};

/*point::point()
{ group=0;};*/

void main()
{  int n;
   float d;
   ofstream fout("points.out");
   ifstream fin("points.inp");
  
  while (!fin.eof())
  { fin>>n;
    if (!n) break;
    fin>>d;
    point* p=new point[n];
  for (int i=0; i<n; i++) 
  {  fin>>p[i].x>>p[i].y; p[i].group=0;
  }
  int g=0;
  for (i=0; i<n; i++)
  {
	  if (!p[i].group) p[i].group=++g;
	  for (int j=i+1; j<n; j++)
		  if ((sqrt(((p[j].x - p[i].x)*(p[j].x - p[i].x))+((p[j].y - p[i].y)*(p[j].y - p[i].y))))<=d) p[j].group=p[i].group;
  }
  fout<<g<<endl;
  }
  fin.close();
  fout.close();
}