#include <stdio.h>

int n;
long double d;
long double x[1020],y[1020];
long double tmp;
int obl;

int qb,qe;
int q[1020];
int u[1020];

void qput(int v)
{
	q[qb]=v;
	u[v]=1;
	qb++;
}

int qget(int & k)
{
	if (qb==qe)
		return 0;
	else
	{
		k=q[qe];
		qe++;
		return 1;
	}
}

int dist_d(int i, int j)
{
	tmp=(x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])-d*d;
	if (tmp<0.000000000001)
		return 1;
	else
		return 0;
}

void wave(int bv)
{
	qb=1;
	qe=1;
	qput(bv);
	int k,i;
	while (qget(k))
	{
		for (i=0;i<n;i++)
			if ((!u[i]) && dist_d(i,k))
				qput(i);
	}
}

int main()
{
	FILE *f=fopen("points.inp","r");
	FILE *fo=fopen("points.out","w");
	fscanf(f,"%d",&n);
	int i;
	while (n>0)
	{
		fscanf(f,"%lf",&d);
		obl=0;
		for (i=0;i<n;i++)
			fscanf(f,"%lf %lf",x+i,y+i);
		for (i=0;i<n;i++)
			u[i]=0;
		for (i=0;i<n;i++)
			if (!u[i])
				{
					wave(i);
					obl++;
				}
		fprintf(fo,"%d\n",obl);
		fscanf(f,"%d",&n);
	}
	fclose(f);
	fclose(fo);
	return 0;
}
