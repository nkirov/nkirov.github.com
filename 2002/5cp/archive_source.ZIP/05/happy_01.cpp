#include <stdio.h>

int c[10000];

int main()
{
	int a[30]={1,0};
	int l=1,cnt;
	int asw=0;
	int i,j;
	int outs;
	for (i=2;i<=30000;i++)
	{ 
		a[0]++;
		j=0;
		while (a[j]==2)
		{
			a[j]=0;
			a[++j]++;
		} 
		if (j>=l)
			l=j+1;
		cnt=0;
		for (j=0;j<l;j++)
			if (a[j])
				cnt++;
		if (2*cnt==l)
		{
			c[asw]=i;
			asw++;
		}
	}
	int ib,ie;
	int fb,fe;
	int sb,se;
	FILE *f=fopen("happy.inp","r");
	FILE *fo=fopen("happy.out","w");
	fscanf(f,"%d %d",&ib,&ie);
	while (!(ib==0 && ie==0))
	{
		fb=0;
		fe=asw-1;
		i=(fb+fe)/2;
		while (fe-fb>1)
			if (c[i]>ib)
			{
				fe=i;
				i=(fb+fe)/2;
			}
			else
			{
				fb=i;
				i=(fb+fe)/2;
			}
		sb=i;
		fb=0;
		fe=asw-1;
		i=(fb+fe)/2;
		while (fe-fb>1)
			if (c[i]>ie)
			{
				fe=i;
				i=(fb+fe)/2;
			}
			else
			{
				fb=i;
				i=(fb+fe)/2;
			}
		se=i;
		while (c[sb]<ib)
			sb++;
		while (c[se+1]<ie)
			se++;
		outs=0;
		for (i=sb;i<=se;i++)
		{
			fprintf(fo,"%d\n",c[i]);
			outs++;
		}
		if (outs)
			fprintf(fo,"\n");
		else 
			fprintf(fo,"0\n\n");
		fscanf(f,"%d %d",&ib,&ie);
	}
	fclose(f);
	fclose(fo);
	return 0;
}
