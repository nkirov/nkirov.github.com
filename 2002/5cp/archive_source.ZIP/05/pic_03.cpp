#include <stdio.h>

int pic[160][160], row[1600];
int cnt, A, B, C, D;

struct CP {
	int p, cnt;
} mas[1700];
int np;

int fnd(int pos, int r)
{
	int i;

	for (i=0; i<B; i++) if (row[pos+i] != pic[r][i]) {
		return 0;
	}

	return 1;
}

int main()
{
	FILE *inf = fopen("pic.inp", "r");
	FILE *of = fopen("pic.out", "w");

	int i, j;

	do {

		fscanf(inf, "%d%d%d%d", &B, &A, &D, &C);

		if (B==0 || C==0 || A==0 || D==0) break;

		for (i=0; i<A; i++) {
			for (j=0; j<B;j++) {
				fscanf(inf, "%d", &pic[i][j]);
			}
		}

		np = 0;cnt = 0;

		for (i=0; i<C; i++) {
			for (j=0; j<D; j++) fscanf(inf, "%d", &row[j]);

			for (j=0; j<np; j++) {
				if (fnd(mas[j].p, mas[j].cnt)) {
					mas[j].cnt++;
				} else {
					mas[j] = mas[np-1];
					j--;
					np--;
				}
			}

			for (j=0; j<= D - B; j++) if (fnd(j, 0)) {
				mas[np].p = j;
				mas[np].cnt = 1;
				np++;
			}

			for (j=0; j<np; j++) {
				if (mas[j].cnt == A) {
					cnt++;
					mas[j] = mas[np-1];
					np--;
					j--;
				}
			}
		}

		fprintf(of, "%d\n", cnt);

	} while (1);

	fclose(of);
	fclose(inf);
	return 0;
}