#include <stdio.h>

int n, len;
int mas[1010];
int p;

int check(int len)
{
	int i;
	for (i = len; i<n; i++) {
		if (mas[i] != mas[i%len]) {
			return 0;
		}
	}

	p = len;
	return 1;
}

int main()
{

	FILE *inf = fopen("period.inp", "r");
	FILE *of = fopen("period.out", "w");
	int i, done;

	do {
		fscanf(inf, "%d", &n);
		if (n==0) break;

		for (i = 0; i<n; i++) {
			fscanf(inf, "%d", mas+i);
		}

		done = 0;
		for (len = 1; len <= n/2; len++) {
			if (check(len)) {
				fprintf(of ,"%d\n", p);
				done = 1;
				break;
			}
		}

		if (!done) fprintf(of, "0\n");
	} while (1);

	fclose(inf);
	fclose(of);
	return 0; 
}