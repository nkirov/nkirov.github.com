#include <stdio.h>

int n,m;
int a[1010][1010];
int b[1010][1010];
int ae[1010];
int q[1010];
int u[1010];
int y[1010];
int l[1010];
int an[1010];
int qb=1,qe=1;
int res;
int r[1010];

/*void qput(int v,int val)
{
	q[qb]=v;
	qb++;
	u[v]=val;
}*/

int qget(int & v)
{
	if (qb==qe)
		return 0;
	v=q[qe];
	qe++;
	return 1;
}

void qput1(int v,int lev,int val,int anc)
{
	q[qb]=v;
	qb++;
	l[v]=lev;
	y[v]=val;
	an[v]=anc;
}

int main()
{
	FILE *f=fopen("pass.inp","r");
	fscanf(f,"%d %d",&n,&m);
	int i,j,v;
	for (i=0;i<n;i++)
		for (j=0;j<m;j++)
		{
			fscanf(f,"%d",&v);
			a[v][ae[v]]=i;
			b[v][ae[v]]=j;
			ae[v]++;
		}
	fscanf(f,"%d",&res);
	for (i=0;i<res;i++)
		fscanf(f,"%d",&r[i]);
	fclose(f);
	for (i=0;i<n;i++)
		y[i]=0;
	qb=1;
	qe=1;
	for (i=0;i<res;i++)
		qput1(r[i],1,0,-1);
	while (qget(i))
		for (j=0;j<ae[i];j++)
		{
			if (l[a[i][j]]==0)
				qput1(a[i][j],l[i]+1,b[i][j],i);
			if (l[a[i][j]]==l[i]+1 && y[a[i][j]]>b[i][j])
			{
				y[a[i][j]]=b[i][j];
				an[a[i][j]]=i;
			}
		}
	f=fopen("pass.out","w");
	i=0;
	j=0;
	do
	{
		j++;
		if (j==51)
		{
			fprintf(f,"\n");
			j=1;
		}
		fprintf(f,"%d",y[i]+1);
		i=an[i];
	} while (l[i]>1);
	fprintf(f,"\n");
	fclose(f);
	return 0;
}
