{$A+,B-,D+,E+,F-,G-,I+,L+,N+,O-,P-,Q-,R-,S-,T-,V+,X+,Y+}
{$M 65384,0,655360}

const fin='SHSH.INP';
      fon='SHSH.OUT';
var fi,fo:Text;
    bolsh:integer;
    n:byte;
    a:array [1..20] of integer;
    b:array [1..20] of comp;
    c:array [1..20] of byte;
    br:comp;

procedure Read_Data;
var i:byte;
begin
readln(fi,n,bolsh);
for i:=1 to n do
read(fi,a[i]);
readln(fi);
end;

procedure Calculate_It;
var pos:byte;
    s:set of byte;

procedure Test;
var i,j:byte;
    sum:integer;
begin
br:=br+1;
sum:=0;
j:=0;
repeat
inc(j);
sum:=sum+a[c[j]];
until sum>=bolsh;
b[c[j]]:=b[c[j]]+1;
end;

procedure perm;
var i:byte;
begin
if s=[] then Test else
  for i:=1 to n do
    if i in s then
    begin
    exclude(s,i);
    inc(pos);
    c[pos]:=i;
    Perm;
    dec(pos);
    include(s,i);
    end;
end;

begin
fillchar(c,sizeof(c),0);
br:=0;
fillchar(b,sizeof(b),0);
pos:=0;
s:=[1..n];
Perm;
end;

procedure Show_Result;
var i:byte;
    k:longint;
begin
for i:=1 to n do
begin
k:=round((b[i]/br)*1000);
if (k mod 10)=0 then writeln(fo,k div 10) else
writeln(fo,k/10:0:1);
end;
writeln(fo);
end;

begin
assign(fi,fin);
assign(fo,fon);
reset(fi);
rewrite(fo);
repeat
Read_Data;
if n>0 then
begin
Calculate_It;
Show_Result;
end;
until n=0;
close(fi);
close(fo);
end.