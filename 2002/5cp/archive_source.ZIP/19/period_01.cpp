{$A+,B-,D+,E+,F-,G-,I+,L+,N+,O-,P-,Q-,R+,S+,T-,V+,X+,Y+}
{$M 65384,0,655360}

const fin='PERIOD.INP';
      fon='PERIOD.OUT';
      max=1000;
var fi,fo:Text;
    n:integer;
    a:array [1..max] of integer;
    per:integer;

procedure Read_Data;
var i:integer;
begin
fillchar(a,sizeof(a),0);
readln(fi,n);
for i:=1 to n do
read(fi,a[i]);
readln(fi);
per:=n;
end;

procedure Calculate_It;
var bool:boolean;
    i,j:integer;
begin
for i:=(n div 2+1) downto 1 do
begin
bool:=true;
for j:=i+1 to n do
if a[j]<>a[j-i] then bool:=false;
if bool then per:=i;
end;
end;

procedure Show_Result;
begin
if per=n then writeln(fo,0) else writeln(fo,per);
end;

begin
assign(fi,fin);
assign(fo,fon);
reset(fi);
rewrite(fo);
repeat
Read_Data;
if n>0 then
begin
Calculate_It;
Show_Result;
end;
until n=0;
close(fi);
close(fo);
end.