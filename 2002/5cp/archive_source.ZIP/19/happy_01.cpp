{$A+,B-,D+,E+,F-,G-,I+,L+,N-,O-,P-,Q-,R-,S-,T-,V+,X+,Y+}
{$M 65384,0,655360}

const fin='HAPPY.INP';
      fon='HAPPY.OUT';
var fi,fo:Text;
    m,n:integer;

procedure Read_Data;
begin
readln(fi,m,n);
end;

function bintobyte(x:integer):boolean;
var ed,nu:byte;
    k:integer;
begin
 ed:=0;nu:=0;
 k:=x;
 repeat
 if k mod 2=0 then inc(nu) else inc(ed);
 k:=k shr 1;
 until k=0;
 bintobyte:=nu=ed;
end;

procedure Calculate_It;
var i:integer;
begin
for i:=m to n do
if bintobyte(i) then writeln(fo,i);
end;

procedure Show_Result;
begin
writeln(fo);
end;

begin
assign(fi,fin);
assign(fo,fon);
reset(fi);
rewrite(fo);
repeat
Read_Data;
Calculate_It;
Show_Result;
until (m=0) and (n=0);
close(fi);
close(fo);
end.