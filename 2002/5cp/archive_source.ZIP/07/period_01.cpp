#include <stdio.h>

int F[2000];
char s[2005];

void computeF(const char* s, int len) {
	F[0] = 0;
	int i = 1, j=0;
	while (i<len) {
		if (s[i]==s[j]) {
			F[i] = F[i-1]+1;
			i++; j++;
		} else {
			if (j==0) {
				F[i]=0;
				i++;
			} else
				if (F[j]-1 > 0)
					j = F[j] - 1;
				else
					j=0;
		}
	}
}

//int kmp(const char* s, const char* p, int slen

int check(const char* s, int len, int per) {
	int i=0;
	int j=0;
	for (i=0; i<per; i++) {
		for (j=i+per; j<len; j+=per) {
			if (s[j]!=s[i])
				return 0;
		}
	}
	return 1;
}

void main() {
	int n;
	int i;
	FILE* fi = fopen("period.inp", "rt");
	FILE* fo = fopen("period.out", "wt");
	//FILE* fo = stdout;
	while (1) {
		fscanf(fi, "%d", &n);
		if (n==0) break;
		for (i=0; i<n; i++) {
			fscanf(fi, "%d", &s[i]);
		}
		s[i]=0;
		computeF(s, n);
		if (F[n-1]>0) {
			if (check(s, n, n - F[n-1]))
				fprintf(fo, "%d\n", n - F[n-1]);
			else
				fprintf(fo, "0\n");
		} else {
			fprintf(fo, "0\n");
		}
	}
}
