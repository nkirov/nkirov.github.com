#include <stdio.h>
#include <queue>
#include <string>

using namespace std;

int JMP[1010][11];
bool FINAL[1010];
struct a
{
	int level;
	string str;
	int prev;
} All[1010];

using namespace std;

FILE *fin = fopen("pass.inp", "rt");
FILE *fout = fopen("pass.out", "wt");
//FILE *fin = stdin;
//FILE *fout = stdout;

int main()
{

	int n, m;
	int i, j;

	for (i = 0; i < 1010; i++)
	{
		FINAL[i] = false;

		All[i].str = "";
		All[i].prev = -1;
		All[i].level = 10000;
	}

	fscanf(fin, "%d %d", &n, &m);

	for (i = 0; i < n; i++)
	{
		for (j = 1; j <= m; j++)
			fscanf(fin, "%d", &JMP[i][j]);
		FINAL[i] = false;
	}

	int final;
	fscanf(fin, "%d", &final);
	for (i = 0; i < final; i++)
	{
		int tmp;
		fscanf(fin, "%d", &tmp);
		FINAL[tmp] = true;
	}

/*	for (i = 0; i < 1010; i++)
		if (FINAL[i] == true)
			printf("%d\n", i);*/

	All[0].prev = -1;
	All[0].str = "";
	All[0].level = 0;

	queue<int> Q[2];
	int c = 0;

	Q[c].push(0);

	while(1)
	{
		if (Q[c].empty())
		{
			fprintf(fout, "0\n");
			goto END;
		}
		bool bFound = false;
		string strBest = "";

		while (!Q[c].empty())
		{
			int node = Q[c].front();
			Q[c].pop();

			if (FINAL[node])
			{
				if (!bFound)
				{
					bFound = true;
					strBest = All[node].str;
				}
				else
				if (strBest.compare(All[node].str) > 0)
				{
					strBest = All[node].str;
				}
			}

			for (j = 1; j <=m; j++)
			{
				int next = JMP[node][j];

				char d = '0' + j;
				string strnew = All[node].str + d;

				if (All[next].prev == -1)
				{
					All[next].level = All[node].level + 1;
					All[next].prev = node;
					All[next].str = strnew;

					Q[1-c].push(next);
				}
				else
				{
					if (All[next].level == All[node].level + 1)
					if (strnew.compare(All[next].str) < 0)
					{
						All[next].prev = node;
						All[next].str = strnew;
					}
				}
			}
		}	// while !empty()

		if (bFound)
		{
			fprintf(fout, "%s\n", strBest.c_str());
			goto END;
		}

		c = 1 - c;
	}	// while (1)

END:;

/*	for (i = 0; i < n; i++)
	{
		printf("%d : lvl - %d, str : %s\n", i, All[i].level, All[i].str.c_str());
	}*/
	fclose(fin);
	fclose(fout);
	return 0;
}
