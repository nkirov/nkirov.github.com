#include <stdio.h>
#include <map>
#include <math.h>

typedef __int64 hyper;

using namespace std;

typedef map<int, int> IntMap;

hyper facts[21];
IntMap m;
int s;

hyper compute(int lim, int k)
{
	bool entered = false;

	hyper cnt = 0;

	if (lim <= k)
		cnt += facts[s];

	for (IntMap::iterator it = m.begin(); it != m.end(); ++it)
		if (lim > it->first && it->second > 0) {
			it->second--;
			s--;
			cnt += compute(lim - it->first, k)*(it->second+1);
			it->second++;
			s++;
			entered = true;
		}

/*	if (!entered) return facts[s];
	else*/
	return cnt;
}

int n, v;

int main(void)
{
	int votes[21] = {0};
	double ind[101];

	int pos = 0;
	facts[0] = facts[1] = 1;

	int i;
	for (i = 2; i <= 20; ++i) {
		facts[i] = facts[i-1] * i;
	}

	FILE* fin = fopen("shsh.inp", "rt");
	FILE* fout = fopen("shsh.out", "wt");

	bool ff = false;

	while (fscanf(fin, "%d %d", &n, &v) == 2) {
		if (ff)
			fprintf(fout, "\n");
		ff = true;
		pos = 0;
		s = 0;
		for (i = 0; i < n; ++i) {
			int x;
			fscanf(fin, "%d", &x);
			votes[pos++] = x;

			if (m.count(x) > 0)
				m[x]++;
			else
				m[x] = 1;
			s += 1;
		}

		votes[pos] = -1;
		s--;
		for (IntMap::iterator it = m.begin(); it != m.end(); ++it) {
			it->second--;
			hyper count = compute(v, it->first);
			it->second++;
			ind[it->first] = ((double) count / facts[n])*100;
		}

		for (i = 0; i < n; ++i)
		{
			double x = ind[votes[i]] * 10;
			x = floor(x+0.5);
			int y = (int) x;
			if (y % 10 == 0)
				fprintf(fout, "%d\n", y/10);
			else
				fprintf(fout, "%d.%d\n", y/10, y%10);
		}

		m.clear();
	}
	return 0;
}
