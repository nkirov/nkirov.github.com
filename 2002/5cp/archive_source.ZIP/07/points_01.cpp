#include <stdio.h>
#include <string.h>

double d, D;
int n;

struct Point {
	double x, y;
};

//double dist[1002][1002];
int comp[1002];
Point p[1050];

inline double compute_dist(int i, int j)
{
	return (p[i].x-p[j].x)*(p[i].x-p[j].x) + (p[i].y-p[j].y)*(p[i].y-p[j].y);
}

inline bool is_edge(int i, int j)
{
	return compute_dist(i, j) < D;
}

void dfs(int cur, int c)
{
	comp[cur] = c;
	for (int i = 0; i < n; ++i)
		if (comp[i] == 0 && is_edge(cur, i))
			dfs(i, c);
}

int main(void)
{
	FILE* fin = fopen("points.inp", "rt");
	FILE* fout = fopen("points.out", "wt");
	//FILE* fout = stdout;

	while (fscanf(fin, "%d %lf", &n, &d) == 2)
	{
		int i;
		D = d*d;
		for (i = 0; i < n; ++i)
			fscanf(fin, "%lf %lf", &p[i].x, &p[i].y);

		memset(comp, 0, sizeof(comp));

		int c = 1;
		while (1) {
			for (i = 0; i < n; ++i)
				if (comp[i] == 0)
					break;
			if (i == n)
				break;
			dfs(i, c++);
		}

		fprintf(fout, "%d\n", c-1);
	}
	return 0;
}
