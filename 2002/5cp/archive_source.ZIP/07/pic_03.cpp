#include <stdio.h>
#include <string.h>

char Text[1600][1600];
int F[160];
char P[160][160];
char Mask[160];;
int Sx, Sy, Px, Py;

/*inline char GetP(int r, int c)
{
	return Mask[r * Px + c];
}
inline char GetS(int r, int c)
{
	return Text[r * Sx + c];
}*/
inline char GetText(int i)
{
	return Text[i / Sx][i % Sx];
}

int KMP(char* Mask, int start)
{
//	int n = strlen(Text);
	int n = Sx * Sy;
	int m = strlen(Mask);
	int i = start, j = 0;

	while (i < n)
	{
		if (GetText(i) == Mask[j])
		{
			if (j == m-1)
				return i-m+1;
			else
			{
				i++;
				j++;
			}
		}
		else
		{
			if (j > 0)
				j = F[j-1];
			else
				i++;
		}
	}
	return -1;
}

void computeFail(char* Msk, int Fail[])
{
	int i = 1, j = 0;
	int m = strlen(Msk);
	Fail[0] = 0;
	while (i < m)
	{
		if (Msk[i] == Msk[j])
		{
			Fail[i] = j+1;
			i++;
			j++;
		}
		else
		{
			if (j > 0)
				j = Fail[j-1];
			else
			{
				Fail[i] = 0;
				i++;
			}
		}
	}
}

bool match(int posx, int posy)
{
	if (posx < 0 || posy < 0 || posx >= Sx - Px + 1 || posy >= Sy - Py +1)
		return false;

	for (int r = 0; r < Py - 1; r++)
		for (int c = 0; c < Px; c++)
			if (P[r][c] != Text[r+posy][c+posx])
				return false;

	return true;
}

int main()
{
	FILE *fin = fopen("pic.inp", "rt");
	FILE *fout = fopen("pic.out", "wt");
//	FILE *fout = stdout;
	int r, c;

	while (1)
	{
		fscanf(fin, "%d %d %d %d", &Px, &Py, &Sx, &Sy);
		if( Px == 0 && Py == 0 && Sx == 0 && Sy == 0)
			break;
		for (r = 0; r < Py; r++)
			for (c = 0; c < Px; c++)
			{
				int a;
				fscanf(fin, "%d", &a);
				P[r][c] = a;
			}


		for (r = 0; r < Sy; r++)
			for (c = 0; c < Sx; c++)
			{
				int a;
				fscanf(fin, "%d", &a);
				Text[r][c] = a;
			}

		for (c = 0; c < Px; c++)
			Mask[c] = P[Py-1][c];
		Mask[c] = '\0';

		computeFail(Mask, F);

		int count = 0;
		int pos = 0;

		while (1)
		{
			int p = KMP(Mask, pos);
			if (p == -1)
				break;

			pos = p+1;
			if (match(p % Sx, p / Sx - Py +1))
			{
//				printf(">%d\n", p);
				count++;
			}
		}
		fprintf(fout, "%d\n", count);
	}
	fclose(fin);
	fclose(fout);
	return 0;
}