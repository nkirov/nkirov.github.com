#include <stdio.h>

bool is_happy(unsigned a)
{
	int zeros = 0, ones = 0;

	while (a != 0) {
		if (a & 1)
			ones++;
		else
			zeros++;
		a >>= 1;
	}
	return ones == zeros;
}

#define MAX 30005

bool tb[MAX];

int main(void)
{
	for (int i = 1; i < MAX; ++i)
		tb[i] = is_happy(i);

	FILE* fin = fopen("happy.inp", "rt");
	FILE* fout = fopen("happy.out", "wt");

	int m, n;
	while (1) {
		fscanf(fin, "%d %d", &m, &n);
		if (m == 0 && n == 0)
			break;
		bool flag = false;
		for (i = m; i <= n; ++i)
			if (tb[i]) {
				fprintf(fout, "%d\n", i);
				flag = true;
			}
		if (!flag)
			fprintf(fout, "0\n");
		fprintf(fout, "\n");
	}
	return 0;
}
