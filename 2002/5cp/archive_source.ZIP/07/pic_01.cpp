#include <stdio.h>

int F[100000];
unsigned char p[170*170];
unsigned char s[1700*1700];

/*unsigned char pat[] = {31, 32, 0, 0, 31, 0, 0};
unsigned char test[] = {3, 31, 32, 4, 5, 31, 9, 9, 9};*/

void computeF(const unsigned char* s, int len) {
	F[0] = 0;
	int i = 1, j=0;
	while (i<len) {
		if (s[i]==s[j] || s[i]==0 || s[j]==0) {
			F[i] = F[i-1]+1;
			i++; j++;
		} else {
			if (j==0) {
				F[i]=0;
				i++;
			} else
				if (F[j]-1 > 0)
					j = F[j] - 1;
				else
					j=0;
		}
	}
}

int kmp(const unsigned char* s, const unsigned char* p, int slen, int plen) {
	computeF(p ,plen);
	int i=0, j=0;
	while (i<=slen) {
		if (j==plen) return i-j;
		if (i==slen) return -1;
		if (s[i]==p[j] || s[i]==0 || p[j]==0) {
			i++;
			j++;
		} else {
			if (j>0)
				j=F[j-1];
			else
				i++;
		}
	}
	return -1;
}

void main() {
	int i ,j, t, q;
	int a, b, c, d;
	//int slen;
	//int plen;
	FILE* fi = fopen("pic.inp", "rt");
	FILE* fo = fopen("pic.out", "wt");
	//FILE* fo = stdout;

	//printf("test: %d\n", kmp(test, pat, 9, 7));

	while (1) {
		fscanf(fi, "%d %d %d %d", &a, &b, &c, &d);
		if (a==0 && b==0 && c==0 && d==0) break;
		//plen = a*b + (b-1)*c;
		t=0;
		for (i=0; i<b; i++) {
			for (j=0; j<a; j++, t++) {
				int l;
				fscanf(fi, "%d", &l);
				p[t]=l;
			}
			if (i<b-1)
				for (j=0; j<c - a; j++, t++)
					p[t]=0;
		}
		q=0;
		for (i=0; i<d; i++)
			for (j=0; j<c; j++, q++) {
				int xx;
				fscanf(fi, "%d", &xx);
				s[q] = xx;
			}
		
		
		/*for (i=0; i<t; i++)
			printf("%d ", p[i]);
		printf("\n");
		for (i=0; i<q; i++)
			printf("%d ", s[i]);
		printf("\n");*/
		int count = 0;
		int match;
		unsigned char* s1 = s;
		unsigned char* p1 = p;
		int last = 0;
		while ((match=kmp(s1, p1, q, t))>=0) {
			if ((last+match)%c + a <= c) {
				//printf("match %d\n", (last+match));
				count++;
				//printf("red %d, stylb %d\n", (last+match)/c, (last+match)%c);
			}
			s1 = s1 + match+1;
			last+= match+1;
			q = q - (match+1);
		}
		fprintf(fo, "%d\n", count);

	}
}
