var
  fi,fo:text;
  mas:array[1..1000] of byte;
  n,i,k:integer;
  is:boolean;
  Function suits(step:integer):boolean;
           var ans:boolean;
               h,jump:integer;
  begin
       ans:=true;
       for h:=1 to step do
       begin
            jump:=h;
            while jump<=n do
            begin
                 if mas[jump]<>mas[h] then ans:=false;
                 jump:=jump+step;
            end;
       end;
       suits:=ans;
  end;

Procedure solute;
          var i:integer;
begin
     for i:=1 to (n div 2) do
         if suits(i) then begin
                     writeln (fo,i);
                     is:=true;
                     break;
                             end;
         if is=false then begin writeln (fo,'0'); end;
end;

begin
assign(fi,'period.inp');
reset(fi);
assign(fo,'period.out');
rewrite(fo);
            while not eof(fi) do
            begin
                 readln (fi,n);
                 if n<> 0 then
                 begin
                 for k:=1 to n-1 do
                     begin
                     read(fi,mas[k]);
                     end;
                     readln (fi,mas[n]);
                     is:=false;
                     solute;
                 end;
            end;

close(fo);
close(fi);
end.