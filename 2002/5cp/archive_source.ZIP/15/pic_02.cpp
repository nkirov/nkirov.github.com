var
  fi,fo:text;
  a,b,c,d,x1,y1,x2,y2,i,j:integer;
  pic1,pic2:array [0..152,0..152] of byte;
Function similar:boolean;
         var res:boolean;
             st:boolean;
begin
     res:=true;
     for c:=1 to x1 do
         begin
         for d:=1 to y1 do
             if pic1[c,d] <> pic2[c+a-1,d+b-1] then
                begin
                st:=true;
                break;
                res:=false;
                end;
         if st then break;
         end;
     similar:=res;
end;
Procedure solute;
          var br:integer;

begin
     br:=0;
     for a:=1 to x2-x1+1 do
         for b:=1 to y2-y1+1 do
             if pic1[1,1]=pic2[a,b] then
                if similar then br:=br+1;
     writeln (fo,br);
end;

begin
assign(fi,'pic.inp');
reset(fi);
assign(fo,'pic.out');
rewrite(fo);
            while not eof(fi) do
            begin
                 read (fi,x1); read (fi,y1); read (fi,x2); readln (fi,y2);
                 if ((x1<>0) and (x2<>0) and (y1<>0) and (y2<>0)) then
                 begin
                      for i:=1 to y1 do
                      begin
                           for j:=1 to x1-1 do
                           begin
                               read(fi,pic1[j,i]);
                           end;
                               readln (fi,pic1[x1,i]);
                      end;
                      for i:=1 to y2 do
                      begin
                           for j:=1 to x2-1 do
                               read (fi,pic2[j,i]);
                               readln (fi,pic2[x2,i]);
                      end;
                 solute;
                 end;
            end;

close(fo);
close(fi);
end.