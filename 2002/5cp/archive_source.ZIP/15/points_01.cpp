uses
 crt;
var
  fi,fo:text;
  mas:array[1..1000,1..2] of real;
  gr:array[1..100,1..100] of integer;
  n,i,k:integer;
  d:real;

function test(K:word):boolean;
  var
    j,l:integer;
  begin
  test:=true;
  for j:=1 to k-1 do
    begin
    for l:=1 to k do
      if gr[j,l]=k then
        begin
        test:=false;
        break;
        end;
    end;
  end;

function f(K:word):integer;
  var
    j,l:integer;
    oki:boolean;
  begin
  for j:=1 to k-1 do
    begin
    for l:=1 to k do
      if gr[j,l]=k then
        begin
        f:=j;
        break;
        end;
    end;
  end;



procedure dist;
  var
    i,j,l,m,q,q1:integer;
    dis:real;
  begin
  l:=0;
  for i:=1 to n do
    begin
    if test(i) then
      inc(l);
    m:=1;
    gr[l,m]:=i;
    for j:=i+1 to n do
      begin
      dis:=sqrt(sqr(mas[i,1]-mas[j,1])+sqr(mas[i,2]-mas[j,2]));
      if dis<=d then
        begin
        m:=m+1;
{        if test(j) then
          begin
          dec(l);
          q1:=f(j);
          if q1>l then ;
          end;}
        gr[l,m]:=j;
        end;
      end;
    end;
  writeln(fo,l);
  end;

begin
clrscr;
assign(fi,'points.inp');
reset(fi);
assign(fo,'points.out');
rewrite(fo);
while not eof(fi) do
  begin
  read(fi,n);
  if n<> 0 then
    begin
    readln(fi,d);
    for k:=1 to n do
      read(fi,mas[k,1],mas[k,2]);
    readln(fi);
    dist;
    end;
{  for k:=1 to n do
    writeln(mas[k,1]:0:0,' ',mas[k,2]:0:0);}
  end;
close(fo);
close(fi);
end.