program fuuuuck;
const fi='points.inp';
      fo='points.out';
      eps=10e-5;
var f,fout:text;
    d:real;
    n,i,nbr:word;
    p:array[1..1001,1..2] of real;
function dist(a,b:word):real;
begin
  if a=0 then begin dist:=0;exit;end else
  begin
    dist:=sqrt(sqr(p[a,1]-p[b,1])+sqr(p[a,2]-p[b,2]));
  end;
end;
procedure compute;
var i,j:word;
    g:array[1..1001] of word;
    c:array[1..1001] of boolean;
begin
  for i:=1 to n do g[i]:=i;
  fillchar(c,sizeof(c),false);
  for i:=1 to n do
    for j:=1 to n do
      if (dist(i,j) -d) <eps then g[j]:=g[i];
  nbr:=0;
  for i:=1 to n do
    if not c[g[i]] then begin c[g[i]]:=true;inc(nbr);end;
end;
begin
  assign(f,fi);
  reset(f);
  assign(fout,fo);
  rewrite(fout);
  repeat
  read(f,n);
  if n<>0 then begin
    readln(f,d);
    for i:=1 to n do
      read(f,p[i,1],p[i,2]);
      readln(f);
      compute;
      writeln(fout,nbr);
    end;
  until n=0;
  close(f);
  close(fout);
end.