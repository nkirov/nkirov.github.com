#include<stdio.h>
int n;
int arr[1001];
FILE * inp, * out;

void run()
{
	int valid;
	int i,k,j;

	for (int cycleLen=1;cycleLen < (n/2) +1 ; cycleLen++)
	{
		//try cycleLen, if true break from the loop
		// and print result
		i = 0;
		valid = 1;
		while (i<n)
		{
			if (arr[i%cycleLen] != arr[i]) { valid=0;break; }
			i++;
		}
		if (valid) break;
	}
	if (cycleLen == (n/2) + 1) fprintf(out,"0\n"); else fprintf(out,"%d\n",cycleLen);

}


main()
{

  inp = fopen("period.inp","r");
  out = fopen("period.out","w");

  fscanf(inp,"%d",&n);
  while (n)
  {
	for (int i=0;i<n;i++)
		fscanf(inp,"%d",&arr[i]);
	run();
	fscanf(inp,"%d",&n);
  }
}

