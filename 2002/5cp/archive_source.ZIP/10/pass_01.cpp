{$A+,B+,D+,E+,F+,G+,I+,L+,N+,O+,P+,Q+,R-,S+,T+,V+,X+,Y+}
{$M 65520,0,655360}
program fsa;
const fin='pass.inp';
      fout='pass.out';
var a:array[0..1000,1..9] of word;
    en:array[1..1000] of boolean;
    n,m:word;
procedure readinput;
var f:text;
    i,j,k:word;
begin
  fillchar(a,sizeof(a),0);
  fillchar(en,sizeof(en),false);
  assign(f,fin);
  reset(f);
  readln(f,n,m);
  for i:=0 to n-1 do
    begin
      for j:=1 to m do read(f,a[i,j]);
      readln(f);
    end;
  read(f,j);
  for i:=1 to j do begin read(f,k);en[k]:=true;end;
  readln(f);
  close(f);
end;
procedure compute;
type quel=^q;
     q=record
       i:word;
       n:quel;
     end;
var qb,qe:quel;
    i:word;
procedure enq(x:word);
var t:quel;
begin
  new(t);
  t^.i:=x;
  t^.n:=nil;
  if (qb=nil) then
  begin qb:=t;qe:=t;end
  else
  begin qe^.n:=t;qe:=t;end;
end;
function deq:word;
var t:quel;
begin
  t:=qb;
  deq:=t^.i;
  qb:=qb^.n;
  dispose(t);
end;
var flag:boolean;
    k:word;
    pas:array[0..1000] of word;
    ans,ans2:array[1..1000] of word;
    msize,size,j,l:word;
    f:text;
begin
  flag:=false;
  msize:=2000;
  for i:=0 to 1000 do pas[i]:=1001;
  qb:=nil;qe:=nil;
  pas[0]:=0;
  for i:=1 to m do begin enq(a[0,i]);pas[a[0,i]]:=0;end;
  while (qb<>nil)and(not flag) do begin
    k:=deq;
    for i:=1 to m do
      if en[a[k,i]] then begin
        j:=k;
        size:=1;
        ans2[1]:=i;
        while (j<>0) do begin
          inc(size);
          l:=1;while a[pas[j],l]<>j do inc(l);
          ans2[size]:=l;
          j:=pas[j];
        end;
        if size>msize then flag:=false;
        if size<msize then begin msize:=size;ans:=ans2;end;
        if size=msize then begin
          j:=size;
          while (j>1)and(ans[j]=ans2[j]) do dec(j);
          if ans[j]>ans2[j] then ans:=ans2;
        end;
      end else if pas[a[k,i]]=1001 then
      begin
           pas[a[k,i]]:=k;
           enq(a[k,i]);
      end;
  end;
  assign(f,fout);
  rewrite(f);
  i:=0;
  for j:=size downto 1 do begin
    inc(i);
    if i mod 50=0 then writeln(f);
    write(f,ans[j]);
  end;
  close(f);
end;
begin
  readinput;
  compute;
end.