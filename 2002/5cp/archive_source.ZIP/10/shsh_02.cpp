#include<stdio.h>
#include<math.h>

FILE *inp, *out;
int n , votesNeeded,first;
int votes[30];
long long index[30], comb[30],end[30];


long long fact(int x)
{
	if (x<1) return 1;
	else return x * fact(x-1);
}

void gen_komb(int n, int k)
{	

	int i,j,l;
	int votesSoFar;

	for (i=1; i<=k ; i++)
	{
		comb[i] = i;
		end[i] = n - k + i;
	}


	while (1)
	{

		//process combination

		votesSoFar = 0;
		for (i=1;i<=k;i++)
			votesSoFar += votes[comb[i]];

		for (i=1;i<=k;i++)
			if (votesSoFar >= votesNeeded && votesSoFar-votes[comb[i]] < votesNeeded)
				index[comb[i]] += ( fact(k-1) * fact(n-k) );


		/*
		for (i=1;i<=k;i++)
			printf("%d ",comb[i]);
		printf("\n");
		*/

		if (comb[1] == end[1]) break;

		i=k;

		while (i>0 && comb[i] == n-k+i)
			i--;
		if (!i) break;
		comb[i]++;
		for (j=i+1;j<=k;j++)
			comb[j] = comb[j-1] + 1;

	}

}


void run()
{
	long long sum=0;
	double tmp;


	for (int i = 1; i<=n; i++)
	{
		index[i] = 0;
	}

	for (i = 1; i<=n; i++)
		gen_komb(n,i);

	for (i=1; i<=n; i++)
		sum+= index[i];


	for (i=1; i<=n; i++)
	{
		  tmp = ((double)index[i]*100 /(float) sum);
		  int test = (int) ((tmp*=10) + 0.5) ;

		  // printf("%d ",test);
			if (test%10==0) fprintf(out,"%d\n",test/10);
			else fprintf(out,"%0.1lf\n",((double)test)/10.0);
	}

}

main()
{
 inp = fopen("shsh.inp","r");
 out = fopen("shsh.out","w");
 first = 1;


 fscanf(inp,"%d",&n);
 while (n)
 {
	if (first) first=0; else fprintf(out,"\n");
	fscanf(inp,"%d",&votesNeeded);
	for (int i=1; i<=n; i++)
		fscanf(inp,"%d",&votes[i]);
	run();
	fscanf(inp,"%d",&n);
 }

}
