#include<ccc_ansi.h>
int red[10000];
int broi=0;
bool ch(int c)
{
 int br;
 if(!c)br=1; else br=0;
 while(c)
 {
  if(c%2)br++; else br--;
  c/=2;
 }
 return !br;
}

void happy(int a,int b)
{
 for(int c=a;c<=b;c++)if(ch(c)){red[broi]=c;broi++;}
}

void main()
{
 ifstream i("happy.inp");
 ofstream o("happy.out");
 int a,b;
 i>>a>>b;
 while(b)
 {
  happy(a,b);
  if(!broi)o<<"0\n";
  for(int c=0;c<broi;c++)o<<red[c]<<"\n";
  broi=0;
  i>>a>>b;
  if(b)o<<"\n";
 }
}