#include <stdio.h>
#include <string.h>

FILE* fi = fopen("pic.inp", "r");
FILE* fo = fopen("pic.out", "w");

int rL, cL, rB, cB;
char lit[155][155];
char big[1505][1505];

void main()
{
	while(1)
	{
		fscanf(fi, "%d%d%d%d\n", &cL, &rL, &cB, &rB);
		if(rL == 0)
			break;
		int r,c;
		for(r = 0; r < rL; r++)
			for(c = 0; c < cL; c++)
				fscanf(fi, "%d", &lit[r][c]);
		for(r = 0; r < rB; r++)
			for(c = 0; c < cB; c++)
				fscanf(fi, "%d", &big[r][c]);
		int cn = 0;
		for(r = 0; r <= rB - rL; r++)
			for(c = 0; c <= cB - cL; c++)
			{
				int ir;
				for(ir = 0; ir < rL; ir++)
					if(strncmp(lit[ir], &big[r + ir][c], rL) != 0)
						break;
				if(ir == rL)
					cn++;
			}
		fprintf(fo, "%d\n", cn);
	}


	fclose(fi);
	fclose(fo);
}