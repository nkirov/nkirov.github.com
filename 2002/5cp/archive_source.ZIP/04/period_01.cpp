#include <stdio.h>

FILE* fi = fopen("period.inp", "r");
FILE* fo = fopen("period.out", "w");

char a[1005];
int N;

void main()
{
	while(1)
	{
		fscanf(fi, "%d", &N);
		if(N == 0)
			break;
		int i;
		for(i = 0; i < N; i++)
			fscanf(fi, "%d", &a[i]);
		int best = 0;
		for(int p = 1; p <= N / 2; p++)
		{
			for(i = p; i < N; i++)
				if(a[i] != a[i % p])
					break;
			if(i == N) {
				best = p;
				break;
			}
		}
		fprintf(fo, "%d\n", best);
	}
	fclose(fi);
	fclose(fo);
}