#include <iostream>
#include <fstream>
#include <list>
using namespace std;

#define MAXN 1010

struct Point
{
	double x, y;
};

double d;
list<int> g[MAXN];
Point p[MAXN];
int n;
int vis[MAXN];

int group(Point a, Point b)
{
	return (a.x-b.x) * (a.x-b.x) + (a.y-b.y) * (a.y-b.y) <= d * d;
}

void makeGraph()
{
	int i, j;

	for (i = 1; i <= n - 1; i++)
		for (j = i + 1; j <= n; j++)
			if (group(p[i], p[j]))
			{
				g[i].push_back(j);
				g[j].push_back(i);
			}
}

void dfs(int v)
{
	vis[v] = 1;

	for (list<int>::iterator it = g[v].begin(); it != g[v].end(); it++)
		if (!vis[*it])
			dfs(*it);
}

void main()
{
	 int i;
	 int ans;

	 ifstream fin("points.inp");
	 ofstream fout("points.out");
	 while (fin >> n)
	 {
		if (!n) break;
		fin >> d;
		for (i = 1; i <= n; i++)
		  fin >> p[i].x >> p[i].y;

		// init
		for (i = 1; i <= n; i++)
		{
			g[i].clear();
			vis[i] = 0;
		}
		makeGraph();
		ans = 0;

		// sol
		for (i = 1; i <= n; i++)
			if (!vis[i])
			{
				dfs(i);
				ans++;
			}

		fout << ans << endl;
	 }

	 fin.close();
	 fout.close();
}
