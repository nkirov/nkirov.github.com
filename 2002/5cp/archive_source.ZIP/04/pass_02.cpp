#include <vector>
#include <stdio.h>
#include <queue>

using namespace std;

FILE* fi = fopen("pass.inp", "r");
FILE* fo = fopen("pass.out", "w");


typedef vector<int> IntVec;

int N,M;
IntVec fin; //finals
IntVec gr[1005];
bool passed[1005];
int F;
bool final[1005];
int prev[1005];
int dig[1005];


void main()
{
	fscanf(fi, "%d%d", &N, &M);
	int i, j;

	for(i = 0; i < N; i++)
		for(j = 1; j <= M; j++)
		{
			int t;
			fscanf(fi, "%d", &t);
			gr[i].push_back(t);
		}
	fscanf(fi, "%d", &F);
	for(i = 0; i < F; i++)
	{	
		int t;
		fscanf(fi, "%d", &t);
		final[t] = true;
	}
	queue<int> q;
	q.push(0);
	passed[0] = true;
	prev[0] = -1;
	int step = 0;
	int last;
	while(!q.empty())
	{
		int x = q.front();
		//printf("%d\n", x);
		for(i = 0; i < M; i++)
		{
			int y = gr[x][i];
			if(passed[y])
				continue;
			dig[y] = i;
			prev[y] = x;
			if(final[y])
			{
				last = y;
				goto out;
			}
			passed[y] = true;
			q.push(y);
		}
		q.pop();
	}
out:
	if(q.empty())
		fprintf(fo, "0\n");
	else 
	{
		IntVec pat;
		int cur = last;
		while(cur != 0)
		{
//			printf("%d\n", cur);
			pat.push_back(dig[cur]);
			cur = prev[cur];
		}
		int cn = 0;
		for(i = pat.size() - 1; i >= 0; i--)
		{
			cn++;
			fprintf(fo, "%d", pat[i] + 1);
			if(cn % 50 == 0)
				fprintf(fo, "\n");
		}
		if(cn % 50 != 0)
			fprintf(fo, "\n");
		
	}

	fclose(fi);
	fclose(fo);

}












