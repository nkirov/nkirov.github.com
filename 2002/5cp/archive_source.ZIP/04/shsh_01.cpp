#include <fstream.h>
#include <string.h>
#include <stdlib.h>
#include <iostream.h>
#include <stdio.h>
#define inFile "shsh.inp"
#define outFile "shsh.out"
#define MAX 30
#define MAXSUM 3000

int n,sum,min;
int used[MAX];
int c[MAX];
__int64 t[MAXSUM][MAX];
int put[MAXSUM];
__int64 f[MAX];
long double rez[MAX];

ofstream outf(outFile);

void solve() {
    int i,j,k,l, allsum;
	__int64 sum;
	char str[255];

    f[0] = 1;
	f[1] = 1;

	allsum = 0;
	for (i = 1; i <= n; i++)
		allsum += c[i];

	for(i = 2; i < MAX; i++)
		f[i] = i*f[i-1];

	t[0][0] = 1;
	put[0] = 1;
	sum = 0;

	for(l = 1; l <= n; l++) 
	{
		for (i = 0; i <= allsum; i++)
			for (j = 0; j <= n; j++)
				t[i][j] = 0;
		
		t[0][0] = 1;
		sum = 0;

		for(i = 1; i <= n; i++) 
			if(i != l) 
			{
				for(j = allsum; j >= 0; j--)
				  if(j + c[i] <= allsum)
 					for(k = 1; k <= n; k++)
						    t[j + c[i]][k] += t[j][k-1]; 
			}

		//cout << "l=" << l << "," << c[l] << endl;
        
        for(i = min-1; i >= 0; i--)
			if(i + c[l] >= min)
			{
				for(j = 1; j < MAX; j++)
					if (t[i][j])
					{
						sum += (t[i][j] * f[j]) * (f[n - j - 1]);
						//cout << "sum=" << i << " " ;
						//cout << "cl=" << j;
						//cout << " = " << long(t[i][j]) << endl;
					}
			}
			else break;

		rez[l] = sum;
		for(i = 1; i <= n; i++)
			rez[l] /= i;
	    rez[l]*=100;
	}

	for(i = 1; i <= n; i++)
	{
		sprintf(str, "%.1Lf", rez[i]);
		if (str[ strlen(str) - 1] == '0')
			str[ strlen(str) - 2] = 0;
		outf << str << endl;
	}
}

void main() {
	int i,j,k,tc;
	ifstream inf(inFile);

	tc = 0;

	while(inf >> n) {
		sum = 0;
		if(n == 0) break;

		inf >> min;

		for(i = 1; i <= n; i++) {
			inf >> c[i];
			sum += c[i];
		}

		tc++;

		if(tc != 1) outf << endl;
 
		solve();
	}

	inf.close(); 
	outf.close();
}
