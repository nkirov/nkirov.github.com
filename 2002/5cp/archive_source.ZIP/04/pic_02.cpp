#include <stdio.h>
#include <string.h>

FILE* fi = fopen("pic.inp", "r");
FILE* fo = fopen("pic.out", "w");

int rL, cL, rB, cB;
char lit[155][155];
char big[1505][1505];

typedef unsigned int hyper;
const int cMax = 1505 * 1505;

hyper ChHash(unsigned char c)
{
	return c;
}

hyper Rot(hyper x, int r)
{
	r *= 17;
	r %= 32;
	return (x << r) | (x >> (32-r));
}

char s[cMax];
int len;
hyper suff[cMax];

void Build()
{
	for(int r = 0; r < rB; r++)
		strncpy(s + r*cB, big[r], cB);
	len = rB*cB;
	for(r = 0; r < rL; r++)
		strncpy(s + len + r*cL, lit[r], cL);
	len += rL*cL;
	s[len] = 0;
	suff[len] = 0;
	for(int i = len - 1; i >= 0; i--)
		suff[i] = ChHash(s[i]) ^ Rot(suff[i + 1], 1);
}

hyper Hash(int pos, int size)
{
	return suff[pos] ^ Rot(suff[pos + size], size);
}







void main()
{
	while(1)
	{
		fscanf(fi, "%d%d%d%d\n", &cL, &rL, &cB, &rB);
		if(rL == 0)
			break;
		int r,c;
		for(r = 0; r < rL; r++)
			for(c = 0; c < cL; c++)
				fscanf(fi, "%d", &lit[r][c]);
		for(r = 0; r < rB; r++)
			for(c = 0; c < cB; c++)
				fscanf(fi, "%d", &big[r][c]);
		int cn = 0;
		Build();
		for(r = 0; r <= rB - rL; r++)
			for(c = 0; c <= cB - cL; c++)
			{
				int ir;
				for(ir = 0; ir < rL; ir++)
					if(Hash((r + ir) * cB + c, cL) != 
						Hash(cB * rB + ir * cL, cL))
					break;
				if(ir != rL)
					continue;
				for(ir = 0; ir < rL; ir++)
					if(strncmp(lit[ir], &big[r + ir][c], rL) != 0)
						break;
				if(ir == rL)
					cn++;
			}
		fprintf(fo, "%d\n", cn);
	}


	fclose(fi);
	fclose(fo);
}