#include <stdio.h>
#include <vector>
using namespace std;
FILE* fi = fopen("lines.inp", "r");
FILE* fo = fopen("lines.out", "w");

const int cMax = 1005;
int lines;
int lBr[cMax];
typedef vector<int> IntVec;
IntVec gr[cMax * cMax];
IntVec ls[cMax];
int lastGiven;
int res;
bool passed[cMax*cMax];
int ndeg(int node)
{
	int res;
	if(passed[node]) 
		return 0; 
	passed[node] = true;
	res = gr[node].size() % 2;
	for(int i = 0; i < gr[node].size(); i++)
		res += ndeg(gr[node][i]);
	return res;
}

 

void main()
{
	while(1)
	{
		fscanf(fi, "%d", &lines);
		if(lines == 0)
			break;
		int i, j;
		for(i = 1; i <= lines; i++)
			fscanf(fi, "%d", &lBr[i]);
		lastGiven = 0;
		for(i = 1; i <= lines; i++)
			ls[i].clear();
		for(i = 1; i <= lines; i++)
		{
			int ign;
			fscanf(fi, "%d", &ign);
			for(j = 1; j <= lBr[i]; j++)
			{
				int spi;
				int num = -1;
				fscanf(fi, "%d", &spi);
				for(int k = 0; k < spi; k++)
				{
					int t1, t2;
					fscanf(fi, "%d%d", &t1, &t2);
					if(t1 < i)
						num = ls[t1][t2 - 1];
				}
				if(num == -1)
					num = lastGiven++;
				ls[i].push_back(num);
			}
		}
		for(i = 0; i < lastGiven; i++)
			gr[i].clear();
		for(i = 1; i <= lines; i++)
			for(j = 1; j < ls[i].size(); j++) {
				gr[ls[i][j]].push_back(ls[i][j - 1]);
				gr[ls[i][j - 1]].push_back(ls[i][j]);
				//printf("%d %d\n", ls[i][j], ls[i][j - 1]);
			}
		res = 0;
		for(i = 0; i < lastGiven; i++)
			passed[i] = false;
		for(i = 0; i < lastGiven; i++)
			if(!passed[i])
			{
				int k = ndeg(i);
				if(k == 0)
					res++;
				else 
					res += k / 2;
			}
		fprintf(fo, "%d\n", res);
	}

	fclose(fi);
	fclose(fo);
}
