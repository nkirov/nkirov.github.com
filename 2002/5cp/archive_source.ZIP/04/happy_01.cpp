#include <iostream.h>
#include <fstream.h>

#define inFile "happy.inp"
#define outFile "happy.out"
#define MAX 31010

int h[MAX];

int isHappy(int num) {
  int zero,one;

  zero = 0;
  one = 0;

  while(num > 0) {
     if(num%2) one++;
	 else zero++;

     num /= 2;
  }

  return (zero == one)?(1):(0);
}


void main() {
  int i,j,k,c,b,e;

  for(i = 1; i <= 30000; i++)
	  h[i] = isHappy(i);

  ifstream inf(inFile);
  ofstream outf(outFile);

  while(inf >> b >> e) {
	  if(b == 0 && e == 0) break;
      c = 0;

	  for(i = b; i <= e; i++)
		  if(h[i]) {
	 	      outf << i << endl;
			  c = 1;
		  }
	  if(c == 0) outf << 0 << endl;
	  outf << endl;
  }

  inf.close();
  outf.close();
}