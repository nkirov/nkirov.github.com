#include <stdio.h>
#include <string.h>

FILE* fi = fopen("pic.inp", "r");
FILE* fo = fopen("pic.out", "w");

int rL, cL, rB, cB;
char lit[155][155];
char big[1505][1505];
typedef unsigned __int64 hyper;
const int cMax = 1505 * 1505;

const int rotLen[] = {9, 11, 13, 14, 17};
const int rotPos[] = {0, 9, 10, 33, 47};
const hyper rotMask[] = {
			 0x1FF,
	       0xFFE00,
	   0x1FFF00000,
	0x7FFE00000000,
0xFFFF800000000000};
const int rotMul = 31;

hyper ChHash(unsigned char c)
{
	return ((hyper)c << rotPos[0]) | ((hyper)c << rotPos[1]) |
		((hyper)c << rotPos[2]) | ((hyper)c << rotPos[3]) |
		((hyper)c << rotPos[4]);
}

hyper Rot(hyper x, int r)
{
	r *= rotMul;
	return 
		((((x & rotMask[0]) << (r % rotLen[0])) |
		((x & rotMask[0]) >> (rotLen[0] - r % rotLen[0])))
		& rotMask[0]) |
		((((x & rotMask[1]) << (r % rotLen[1])) |
		((x & rotMask[1]) >> (rotLen[1] - r % rotLen[1])))
		& rotMask[1]) |
		((((x & rotMask[2]) << (r % rotLen[2])) |
		((x & rotMask[2]) >> (rotLen[2] - r % rotLen[2])))
		& rotMask[2]) |
		((((x & rotMask[3]) << (r % rotLen[3])) |
		((x & rotMask[3]) >> (rotLen[3] - r % rotLen[3])))
		& rotMask[3]) |
		((((x & rotMask[4]) << (r % rotLen[4])) |
		((x & rotMask[4]) >> (rotLen[4] - r % rotLen[4])))
		& rotMask[4]);
	
	//return (x << r) | (x >> (32-r));
}

char s[cMax];
int len;
hyper suff[cMax];

void Build()
{
	for(int r = 0; r < rB; r++)
		strncpy(s + r*cB, big[r], cB);
	len = rB*cB;
	for(r = 0; r < rL; r++)
		strncpy(s + len + r*cL, lit[r], cL);
	len += rL*cL;
	s[len] = 0;
	suff[len] = 0;
	for(int i = len - 1; i >= 0; i--)
		suff[i] = ChHash(s[i]) ^ Rot(suff[i + 1], 1);
}

hyper Hash(int pos, int size)
{
	return suff[pos] ^ Rot(suff[pos + size], size);
}







void main()
{
	while(1)
	{
		fscanf(fi, "%d%d%d%d\n", &cL, &rL, &cB, &rB);
		if(rL == 0)
			break;
		int r,c;
		for(r = 0; r < rL; r++)
			for(c = 0; c < cL; c++)
				fscanf(fi, "%d", &lit[r][c]);
		for(r = 0; r < rB; r++)
			for(c = 0; c < cB; c++)
				fscanf(fi, "%d", &big[r][c]);
		int cn = 0;
		Build();
		for(r = 0; r <= rB - rL; r++)
			for(c = 0; c <= cB - cL; c++)
			{
				int ir;
				for(ir = 0; ir < rL; ir++)
					if(Hash((r + ir) * cB + c, cL) != 
						Hash(cB * rB + ir * cL, cL))
					break;
/*				if(ir != rL)
					continue;
				for(ir = 0; ir < rL; ir++)
					if(strncmp(lit[ir], &big[r + ir][c], rL) != 0)
						break;
*/				if(ir == rL)
					cn++;
			}
		fprintf(fo, "%d\n", cn);
	}


	fclose(fi);
	fclose(fo);
}