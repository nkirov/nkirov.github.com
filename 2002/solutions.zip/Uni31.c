#include <stdio.h>
#include <stdlib.h>

#define MAX_N 32

int n, v;
int a[MAX_N], b[MAX_N], oldindex[MAX_N], reindex[MAX_N], totalsum;
int o[MAX_N], osum;

int top, bottom;
char used[MAX_N];

int rec( int csum, int starti )
{
   int s;
   int i;

   if ( csum >= bottom )
   {
      if ( csum <= top )
         s = 1;
      else
         return 0;
   }
   else
      s = 0;

   for ( i = starti; i < n; i++ ) if ( !used[i] )
   {
      used[i] = 1;
      s += rec( csum + a[i], i + 1 );
      used[i] = 0;
   }

   return s;
}

int main( void )
{
   int i, j, op, ti, t;
   double d;
   FILE * f, * ff;
   char bNotFirst = 0;

   f = fopen( "uni.in", "r" );
   ff = fopen( "uni31.out", "w" );

   for (;;)
   {
      fscanf( f, "%d", &n );
      if ( n == 0 ) break;
      fscanf( f, "%d", &v );
      totalsum = 0;
      for ( i = 0; i < n; i++ )
      {
         fscanf( f, "%d", a + i );
         b[i] = a[i];
         totalsum += a[i];
         oldindex[i] = i;
      }

      for ( i = 0; i < n - 1; i++ )
      {
         ti = i; t = a[i];

         for ( j = i + 1; j < n; j++ )
         {
            if ( a[j] < t )
            {
               t = a[j];
               ti = j;
            }
         }

         if ( ti != i )
         {
            a[ti] = a[i];
            a[i] = t;
            t = oldindex[i];
            oldindex[i] = oldindex[ti];
            oldindex[ti] = t;
         }
      }

      for ( i = 0; i < n; i++ )
         reindex[ oldindex[i] ] = i;

      osum = 0;
      for ( i = 0; i < n; i++ )
      {
         bottom = v - a[i];
         if ( bottom < 0 ) bottom = 0;
         top = v - 1;

         used[i] = 1;
         if ( totalsum - a[i] >= bottom )
            o[i] = rec( 0, 0 );
         else
            o[i] = 0;
         osum += o[i];
         used[i] = 0;
      }

      if ( bNotFirst ) fprintf( ff, "\n" ); else bNotFirst = 1;

      if ( osum == 0 )
         for ( i = 0; i < n; i++ )
            fprintf( ff, "0\n" );
      else
      {
         for ( i = 0; i < n; i++ )
         {
            d = o[ reindex[i] ]*100; d /= osum; d += 0.5;
            op = d;
            fprintf( ff, "%d\n", op );
         }
      }
   }

   fclose(f);
   fclose(ff);

   return 0;
}
