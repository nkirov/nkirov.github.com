#include <iostream.h>
#include <stdlib.h>
#include <fstream.h>
#include <math.h>
#include <limits.h>
#include <iomanip.h>

int x[10],y[10];
double d[10][10];
int N = 10;
typedef char set[12];
set s;


double dist(int x1,int x2,int y1,int y2)
{
 return sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
}

double ps(int v, set s)
{
 double m,t;
 m = INT_MAX;
 for(int i=1; i<=N; i++)
 if(s[i]!= '0')
 {
  s[i] = '0';
  t = d[v-1][i-1] + ps(i,s);
  s[i]='0'+i;
  if(t<m) m=t;
 }
if(m == INT_MAX) m=d[v-1][0];
return m;
}

ifstream fin("lan.in");
ofstream fout("lan41.out");

int main()
{
do
{
 fin>>N;
 if(N>0)
 {
 int i=0,j=0;
 for(i=0; i<N; i++) fin>>x[i]>>y[i];
 for(i=0; i<N; i++)
  for(j=0; j<N; j++)
           d[i][j]= dist(x[i],x[j],y[i],y[j]);

 s[0] ='0';
 s[1] ='0';
 for(i=2; i<=N; i++) s[i]= '0'+i;
 s[N+1]='\0';
 double res;
 res = ps (0,s);
 res *= 1000;
 res = int(res);
 res /= 1000;
 fout << res << endl;
  }}
while(N>0);
return 0;
}
