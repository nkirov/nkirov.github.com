#include <stdio.h>
#include <fstream>

int s(int n)
{
int sum=0,a=n;
sum+=(int)(a/10000);
a%=10000;
sum+=(int)(a/1000);
a%=1000;
sum+=(int)(a/100);
a%=100;
sum+=(int)(a/10);
a%=10;
sum+=a;
return sum;
}

int n1=0,n=0,min=0,N=0;

int main()
{
  ifstream ifile("div.in");
  ofstream ofile("div92.out");
  do
    {
    ifile>>N;
    if (N>0)
      {
      min=10000;
      for (int n2=1;n2<=(int)(10000/N);n2++)
        {
        n1=n2*N;
        if ((int)(n1/n2)==N)
          if (s(n1)==s(n2))
            {
            n=n1-n2;
            if (n<min)
              min=n;
            }
        }
      if (min!=10000)
        ofile<<min<<endl;
      else
        ofile<<'*'<<endl;
      }
    }
  while (N>0);
  return 0;
}
