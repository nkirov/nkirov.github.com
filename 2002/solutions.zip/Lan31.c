#include <stdio.h>
#include <math.h>

#define MAX_N 20

typedef struct { int x, y; } CPoint;

int n;
CPoint net[MAX_N];

double bestdist;
double dist[MAX_N][MAX_N];
double cdist;
char used[MAX_N];
char path[MAX_N];

void rec( int level )
{
   int i;

   if ( level == n )
   {
      if ( ( bestdist == -1 ) || ( cdist < bestdist ) )
         bestdist = cdist;
      return;
   }

   if ( ( bestdist != -1 ) && ( cdist >= bestdist ) ) return;

   for ( i = 0; i < n; i++ ) if ( !used[i] )
   {
      used[i] = 1;
      path[level] = i;
      if ( level ) cdist += dist[i][ path[level - 1] ];
      rec( level + 1 );
      if ( level ) cdist -= dist[i][ path[level - 1] ];
      used[i] = 0;
   }
}

int main( void )
{
   FILE * f, * t;
   int i, j;
   double d;
//   char bNotFirst = 0;

   f = fopen( "lan.in", "r" );
   t = fopen( "lan31.out", "w" );

   for (;;)
   {
      fscanf( f, "%d", &n );
      if ( n == 0 ) break;
      for ( i = 0; i < n; i++ )
         fscanf( f, "%d %d", &net[i].x, &net[i].y );

      for ( i = 0; i < n - 1; i++ )
         for ( j = i + 1; j < n; j++ )
         {
            d = sqrt( (net[i].x - net[j].x)*(net[i].x - net[j].x) +
                      (net[i].y - net[j].y)*(net[i].y - net[j].y) );
            dist[i][j] = dist[j][i] = d;
         }

      bestdist = -1;
      cdist = 0;
      rec(0);

//      if ( bNotFirst ) fprintf( t, "\n" ); else bNotFirst = 1;
      bestdist = ((double) (int) (bestdist*1000))/1000;
      fprintf( t, "%.3lf\n", bestdist );
   }

   fclose(t);
   fclose(f);

   return 0;
}
