#include <stdio.h>

#define MAX_N 128

int n;
long long zz[MAX_N];
char calced[MAX_N];

long long calc( int n )
{
   long long r;
   if ( calced[n] ) return zz[n];

   if ( n == 0 ) return 1;
   r = 0;
   if ( n >= 1 )
   {
      r += calc( n - 1 );
      r *= 2;
   }
   if ( n >= 2 ) r += calc( n - 2 );
   if ( n >= 3 ) r += calc( n - 3 );

   calced[n] = 1;
   zz[n] = r;
   return r;
}

int main( void )
{
   FILE * f, * t;
   int i;

//   f = fopen( "count.in", "r" );
//   t = fopen( "count31.out", "w" );

   calc(100);
   for ( i = 0; i <= 100; i++ )
      printf( "%lld\n", zz[i] );

/*   while ( fscanf( f, "%d", &n ) != EOF )
   {
      fprintf( t, "%ld\n", calc(n) );
   }

   fclose(t);
   fclose(f);*/

   return 0;
}
