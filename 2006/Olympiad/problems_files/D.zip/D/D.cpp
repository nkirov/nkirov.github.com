#include<iostream>
using namespace std;

const int S=10000;
bool a[2*S*S+1];

int main()
{
 for(int x=0;x<=S;x++)
 for(int y=0;y<=x;y++)
  a[x*x+y*y]=true; 
  
 int t; cin >> t; 
 for(int i=1;i<=t;i++)
 {
  int s; cin >> s;
  int c=0;
  for(int k=1;k<=s; k++)
   if(a[k]) c++;
  cout << c << endl;
 }
}
