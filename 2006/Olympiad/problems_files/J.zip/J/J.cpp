#include <stdio.h>
//#include <fstream.h>
//ifstream in ("test.txt");
//ofstream out ("out.txt");
static unsigned short a[10000001],p[13000];
main()
{
//	long *a;
//	long *p;
	int x;
	int af = 0, al = 0, i, f = 1, l, br = 0;
	int best, n, k;
	scanf("%d",&x);
	for (int d = 1; d <= x; d++)
	{
   af = 0;al = 0;f = 1;br = 0;
   scanf("%d %d",&n,&k);
//	a = new long[n+1];
//	p = new long[k+1];
	for (i = 1; i <= k; i++)
	{
		p[i] = 0;
	}
	best = n;
	for (i = 1; i <= n; i++)
	{ 
		scanf("%d",&a[i]);
	}
	i = 1;
	while (br < k)
	{
		if (!p[a[i]]) br++;
		l = i;
		p[a[i]]++;
		i++;
	}
	af = f;
	al = l;
	while (f <= n-k && l <= n)
	{
		while (p[a[f]] > 1)
		{
			p[a[f]]--;
			f++;
		}
		if (best > l-f+1)
		{
			best = l-f+1;
			af = f;
			al = l;
		}
		if (best == k)
			break;
		l++;
		if (l <= n)
			p[a[l]]++;
	}
	printf("%d %d\n",af,al);
	}
//	delete p;
//	delete a;
}
