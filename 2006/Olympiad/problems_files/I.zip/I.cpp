// I.cpp
#include<iostream>
#include <fstream>
using namespace std;

class Rect {
public:
  Rect();
  Rect(int, int);
  ~Rect();
  void read();
  int HD(const Rect&) const;     
private:
  int m, n;
  int* a;  
  int ext(int, int) const;
  int dist(int, int) const;
};    

Rect::Rect()
{  m = n = 0; a = NULL;  }

Rect:: Rect(int mm, int nn)
{  m = mm; n = nn;
   a = new int[m*n];
   if (!a) { cout << "memory" << endl; exit(1); }
}

Rect::~Rect()
{  delete a; }

void Rect::read()
{ for (int i = 0; i < m*n; i++) cin >> a[i];  } 

int Rect::ext(int i, int j) const
{ if(i < 0 || i >= m || j < 0 || j >= n) return 0;
  else return a[i*n + j];
}      

int Rect::dist(int i, int j) const
{ int k, i1, i2, j1, j2;
  for (k = 1; k < 1000; k++) 
  {  j1 = j - k; j2 = j + k;
     for (i1 = i - k; i1 <= i + k; i1++)
         if ((ext(i1,j1) == 1) || (ext(i1,j2) == 1)) return k;

     i1 = i - k; i2 = i + k;
     for (j1 = j - k; j1 <= j + k; j1++)
           if ((ext(i1,j1) == 1) || (ext(i2,j1) == 1)) return k;  
  }
  return k;
}

int Rect::HD(const Rect& r) const
{ int result1 = 0, result2 = 0, res;
  for (int i = 0; i < m; i++)
     for (int j = 0; j < n; j++)
  {  if (a[i*n + j] != r.a[i*n + j])
    {  if (r.a[i*n + j] == 1)
       { res = dist(i, j);
         if (res > result1) result1 = res;
       }
       else
       { res = r.dist(i, j);
         if (res > result2) result2 = res;
       }
    }
  }

  int result = (result1 > result2) ? result1 : result2;
  return result;
}

int main()
{ int m, n;
  while (cin >> m >> n && m > 0 && n > 0)
  { Rect r(m, n);
    r.read();    
    Rect s(m, n);
    s.read();
    cout << r.HD(s) << endl;    
  }     
  return 0;
}    
