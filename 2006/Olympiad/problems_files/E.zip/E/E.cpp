#include<iostream>
using namespace std;

const int N=200;
const int B=2000;

int t[N+1][B+1];
int n,b;


int main()
{
  n=N;
  b=B;
  for(int j=1;j<=b;j++) 
   if(j%2==0) t[1][j]=(j/2)*(j/2);
   else t[1][j]=(j/2)*(j/2+1);
   
   for(int i=2;i<=n;i++)
   for(int j=1;j<=b;j++) 
   {
    int s=0;
    for(int k=1;k<j;k++)
    { int v=t[i-1][j-k]+k*(j-k);
      if(v>s)s=v;
    } 
   t[i][j]=s;         
   }   
   
   int K; cin >> K;
   for(int k=1;k<=K;k++)
   {
    cin >> n >> b;
   
   //for(int i=1;i<=n;i++)
   //{ cout << endl;
   //  for(int j=1;j<=b;j++) cout << t[i][j] << " ";
   //}
   
   //cout << "res=";
   cout << t[n][b] << endl;
   //system("pause");
   }
}

