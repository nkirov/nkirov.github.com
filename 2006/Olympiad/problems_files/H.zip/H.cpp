// H.cpp
#include <iostream>
using namespace std;

int main()
{ int n;
  cin >> n;
  for (int i=0; i<n; i++)
  {  int num;
     cin >> num;     
     int x, xmin, xmax;
     cin >> x;
     xmin = xmax = x; 
     for (int j=1; j<num; j++)
     {  cin >> x;
        if (x < xmin) xmin = x;
        if (x > xmax) xmax = x;
     }    
     cout << xmin << " " << xmax << endl;
  }     
  return 0;
}      
