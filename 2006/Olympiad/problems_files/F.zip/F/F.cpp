#include <stdio.h>
#define MAXN 1001
#define MAXM 100001
double g[MAXN][MAXN],c[MAXM];int e[MAXM][2];
int N,M; double xm,ym,r,lr; int edgem;

void explore(int edge)
{
     double a[MAXN],b[MAXN],x[MAXN],y[MAXN],tmp;
     
     int i,j,k; double tb,tx,ty;
     i=e[edge][0];j=e[edge][1];
     for(k=1;k<=N;k++) 
     {a[k]=g[i][k];b[k]=g[j][k]+c[edge];}
     for(i=N-1;i>=1;i--)
        for(j=1;j<=i;j++)
           if(a[j]<a[j+1]||(a[j]==a[j+1]&&b[j]<b[j+1]))
           {tmp=a[j];a[j]=a[j+1];a[j+1]=tmp;
            tmp=b[j];b[j]=b[j+1];b[j+1]=tmp;
           }                  
     for(k=1;k<=N;k++){x[k]=(b[k]-a[k])/2.;y[k]=(b[k]+a[k])/2.;}
//for(k=1;k<=N;k++) printf("%8.4lf %8.4lf %8.4lf %8.4lf\n",a[k],b[k],x[k],y[k]);    
     if(a[1]<ym){ym=a[1];xm=0.;edgem=edge;}
//printf("1 %8.4lf %8.4lf\n",xm,ym);     
     tb=b[1];tx=x[1];ty=y[1];
     for(k=2;k<=N;k++)
     {
        if(x[k]<tx||(-x[k]+tb>=y[k])) continue;
        if((y[k]-x[k]+tb)/2<ym)
        {ym=(y[k]-x[k]+tb)/2;xm=x[k]-(y[k]+x[k]-tb)/2;edgem=edge;}
        tb=b[k];tx=x[k];ty=y[k];
//printf("%d %8.4lf %8.4lf\n",k,xm,ym);                         
     }
}
main()
{
     int i,j,k,t,T;
   scanf("%d",&T);
   for(t=1;t<=T;t++)
   {
     scanf("%d %d",&N,&M);
     for(i=1;i<=N;i++)
     {
        for(j=1;j<=N;j++) g[i][j]=2000000000.;
        g[i][i]=0.;
     }
     
     for(i=1;i<=M;i++)
     {
        scanf("%d %d %lf",&e[i][0],&e[i][1],&c[i]);
        g[e[i][0]][e[i][1]]=g[e[i][1]][e[i][0]]=c[i];                 
     }
     for(k=1;k<=N;k++)
        for(i=1;i<=N;i++)
           for(j=1;j<=N;j++)
              if(g[i][k]+g[k][j]<g[i][j])
                 g[i][j]=g[j][i]=g[i][k]+g[k][j];
        
/*for(i=1;i<=N;i++)
{
   for(j=1;j<=N;j++) 
      printf("%5.2lf ",g[i][j]);
      printf("\n");
   }
*/
   xm=0.;ym=2000000000.;
   for(i=1;i<=M;i++)explore(i);
   printf("%.4lf\n",ym);
}
}


