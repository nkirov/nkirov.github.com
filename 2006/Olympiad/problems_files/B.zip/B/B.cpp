#include<iostream>
using namespace std;

const int M=101;
string s[M];
int m;

const int N=101;
int a[N];
int n;

//char p[10][5]=
//{{' '}, {' '},     {'A','B','C'},{'D','E','F'},
// {'G','I','J'},    {'J','K','L'},{'M','N','O'},
// {'P','Q','R','S'},{'T','U','V'},{'W','X','Y','Z'}};
//int len[10]={0,1,3,3,3,3,3,4,3,4};

int letter[28]={0,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,7,8,8,8,9,9,9,9};

bool eq(int n, int a[], int b[])
{
 for(int i=1;i<=n;i++) 
  if(a[i]!=b[i]) return false;
 return true;    
};

void find(int n, int c[])
{
 //for(int i=1;i<=n;i++) cout << c[i];  
 int v[101];
 for(int i=1;i<=m;i++)
 if(s[i].size()==n)
 {
   for(int j=0;j<n;j++) v[j+1]=letter[(int)s[i][j]-(int)'A'+2];        
   if(eq(n,v,c)) {cout << s[i]; return;}      
 }   
 for(int i=1;i<=n;i++) cout << '*';
 
}


void input()
{
  cin >> m;
//  cout << "m=" << m << endl;
  for(int i=1;i<=m;i++) cin >> s[i];
//  for(int i=1;i<=m;i++) cout << s[i] << endl;
   cin >> n;
//  cout << "n=" << n << endl;
  for(int i=1;i<=n;i++) cin >> a[i];  
//  for(int i=1;i<=n;i++) cout << a[i];
//  cout << endl;  
}

void run()
{
  input();
  int k=0;
  int p[101];
  for(int i=1;i<=n;i++)
   {// cout << "a[i]=" << a[i] << endl;
    if(a[i]==1){find(k,p);k=0;cout << " ";}
    else {k++;p[k]=a[i];}
   } 
   if(a[n]!=1) find(k,p);   
}

int main()
{
 int t;
 cin >> t;   
 for(int i=1;i<=t;i++) {run(); cout << endl;}  
}
