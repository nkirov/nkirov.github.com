/* 
  reshava samo po edin primer - vinagi zav'rshva s exit(0)
*/
#include <iostream>
#include <iomanip>
#define MAXX 1000
using namespace std;

int k, num;
int a[MAXX]; 

int nonz[MAXX]; // positions of nonzero elements of a
int nonzeros;   // number of nonzero elements of a

int mp[MAXX]; // combinations with repetition (real indexes in a)
int s;

void print(int*);

void calc(int len)
{  int ss = 0; 
   for (int i=0; i<len; i++) ss += mp[i];
   ss %= k;
   if (ss != s) return;  // no chanse!
   
   int mm[MAXX] = {0};
   for (int i=0; i<len; i++) mm[mp[i]]++; 
// number of elements needed to realize ss == s
   
   for (int j=0; j<k; j++)
      if (a[j] < mm[j]) return; // no enough elements of a[j]
      
   cout << num - len << endl;  // sucsess !!
   exit(0);
}     

bool nextC(int mpm[], int len, int hi)
{  for (int i = len; --i >=0; )
      if (mpm[i] < hi)
      {  for (mpm[i++]++; i < len; ++i)
            mpm[i] = mpm[i-1];
         return true;
       }      
    return false;   
}  

void combo(int len)
{ int mpm[MAXX];   // combinations with repetition 1..nonzeros
  for (int i=0; i<len; i++) 
  { mpm[i] = 1; mp[i] = 1; }
  bool b;
  int i;
  do 
  {  int pp = 0;
     for (i=0; i<len; i++)
     {  mp[i] = nonz[mpm[i]-1]; // invert 1..nonzeros to real indexes of a
     }         
  
     calc(len);
     b = nextC(mpm, len, nonzeros); // len elements in [1..nonzero]     
  }  while (b);      
}
   
void make()
{  if (a[s] != 0) 
   { cout << num - 1 << endl;  exit(0); }   
   for (int i = 2; i < k; i++) combo(i);          
}

void print(int* a)
{  for (int j=0; j<k; j++) cout << setw(3) << j << " ";
   cout << endl;
   for (int j=0; j<k; j++) cout << setw(3) << a[j] << " "; 
   cout << endl;
}

int main()
{  cin >> num >> k;  // samo edin primer !!!!
   {  int summ = 0;
      s = 0;
      for (int j=0; j<k; j++) a[j] = 0;
      for (int j=0; j<num; j++)
      {  int temp;
         cin >> temp;
         a[temp%k]++;
         s += temp%k;
         if (summ <= k) summ += temp;
      }      
      
      s = s%k;    
      if (summ < k) cout << "0" << endl; 
      else if (s == 0) cout << num << endl;    
      else 
      {  nonzeros = 0;
         for (int i=1; i<k; i++) 
           if (a[i] != 0) 
         {  nonz[nonzeros] = i; nonzeros++;  }
         make();
      }   
   }
   return 0;
}      
