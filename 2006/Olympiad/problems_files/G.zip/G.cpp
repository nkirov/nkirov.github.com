// G.cpp
#include <iostream>
#define MAXX 20
using namespace std;

int a[3];
unsigned long F[MAXX][MAXX][MAXX][3] = {0};
// 0 - coord1, 1 - coord2, 2 - coord3, 

void calc()
{ // F[a[0]][a[1]][a[2]][0] = 1;
  // 1-dim 
  F[a[0]-1][a[1]][a[2]][0] = 1; //1. coord
  F[a[0]][a[1]-1][a[2]][1] = 1;
  F[a[0]][a[1]][a[2]-1][2] = 1;

  // 2-dim
  for (int i0=a[0]-1; i0>=0; i0--)    // 1-2
    for (int i1=a[1]-1; i1>=0; i1--)
  { F[i0][i1][a[2]][0] = F[i0+1][i1][a[2]][1];
    F[i0][i1][a[2]][1] = F[i0][i1+1][a[2]][0];                 
  }   
  for (int i1=a[1]-1; i1>=0; i1--)    // 2-3
    for (int i2=a[2]-1; i2>=0; i2--)
  { F[a[0]][i1][i2][1] = F[a[0]][i1+1][i2][2];
    F[a[0]][i1][i2][2] = F[a[0]][i1][i2+1][1];                 
  }   
  for (int i2=a[2]-1; i2>=0; i2--)    // 3-1
    for (int i0=a[0]-1; i0>=0; i0--)
  { F[i0][a[1]][i2][2] = F[i0][a[1]][i2+1][0];
    F[i0][a[1]][i2][0] = F[i0+1][a[1]][i2][2];                 
  }  
  
  // 3dim
  for (int i0=a[0]-1; i0>=0; i0--)    // 1-2-3
    for (int i1=a[1]-1; i1>=0; i1--) 
       for (int i2=a[2]-1; i2>=0; i2--)      
  {  F[i0][i1][i2][0] = F[i0+1][i1][i2][1] + F[i0+1][i1][i2][2];
     F[i0][i1][i2][1] = F[i0][i1+1][i2][0] + F[i0][i1+1][i2][2];
     F[i0][i1][i2][2] = F[i0][i1][i2+1][0] + F[i0][i1][i2+1][1];
  }        
}     

int main()
{ while (cin >> a[0] >> a[1] >> a[2])
  { for (int i0=0; i0 <= a[0]; i0++)
      for (int i1=0; i1 <= a[1]; i1++)
        for (int i2=0; i2 <= a[2]; i2++)
            for (int j=0; j<3; j++) F[i0][i1][i2][j] = 0;
    calc();     
    long sum = F[0][0][0][0] + F[0][0][0][1] + 
               F[0][0][0][2];
       
    cout << sum << endl;     
  } 
  return 0;  
}    
