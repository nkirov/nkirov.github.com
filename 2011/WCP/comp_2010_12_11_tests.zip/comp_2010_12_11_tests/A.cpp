#include <iostream>
using namespace std;
int a1,a2,a3,a4;
int run()
{ int sum,min;

  cin>>a1;
  min=a1;
  sum=a1;

  cin>>a2;
  if(a2<min) min=a2;
  sum = sum + a2;

  cin>>a3;
  if(a3<min) min=a3;
  sum = sum + a3;

  cin>>a4;
  if(a4<min) min=a4;
  sum = sum + a4;

  sum = sum - min;
  cout<<sum+1<<endl;
}  

int main()
{
  int nt;
  cin >> nt;
  for(int i=1;i<=nt;i++) run();

}

