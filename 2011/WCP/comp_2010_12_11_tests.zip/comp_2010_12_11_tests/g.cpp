#include <cstdlib>
#include <iostream>

using namespace std;

#define MAX 10

void countFreq(unsigned int freq[MAX])
{
    for (int i = 0; i < MAX; i++)
    {
        freq[i] = 0;
    }
    while (true)
    {
        char next_char;
        cin.get(next_char);
        if (next_char == '\n')
        {
            break;
        }
        freq[(next_char - '0')]++;
    }
}

void outputMin(unsigned int freq[MAX])
{
    for (int i = 1; i < MAX; i++)
    {
        for (int j = freq[i]; j > 0; j--)
        {
            cout << i;
        }
    }    
}

void outputMax(unsigned int freq[MAX])
{
    for (int i = MAX - 1; i > 0; i--)
    {
        for (int j = freq[i]; j > 0; j--)
        {
            cout << i;
        }
    }
    for (int j = freq[0]; j > 0; j--)
    {
        cout << 0;
    }
}

inline void minMaxPrint()
{
    unsigned int freq[MAX];
    countFreq(freq);
    outputMin(freq);
    cout << " ";
    outputMax(freq);
    cout << endl;        
}

int main()
{    
    int numb;
    cin >> numb;
    char dummy;
    cin.get(dummy);
    for (int i = 0; i < numb; i++)
    {
        minMaxPrint();
    }
    return 0;
}
