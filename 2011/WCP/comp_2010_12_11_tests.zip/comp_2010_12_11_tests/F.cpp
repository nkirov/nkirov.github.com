#include<iostream>
using namespace std;

int n;
struct{int ax,ay,bx,by;}p[1001];
short int c[1001][1001];

int run()
{
  for(int i=0;i<=1000;i++)
  for(int j=0;j<=1000;j++)
   c[i][j]=0;
   
  cin >> n;
  for(int i=1;i<=n;i++)
   {
    cin >> p[i].ax >> p[i].ay >> p[i].bx >> p[i].by;
    if(p[i].ax>p[i].bx)swap(p[i].ax,p[i].bx);
    if(p[i].ay>p[i].by)swap(p[i].ay,p[i].by);
   }
  for(int i=1;i<=n;i++)
  for(int j=1;j<=n;j++)
  if(p[i].ax==p[i].bx)
  if(p[j].ay==p[j].by)
  if((p[j].ax<=p[i].ax)&&(p[i].ax<=p[j].bx)&&(p[i].ay<=p[j].ay)&&(p[j].ay<=p[i].by))
   c[p[i].ax][p[j].ay]=1;

  int k=0;
  for(int i=0;i<=1000;i++)
  for(int j=0;j<=1000;j++)
  k += c[i][j];

  cout << k << endl;

}

int main()
{
  int nt; cin >> nt;
  for(int i=1;i<=nt;i++) run ();
}
