#include <cstdlib>
#include <iostream>

using namespace std;

#define ABS(x) x < 0 ? -x : x

void polygonArea()
{
    double x_prev;
    cin >> x_prev;
    double y_prev;
    cin >> y_prev;
    double x_first = x_prev;
    double y_first = y_prev;
    double sum = 0.0;
    while (true)
    {
        char test;
        cin.get(test);
        if (test == '\n')
        {
            break;
        }
        cin.unget();
        double x_curr;
        cin >> x_curr;
        double y_curr;
        cin >> y_curr;
        sum += (x_curr - x_prev) * (y_curr + y_prev);
        x_prev = x_curr;
        y_prev = y_curr;
    }
    sum += (x_first - x_prev) * (y_first + y_prev);
    sum = ABS(sum);
    sum /= 2;
    
    cout << sum;
}

int main()
{
    int numb;
    cin >> numb;
    char dummy;
    cin.get(dummy);
    for (int i = 0; i < numb; i++)
    {
        polygonArea();
        cout << endl;    
    }
    return 0;
}
