#include<cstdio>

const int N_max=1001;
int n;
int a[N_max], b[N_max];
int d[N_max];

int run()
{
  scanf("%d",&n);
  for(int i=1;i<n-1;i++) scanf("%d%d", &a[i], &b[i]);
  scanf("%d",&a[n-1]);

  d[1]=0;
  d[2]=a[1];
  for(int i=3;i<=n;i++)
  {
   int v1 = d[i-1]+a[i-1];
   int v2 = d[i-2]+b[i-2];
   d[i] = v1 < v2 ? v1 : v2;
  }
  
//  for(int i=1;i<=n;i++) printf("%d ",d[i]);
// printf("\n");
  printf("%d\n",d[n]);
}

int main()
{ int nt; scanf("%d",&nt);
  for(int i=1;i<=nt;i++) run ();
}
