#include <stdio.h>
int G[1001][1001];

int main(int argc, char* argv[])
{
   int i,j,k,b,e,t,T,N,M;
   
   FILE *in = fopen(argv[1],"r");
   FILE *ou  = fopen(argv[2],"r");
   if(ou==NULL) {printf("No output!\n");return 1;} 
   fscanf(in,"%d",&T);
for(t=1;t<=T;t++)
{   
   fscanf(in,"%d %d",&N,&M);
//   printf("%d %d %d\n",N,M,T);
   for(i=1;i<=N;i++)
      for(j=1;j<=N;j++) G[i][j]=0;
   for(i=1;i<=M;i++)         
   {   fscanf(in,"%d %d",&b,&e);
       G[b][e]=G[e][b]=1;
   }
   if(fscanf(ou,"%d",&i)==0) {printf("Empty output!\n");return 1;}
   for(k=1;k<=2*M;k++)
   { if(fscanf(ou,"%d",&j)==0) {printf("Short output!\n");return 1;}
//     printf("%d %d %d\n",k,i,j); 
     if(G[i][j]==0) {printf("Wrong edge %d %d!\n",i,j);return 1;}
     G[i][j]=0; i=j;
   }
  //printf("End of test %d\n",t);
}
   printf("Accepted!\n"); return 0;
}
