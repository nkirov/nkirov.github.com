#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

int main()
{
   int  I,N,Dir,Len,brt;
   double X,Y,X0,Y0, Distance, Sq2;
   Sq2 = 1.0/sqrt(2);    
   cin >> brt;
   for(int j=0; j<brt; j++){
    cin >> X0 >> Y0;
    X=X0; Y=Y0;
    cin >> Dir >> Len;
    while(Dir > 0)
    {
     switch(Dir)
          {
           case 1:
                  Y += Len; 
                  break;
           case 2:
                  X += Len *Sq2;
                  Y += Len *Sq2;
                  break;
           case 3:
                  X += Len;
                  break;
           case 4:
                  X += Len *Sq2;
                  Y -= Len *Sq2;
                  break;
           case 5:
                  Y -= Len;
                  break;
           case 6:
                  X -= Len *Sq2;
                  Y -= Len *Sq2;
                  break;
           case 7:
                  X -= Len;
                  break;
           case 8:
                  X -= Len *Sq2;
                  Y += Len *Sq2;
                  break;     
          }         
     cin >> Dir >> Len;
    } 
   Distance = sqrt((X-X0)*(X-X0)+(Y-Y0)*(Y-Y0));
   printf("%.2f\n",Distance);
  }
     return 0;
}
