#include <iostream>
using namespace std;

unsigned int cubs(int x, int y, int z, int l)
{
    unsigned int cc = 4*(x+y+z+l-2)*(l-1) + 2*(x*y + x*z + y*z);
    return cc;
}


void solve(int num)
{
    int sub;
    int min = num + 1;
    int minV = num*num;
    int minX = 0, minY = 0, minZ = 0;

    if (num%2)
    {
        cout << "-1" << endl;
        return;
    }

    for (int x = 1; x <= min/4; ++x)
    {
        for (int y = 1; y <= x; ++y)
        {
            for (int z = 1; z <= y; ++z)
            {
                int l = 1;
                sub = num;
                while (sub > 0)
                {
                    sub -= cubs(x, y, z, l);
                    ++l;
                }
                if (sub == 0)
                {
                    int S = cubs(x, y, z, 1);
                    int V = x*y*z;
//                    cout << x << 'x' << y << 'x' << z << "\t\t"
//                         << "S=" << S << "\tV=" << V << endl;

                    if (min >= S)
                    {
                        min = S;
                        if (minV > V)
                        {
                            minX = x; minY = y; minZ = z; minV = V;
                        }
                    }
                }
            }
        }
    }
    if (min <= num)
    {
        cout << minX << 'x' << minY << 'x' << minZ << endl;
    }
    else
    {
        cout << "-1" << endl;
    }
}

int main()
{
    int total;
    int N;

    cin >> total;
    while (total--)
    {
        cin >> N;
        solve(N);
    }
    return 0;
}
