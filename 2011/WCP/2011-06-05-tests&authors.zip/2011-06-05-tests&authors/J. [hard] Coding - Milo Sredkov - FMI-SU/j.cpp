#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cstdlib>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"
typedef long long hyper;

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

const int MAXL = 1000*1000;
const int MAXM = 30*1000;

struct Query {
	int S;
	int K;
	int L;
	
	void check(int N) const {
		assert(S >= 0 && S < N);
		assert(K >= 1 && K < N);
		assert(L >= 1 && S + (L - 1) * K < N);
	}
};

vector<int> slow(vector<bool> const& a, vector<Query> const& queries) {
	vector<int> res;
	//DEBV(a);
	REP(qi, queries.size()) {
		Query const& q = queries[qi];
		//DEBT(q.S); DEBT(q.K); DEB(q.L);
		int count = 0;
		REP(i, q.L) {
			//DEB(q.S + i * q.K);
			//DEB(a[q.S + i * q.K]);
			if(a[q.S + i * q.K]) ++count;
		}
		//DEB(sum);
		res.push_back(count);
	}
	//DEBV(res);
	return res;
}

vector<int> solve(vector<bool> const& a, vector<Query> const& qs) {
	const int N = a.size();
	const int KP = (int)sqrt(N) / 49 + 1;

	// precompute
	vector<vector<int> > sums(KP, vector<int>(N));
	REP(k, KP) REP(i, N) {
		sums[k][i] = (a[i] ? 1 : 0) + (i >= k ? sums[k][i - k] : 0);
	}

	vector<int> res;
	REP(qi, qs.size()) {
		Query const& q = qs[qi];
		if(q.K < KP) {
			int to = sums[q.K][q.S + (q.L - 1) * q.K];
			int from = q.S >= q.K ? sums[q.K][q.S - q.K] : 0;
			res.push_back(to - from);
		}
		else {
			int sum = 0;
			REP(i, q.L) sum += a[q.S + i * (q.K)];
			res.push_back(sum);
		}
	}
	return res;
}

template<class T> bool in(T a, T b, T c) {
	return a <= b && b <= c;
}

bool get_bit(char hex, int index) {
	assert(in('0', hex, '9') || in('a', hex, 'f'));
	assert(in(0, index, 3));
	int hv;
	if(in('0', hex, '9')) hv = hex - '0';
	else if(in('a', hex, 'f')) hv = hex - 'a' + 10;
	else assert(false);
	//big endian!
	return (hv & (1 << (3 - index))) ? true : false;
}

void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	
	string mode = "both";
	if(argc >= 2 && string("fast") == argv[1]) mode = "fast";
	if(argc >= 2 && string("slow") == argv[1]) mode = "slow";
	
	string as;
	int M;
	while(cin >> as >> M) {
		int L = as.size();
		assert(M > 0 && M <= MAXM);
		assert(L > 0 && L <= MAXL);
		int N = L * 4;
		vector<bool> a(N);
		REP(i, N) a[i] = get_bit(as[i / 4], i % 4);
		
		vector<Query> qs(M);
		REP(i, M) {
			Query& q = qs[i];
			cin >> q.S >> q.K >> q.L;
			q.check(N);
		}
		vector<int> res = mode == "slow" ? slow(a, qs) : solve(a, qs);
		REP(i, res.size()) cout << res[i] << (i < (int)res.size() - 1 ? " " : "\n");
		if(mode == "both" && (hyper)N * M < 1000 * 1000) {
			vector<int> sr = slow(a, qs);
			assert(sr == res);
		}
	}
	return 0;
}

template<class T>
vector<T> operator,(vector<T> const& a, T const& b) {
	vector<T> res = a;
	res.push_back(b);
	return res;
}

int rnd(int mod) {
	assert(mod > 0);
	hyper res = rand() | (hyper)rand() << 10 | (hyper)rand() << 20;
	assert(res >= 0);
	return res % mod;
}

int rnd2(int mod) {
	const int M = 1000 * 1000 * 1000;
	double ln = log(mod);
	double p = (rnd(M) * 1.0 / M);
	p = p * p * ln;
	double res = exp(p);
	//int sq = (int)sqrt(mod);
	//int t = rnd(sq);
	//int res = t*t;
	//res += rnd(min(sq, mod - res));
	int r = (int)res;
	//DEBT(mod); DEBT(res); DEB(r);
	assert(r < mod && r >= 0);
	
	return r;
}

void out(vector<bool> const& a, vector<Query> const& qs) {
	assert(a.size() % 4 == 0);
	string to_hex = "01234567890abcdef";
	int L = a.size() / 4;
	string as(L, '-');
	REP(i, L) {
		int hv = 0;
		REP(j, 3) hv |= (a[i * 4 + j] ? 1 : 0) << (3 - j);
		as[i] = to_hex.at(hv);
	}
	int M = (int)qs.size();
	assert(in(1, L, MAXL));
	assert(in(1, M, MAXM));
	cout << as << " " << M << "\n";
	REP(i, M) {
		Query const& q = qs[i];
		q.check(L * 4);
	    cout << q.S << " " << q.K << " " << q.L;
	    cout << (i < M - 1 ? " " : "\n");
	}

}

Query mq(int s, int k, int l) {
	Query res = {s, k, l};
	return res;
}

vector<bool> genv(int N) {
	vector<bool> res;
	REP(i, N) res.push_back(rnd(2) ? true : false);
	return res;
}

vector<Query> genq(int N, int M) {
	vector<Query> res;
	REP(i, M) {
		Query q;
		do {
			q.S = rnd(N);
			q.K = rnd2(N);//rnd(2) == 0 ? rnd2(N) : rnd(min(N - 1, 20)) + 1;
			// s + k * (l-1) <= n-1
			// k * (l-1) <= n-1-s
			// l-1 <= (n-1-s) / k
			// l < (n-1-s) / k + 2
			int lim = (N-1-q.S) / q.K + 1;
			q.L = rnd(lim) + 1;
		} while(q.S + q.K * (q.L - 1) >= N);
		//DEBT(N); DEBT(q.S); DEBT(q.K); DEB(q.L);
		
		res.push_back(q);
	}
	return res;
}

vector<bool> to_bin(string const& bin) {
	vector<bool> res(bin.size());
	REP(i, res.size()) res[i] = bin[i] == '1' ? true : false;
	return res;
}

void generate() {
	out(to_bin("01101100"), (vector<Query>(), 
		mq(0, 1, 2), //1
		mq(0, 2, 3), //2
		mq(0, 1, 6), //4
		mq(2, 1, 4), //3
		mq(2, 3, 2) //2
	));

	REP(t, 100) out(genv(8), genq(8, 10));
	REP(t, 20) out(genv(80), genq(80, 100));
	REP(t, 5) out(genv(800), genq(800, 1000));
	REP(t, 5) out(genv(10*1000), genq(10*1000, 10*1000));
	REP(t, 3) out(genv(100*1000), genq(100*1000, 30*1000));
	REP(t, 5) out(genv(1000*1000), genq(1000*1000, 30*1000));
}

// P=slices; g++ -Wall -O2 $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > $P.out && cat $P.out
// P=slices; g++ -Wall -O2 $P.cpp -o $P && ./$P gen > $P.in && time ./$P fast < $P.in > $P.out && time ./$P slow < $P.in > $P.out && time ./$P < $P.in > $P.out 
