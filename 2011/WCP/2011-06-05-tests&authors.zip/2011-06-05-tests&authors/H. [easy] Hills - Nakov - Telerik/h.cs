﻿using System;
using System.IO;

class Hills
{
    static void Main()
    {
		string nStr = Console.ReadLine();
		int n = Int32.Parse(nStr);
		for (int testIndex = 0; testIndex < n; testIndex++)
		{
			string testLine = Console.ReadLine();
			string[] pointsStr = testLine.Split(' ');
			int[] points = new int[pointsStr.Length];
			for (int i = 0; i < pointsStr.Length; i++)
			{
				points[i] = Int32.Parse(pointsStr[i]);
			}
			int marshes = CountMarshes(points);
			int hills = CountHills(points);
			int plateaus = CountPlateaus(points);
			int valleys = CountValleys(points);
			Console.WriteLine(marshes + " " + hills + " " + plateaus + " " + valleys);
		}
    }

    private static int CountMarshes(int[] points)
    {
        int marshesCount = 0;
        for (int i = 1; i < points.Length - 1; i++)
        {
            if (points[i] < points[i - 1] && points[i]==points[i+1])
            {
                for (; i < points.Length - 1; i++)
                {
                    if (points[i] < points[i + 1])
                    {
                        marshesCount++;
                        break;
                    }
                    else if (points[i] > points[i + 1])
                    {
                        break;
                    }
                }
            }
        }

        return marshesCount;
    }

    private static int CountPlateaus(int[] points)
    {
        int plateausCount = 0;

        for (int i = 1; i < points.Length - 1; i++)
        {
            if (points[i] > points[i - 1] && points[i] == points[i + 1])
            {
                for (; i < points.Length - 1; i++)
                {
                    if (points[i] > points[i + 1])
                    {
                        plateausCount++;
                        break;
                    }
                    else if (points[i] < points[i + 1])
                    {
                        break;
                    }
                }
            }
        }

        return plateausCount;
    }

    private static int CountValleys(int[] points)
    {
        int valleysCount = 0;
        for (int i = 1; i < points.Length - 1; i++)
        {
            if (points[i] < points[i - 1] && points[i] < points[i + 1])
            {
                valleysCount++;
            }
        }
        return valleysCount;
    }

    private static int CountHills(int[] points)
    {
        int hillsCount = 0;
        for (int i = 1; i < points.Length - 1; i++)
        {
            if (points[i] > points[i - 1] && points[i] > points[i + 1])
            {
                hillsCount++;
            }
        }
        return hillsCount;
    }
}
