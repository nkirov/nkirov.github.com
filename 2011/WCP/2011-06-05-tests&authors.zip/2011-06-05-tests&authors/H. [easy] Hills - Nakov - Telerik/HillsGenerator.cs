﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

class HillsGenerator
{
    static void Main()
    {
        Random rnd = new Random();

        StreamWriter writer = new StreamWriter("../../../hills.in.generated");
        using (writer)
        {
            for (int n = 0; n < 100; n++)
            {
                int count = rnd.Next(5, 100001);
                int[] numbers = new int[count];
                for (int i = 0; i < count; i++)
                {
                    if (rnd.Next(3) == 1)
                    {
                        numbers[i] = rnd.Next(-100, 100);
                    }
                }

                for (int i = 0; i < count-1; i++)
                {
                    writer.Write(numbers[i]);
                    writer.Write(" ");
                }
                writer.WriteLine(numbers[count-1]);
            }
        }
    }
}
