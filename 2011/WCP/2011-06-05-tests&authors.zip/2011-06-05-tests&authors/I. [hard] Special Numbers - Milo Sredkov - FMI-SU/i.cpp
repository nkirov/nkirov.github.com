#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <map>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"
typedef long long hyper;
typedef unsigned long long uhyper;

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

const hyper MAXV = (hyper)1e18;
const hyper MAXD = 18;

hyper dig_sum(hyper x) {
	hyper res = 0;
	while(x > 0) {
		res += x % 10;
		x /= 10;
	}
	return res;
}

hyper slow(const hyper K, const hyper F, const hyper T) {
	hyper B = F;
	if(B % K != 0) B += (K - B % K);
	hyper res = 0;
	for(hyper x = B; x <= T; x += K) {
		if(dig_sum(x) % K == 0) ++res;
	}
	return res;
}

//mv[val_mod][dig_mod]
typedef vector<vector<hyper> > ModVec;

map<hyper, map<hyper, ModVec> > mem;
ModVec const& mod_counts(hyper K, hyper T) {
	//DEBT(K); DEB(T);
	assert(T >= -1 && K > 0);
	ModVec& res = mem[K][T];
	if(res.size() > 0) return res;
	res = ModVec(K, vector<hyper>(K, 0));
	if(T <= 9) {
		REP(x, T+1) ++res[x % K][x % K];
	}
	else {
		//e.g. 5678
		hyper fs = 1; //the significe of the first digit
		while((uhyper)fs * 10 <= (uhyper)T) fs *= 10;
		assert(fs <= T && (uhyper)fs * 10 > (uhyper)T);
		hyper fd = T / fs; //first digit
		//DEBT(fd); DEB(fs);
		if(fd < 1) {
			DEBT(T); DEBT(fs); DEB(fd);
		}
		assert(fd >= 1 && fd <= 9);
		
		ModVec sv = mod_counts(K, fs-1);
		// (0,1,2,3,4)(000..999)
		REP(d, fd) {
			hyper voff = d * fs;
			REP(vm, K) REP(dm, K) {
				res[(voff + vm) % K][(d + dm) % K] += sv[vm][dm];
			}
		}
		
		// and the remaining 5(000..678)
		{
			ModVec nv = mod_counts(K, T - (fd) * fs);
			hyper voff = fd * fs;
			REP(vm, K) REP(dm, K) {
				res[(voff + vm) % K][(fd + dm) % K] += nv[vm][dm];
			}
		}
	}
	return res;
}

hyper solve(hyper K, hyper F, hyper T) {
	if(K > MAXD * 10) return F == 0 ? 1 : 0;
	return mod_counts(K, T)[0][0] - mod_counts(K, F-1)[0][0];
}

void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	
	string mode = "both";
	if(argc >= 2 && string("fast") == argv[1]) mode = "fast";
	if(argc >= 2 && string("slow") == argv[1]) mode = "slow";
		
	hyper K, F, T;
	while(cin >> K >> F >> T) {
		assert(K > 0 && K <= MAXV);
		assert(F >= 0 && F <= MAXV);
		assert(T >= F && T <= MAXV);
		
		//DEBT(K); DEBT(F); DEB(T);

		hyper res = mode == "slow" ? slow(K, F, T) : solve(K, F, T);
		cout << res << "\n";
		if(mode == "both" && T < 100 * 1000 * 1000) {
			//DEBT(K); DEBT(F); DEB(T);
			//DEB(res);
			hyper sr = slow(K, F, T);
			assert(sr == res);
		}
	}
	return 0;
}



hyper rnd(hyper mod) {
	assert(mod > 0);
	hyper res = 0; rand();
	REP(i, 7) res ^= (hyper)rand() << (10 * i);
	return (res % mod + mod) % mod;
}

template<class T>
vector<T> operator, (vector<T> const& a, T const& b) {
	vector<T> res = a;
	res.push_back(b);
	return res;
}


void out(hyper K, hyper F, hyper T) {
	//DEBT(K); DEBT(F); DEB(T);
	assert(K > 0 && K <= MAXV);
	assert(F >= 0 && F <= MAXV);
	assert(T >= F && T <= MAXV);
	cout << K << " " << F << " " << T << "\n";
}

void generate() {
	out(1, 0, 9);
	out(1, 10, 14);
	out(2, 0, 9);
	out(3, 0, 999);
	//14 (308, 407, 506, 605, 704, 803, 902, 2090, 2299, 2398, 2497, 2596, 2695, 2794)
	out(11, 300, 2800);
	
	//K=12: 0, 48, 84, 156, 192, 228, 264, 336, 372, 408, 444, 480, 516, 552, 624, 660, 732, 804, 840, 888, 912, 996
	out(12, 0, 10); //1
	out(12, 10, 19); //0
	out(12, 48, 84); //2
	out(12, 47, 84); //2
	out(12, 49, 84); //1
	out(12, 0, 84); //3
	out(12, 0, 83); //2
	out(12, 0, 85); //3
	out(12, 0, 1000); //22
	
	//K=58: 0, 8988898, 9797998, 9899788, 9998968, 
	// 16998988, 17888998, 18799888, 18979978, 18989896, 19689898, 19798996, 19869988, 19898698, 19976998, 19997878, 19999966, 
	// 25979998, 26997898, 26999986, 27699988, 27889996, 27989698, 28589998, 28798798, 28897978, 28978888, 28999768, 29787988, 
	// 29799994, 29868898, 29889778, 29894998, 29899696, 29977996, 29988958, 29996788, 29998876, 29999398, 
	// 35897998, 35999788, 36889798, 36988978, 36998896, 37698898, 37878988, 37899868, ...
	out(58, 10000000, 20000000); //12
	out(58, 20000000, 30000000); //22
	out(100, 0, 100*1000*1000); //1
	out(100, 1, 100*1000*1000); //0
	
	//extremal
	{
		vector<hyper> ext;
		ext = (ext, 0LL, 1LL, 2LL, 3LL, 4LL, 5LL, 6LL, 7LL, 8LL);
		for(uhyper t = 10; t < (uhyper)MAXV; t *= 10) {
			ext = (ext, (hyper)t-1, (hyper)t, (hyper)t+1);
		}
		ext = (ext, MAXV-2, MAXV-1, MAXV);
		
		REP(t, 100) {
			hyper K, F, T;
			do {
				K = ext[rnd(ext.size())];
				F = ext[rnd(ext.size())];
				T = ext[rnd(ext.size())];
			} while(F > T || K == 0);
			out(K, F, T);
		}
	}
	
	vector<hyper> lims;
	lims = (lims, (hyper)10e2, (hyper)10e3, (hyper)10e6, (hyper)10e12, MAXV);
	REP(li, lims.size()) {
		hyper lim = lims[li];
		REP(t, 25) {
			hyper F = rnd(lim + 1);
			hyper T = rnd(lim + 1);
			if(F > T) swap(F, T);
			hyper K = rnd(4) ? rnd(MAXD * 10) + 1 : rnd(lim) + 1;
			out(K, F, T);
		}
	}
}

// P=special; g++ -Wall -O2 $P.cpp -o $P && ./$P gen > $P.in && time ./$P fast < $P.in > $P.out && time ./$P slow < $P.in > $P.out && time ./$P < $P.in > $P.out && cat $P.out
