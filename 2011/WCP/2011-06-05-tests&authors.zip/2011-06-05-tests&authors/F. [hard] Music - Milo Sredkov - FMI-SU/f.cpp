#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <cstdlib>
#include <stack>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"
typedef long long hyper;
typedef unsigned long long uhyper;

template<class T> inline bool in(T a, T b, T c) {
	return a <= b && b <= c;
}
 
#define DEBV(v) { \
		typeof(v) vc = v; \
		cerr << #v << ": "; \
		REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
		cerr << "\t at " << __LINE__ << endl; \
	}
 
#define DEBVC(v) { \
		typeof(v) vc = v; \
		cerr << #v << ": "; \
		REP(i, min((int)vc.size(), 100)) cerr << (int)vc[i] << " "; \
		cerr << "\t at " << __LINE__ << endl; \
	}
 
const int MAXL = 100*1000*1000;
 
//0  1  2  3  4  5  6  7  8  9  10  11
//A  A# B  C  C# D  D# E  F  F#  G  G#
char codes[256] = {-1};
bool init() {
	codes['A'] = 0;
	codes['B'] = 2;
	codes['C'] = 3;
	codes['D'] = 5;
	codes['E'] = 7;
	codes['F'] = 8;
	codes['G'] = 10;
	return true;
};
bool invoke_init = init();
//next token 0..11  - tone, '(', ')', 'x', 'e', moves the pointer
char next(string const& s, int& p) {
	while(s[p] == ' ') ++p;
	if(s[p] == '\0') return 'e';
	char c = s[p++];
	if(in('A', c, 'G')) {
		int res = codes[(int)c];
		assert(in(0, res, 11));
		if(s[p] == '#') {
			//no B# and E#
			assert(res != 2 && res != 7);
			++res;
			++p;
		}
		return res;
	}
	if(c == '(' || c == ')' || c == 'x') return c;
	assert(false);
	return -1;
}
 
void decode(string const& s, int& p, vector<char>& out) {
	stack<int> os; // open brackets
	for(char t = next(s, p); t != 'e'; t = next(s, p)) {
		//DEBT(s); DEBT(t); DEB(p);
		if(in<char>(0, t, 11)) out.push_back(t);
		else if(t == '(') os.push(out.size());
		else if(t == ')') {
			assert(!os.empty());
			int pb = os.top();
			os.pop();
			int pe = out.size();
 
			char t3 = next(s, p);
			assert(t3 == 'x');
 
			int x = 0;
			while(in('0', s[p], '9')) {
				x *= 10;
				x += s[p] - '0';
				++p;
			}
			assert(x >= 2);
			out.reserve(out.size() + pe - pb + 5);
			REP(i, x - 1) {
				out.insert(out.end(), out.begin() + pb, out.begin() + pe);
			}
		} else assert(false);
	}
	assert((int)out.size() <= MAXL);
	assert((int)out.size() >= 2);
}


const hyper BASE = 313;
int matches(vector<char> const& text, vector<char> const& pat) {
	int res = 0;
	hyper ph = 0;
	const int N = pat.size();
	const int M = text.size();
	REP(i, N) ph = ph * BASE + pat[i];
	hyper th = 0;
	hyper head = 1;
	REP(i, N) head *= BASE;
	//DEB(head);
	//DEB(ph);
	REP(i, M) {
		th = th * BASE + text[i];
		if(i >= N) th -= head * text[i - N];
		if(i >= N - 1 && th == ph) ++res;
		//DEBT(i); DEB(th);
	}
	//DEBVC(text);
	//DEBVC(pat);
	//DEB(res);
	return res;
}
 
 
int slow(string const& sa, string const& sb) {
	vector<char> da, db;
	int pa = 0;
	decode(sa, pa, da);
	assert(pa == (int)sa.size());
	assert(in(2, pa, MAXL));
	int pb = 0;
	decode(sb, pb, db);
	assert(pb == (int)sb.size());
	assert(in(2, pb, MAXL));
 
	int res = 0;
	REP(tr, 12) {
		REP(i, db.size()) db[i] = (db[i] + 1) % 12;
		res += matches(da, db);
	}
	return res;
}
 
int solve(string const& sa, string const& sb) {
	vector<char> da, db;
	int pa = 0;
	decode(sa, pa, da);
	//DEBT(sa); DEBT(sa.size()); DEB(pa);
	//DEB(da.size());
	assert(pa == (int)sa.size());
	assert(in(2, pa, MAXL));
	int pb = 0;
	decode(sb, pb, db);
	assert(pb == (int)sb.size());
	assert(in(2, pb, MAXL));
 
	REP(i, da.size() - 1) da[i] = (da[i + 1] - da[i] + 12) % 12;
	da.pop_back();
	REP(i, db.size() - 1) db[i] = (db[i + 1] - db[i] + 12) % 12;
	db.pop_back();
	int res = matches(da, db);
	return res;
}
 
void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
 
	string mode = "both";
	if(argc >= 2 && string("fast") == argv[1]) mode = "fast";
	if(argc >= 2 && string("slow") == argv[1]) mode = "slow";
 
	string as;
	string bs;
	while(getline(cin, as)) {
		bool ok = getline(cin, bs);
		assert(ok);
		assert(in<int>(2, as.size(), MAXL));
		assert(in<int>(2, bs.size(), MAXL));
 
		//Test
		if(false) {
			DEBT(as);
			DEB(bs);
			vector<char> at;
			int atp = 0;
			decode(as, atp, at);
			DEB(at.size());
			DEBVC(at);
			//REP(i, at.size()) cerr << (int)at[i] << (i < at.size() - 1 ? " " : "\n");
			vector<char> bt;
			int btp = 0;
			decode(bs, btp, bt);
			DEB(bt.size());
			DEBVC(bt);
			//REP(i, bt.size()) cerr << (int)bt[i] << (i < bt.size() - 1 ? " " : "\n");
		}
 
		int res = mode == "slow" ? slow(as, bs) : solve(as, bs);
		cout << res << "\n";
		if(mode == "both") {
			//DEBT(K); DEBT(F); DEB(T);
			//DEB(res);
			hyper sr = slow(as, bs);
			if(sr != res) {
				DEBT(as); DEBT(bs); DEBT(res); DEB(sr);
			}
			assert(sr == res);
		}
	}
	return 0;
}

hyper rnd(hyper mod) {
	assert(mod > 0);
	hyper res = 0; rand();
	REP(i, 7) res ^= (hyper)rand() << (10 * i);
	return (res % mod + mod) % mod;
}

vector<string> split(string whole) {
	istringstream si(whole);
	vector<string> res;
	string t;
	while(si >> t) res.push_back(t);
	return res;
}

string gen(int len, vector<string> parts) {
	string res;
	REP(i, len) res += parts[rnd(parts.size())];
	return res;
}

void out(string a, string b) {
	cout << a << "\n";
	cout << b << "\n";
}

string ws() {
	return rnd(5) == 0 ? " " : "";
}

string make(vector<string> const& notes, int fl, int rp, int rcl) {
	if(rnd(100) < rp) {
		// (some notes)xN  some notes
		ostringstream so;
		so << ws() << "(" << make(notes, fl, rp, rcl) << ")";
		so << ws() << "x" << rnd(rcl) + 2 << ws();
		return so.str() + make(notes, fl, rp, rcl);
	} else {
		// some notes or
		string res;
		int len = rnd(fl) + 1;
		REP(i, len) res += ws() + notes[rnd(notes.size())];
		return res;
	}
}
 
void generate() {

	// some sample manual
	///*
	out("A A# B C C# D D# E F F# G G#", "A# B C C# D D# E F F# G G# A"); //1
	out("(A B C)x10 D (E F G)x10", "A# C C#"); //11
	
	out("(EFEFGG)x2 AGAGFF GFGFEE", "(EFEFGG)x2 AGAGFF GFGFEE"); //1
	out("(EFEFGG)x2 AGAGFF GFGFEE", "ABC"); //0
	out("(EFEFGG)x2 (AG)x2 FF GFGFEE", "((EF)x2 GG)x2 AGAGFF GFGFEE"); //1
	out("(EFEFGG)x2 AGAGFF GFGFEE", "BCD"); //1
	out("(EFEFGG)x2 AGAGFF GFGFEE", "BC"); //4
	//*/
	
	vector<string> all = split("A A# B C C# D D# E F F# G G#");
	vector<string> four = split("A C D# F#");
	vector<string> two = split("A D#");
	
	// some random without repeats
	///*
	REP(t, 50) out(gen(36, all), gen(3, all));
	REP(t, 50) out(gen(36, four), gen(3, four));
	REP(t, 50) out(gen(36, two), gen(3, two));
	REP(t, 50) out(gen(36, all), gen(2, all));
	
	
	REP(t, 50) out(gen(2, all) + make(all, 24, 40, 6), 
			gen(2, all) + make(all, 2, 10, 2));

	REP(t, 50) out(gen(2, four) + make(four, 24, 40, 6), 
			gen(2, four) + make(four, 2, 10, 2));

	REP(t, 50) out(gen(2, two) + make(two, 24, 40, 6), 
			gen(2, two) + make(two, 2, 10, 2));
	//*/
	
	// some large manual
	out("(A B C)x1000 D (E F G)x1000", "A# C C#"); //1001
	out("((A B C)x1000)x1000 D ((E F G)x1000)x1000", "A# C C#"); //1000001
	out("((A B C)x1000)x15000 D ((E F G)x1000)x15000", "A# C C#"); //15000001

	out("G ((A B C)x10000 D)x3000 D ", "(A B C)x9000 D"); //3000
	out("B ((BF)x10000 B)x3000 B ", "(CF#CF#)x4500"); //6006000

	//TODO: more tests
	
 
}
 
// P=music; g++ -Wall -O2 $P.cpp -o $P && ./$P gen > $P.in && time ./$P fast < $P.in > $P.out && time ./$P slow < $P.in > $P.out && time ./$P < $P.in > $P.out && cat $P.out
/*

http://forum.muzikant.org/index.php?/topic/27054-ieea-iiy-iaii/
Мила моя мамо:
	Ми Фа Ми Фа Сол Сол
	Ми Фа Ми Фа Сол Сол
	Ла Сол ла Сол Ф Фа
	Сол Фа Сол Фа Ми Ми
	
	(EFEFGG)x2 AGAGFF GFGFEE


Тръгнал кос:
	Сол Ми ми
	Фа Ре Ре
	До Ре Ми Фа Сол Сол Сол
	Сол Ми ми
	Фа Ре Ре
	До Ми Сол Сол До До До
	Ре Ре Ре Ре Ре Ми Фа
	Ми Ми Ми Ми Ми Фа Сол
	Сол Ми Ми
	Фа Ре Ре
	До Ми Сол Сол До До До 
	
	GEE FDD CDEFGGG GEE FDD CEGGCCC DDDDDEF EEEEEFG GEE FDD CEGGCCC
	
	
Зеленчуци който не яде:

	ми-сол-ми-сол- ла сол фа ми ре,
	ре-фа-ре-фа- сол фа ми ре до.
	ми-сол-ми-сол- ла сол фа ми ре,
	си--ла сол фа ми ре до.
	
	EGEGAGFED DFDFGFEDC EGEGAGFED B AGFEDC
	
*/
