#include <cstdio>
#include <algorithm>
#define MAXN 1001
#define INF 2000000000
using namespace std;
typedef struct {int id;double x;double y;double tn;} point;
int p[MAXN],f[MAXN],d[MAXN],used[MAXN],N,M,pivot;
point a[MAXN];
int g[MAXN+1][MAXN+1],m[MAXN+1][MAXN+1];

int left_turn(int p1, int p2, int p3)
{
    double x=(a[p3].x-a[p2].x)*(a[p1].y-a[p2].y)-(a[p3].y-a[p2].y)*(a[p1].x-a[p2].x);
    if(x<=0) return 0; else return 1;   
}

int find_convex()
{   int i,len;
    p[0]=0; p[1]=1;len=1;
    for(i=2;i<=N;i++)
    {  if(left_turn(p[len-1],p[len],i))
       {  do len--; while (left_turn(p[len-1],p[len],i)); }
       p[++len]=i;
    }
    return len;
}

int find_pivot()
{   int i,pi=0;
    for(i=1;i<N;i++)
       if(a[i].x<a[pi].x||a[i].x==a[pi].x&&a[i].y<a[pi].y) pi=i;
    return pi;      
}
bool ang_cmp(point p, point q)
{   double d1=p.x-a[pivot].x, d2=p.y-a[pivot].y;
    double d3=q.x-a[pivot].x, d4=q.y-a[pivot].y;
    if(p.tn==q.tn) return d1*d1+d2*d2<d3*d3+d4*d4;          
    else return p.tn>q.tn;
}

void dijkstra()
{
    int i,j,v,w,min,minv;
    for(i=1;i<=N-1;i++)
    {
      min=INF;minv=0;
      for(v=1;v<=N;v++)
         if((used[v]!=1)&&(d[v]<min)) {min=d[v];minv=v;}
      v=minv;used[v]=1;
      for(j=1;j<=g[v][0];j++)
      {  w=g[v][j];
         if(used[w]==0)
            if(d[w]>d[v]+m[v][w]) {d[w]=d[v]+m[v][w];f[w]=v;}
      }    
    }   
}

int main()
{
  
    int i,j,ti,b,e,w; double td;
    int t,T;
  scanf("%d",&T);
  for(t=1;t<=T;t++)
  {    
    scanf("%d %d",&N,&M);
    for(i=1;i<=N;i++)
    {  a[i-1].id=i;scanf("%lf %lf",&a[i-1].x,&a[i-1].y);
       g[i][0]=0; used[i]=0;d[i]=INF;
       for(j=1;j<=N;j++) m[i][j]=INF; m[i][i]=0;
       
    }
    for(i=1;i<=M;i++)
    {  scanf("%d %d %d",&b,&e,&w);
       g[b][++g[b][0]]=e;g[e][++g[e][0]]=b;
       m[b][e]=m[e][b]=w;
    } 
    pivot=find_pivot();
    for(i=0;i<N;i++)
    {  if(a[i].x==a[pivot].x) 
       { if(a[i].y>a[pivot].y) a[i].tn=(double)INF;
         else a[i].tn=(double)-INF; 
       }  
       else a[i].tn=(a[i].y-a[pivot].y)/(a[i].x-a[pivot].x);
    }
    ti=a[0].id;a[0].id=a[pivot].id;a[pivot].id=ti; 
    td=a[0].x;a[0].x=a[pivot].x;a[pivot].x=td;
    td=a[0].y;a[0].y=a[pivot].y;a[pivot].y=td;
    td=a[0].tn;a[0].tn=a[pivot].tn;a[pivot].tn=td;
    sort(a+1,a+N,ang_cmp);
//for(i=0;i<N;i++) printf("%d %lf\n",a[i].id,a[i].tn);    
    a[N].id=a[0].id;a[N].x=a[0].x;a[N].y=a[0].y;
    j=find_convex();
    for(i=0;i<=j;i++)
    {  f[a[p[i]].id]=0;d[a[p[i]].id]=0; }
    f[0]=-1;used[0]=1;dijkstra(); 
    for(i=1;i<=N;i++)
    {  if(f[i]==0) continue;
       j=i; while(f[j]!=0)j=f[j];
       printf("%d %d\n",i,d[i]);   
    }
  }
  return 0;         
}
