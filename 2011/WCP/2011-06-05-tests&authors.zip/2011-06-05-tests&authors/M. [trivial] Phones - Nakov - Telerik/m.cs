﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

class Phones
{
    static void Main()
    {
        while (true)
        {
            string phone = Console.ReadLine();
            if (phone == "end")
            {
                return;
            }
            string fixedPhone = Regex.Replace(phone, "[^0-9+]", "");
            if (!fixedPhone.StartsWith("+"))
            {
                fixedPhone = "+359" + fixedPhone.Substring(1);
            }
            Console.WriteLine(fixedPhone);
        }
    }
}
