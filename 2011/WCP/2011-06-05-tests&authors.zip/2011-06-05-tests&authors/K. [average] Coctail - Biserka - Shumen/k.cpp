#include<iostream>
#include<cstdio>
using namespace std;

int n,k,p,br,res,br2;
int a[100100];

int main()
{
    int i, tests;
    scanf("%d",&tests);
    while(tests--)
    {
	scanf("%d%d%d",&n,&k,&p);
	for(i=0;i<n;i++) scanf("%d",&a[i]);
	for(i=0;i<k-1;i++) if(a[i]>a[k-1])br++;
	res=n-1-br-p;
	if(res<0)res=0;
	for(i=k;i<n;i++)
	{
	    if(a[i]<a[k-1]&&res>0)br2++;
	    if(a[i]>=a[k-1])res--;
	}
	printf("%d\n",k-br+br2);
	br2 = 0, br = 0, res = 0;
    }
    return 0;
}
