#include <iostream>
using namespace std;
int a[128][128],used[128],deg[128],n,k,b,cnt[128],m;
void init()
{
  int i,j;
  b=0;
  for(i=0;i<128;i++)
    for(j=0;j<128;j++)
      a[i][j]=1;
    for(i=0;i<128;i++){used[i]=0;cnt[i]=0;deg[i]=0;}
}
void read()
{
  int j,i,x,y;
  cin>>n>>m;
  if(m!=0)
  for(i=0;i<=n;i++)deg[i]=n+2;
  for(i=1;i<=m;i++)
  {
    cin>>x>>y;
    a[x][y]=a[y][x]=0;
    deg[x]--;
    deg[y]--;
  }
 for(i=0;i<=n;i++)
 if(deg[i]==0)used[i]=255;
}
void dfs(int i, int c)
{
  int j;
  used[i]=c;
  for(j=0;j<=n;j++)
  {
    if(a[i][j]&&!used[j])
    dfs(j,c);
  }
}

void mark()
{
  int i;
  for(i=0;i<=n;i++)
    if(!used[i])
  {
    b++;
    dfs(i,b);
  }
}
void solve()
{
  int i,j,counter=0;
  mark();
  for(i=0;i<=n;i++)
    if(deg[i]%2)cnt[used[i]]++;
    //cout<<used[i]<<endl;
  for(i=1;i<=b;i++)
  if(cnt[i]==0)
  counter++;
  else
  counter+=(cnt[i]/2);
  cout<<counter<<endl;
}

int main()
{
  int i;
  cin>>k;
  for(i=1;i<=k;i++)
  {
    init();
    read();
    if(m==0) cout<<1<<endl;
    else solve();
  }
  return 0;
}