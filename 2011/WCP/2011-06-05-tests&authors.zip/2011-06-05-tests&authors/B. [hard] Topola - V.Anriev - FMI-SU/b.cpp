#include <stdio.h>
#include <string.h>
#include <math.h>
#include <vector>
#include <map>
using namespace std;

bool stupid = false;
typedef long long ll;
map<int, int> primitive_c;

const int MAXN = 10000000;

vector<pair<int, int> > factorize(int x)
{
	vector<pair<int, int> > res;
	int d = 2;
	while (d * d <= x) {
		int c = 0;
		while (x % d == 0) {
			c++;
			x /= d;
		}
		if (c)
			res.push_back(make_pair(d, c));
		d++;
	}
	if (x > 1 || res.empty())
		res.push_back(make_pair(x, 1));
	return res;
}

int gcd(int a, int b)
{
	while (a && b) {
		a %= b;
		if (a) b %= a;
	}
	return a + b;
}

void precalc_smart(void)
{
// 	printf("Precalculating..."); fflush(stdout);
	//
	int maxM = (int) ceil(sqrt((double) MAXN));
	for (int m = 2; m <= maxM; m++) {
// 		vector<pair<int, int> > fm = factorize(m);
		for (int n = 1; n < m; n += ((m % 2 == 0) ? 2 : 1)) {
			if ((n+m) % 2 != 1) continue;
			
/*			bool good = true;
			for (int i = 0; i < (int) fm.size(); i++) {
				if (n % fm[i].first == 0) {
					good = false;
					break;
				}
			}
			if (!good) continue;*/
			if (gcd(m, n) != 1) continue;
			int c = n*n + m*m;
			if (c > MAXN) continue;
			primitive_c[c]++;
		}
	}
	//
// 	printf("Done (set contains %d elements)\n", (int) primitive_c.size()); fflush(stdout);
}


int solve_stupid(ll c)
{
	int res = 0;
	for (ll a = 1; a < c; a++) {
		ll b = (ll) floor(sqrt(c*c - a*a));
		if (b < a) break;
		if (a*a + b*b == c*c) {
// 			int g = gcd(gcd(a, b), c);
// 			printf("%d^2 + %d^2 == %d^2 [%d, %d, %d]\n", (int) a, (int) b, (int) c, (int) a/g, (int) b/g, (int) c/g);
			res++;
		}
	}
	return res;
}

int bt(int x, const vector<pair<int, int> > fc, int ci, int c)
{
	if (ci == (int) fc.size()) {
		int res = 0;
		if (primitive_c.find(c/x) != primitive_c.end()) res = primitive_c[c / x];
// 		if (res) printf("sm: primitive: %d, k: %d, c: %d\n", c/x, x, c);
// 		printf("%d: %d/%d = %d -> r=%d\n", c, c, x, c/x, ok);
		return res;
	}
	int r = 0;
	for (int i = 0; i <= fc[ci].second; i++) {
		r += bt(x, fc, ci + 1, c);
		x *= fc[ci].first;
	}
	return r;
}

int solve_smart(int c)
{
	vector<pair<int, int> > fc = factorize(c);
	return bt(1, fc, 0, c);
}

int solve(int n, int c)
{
	if (n == 1) return c/2;
	if (n > 2) return 0;
	if (stupid) return solve_stupid(c);
	else return solve_smart(c);
}


int main(int argc, char** argv)
{
	if (argc == 2 && !strcmp(argv[1], "--stupid")) stupid = true;
	if (!stupid) precalc_smart();
	int n, c;
	while (true) {
		scanf("%d%d", &n, &c);
		if (n == 0) break;
		printf("%d\n", solve(n, c));
	}
	return 0;
}
