/*
 
*/

#include <iostream>
using namespace std;

const int MAX = 1000000;
int a, b;

int fib(int k)
{
     if (k == 1) return 2;
 int k0, k1 = 1, k2 = 1;
 int index = 2;
 do 
 {
     index++;
     k0 = a*k1 + b*k2;
     k1 = k2;
     k2 = k0;
// cout << k0 << " ";     
 } while ( k0 < k );
 if ( k0 == k ) return index;
 return 0; 
}

int main()
{
    int x, n;
 while (cin >> a >> b)
 {
       cin >> n;
       for (int i=0; i<n; i++) 
       {
           cin >> x;
           cout << fib(x) << endl;
       }
 }
 return 0;   
}
