#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstring>
#include <map>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"


#define VECT(name, type, ...) \
	type name##_tmp_vals[] = {__VA_ARGS__}; \
	int name##_tmp_count = sizeof(name##_tmp_vals) / sizeof(name##_tmp_vals[0]); \
	vector<type > name(name##_tmp_vals, name##_tmp_vals + name##_tmp_count);

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}


typedef long long hyper;

/*
p5: () const
p4: ** (right)
p3: + - (unary)
p2: * /
p1: + -
*/

map<string, int> prio;

bool init() {
	prio["+"] = 1;
	prio["-"] = 1;
	prio["*"] = 2;
	prio["/"] = 2;
	prio["**"] = 4;
	prio[""] = 0;
	return true;
}

bool tmp_junk = init();

string next_token(string const& exp, int pos) {
	string res = "";
	for(typeof(prio.begin()) it = prio.begin(); it != prio.end(); ++it) {
		string t = it->first;
		if(t == exp.substr(pos, t.size()) && t.size() > res.size()) res = t;
	}
	return res;
}


hyper eval(string const& exp, int& pos, int level) {
	//DEBT(exp.substr(pos)); DEBT(pos); DEB(level);
	if(level == 1 || level == 2) {
		hyper res = eval(exp, pos, level + 1);
		while(prio[next_token(exp, pos)] == level) {
			string t = next_token(exp, pos);
			pos += t.size();
			hyper right = eval(exp, pos, level + 1);
			if(t == "+") res += right;
			else if(t == "-") res -= right;
			else if(t == "*") res *= right;
			else if(t == "/") res /= right;
			else assert(false);
		}
		return res;		
	}
	else if(level == 3) {
		string t = next_token(exp, pos);
		if(t == "+" || t == "-") {
			pos += t.size();
			hyper right = eval(exp, pos, level);
			return (t == "-" ? -right : right);
		}
		return eval(exp, pos, level + 1);
	} 
	else if(level == 4) {
		hyper res = eval(exp, pos, level + 1);
		if(prio[next_token(exp, pos)] == level) {
			string t = next_token(exp, pos);
			assert(t == "**");
			pos += t.size();
			// can also have unary, thus level 3
			hyper right = eval(exp, pos, 3); 
			assert(right >= 0);
			int b = res;
			res = 1;
			REP(i, right) res *= b;
		}
		return res;
	} 
	else if(level == 5) {
		if(isdigit(exp[pos])) {
			string literal;
			while(isdigit(exp[pos])) literal += exp[pos++];
			istringstream si(literal);
			hyper res;
			si >> res;
			return res;
		}
		assert(exp[pos] == '(');
		++pos;
		int res = eval(exp, pos, 1);
		//DEBT(exp); DEBT(pos); DEB(exp[pos]);
		assert(exp[pos] == ')');
		++pos;
		return res;
	}
	assert(false);
	return 0;
}



void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	string exp;
	while(cin >> exp) {
		int pos = 0;
		cout << eval(exp, pos, 1) << "\n";
		assert(pos == (int)exp.size());
	}
	return 0;
}


void out(string exp) {
	cout << exp << "\n";
}
/*
p5: () const
p4: ** (right)
p3: + - (unary)
p2: * /
p1: + -
*/

void generate() {
	out("2+2");
	out("2+3*4/5");
	out("2**3**2");
	out("-2**3");
	out("3**-(-2)");
	out("--5");
	
	out("9+8-7*6/5--3**2"); // 17-8+9 = 18
	out("1+2-3+10*4+31/5+-6++7+2**8+3*(-9+10)"); // 306
	
	out("1+2-3*5-4/2+-(3+1)"); //-18
	out("1-2-3-4"); //-8
	out("1-(2-(3-(4)))"); //-2
	
	out("1*(2*3)*4*(5+6)/6/7"); //6
	out("1/2*3*4"); //0
	out("3*-2"); //-6
	out("5/-2"); //-2
	out("10*12*14/5/6/7"); //8
	out("10*12*14/5/6/(42/6)"); //8
	
	out("---+-+-2"); //-2
	out("---+-+-(-2--5)+-1"); //-4
	
	out("2**2"); //4
	out("-2**2"); //-4
	out("(-2)**2"); //4
	out("(-2)**3"); //-8
	out("2**3**2"); //512
	out("(2**3)**2"); //64
	out("(2**3)**2"); //64
	out("2**2**2**2"); //65536
	out("3**2**2**2"); //43046721
	out("5**3**2"); // 1,953,125
	out("(5**3)**2"); // 15,625
	out("5**-(-2)**3"); // 390,625
	out("5**2-3**2"); // 16
	out("5**--2"); // 25
	out("2**-(-2-3)"); // 32
	out("12**-(-2+2)"); // 1
}

//P=expr; g++ -O2 -Wall $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > tmp && cat tmp
