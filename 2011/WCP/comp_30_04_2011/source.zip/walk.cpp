#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"


#define VECT(name, type, ...) \
	type name##_tmp_vals[] = {__VA_ARGS__}; \
	int name##_tmp_count = sizeof(name##_tmp_vals) / sizeof(name##_tmp_vals[0]); \
	vector<type > name(name##_tmp_vals, name##_tmp_vals + name##_tmp_count);

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

typedef long long hyper;
typedef unsigned long long uhyper;

int& get(vector<int>& v, int x, int y) {
	assert(v.size() == 6 && x >= 0 && x < 4 && y >= 0 && y < 4 && x != y);
	if(x > y) swap(x, y);
	int off[] = {0, 0+3, 0+3+2};
	return v[off[x] + y-x-1];
}


hyper slow(vector<int> v) {
	vector<int> deg(4);
	REP(j, 4) REP(i, j) {
		deg[i] += get(v, i, j);
		deg[j] += get(v, i, j);
	}
	REP(i, 4) if(deg[i] % 2 != 0) return 0;
	vector<int> path; 
	REP(i, 4) REP(j, deg[i] / 2) path.push_back(i);
	path.push_back(0);
	hyper res = 0;
	do {
		if(path[0] != 0) break;
		vector<int> vc = v;
		bool ok = path[0] == 0 && path[path.size() - 1] == 0;
		if(ok) REP(i, path.size() - 1) {
			if(path[i] == path[i + 1]) {
				ok = false;
				break;
			}
			else --get(vc, path[i], path[i + 1]);
		}
		if(ok) REP(i, vc.size()) if(vc[i] != 0) {
			ok = false;
			break;
		}
		if(ok) ++res;
	} while(next_permutation(path.begin(), path.end()-1));
	return res;
}


const int VS = 1000000;
vector<hyper> solMem(4*VS, -1);
const int to = 0;
hyper solve(vector<int>& v, int from) {
	//DEBV(v);
	int vcode = 0; REP(i, v.size()) vcode = vcode * 10 + v[i];
	assert(vcode >= 0 && vcode < VS);
	int code = from * VS + vcode;
	hyper& res = solMem[code];
	if(res != -1) return res;
	
	if(vcode == 0 && from == to) res = 1;
	else {
		res = 0;
		REP(next, 4) if(from != next && get(v, from, next) > 0) {
			--get(v, from, next);
			//DEBV(v);
			res += solve(v, next);
			++get(v, from, next);
		}
	}
	assert(res >= 0);
	return res;
}


void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	{
		//test
		VECT(v, int, 0, 1, 2, 3, 4, 5);
		assert(get(v, 0, 1) == 0);
		assert(get(v, 0, 2) == 1);
		assert(get(v, 0, 3) == 2);
		assert(get(v, 1, 2) == 3);
		assert(get(v, 1, 3) == 4);
		assert(get(v, 2, 3) == 5);
	}
	hyper most = 0;
	vector<int> v(6);
	while(cin >> v[0] >> v[1] >> v[2] >> v[3] >> v[4] >> v[5]) {
		//DEBV(v);
		REP(i, 6) assert(v[i] >= 0 && v[i] < 10);
		hyper res = solve(v, 0);
		cout << res << "\n";
		most = max(most, res);
		if(res < 0) {
			DEBV(v);
			DEB(res);
			assert(res >= 0);
		}
		
		//DEB(res);
		int sum = 0; REP(i, 6) sum += v[i];
		if(sum <= 10) {
			hyper rs = slow(v);
			assert(rs == res);
		}
	}
	//DEB(most);
	return 0;
}

int rnd(int mod) {
	hyper res = rand() | (hyper)rand() << 10 | (hyper)rand() << 20;
	assert(res >= 0);
	return res % mod;
}

vector<string> split(string whole) {
	istringstream si(whole);
	vector<string> res;
	string t;
	while(si >> t) res.push_back(t);
	return res;
}

string gen(int len, vector<string> parts) {
	string res;
	while((int)res.size() < len) res += parts[rnd(parts.size())];
	return res.substr(0, len);
}

string mul(string s, int count) {
	string res;
	REP(i, count) res += s;
	return res;
}

void out(int ab, int ac, int ad, int bc, int bd, int cd) {
	VECT(v, int, ab, ac, ad, bc, bd, cd);
	REP(i, 6) assert(v[i] >= 0 && v[i] <= 9);
	REP(i, 6) cout << v[i] << (i == 5 ? "\n" : " ");
}

void generate() {
	
	out(1, 1, 1, 1, 1, 1);
	out(1, 1, 0, 1, 0, 0);
	out(4, 0, 0, 4, 0, 0);
	out(1, 2, 3, 4, 5, 6);
	
	out(0, 0, 0, 0, 0, 0); //1
	out(1, 1, 1, 1, 1, 1); //0
	out(2, 0, 0, 0, 0, 0); //1
	out(6, 0, 0, 0, 0, 0); //1
	out(1, 1, 0, 1, 0, 0); //2
	out(1, 0, 1, 1, 0, 1); //2
	out(2, 1, 1, 1, 1, 2); //?
	REP(t, 10000) out(rnd(5), rnd(5), rnd(5), rnd(5), rnd(5), rnd(5));
	const int M = 8;
	REP(t, 10000) out(rnd(M), rnd(M), rnd(M), rnd(M), rnd(M), rnd(M));
}

//P=walk; g++ -O2 -Wall $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > $P.ans && cat $P.ans
