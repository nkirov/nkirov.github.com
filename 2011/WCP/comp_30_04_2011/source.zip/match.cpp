#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstring>
#include <map>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"


#define VECT(name, type, ...) \
	type name##_tmp_vals[] = {__VA_ARGS__}; \
	int name##_tmp_count = sizeof(name##_tmp_vals) / sizeof(name##_tmp_vals[0]); \
	vector<type > name(name##_tmp_vals, name##_tmp_vals + name##_tmp_count);

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

typedef long long hyper;
const hyper BASE = 313;

int slow_matches(string const& text, string const& pat) {
	int res = 0;
	for(int p = 0; p + pat.size() <= text.size(); ++p) {
		if(text.substr(p, pat.size()) == pat) ++res;
	}
	return res;
}



int matches(string const& text, string const& pat) {
	int res = 0;
	hyper ph = 0;
	const int N = pat.size();
	const int M = text.size();
	REP(i, N) ph = ph * BASE + pat[i];
	hyper th = 0;
	hyper head = 1; REP(i, N) head *= BASE;
	//DEB(head);
	//DEB(ph);
	REP(i, M) {
		th = th * BASE + text[i];
		if(i >= N) th -= head * text[i - N];
		if(i >= N - 1 && th == ph) ++res;
		//DEBT(i); DEB(th);
	}
	return res;
}

void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	string text, pattern;
	while(cin >> text >> pattern) {
		int res = matches(text, pattern);
		cout << res << "\n";
		//DEBT(text); DEBT(pattern); DEB(res);
		if(text.size() * pattern.size() < 10*1000*1000) assert(res == slow_matches(text, pattern));
	}
	return 0;
}

vector<string> split(string whole) {
	istringstream si(whole);
	vector<string> res;
	string t;
	while(si >> t) res.push_back(t);
	return res;
}

void out(string t, string p) {
	cout << t << " " << p << "\n";
}

string gen(int len, vector<string> parts) {
	string res;
	while((int)res.size() < len) res += parts[rand() % parts.size()];
	return res.substr(0, len);
}

string mul(string s, int count) {
	string res;
	REP(i, count) res += s;
	return res;
}

void generate() {
	out("hellowolo", "lo");
	out("ababakababa", "aba");
	out("kabakaba", "baba");
	out("asdfstanchoasdfs", "stancho");
	
	out("stancho", "stancho");
	out("stanch", "stancho");
	out("tancho", "stancho");
	
	out("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaa"); //31
	out("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaab"); //0
	
	out(gen(1000, split("a")), gen(100, split("a"))); //901
	out(gen(10000, split("aaaaaaaa aaaaaaaa aaaaaaaa aaaaaaaa b")), gen(100, split("a")) + "b");
	out(gen(10000, split(mul("alalalal ", 100) + "ala x")), gen(100, split("al")));
	out(gen(10000, split(mul("xyzxyzxyzxyz ", 19) + " t")), gen(96, split("xyz")) + "t" + gen(96, split("xyz")));
	out(gen(10000, split("asdfstanchoasdfs")), gen(96, split("asdfstanchoasdfs")) + "a");
	
	out(gen(1000000, split("a")), gen(100*1000, split("a"))); //901
	out(gen(1000000, split(string(50*1000, 'a') + " b")), gen(99*1000, split("a")) + "b");
	out(gen(1000000, split(mul(mul("al", 1000)+ " ", 200) + "ala x")), gen(100*1000, split("al")));
	out(gen(1000000, split(mul("xyzxyzxyzxyz ", 20*1000) + " t")), gen(96*500, split("xyz")) + "t" + gen(96*500, split("xyz")));
	out(gen(1000000, split("asdfstanchoasdfs")), gen(96*1000, split("asdfstanchoasdfs")) + "a");
}

//P=match; g++ -O2 -Wall $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > tmp && cat tmp
