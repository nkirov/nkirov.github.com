#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"


#define VECT(name, type, ...) \
	type name##_tmp_vals[] = {__VA_ARGS__}; \
	int name##_tmp_count = sizeof(name##_tmp_vals) / sizeof(name##_tmp_vals[0]); \
	vector<type > name(name##_tmp_vals, name##_tmp_vals + name##_tmp_count);

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

typedef long long hyper;

int slow(int K, vector<string> const& a, vector<string> const& b) {
	const int R = a.size();
	const int C = a[0].size();
	set<string> as, bs;
	int dr[] = {0, 0, 1, 1, 1,-1,-1,-1};
	int dc[] = {1,-1,-1, 0, 1,-1, 0, 1};
	REP(r, R) REP(c, C) REP(d, 8) {
		string ta, tb;
		REP(k, K) {
			int rk = r + dr[d] * k;
			int ck = c + dc[d] * k;
			if(rk >= 0 && rk < R && ck >= 0 && ck < C) {
				ta += a[rk][ck];
				tb += b[rk][ck];
			}
		}
		if((int)ta.size() == K) {
			assert((int)tb.size() == K);
			as.insert(ta);
			bs.insert(tb);
		}
	}
	int res = 0;
	for(typeof(as.begin()) it = as.begin(); it != as.end(); ++it) {
		if(bs.count(*it)) ++res;
	}
	//DEBV(vector<string>(as.begin(), as.end()));
	//DEBV(vector<string>(bs.begin(), bs.end()));
	return res;
}


const hyper BASE = 313;
vector<hyper> basePowMem(1, 1);
hyper basePow(int e) {
	//DEB(e);
	while((int)basePowMem.size() < e + 1) {
		basePowMem.push_back(basePowMem[(basePowMem.size() - 1)] * BASE);
	}
	//DEB(e);
	return basePowMem[e];
}

struct Hasher {
	string const& s;
	const int N;
	vector<hyper> pre;
	
	Hasher(string const& _s): s(_s), N(_s.size()) {
		pre.resize(N + 1, 0);
		REP(i, N) pre[i + 1] = pre[i] * BASE + s[i];
	}
	
	hyper sub(int b, int e) {
		//DEBT(b); DEB(e);
		return pre[e] - pre[b] * basePow(e - b);
	}
	
};

bool in(int r, int c, int R, int C) {
	return r >= 0 && r < R && c >= 0 && c < C;
}

vector<string> slices(vector<string> const& m) {
	const int R = m.size();
	const int C = m[0].size();
	vector<string> res;
	int drs[] = {0, 0, 1, 1, 1,-1,-1,-1};
	int dcs[] = {1,-1,-1, 0, 1,-1, 0, 1};
	REP(sr, R) REP(sc, C) REP(d, 8) {
		int dr = drs[d], dc = dcs[d];
		if(in(sr - dr, sc - dc, R, C)) continue; //not the initial cell
		string t;
		for(int r = sr, c = sc; in(r, c, R, C); r += dr, c += dc) {
			t += m[r][c];
		}
		res.push_back(t); 
	}
	//DEBV(m);
	//DEBV(res);
	return res;
}

vector<hyper> hashes(vector<string> const& slices, int K) {
	vector<hyper> res;
	REP(i, slices.size()) {
		Hasher h(slices[i]);
		REP(b, slices[i].size() - K + 1) res.push_back(h.sub(b, b + K));
	}
	sort(res.begin(), res.end());
	res.erase(unique(res.begin(), res.end()), res.end());
	return res;
}

int solve(int K, vector<string> const& a, vector<string> const& b) {
	vector<string> ats = slices(a);
	vector<string> bts = slices(b);
	
	vector<hyper> ah = hashes(ats, K);
	vector<hyper> bh = hashes(bts, K);
	
	vector<hyper> both(ah.size());
	both.erase(set_intersection(ah.begin(), ah.end(), bh.begin(), bh.end(), both.begin()), both.end());
	return both.size();
}

void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	int N, M, K;
	while(cin >> N >> M >> K) {
		assert(N > 0 && N <= 1000);
		assert(M > 0 && M <= 1000);
		assert(K > 0 && K <= 1000);
		vector<string> a(N);
		REP(r, N) {
			cin >> a[r];
			assert((int)a[r].size() == M);
		}
		vector<string> b(N);
		REP(r, N) {
			cin >> b[r];
			assert((int)b[r].size() == M);
		}
		
		
		int res = solve(K, a, b);
		cout << res << "\n";
		//DEB(res);
		//DEBT(text); DEBT(pattern); DEB(res);
		if(N*M*K < 100*1000) {
			int sr = slow(K, a, b);
			//DEB(sr);
			assert(res == sr);
		} 
	}
	return 0;
}

int rnd(int mod) {
	hyper res = rand() | (hyper)rand() << 10 | (hyper)rand() << 20;
	assert(res >= 0);
	return res % mod;
}

vector<string> split(string whole) {
	istringstream si(whole);
	vector<string> res;
	string t;
	while(si >> t) res.push_back(t);
	return res;
}

string gen(int len, vector<string> parts) {
	string res;
	while((int)res.size() < len) res += parts[rnd(parts.size())];
	return res.substr(0, len);
}

string mul(string s, int count) {
	string res;
	REP(i, count) res += s;
	return res;
}

void out(int K, vector<string> a, vector<string> b) {
	int N = a.size();
	int M = a[0].size();
	assert(N > 0 && N <= 1000);
	assert(M > 0 && M <= 1000);
	assert(K > 0 && K <= 1000);
	cout << N << " " << M << " " << K << "\n";
	REP(r, N) {
		assert((int)a[r].size() == M);
		cout << a[r] << "\n";
	}
	REP(r, N) {
		assert((int)b[r].size() == M);
		cout << b[r] << "\n";
	}
}

void make(int N, int M, int K, string ap, string bp) {
	string as = gen(N * M, split(ap));
	vector<string> a(N); REP(i, N) a[i] = as.substr(i * M, M);
	string bs = gen(N * M, split(bp));
	vector<string> b(N); REP(i, N) b[i] = bs.substr(i * M, M);
	out(K, a, b);
}

void generate() {
	out(2, split("abc abc"), split("bac bac")); //6
	out(3, split("aaaa"), split("bbbb")); //0
	out(2, split("abcde fghij"), split("fghij abcde")); //0

	out(3, split("aaaa aaaa aaaa aaaa"), split("aaaa aaaa aaaa aaaa")); //1
	out(3, split("aaaa aaba aaaa aaaa"), split("aaba aaaa aaaa aaaa")); //4
	
	make(1, 1, 1, "b", "c");
	make(1, 1, 1, "x", "x");
	make(8, 8, 13, "ala b c", "ala b c");

	make(4, 4, 3, "a b c", "a b c");
	make(8, 8, 3, "ala b c", "ala b c");
	make(8, 8, 8, "ala b c", "ala b c");
	make(8, 8, 4, "asdf gdfa sdf fds", "jgor ahsd sdjf");

	make(30, 40, 10, "a b c", "a b c");
	make(30, 40, 10, "ala b c", "ala b c");
	make(30, 40, 10, "ala b c", "ala b c");
	make(30, 40, 6, "asdf gdfa sdf fds", "jgor ahsd sdjf");

	make(100, 110, 10, "a b c", "a b c");
	make(100, 110, 20, "ala b c", "ala b c");
	make(100, 110, 20, "ala b c", "ala b c");
	make(100, 110, 10, "asdf gdfa sdf fds", "jgor ahsd sdjf");

	make(200, 300, 10, "a b c", "a b c");
	make(200, 300, 20, "ala b c", "ala b c");
	make(300, 200, 20, "ala b c", "ala b c");
	make(300, 200, 10, "asdf gdfa sdf fds", "jgor ahsd sdjf");

	make(1000, 1000, 1000, mul("aa ", 100) + "b", mul("aa ", 100) + "b");
	make(400, 600, 150, mul("aa ", 100) +"ala b c", mul("aa ", 100) + "ala b c");
	make(400, 600, 150, mul("aa ", 100) + "ala b c", mul("aa ", 100) + "ala b c");
	make(600, 400, 60, mul("aa ", 50) + "asdf gdfa sdf fds", mul("aa ", 50) + "jgor ahsd sdjf");
	
}

//P=reco; g++ -O2 -Wall $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > $P.ans && cat $P.ans
