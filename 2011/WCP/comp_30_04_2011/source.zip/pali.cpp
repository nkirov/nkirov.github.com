#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstring>
#include <map>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"


#define VECT(name, type, ...) \
	type name##_tmp_vals[] = {__VA_ARGS__}; \
	int name##_tmp_count = sizeof(name##_tmp_vals) / sizeof(name##_tmp_vals[0]); \
	vector<type > name(name##_tmp_vals, name##_tmp_vals + name##_tmp_count);

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

typedef long long hyper;

int slow(string const& s) {
	int res = 0;
	const int N = s.size();
	REP(e, N + 1) REP(b, e) {
		string u = s.substr(b, e - b);
		string v = u; reverse(v.begin(), v.end());
		if(u == v) res = max(res, e - b);
	}
	return res;
}

const hyper BASE = 313;
vector<hyper> basePowMem(1, 1);
hyper basePow(int e) {
	//DEB(e);
	while((int)basePowMem.size() < e + 1) {
		basePowMem.push_back(basePowMem[(basePowMem.size() - 1)] * BASE);
	}
	//DEB(e);
	return basePowMem[e];
}

struct Hasher {
	string const& s;
	const int N;
	vector<hyper> pre;
	
	Hasher(string const& _s): s(_s), N(_s.size()) {
		pre.resize(N + 1, 0);
		REP(i, N) pre[i + 1] = pre[i] * BASE + s[i];
	}
	
	hyper sub(int b, int e) {
		//DEBT(b); DEB(e);
		return pre[e] - pre[b] * basePow(e - b);
	}
	
};

bool pal(int b, int e, int N, Hasher& sh, Hasher& rh) {
	
	if(b < 0 || e > N) return false;
	hyper shs = sh.sub(b, e);
	hyper rhs = rh.sub(N-e, N-b);
	//DEBT(b); DEBT(e); DEBT(shs); DEB(rhs);
	return shs == rhs;
}

int solve(string const& s) {
	//DEB(s);
	const int N = s.size();
	string r = s; reverse(r.begin(), r.end());
	Hasher sh(s);
	Hasher rh(r);
	//DEB("");
	int best = 1;
	//pal(b, e): s[b..e] == r[N-e .. N-b]
#define PAL(b, e) ((b) >= 0 && (e) <= N && sh.sub((b), (e)) == rh.sub(N-(e), N-(b)))
	for(int es = 1; es <= 2; ++es) {
		int b = 0;
		int e = es;
		while(e <= N) {
			//DEBT(b); DEB(e);
			while(pal(b-1, e+1, N, sh, rh)) {
				--b; 
				++e;
				//DEB("");
			}
			if(pal(b, e, N, sh, rh)) best = max(best, e - b);
			++b; 
			++e;
		}
	}
#undef PAL
	return best;
	
}

void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	{
		//test     01234567
		Hasher sh("kabakaba");
		Hasher rh("abakabak");
		//DEBT(sh.sub(1, 4)); DEB(rh.sub(4, 7));
		//DEBT(sh.sub(5, 8)); DEB(rh.sub(0, 3));
		assert(sh.sub(1, 4) == rh.sub(4, 7));
		assert(sh.sub(5, 8) == rh.sub(0, 3));
		
	}
	string text;
	while(cin >> text) {
		int res = solve(text);
		cout << res << "\n";
		//DEBT(text); DEB(res);
		//DEBT(text); DEBT(pattern); DEB(res);
		if(text.size() < 200) assert(res == slow(text));
	}
	return 0;
}

int rnd(int mod) {
	hyper res = rand() | (hyper)rand() << 10 | (hyper)rand() << 20;
	assert(res >= 0);
	return res % mod;
}

vector<string> split(string whole) {
	istringstream si(whole);
	vector<string> res;
	string t;
	while(si >> t) res.push_back(t);
	return res;
}

void out(string t) {
	cout << t << "\n";
}

string gen(int len, vector<string> parts) {
	string res;
	while((int)res.size() < len) res += parts[rnd(parts.size())];
	return res.substr(0, len);
}

string mul(string s, int count) {
	string res;
	REP(i, count) res += s;
	return res;
}

void make(int len, string parts, int pals) {
	string res = gen(len, split(parts));
	REP(pp, pals) {
		int b = rnd(len);
		int e = rnd(len + 1);
		REP(i, e - b) res[b + i] = res[e - i];
	}
	out(res);
}

void generate() {
	out("abc");
	out("xyabbayzazka");
	out("babakabakabbaz");
	out("aba");	
	
	out("a"); //1
	out("bb"); //2
	out("alabala"); //7
	out("ababakkababa"); //12
	out("kabakaba"); //7
	out("abakabak"); //7
	out("asdfatsstanchoasdfs"); //6
	out("abbastancho"); //4
	out("stanchoabba"); //4
	out("stanchoabba"); //4

	make(100, "ababakkababa ababakababa", 0);
	make(100, "a b", 0);
	make(100, "alabala ababa alasala", 0);

	
	out("xx" + mul("ababakkababa", 100) + "stancho"); //12*100
	out("xx" + mul("ababakababa", 100) + "stancho"); //11*100
	make(1000, "a b c d", 0);
	make(1000, "a b c d", 10);
	make(1000, "a b c d", 100);
	make(1000, "ababakkababa ababakababa", 0);
	make(1000, "a b", 0);
	make(1000, "alabala ababa alasala", 0);
	make(1000, "ababakkababa ababakababa", 30);
	make(1000, "a b", 30);
	make(1000, "alabala ababa alasala", 30);

	make(1000*1000, "ababakkababa ababakababa", 0);
	make(1000*1000, "a b", 0);
	make(1000*1000, "alabala ababa alasala", 0);
	make(1000*1000, "ababakkababa ababakababa", 30);
	make(1000*1000, "a b", 30);
	make(1000*1000, "alabala ababa alasala", 30);
}

//P=pali; g++ -O2 -Wall $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > tmp && cat tmp

