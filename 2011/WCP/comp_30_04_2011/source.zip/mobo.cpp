#include <iostream>
#include <cassert>
#include <algorithm>
#include <vector>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <sstream>
using namespace std;

#define REP(i, n) for(int i = 0; i < int(n); ++i)

#define DEB(x) cerr << #x << ":" << (x) << "\t at " << __LINE__ << endl
#define DEBT(x) cerr << #x << ":" << x << "\t"


#define VECT(name, type, ...) \
	type name##_tmp_vals[] = {__VA_ARGS__}; \
	int name##_tmp_count = sizeof(name##_tmp_vals) / sizeof(name##_tmp_vals[0]); \
	vector<type > name(name##_tmp_vals, name##_tmp_vals + name##_tmp_count);

#define DEBV(v) { \
	typeof(v) vc = v; \
	cerr << #v << ": "; \
	REP(i, min((int)vc.size(), 100)) cerr << vc[i] << " "; \
	cerr << "\t at " << __LINE__ << endl; \
}

typedef long long hyper;


bool in(int r, int c, int R, int C) {
	return r >= 0 && r < R && c >= 0 && c < C;
}


hyper slow(vector<string> const& m) {
	const int R = m.size();
	const int C = m[0].size();
	hyper res = 0;
	REP(sr, R) REP(sc, C) {
		char target = m[sr][sc] == '+' ? '-' : '+';
		vector<vector<bool> > vis(R, vector<bool>(C));
		vector<pair<int, int> > nv(1, make_pair(sr, sc));
		int nd = 0;
		int dist = 0;
		while(!nv.empty() && dist == 0) {
			vector<pair<int, int> > cv;
			swap(nv, cv);
			int cd = nd;
			++nd;
			REP(i, cv.size()) {
				int r = cv[i].first, c = cv[i].second;
				if(!in(r, c, R, C) || vis[r][c]) continue;
				vis[r][c] = true;
				if(m[r][c] == target) {
					dist = cd;
					break;
				}
				nv.push_back(make_pair(r, c + 1));
				nv.push_back(make_pair(r, c - 1));
				nv.push_back(make_pair(r + 1, c));
				nv.push_back(make_pair(r - 1, c));
			}
		}
		res += dist;
	}
	return res;
}

hyper solve(vector<string> const& m) {
	const int R = m.size();
	const int C = m[0].size();
	hyper res = 0;
	REP(sg, 2) {
		char goal = "+-"[sg];
		vector<vector<int> > dist(R, vector<int>(C, -1));
		vector<pair<int, int> > nv;
		REP(r, R) REP(c, C) if(m[r][c] == goal) {
			nv.push_back(make_pair(r, c));
		}
		int nd = 0;
		if(nv.empty()) return 0; //no solution
		while(!nv.empty()) {
			vector<pair<int, int> > cv;
			swap(nv, cv);
			int cd = nd;
			++nd;
			REP(i, cv.size()) {
				int r = cv[i].first, c = cv[i].second;
				if(!in(r, c, R, C) || dist[r][c] != -1) continue;
				dist[r][c] = cd;
				nv.push_back(make_pair(r, c + 1));
				nv.push_back(make_pair(r, c - 1));
				nv.push_back(make_pair(r + 1, c));
				nv.push_back(make_pair(r - 1, c));
			}
		}
		REP(r, R) REP(c, C) {
			assert(dist[r][c] != -1);
			res += dist[r][c];
		}
	}
	return res;
}


void generate();
int main(int argc, char** argv) {
	if(argc >= 2 && string("gen") == argv[1]) {
		generate();
		return 0;
	}
	int N, M;
	while(cin >> N >> M ) {
		assert(N > 0 && N <= 1000);
		assert(M > 0 && M <= 1000);
		vector<string> a(N);
		REP(r, N) {
			cin >> a[r];
			assert((int)a[r].size() == M);
		}
		int res = solve(a);
		cout << res << "\n";
		//DEB(res);
		//DEBT(text); DEBT(pattern); DEB(res);
		if(N*M < 5*1000) {
			int sr = slow(a);
			//DEB(sr);
			assert(res == sr);
		} 
	}
	return 0;
}

int rnd(int mod) {
	hyper res = rand() | (hyper)rand() << 10 | (hyper)rand() << 20;
	assert(res >= 0);
	return res % mod;
}

vector<string> split(string whole) {
	istringstream si(whole);
	vector<string> res;
	string t;
	while(si >> t) res.push_back(t);
	return res;
}

string gen(int len, vector<string> parts) {
	string res;
	while((int)res.size() < len) res += parts[rnd(parts.size())];
	return res.substr(0, len);
}

string mul(string s, int count) {
	string res;
	REP(i, count) res += s;
	return res;
}

void out(vector<string> a) {
	int N = a.size();
	int M = a[0].size();
	assert(N > 0 && N <= 1000);
	assert(M > 0 && M <= 1000);
	cout << N << " " << M << "\n";
	REP(r, N) {
		assert((int)a[r].size() == M);
		cout << a[r] << "\n";
	}
}

void make(int N, int M, string ap, int sc, int ss) {
	string as = gen(N * M, split(ap));
	vector<string> a(N); REP(i, N) a[i] = as.substr(i * M, M);
	REP(st, sc) {
		char t = "+-"[rnd(2)];
		int rs = rnd(N), cs = rnd(M);
		int rl = rnd(ss), cl = rnd(ss);
		REP(r, rl) REP(c, cl) if(in(rs+r, cs+c, N, M)) a[rs+r][cs+c] = t;
	}
	out(a);
}

void generate() {
	out(split("+- -+")); //1
	out(split("+-- ---")); //10
	out(split("+++")); //0
	out(split("+++-++ ++---+ +-----")); //0
	out(split("++++---- ++++---- ++++---- ++++----")); //80
	
	make(10, 10, "+ + + + + + -", 0, 0);
	make(20, 20, "+ -", 0, 0);
	make(20, 20, "+++ --- + -", 0, 0);
	make(200, 100, "+ -", 0, 0);
	make(200, 100, "++++++++++ ----------------- +++ --- + -", 0, 0);
	make(200, 100, "+++++++ + -", 0, 0);
	make(200, 100, "+++++++ + -", 50, 50);

	make(500, 500, "+ -", 0, 0);
	make(500, 500, "++++++++++ ----------------- +++ --- + -", 0, 0);
	make(500, 500, "+++++++ + -", 0, 0);

	make(500, 500, "+ -", 500, 500);
	make(500, 500, "+++++++ + -", 500, 500);
	make(1000, 1000, "+++++++ + -", 5000, 1000);

	make(1000, 1000, mul("+++++++ ", 200000) + "+ -", 0, 0);
	make(1000, 1000, mul("+++++++ ", 100000) + "+ -", 0, 0);
	
}

//P=mobo; g++ -O2 -Wall $P.cpp -o $P && ./$P gen > $P.in && time ./$P < $P.in > $P.ans && cat $P.ans
