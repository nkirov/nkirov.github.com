#include <iostream>
#include <string>

using namespace std;

int main()
{  
   string word;
   while (cin >> word)
      cout << word << "\n";
   return 0;
}
