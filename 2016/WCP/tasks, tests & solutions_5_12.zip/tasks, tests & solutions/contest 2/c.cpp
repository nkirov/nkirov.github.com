#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;
 
typedef long long ll;
 
int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

    int n;
    while (cin >> n && n) 
	{
        map<string, int> win;
        vector<pair<string, string> > c((1<<n)-1);
         
        for (int i = 0; i < (1 << n) - 1; i++) 
		{
            cin >> c[i].first >> c[i].second;
            win[c[i].first]++;
        }
         
        string gold, silver;
		map<string, int>::iterator it;
		for (it = win.begin(); it != win.end(); ++it)
		{
            if (it->second == n) 
				gold = it->first;
            else if (it->second == n-1) 
				silver = it->first;
        }
        
		vector<string> rep;
		for (int i = 0;i < c.size();i++) 
		{
			if (c[i].first == gold || c[i].first == silver) 
			{
				if (c[i].second != silver) 
				{
                    rep.push_back(c[i].second);
                }
            }
        }

        sort(rep.begin(), rep.end());
         
        cout << "Gold: " << gold << endl;
        cout << "Silver: " << silver << endl;
        cout << "Repechage: ";
        for (int i = 0;i < rep.size() - 1;i++) 
			cout << rep[i] << " ";
		cout << rep[rep.size() - 1] << endl;
    }

    return 0;
}