/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <queue>

using namespace std;
FILE *in; FILE *out;

const int MAX = 1024;
const int INF = 1000000001;

struct Cell {
    int row, col;
    Cell(int row_ = 0, int col_ = 0) : row(row_), col(col_) {};
};

int n, m;
char a[MAX][MAX];
int ans[26];
int dist[MAX][MAX];
int dir[8][2] = {
    {-1, 0}, {0, 1}, {1, 0}, {0, -1} ,
    {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
};

void solve() {
    queue <Cell> q, w;
    for (int row = 0; row < n; row++) {
        for (int col = 0; col < m; col++) {
            dist[row][col] = INF;
            if (a[row][col] == 'W') {
                dist[row][col] = -1;
                q.push(Cell(row, col));
            }
        }
    }
    int curDist = -2;
    while (!q.empty()) {
        curDist++;
        while (!q.empty()) {
            Cell cur = q.front(); q.pop();
            if (dist[cur.row][cur.col] != curDist)
                continue;
            for (int i = 0; i < 8; i++) {
                Cell nxt(cur.row + dir[i][0], cur.col + dir[i][1]);
                if (nxt.row < 0 || nxt.row >= n || nxt.col < 0 || nxt.col >= m)
                    continue;
                int nxtDist = dist[cur.row][cur.col] + (a[cur.row][cur.col] != a[nxt.row][nxt.col]);
                if (nxtDist < dist[nxt.row][nxt.col]) {
                    dist[nxt.row][nxt.col] = nxtDist;
                    if (a[cur.row][cur.col] == a[nxt.row][nxt.col])
                        q.push(nxt);
                    else
                        w.push(nxt);
                }
            }
        }
        swap(q, w);
    }

    for (int i = 0; i < 26; i++)
        ans[i] = INF;
    for (int row = 0; row < n; row++) {
        for (int col = 0; col < m; col++) {
            ans[a[row][col] - 'A'] = min(ans[a[row][col] - 'A'], dist[row][col]);
        }
    }
    for (int i = 0; i < 26; i++) {
        if (i != 'W' - 'A' && ans[i] < INF) {
            fprintf(out, "%c %d\n", 'A' + i, ans[i]);
        }
    }
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("A.in", "rt"); // out = fopen("file.out", "wt");
	
	int numTests;
	fscanf(in, "%d", &numTests);
	for (int test = 0; test < numTests; test++) {
	    if (test > 0)
	        fprintf(out, "\n");

	    fscanf(in, "%d %d", &n, &m);
	    for (int i = 0; i < n; i++)
	        fscanf(in, "%s", a[i]);
	    solve();
    }
	return 0;
}
