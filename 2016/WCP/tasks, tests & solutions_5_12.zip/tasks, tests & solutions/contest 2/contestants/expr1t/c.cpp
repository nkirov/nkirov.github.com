/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>

using namespace std;
FILE *in; FILE *out;

const int MAX = 1024;

map < string, set <string> > won, lost;

void solve() {
    int first = -1, second = -1;
    string nameFirst, nameSecond;
    for (auto it = won.begin(); it != won.end(); it++) {
        if (second < (int)it->second.size()) {
            second = it->second.size();
            nameSecond = it->first;
            if (second > first) {
                swap(first, second);
                swap(nameFirst, nameSecond);
            }
        }
    }
    fprintf(out, "Gold: %s\n", nameFirst.c_str());
    fprintf(out, "Silver: %s\n", nameSecond.c_str());
    fprintf(out, "Repechage:");
    for (auto it = lost.begin(); it != lost.end(); it++) {
        if (it->first != nameFirst && it->first != nameSecond) {
            if (it->second.find(nameFirst) != it->second.end() ||
                it->second.find(nameSecond) != it->second.end()) {
                fprintf(out, " %s", it->first.c_str());
            }
        }
    }
    fprintf(out, "\n");
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("C.in", "rt"); // out = fopen("file.out", "wt");
	
	while (true) {
	    won.clear();
	    lost.clear();

	    int n;
	    fscanf(in, "%d", &n);
	    if (n == 0)
	        break;
	    for (int i = 0; i < (1 << n) - 1; i++) {
	        char name1[16], name2[16];
	        fscanf(in, "%s %s", name1, name2);
	        won[name1].insert(name2);
	        lost[name2].insert(name1);
        }
        solve();
    }
	return 0;
}
