/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;
FILE *in; FILE *out;

const int MAX = 20;

int n, m;
int masks[MAX];

int recurse(int idx, int mask) {
    if (idx >= n)
        return 1;
    if (masks[idx] & mask)
        return recurse(idx + 1, mask);
    return recurse(idx + 1, mask | (1 << idx)) + recurse(idx + 1, mask);
}

void solve() {
    int ans = recurse(0, 0);
    fprintf(out, "%d\n", ans);
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("G.in", "rt"); // out = fopen("file.out", "wt");
	
	while (true) {
	    fscanf(in, "%d", &n);
	    if (n == -1)
	        break;
	    fscanf(in, "%d", &m);
	    for (int i = 0; i < n; i++)
	        masks[i] = 0;
	    for (int i = 0; i < m; i++) {
	        int node1, node2;
	        fscanf(in, "%d %d", &node1, &node2);
	        node1--; node2--;
	        masks[node1] |= (1 << node2);
	        masks[node2] |= (1 << node1);
        }
        solve();
    }
	return 0;
}
