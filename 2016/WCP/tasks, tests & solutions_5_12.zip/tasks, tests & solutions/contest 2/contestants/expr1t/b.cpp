/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;
FILE *in; FILE *out;

const int MAX = 10004;
const int INF = 1000000001;

int n, x;
int a[MAX];

void solve() {
    int minn = a[0], maxx = a[0];
    for (int i = 1; i < n; i++) {
        minn = min(minn, a[i]);
        maxx = max(maxx, a[i]);
    }
    int ans = INF;
    if (x <= minn) {
        ans = n + maxx - x;
    } else if (x >= maxx) {
        ans = n + x - minn;
    } else {
        ans = min(ans, n + x - minn + maxx - minn);
        ans = min(ans, n + maxx - x + maxx - minn);
    }
    fprintf(out, "%d\n", ans);
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("B.in", "rt"); // out = fopen("file.out", "wt");
	
	int numTests;
	while (fscanf(in, "%d", &n) == 1) {
        for (int i = 0; i < n; i++)
	        fscanf(in, "%d", &a[i]);
	    fscanf(in, "%d", &x);
	    solve();
    }
	return 0;
}
