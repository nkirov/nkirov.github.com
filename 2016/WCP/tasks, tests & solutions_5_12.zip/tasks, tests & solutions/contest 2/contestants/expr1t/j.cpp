/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>

using namespace std;
FILE *in; FILE *out;

const int MAX = 1024;

int bitCount(unsigned long long num) {
    int ret = 0;
    for (int pos = 0; pos < 64; pos++)
        if (num & (1ULL << pos)) ret++;
    return ret;
}

int main(void) {
	in = stdin; out = stdout;
//	freopen("J.in", "rt", stdin);
	
	unsigned long long a, b;
	while (cin >> a >> b) {
	    int ans = 0;
	    for (unsigned long long i = a; i <= b; i++) {
	        ans += bitCount(i);
	        if (i == b) break;
        }
        fprintf(out, "%d\n", ans);
    }
	return 0;
}
