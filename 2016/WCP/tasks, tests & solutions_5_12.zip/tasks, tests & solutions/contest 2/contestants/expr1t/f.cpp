/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>

using namespace std;
FILE *in; FILE *out;

const int MAX = 131072;
const int MAX_BUFF_SIZE = 1048576;

int n;
int a[MAX];
char buff[MAX_BUFF_SIZE];

void solve() {
    sort(a, a + n);
    long long ans = 0;
    for (int i = n - 1; i >= 0; i--) {
        if (i >= 2) {
            ans += a[i] + a[i - 1];
            i -= 2;
        } else {
            while (i >= 0)
                ans += a[i--];
        }
    }
    cout << ans << endl;
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("F.in", "rt"); // out = fopen("file.out", "wt");
	
	while (!feof(in)) {
	    buff[0] = 0;
	    fgets(buff, MAX_BUFF_SIZE, in);
	    stringstream ss(buff);
	    n = 0;
	    while (ss >> a[n])
            n++;
	    if (n == 0)
	        break;
	    solve();
    }
	return 0;
}
