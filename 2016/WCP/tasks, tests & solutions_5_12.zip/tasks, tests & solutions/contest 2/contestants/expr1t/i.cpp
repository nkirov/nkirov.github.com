/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;
FILE *in; FILE *out;

const int MAX = 2050;

int n;
char a[MAX][MAX];
int ans[MAX][MAX];

void solve() {
    for (int row = 0; row < n; row++)
        for (int col = 0; col < n; col++)
            ans[row][col] = 0;
    int best = 0;
    for (int row = n - 1; row >= 0; row--) {
        for (int col = n - 1; col >= 0; col--) {
            if (a[row][col] == '1') {
                int sz = MAX;
                if (row + 1 < n && col + 1 < n) {
                    sz = min(sz, ans[row + 1][col]);
                    sz = min(sz, ans[row][col + 1]);
                    sz = min(sz, ans[row + 1][col + 1]);
                } else sz = 0;
                ans[row][col] = sz + 1;
                best = max(best, ans[row][col]);
            }
        }
    }
    fprintf(out, "%d\n", best);
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("I.in", "rt"); // out = fopen("file.out", "wt");
	
	int numTests;
	fscanf(in, "%d", &numTests);
	for (int test = 0; test < numTests; test++) {
	    fscanf(in, "%d", &n);
	    for (int i = 0; i < n; i++)
	        fscanf(in, "%s", a[i]);
	    solve();
    }
	return 0;
}
