/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;
FILE *in; FILE *out;

const int MAX = 1024;
const int INF = 1000000001;

int n, m;
int a[MAX][MAX];
int dyn[MAX][MAX];

int recurse(int row, int col) {
    if (a[row][col] == 1)
        return INF;
    if (row == n - 1 && col == m - 1)
        return 0;
    if (dyn[row][col] != -1)
        return dyn[row][col];
    
    int ans = INF;
    // Down
    if (row + 1 < n)
        ans = min(ans, recurse(row + 1, col) + 1);
    
    // Right
    if (col + 1 < m)
        ans = min(ans, recurse(row, col + 1) + 1);
    
    // Diagonal
    if (row + 1 < n && col + 1 < m)
        ans = min(ans, recurse(row + 1, col + 1) + 1);
    
    return dyn[row][col] = ans;
}

void solve() {
    for (int row = 0; row < n; row++) {
        for (int col = 0; col < m; col++) {
            dyn[row][col] = -1;
        }
    }
    int ans = recurse(0, 0);
    fprintf(out, "%d\n", ans >= INF ? 0 : ans * 1000);
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("K.in", "rt"); // out = fopen("file.out", "wt");
	
	int numTests;
	fscanf(in, "%d", &numTests);
	for (int test = 0; test < numTests; test++) {
	    fscanf(in, "%d %d", &n, &m);
	    for (int row = 0; row < n; row++) {
	        for (int col = 0; col < m; col++) {
	            fscanf(in, "%d", &a[row][col]);
            }
        }
        solve();
    }
	return 0;
}
