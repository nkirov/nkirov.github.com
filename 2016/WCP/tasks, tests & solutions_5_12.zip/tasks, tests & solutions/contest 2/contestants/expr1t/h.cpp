/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>

using namespace std;
FILE *in; FILE *out;

const int MAX = 1024;

void solve(double h, double w) {
    double ans = 0.0;

    // Horizontal
    ans = max(ans, min(h, w / 3.0));
    
    // Vertical
    ans = max(ans, min(w, h / 3.0));
    
    // Pyramid
    ans = max(ans, min(w / 2.0, h / 2.0));
    
    fprintf(out, "%.3lf\n", ans);
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("H.in", "rt"); // out = fopen("file.out", "wt");
	
	int numTests;
	fscanf(in, "%d", &numTests);
	for (int test = 0; test < numTests; test++) {
	    int h, w;
	    fscanf(in, "%d %d", &h, &w);
	    solve(h, w);
    }
	return 0;
}
