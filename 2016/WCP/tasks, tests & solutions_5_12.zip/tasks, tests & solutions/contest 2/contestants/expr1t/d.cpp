/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>

using namespace std;
FILE *in; FILE *out;

const int MAX = 1024;

int main(void) {
	in = stdin; out = stdout;
//	freopen("D.in", "rt", stdin);
	
	while (true) {
	    long long n;
	    cin >> n;
	    if (n == 0)
	        break;

	    long long ans = n + 1;
	    long long left = 0, right = 1 << 29;
	    while (left <= right) {
	        long long mid = (left + right) / 2;
	        long long sum = mid * (mid + 1) / 2;
	        if (sum >= n)
	            ans = sum, right = mid - 1;
	        else
	            left = mid + 1;
        }
        if (ans == n) {
            cout << "OK" << endl;
        } else {
            cout << ans - n << endl;
        }
    }
	return 0;
}
