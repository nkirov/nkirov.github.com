/*
ID: espr1t
TASK: 
KEYWORDS: 
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <queue>

using namespace std;
FILE *in; FILE *out;

const int MAX = 303;

int n, m;
bool vis[MAX];
vector <int> v[MAX];

int recurse(int node) {
    int odd = 0;
    vis[node] = true;
    if (v[node].size() % 2 == 1)
        odd++;
    for (int i = 0; i < (int)v[node].size(); i++)
        if (!vis[v[node][i]]) odd += recurse(v[node][i]);
    return odd;
}

void solve() {
    priority_queue <int> q;
    memset(vis, 0, sizeof(vis));
    for (int i = 0; i < n; i++)
        if (!vis[i] && !v[i].empty())
            q.push(recurse(i));
    int ans = 0;
    while (!q.empty()) {
        if ((int)q.size() == 1) {
            ans += q.top() / 2;
            break;
        }
        int odd1 = q.top(); q.pop();
        int odd2 = q.top(); q.pop();
        ans++;
        odd1 = (odd1 == 0 ? 1 : odd1 - 1);
        odd2 = (odd2 == 0 ? 1 : odd2 - 1);
        q.push(odd1 + odd2);
    }
    fprintf(out, "%d\n", ans);
}

int main(void) {
	in = stdin; out = stdout;
//	in = fopen("E.in", "rt"); // out = fopen("file.out", "wt");
	
	while (true) {
	    fscanf(in, "%d %d", &n, &m);
	    if (n == 0 && m == 0)
	        break;
	    for (int i = 0; i < n; i++)
	        v[i].clear();
	    
	    for (int i = 0; i < m; i++) {
	        int node1, node2;
	        fscanf(in, "%d %d", &node1, &node2);
	        node1--, node2--;
	        v[node1].push_back(node2);
	        v[node2].push_back(node1);
        }
        solve();
    }
	return 0;
}
