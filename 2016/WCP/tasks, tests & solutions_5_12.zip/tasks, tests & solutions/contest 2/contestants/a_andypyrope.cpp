#include <cstdio>
#include <queue>
#include <algorithm>
#include <set>
#include <cstdlib>

using namespace std;


const int MAXN = 1000;
const int MAXM = 1000;

int N,M;
char terrain[MAXN][MAXM+5];

void init()
{
	scanf("%d %d", &N, &M);
	for(int i=0; i<N; ++i) scanf("%s", terrain[i]);
}

const int dx[8] = { 0, 0,-1,+1,+1,-1,+1,-1};
const int dy[8] = {-1,+1, 0, 0,+1,+1,-1,-1};

bool valid(int x, int y) { return (x>=0 and x<M and y>=0 and y<N); }

int dist[256];
int cellDist[MAXN][MAXM];
bool u[MAXN][MAXM];

queue<pair<int,int> > q;

void dfs(int x, int y, int d)
{
	q.push(pair<int,int>(x,y));
	u[y][x] = true;
	cellDist[y][x] = d;
	
	int newX,newY;
	for(int i=0; i<8; ++i)
	{
		newX=x+dx[i]; newY=y+dy[i];
		if(valid(newX,newY) and !u[newY][newX] and terrain[newY][newX]==terrain[y][x])
		{
			dfs(newX,newY,d);
		}
	}
}

void solve()
{
	
	for(int i=0; i<N; ++i)
	{
		for(int j=0; j<M; ++j)
		{
			u[i][j] = false;
			cellDist[i][j] = 1818181818;
		}
	}
	
	for(int i=0; i<N; ++i)
	{
		for(int j=0; j<M; ++j)
		{
			if(terrain[i][j] == 'W') { if(!u[i][j]) dfs(j,i,-1); }
		}
	}
	
	pair<int,int> curr;
	int newX,newY;
	
	while(!q.empty())
	{
		curr = q.front();
		q.pop();
		
		for(int i=0; i<8; ++i)
		{
			newX = curr.first+dx[i];
			newY = curr.second+dy[i];
			if(valid(newX,newY) and (!u[newY][newX] or cellDist[newY][newX] > cellDist[curr.second][curr.first]+1))
			{
				dfs(newX,newY,cellDist[curr.second][curr.first]+1);
			}
		}
	}
	//for(int i=0; i<N; ++i) { for(int j=0; j<M; ++j) printf("%d ", cellDist[i][j]); printf("\n"); }
	
	for(int i=0; i<256; ++i) dist[i] = 1818181818;
	
	for(int i=0; i<N; ++i)
	{
		for(int j=0; j<M; ++j)
		{
			if(terrain[i][j] != 'W') dist[terrain[i][j]] = min(dist[terrain[i][j]], cellDist[i][j]);
		}
	}
	
	for(int i=0; i<256; ++i) if(dist[i] < 1818181818) printf("%c %d\n", (char)(i), dist[i]);
}

int main()
{
	//freopen("A.in", "r", stdin);
	
	int t;
	scanf("%d", &t);
	for(int i=0; i<t; ++i)
	{
		if(i>0) printf("\n");
		init();
		solve();
	}
	
	return 0;
}
