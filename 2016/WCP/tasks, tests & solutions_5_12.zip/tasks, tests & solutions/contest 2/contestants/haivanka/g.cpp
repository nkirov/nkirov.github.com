# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

int n, m;
int a[32][32];
int used[32];
int cnt;

void go (int x)
{
	if (x == n + 1)
	{
		cnt ++;
		return;
	}
	go (x + 1);
	int i;
	for (i = 1; i <= n; i ++)
		if (a[x][i] && used[i])
			break;
	if (i <= n)
		return;
	used[x] = 1;
	go (x + 1);
	used[x] = 0;
}

int main ()
{
	int i, p, q;
	while (1)
	{
		scanf ("%d", &n);
		if (n == -1)
			break;
		memset (a, 0, sizeof (a));
		scanf ("%d", &m);
		for (i = 0; i < m; i ++)
		{
			scanf ("%d%d", &p, &q);
			a[p][q] = a[q][p] = 1; 
		}
		cnt = 0;
		go (1);
		printf ("%d\n", cnt);
	}
	return 0;
}

