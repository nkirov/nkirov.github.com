# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

int main ()
{
	unsigned long long a, b, i, x;
	int ans;
	while (cin >> a >> b)
	{
		ans = 0;
		for (i = a; i <= b; i ++)
		{
			x = i;
			while (x)
			{
				ans ++;
				x = x & (x - 1);
			}
 		}
 		printf ("%d\n", ans);
	}
	return 0;
}

