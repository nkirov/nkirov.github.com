# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

int n;
string w[128], l[128];
map <string, int> ma;
string gold, silver;
string ans[128];
int pos;

map <string, int> :: iterator it;

int main ()
{
	int i;
	while (1)
	{
		cin >> n;
		if (!n)
			break; 
		for (i = 0; i < (1 << n) - 1; i ++)
		{
			cin >> w[i];
			cin >> l[i];
			ma[w[i]] ++;
		}
		for (it = ma.begin (); it != ma.end (); it ++)
			if (it->second == n)
				gold = it->first;
				
		for (it = ma.begin (); it != ma.end (); it ++)
			if (it->second == n - 1)
				silver = it->first;
		
		for (i = 0; i < (1 << n) - 1; i ++)
		{
			if (w[i] == gold && l[i] == silver)
				continue;
			if (w[i] == gold)
				ans[pos ++] = l[i];
			if (w[i] == silver)
				ans[pos ++] = l[i]; 
		}
		sort (ans, ans + pos);
		cout << "Gold: " << gold << "\n";
		cout << "Silver: " << silver << "\n";
		cout << "Repechage:";
		for (i = 0; i < pos; i ++)
			cout << " " << ans[i];
		cout << endl;
		ma.clear ();
		pos = 0;			
	}
	return 0;
}

