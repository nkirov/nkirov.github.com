# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

const int MAX_N = 1024;

int n, m;
char c[MAX_N][MAX_N];
int ans[MAX_N][MAX_N];
int let[32];

queue <pair <int, int>> q;

int aa[8] = {-1, 1, 0, 0, -1, 1, -1, 1};
int bb[8] = {0, 0, -1, 1, -1, -1, 1, 1};

void dfs (int x, int y, int cans)
{
	int i;
	///printf ("#%d %d %c %d\n", x, y, c[x][y], cans);
	q.push ({x, y});
	ans[x][y] = cans;
	for (i = 0; i < 8; i ++)
	{
		if (x + aa[i] >= 0 && x + aa[i] < n && y + bb[i] >= 0 && y + bb[i] < m && c[x + aa[i]][y + bb[i]] == c[x][y] && !ans[x + aa[i]][y + bb[i]])
			dfs (x + aa[i], y + bb[i], cans);
	}
}

int main ()
{
	int ttt;
	scanf ("%d", &ttt);
	while (ttt --)
	{
		int i, j;
		pair <int, int> t, nt;
		scanf ("%d%d", &n, &m);
		for (i = 0; i < n; i ++)
			scanf ("%s", c[i]);
		for (i = 0; i < n; i ++)
			for (j = 0; j < m; j ++)
				if (c[i][j] == 'W')
				{
					q.push ({i, j});
					ans[i][j] = 1;
				}
	
		for (i = 0; i < 26; i ++)
			let[i] = 1e9 + 7;
	
		while (!q.empty ())
		{
			t = q.front ();
			q.pop ();
			///printf ("%d %d %c %d\n", t.first, t.second, c[t.first][t.second], ans[t.first][t.second] - 1);
			for (i = 0; i < 8; i ++)
			{
				nt = t;
				nt.first += aa[i];
				nt.second += bb[i];
				if (nt.first < 0 || nt.first >= n)
					continue;
				if (nt.second < 0 || nt.second >= m)
					continue;
				if (ans[nt.first][nt.second])
					continue;
				dfs (nt.first, nt.second, ans[t.first][t.second] + 1);
			}
		}
	
		for (i = 0; i < n; i ++)
			for (j = 0; j < m; j ++)
				let[c[i][j] - 'A'] = min (let[c[i][j] - 'A'], ans[i][j]);
	
		for (i = 0; i < 26; i ++)
		{
			if (char (i + 'A') == 'W')
				continue;
			if (let[i] == 1e9 + 7)
				continue;
			if (let[i])
				printf ("%c %d\n", i + 'A', let[i] - 2);
		}
		printf ("\n");
		
		memset (ans, 0, sizeof (ans));
	}
	return 0;
}
