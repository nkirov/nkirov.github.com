# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

int n;
int a[20000];
int st;

int main ()
{
	ios_base::sync_with_stdio (0);
	cin.tie (0);
	int i, ans1 = 0, ans2 = 0, t;
	while (cin >> n)
	{
		///scanf ("%d", &n);
		for (i = 1; i <= n; i ++)
			cin >> a[i];///scanf ("%d", &a[i]);
		cin >> t;///scanf ("%d", &t);
		sort (a + 1, a + n + 1);
	
		ans1 = ans2 = n;
	
		if (t <= a[1])
		{
			cout << n + a[n] - t << "\n";///printf ("%d\n", n + a[n] - t);
			continue;
		}
	
		if (t >= a[n])
		{
			cout << n + t - a[1] << "\n";///printf ("%d\n", n + t - a[1]);
			continue;
		}
		if (t - a[1] > a[n] - t)
		{
			cout << n + a[n] - t + a[n] - a[1] << "\n";///printf ("%d\n", n + a[n] - t + a[n] - a[1]);
			continue;
		}
		else
		{
			cout << n + t - a[1] + a[n] - a[1] << "\n";///printf ("%d\n", n + t - a[1] + a[n] - a[1]);
			continue;
		}
	}
	return 0;
}
