# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

const int MAX_N = 2e5;

int n;
int c[MAX_N];
long long ans;
int main ()
{
	
	///ios_base::sync_with_stdio (0);
	///cin.tie (0);
	int i, a;
	char cc;
	n = 1;
	while (cin >> a)
	{
		c[n ++] = a; 
		ans += a;
		cin.get (cc);
		if (cc == ' ')
			continue;
		n --;
		sort (c + 1, c + n + 1);
		for (i = n - 2; i > 0; i -= 3)
			ans -= c[i];
		cout << ans << "\n";///printf ("%lld\n", ans);
		n = 1;
		ans = 0;
	}
	/**
	n --;
	sort (c + 1, c + n + 1);
	for (i = n - 2; i > 0; i -= 3)
		ans -= c[i];
	cout << ans << "\n";
	**/
	return 0;
}
