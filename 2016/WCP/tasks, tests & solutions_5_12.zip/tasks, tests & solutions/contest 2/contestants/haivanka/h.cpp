# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

int n, m;
double a, b;
double c1, c2;

double solve (double ca, double cb)
{
	double ans = 0;
	ans = max (ans, min (ca / 3.0, cb));
	ans = max (ans, min (ca / 2.0, cb / 2.0));
	return ans;
}

int main ()
{
	int t;
	scanf ("%d", &t);
	while (t --)
	{
		scanf ("%d%d", &n, &m);
		a = n;
		b = m;
		c1 = solve (a, b);
		c2 = solve (b, a);
		if (c1 > c2)
			printf ("%.3lf\n", c1);
		else
			printf ("%.3lf\n", c2);
	}
	return 0;
}
