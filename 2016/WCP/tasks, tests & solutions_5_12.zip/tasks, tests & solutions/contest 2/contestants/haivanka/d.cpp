# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

int solve (long long sum)
{
	long long l, r, mid, ans;
	l = 0;
	r = 1e9 + 7;
	while (r - l > 1)
	{
		mid = (l + r) >> 1;
		ans = mid * (mid + 1) / 2;
		if (ans - sum >= 0)
			r = mid;
		else
			l = mid;
	}
	return r;
}

int main ()
{
	long long sum, tt;
	while (1)
	{
		scanf ("%lld", &sum);
		if (!sum)
			break;
		tt = solve (sum);
		if (tt * (tt + 1) / 2 == sum)
			printf ("OK\n");
		else
			printf ("%lld\n", tt * (tt + 1) / 2 - sum);
	}
	return 0;
}
