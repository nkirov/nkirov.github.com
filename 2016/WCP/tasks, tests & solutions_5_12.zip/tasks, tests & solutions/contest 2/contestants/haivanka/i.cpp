# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

const int MAX_N = 2050;

int n;
char c[MAX_N][MAX_N];
int sum[MAX_N][MAX_N];

void read ()
{
	int i, j;
	scanf ("%d", &n);
	for (i = 1; i <= n; i ++)
		for (j = 1; j <= n; j ++)	
		{
			while (1)
			{
				scanf ("%c", &c[i][j]);
				if (c[i][j] == '0' || c[i][j] == '1')
					break;
			}
			sum[i][j] = sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1] + (c[i][j] == '1');
		}
}


int main ()
{
	int t, l, r, mid, i, j, fl;
	scanf ("%d", &t);
	while (t --)
	{
		read ();
		l = 0;
		r = n + 1;
		while (r - l > 1)
		{
			fl = 0;
			mid = (l + r) >> 1;
			for (i = mid; i <= n; i ++)
				for (j = mid; j <= n; j ++)
					if ((sum[i][j] - sum[i - mid][j] - sum[i][j - mid] + sum[i - mid][j - mid]) == mid * mid)
						fl = 1;
			if (fl)
				l = mid;
			else
				r = mid;
		}
		printf ("%d\n", l);
	}
}

