# include <cstdio>
# include <cmath>
# include <cstring>
# include <string>
# include <vector>
# include <queue>
# include <map>
# include <algorithm>
# include <iostream>

using namespace std;

const int MAX_N = 1024;
int n, m;

int a[MAX_N][MAX_N];
int ans[MAX_N][MAX_N];

int main ()
{
	int t, i, j;
	scanf ("%d", &t);
	while (t --)
	{
		memset (ans, 0, sizeof (ans));
		scanf ("%d%d", &n, &m);
		for (i = 1; i <= n; i ++)
			for (j = 1; j <= m; j ++)
				scanf ("%d", &a[i][j]);
		for (i = 1; i <= n; i ++)
			ans[i][0] = 1e9;
		for (i = 1; i <= m; i ++)
			ans[0][i] = 1e9;
		for (i = 1; i <= n; i ++)
			for (j = 1; j <= m; j ++)
			{
				ans[i][j] = 1e9;
				if (a[i][j] == 1)
					continue;
				
				if (i == 1 && j == 1)
					ans[i][j] = 0;
				ans[i][j] = min (ans[i][j], ans[i - 1][j] + 1);
				ans[i][j] = min (ans[i][j], ans[i][j - 1] + 1);
				ans[i][j] = min (ans[i][j], ans[i - 1][j - 1] + 1);
			}
		if (ans[n][m] == 1e9)
			printf ("0\n");
		else
			printf ("%d000\n", ans[n][m]);
	}
	return 0;
}

