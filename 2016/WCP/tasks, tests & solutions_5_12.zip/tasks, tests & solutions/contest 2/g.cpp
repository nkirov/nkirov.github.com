#include <iostream>
using namespace std;

int N, M, a, b, ans;
int D[20][20];

bool good(int &mask)
{
	for(int i = 0;i < N - 1;i++)
	{
		if(mask & 1 << i)
		{
			for(int j = i + 1;j < N;j++)
			{
				if(mask & 1 << j && D[i][j])
				{
					return false;
				}
			}
		}
	}

	return true;
}

int main ()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while(cin>>N>>M && N > -1)
	{
		memset(D, 0, sizeof D);
		ans = 1;

		for(int i = 0;i < M;i++)
		{
			cin>>a>>b;
			a--, b--;
			D[a][b] = true;
			D[b][a] = true;
		}

		// for each subsets (2^N)
		for(int mask = 1;mask < (1 << N);mask++)
			if(good(mask))
				ans++;

		cout<<ans<<endl;
	}

	return 0;
}

