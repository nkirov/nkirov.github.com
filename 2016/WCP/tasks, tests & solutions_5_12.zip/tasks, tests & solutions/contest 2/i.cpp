#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
using namespace std;

const int MAXN = 2048;
char in[MAXN][MAXN];
int UP[MAXN];
int N , ANS;
int Left[MAXN] , Right[MAXN];
stack<int> pos;

void go_left()
{
	while(!pos.empty()) 
		pos.pop();

	UP[0] = -100;
	pos.push(0);
	for(int i = 1;i <= N;++i)
	{
		while(UP[pos.top()] >= UP[i])
			pos.pop();
		Left[i] = pos.top();
		pos.push(i);
	}
}

void go_right()
{
	while(!pos.empty()) 
		pos.pop();
  
	UP[N+1] = -100;
	pos.push(N+1);
  
	for(int i=N;i>=1;--i)
	{
		while(UP[pos.top()] >= UP[i])
			pos.pop();
		Right[i] = pos.top();
		pos.push(i);
	}
}

bool ch(int i, int j)
{
	for(int k = i;k < i + ANS;k++)
		for(int l = j;l < j + ANS;l++)
			if(in[k][l] != '1')
				return false;

	return true;
}

bool check()
{
	for(int i = 0;i < N - ANS + 1;i++)
		for(int j = 0;j < N - ANS + 1;j++)
			if(ch(i, j))
			{
				printf("uper left indexes:%d %d\n", i, j);
			}

	return false;
}

int tc = 1;
void doit()
{
	ANS = 0;

	int lp = 0, rp = 0;

	scanf("%d", &N);
	for(int i = 0;i < N;++i)
		scanf("%s", in[i]);
  
	fill(UP , UP + N + 1 , 0);
	for(int i = 0;i < N;++i)
	{
		for(int j = 0;j < N;++j)
			if(in[i][j] == '0') 
				UP[j+1] = 0;
			else 
				UP[j+1] = 1 + UP[j+1];
   
		go_left();
		go_right();
   
		for(int j = 1;j <= N;++j)
		{
			int H = UP[j];
			int LP = Left[j];
			int RP = Right[j];
			int span = max(1, (RP-1) - (LP+1) + 1);
			if(ANS < min(H, span))
			{
				ANS = min(H, span);
				lp = i;
				rp = j;
			}
		}
	}
	
	printf("%d\n", ANS);
	//printf("test #%d: %d\n", tc++, ANS);
	//check();	
}

int main()
{
	int t;
	scanf("%d" , &t);
	while(t--) 
		doit();
  
	return 0;
}
