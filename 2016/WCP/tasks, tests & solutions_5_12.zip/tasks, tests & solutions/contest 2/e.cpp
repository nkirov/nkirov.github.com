#include <iostream>
#include <vector> 
#include <queue>
#include <memory.h>
using namespace std;
 
typedef long long ll;
#define MAX 305 
vector<int> g[MAX];
int seen[MAX];

int main() 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

    int n, m;
    while (cin >> n >> m) 
	{
        if (n == 0) 
			break;

		if(m == 0)
		{
			cout<<0<<endl;
			continue;
		}

        for (int i = 1; i <= n; i++) 
            g[i].clear();
                 
        for (int i = 0; i < m; i++) 
		{
            int x, y; 
			cin >> x >> y;
			
            g[x].push_back(y);
            g[y].push_back(x);
		}
         
        //need to add at least (odd deg)/2 edges.
        //then need to connect all the components together in a cycle.
        //need #(even comp) more edges
        memset(seen, 0, sizeof seen);
        int num_odd = 0, num_even = 0;
        for (int i = 1; i <= n; i++) 
		{
            if (seen[i]) 
				continue;

            if (g[i].empty()) 
				continue;
			             
            vector<int> comp;
            queue<int> q;

            q.push(i);
            seen[i] = true;
            while (!q.empty()) 
			{
                int u = q.front(); q.pop();
                comp.push_back(u);
				for (int i = 0; i < g[u].size();i++) 
				{
					int v = g[u][i];
                    if (seen[v]) 
						continue;

                    q.push(v);
                    seen[v] = true;
                }
            }
             
            int o = 0, e = 0;
			for (int i = 0; i < comp.size();i++) 
                if (g[comp[i]].size() % 2) 
                    o++;
                else 
                    e++;     
             
            if (e == comp.size()) 
                num_even++;
            else 
                num_odd += o;
        }
         
        cout << (num_odd) / 2 + (num_even + bool(num_odd) > 1 ? num_even : 0) << endl;
    }

    return 0;
}