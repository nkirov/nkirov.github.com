#include <iostream>
#include <cmath>
using namespace std;
 
typedef long long ll;
 
int main() 
{
	ll s;
	while (cin >> s && s) 
	{
		ll n = sqrt((double)s*2);
		ll S = n*(n+1)/2;
		if (S == s) 
		{
			cout << "OK\n";
			continue;
		}

		if (s < S)
			cout << S-s << "\n";
		else
			cout << S+n+1-s << "\n";
	}
  
	return 0;
}