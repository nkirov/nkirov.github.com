#include <iostream>
#include <sstream>
#include <string>
#include <functional>   // std::greater
#include <algorithm>    // std::sort
using namespace std;

int n, c, C[100005];
string s;

int main ()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while (getline(cin, s))
	{
		n = 1;
		istringstream instr(s);
		while(instr >> c)
			C[n++] = c; 

		sort(C + 1, C + n, greater<int>());
				
		long ans = 0;
		for(int i = 1;i < n;i++)
			if(i % 3 != 0) 
				ans += C[i];
    
		cout<<ans<<endl;
	}
	
	return 0;
}

