#include <iostream>
#include <cstdlib>
using namespace std;

int a[1000][1000];
int c[1000][1000];

int num, m, n;
const int MAXX = 10000;

void print()
{
     for (int i=0; i<m; i++)
     {
             for (int j=0; j<n; j++)
                 if (c[i][j] < MAXX) cout << c[i][j] << " ";
                 else cout << "x ";
//                 cout << ((c[i][j] < 1000) ? (c[i][j]) : "x") << " ";
             cout << endl;
     }  
     cout << endl;  
}     

int min3(int i, int j)
{
    int c1 = MAXX, c2 = MAXX, c3 = MAXX;
    c1 = c[i-1][j];
    c2 = c[i][j-1];
    c3 = c[i-1][j-1];
    if ( c2 < c1 ) c1 = c2; 
    if ( c3 < c1 ) c1 = c3;
    return c1;
}

void solver()
{
    cin >> num;
    for( int k = 0; k < num; k++)
    { 
         cin >> m >> n;
         for (int i=0; i<m; i++)
             for (int j=0; j<n; j++) 
         {
             cin >> a[i][j];
             c[i][j] = 0;
         }
//         int c[100][100] = {0};
//         print();
         for (int i=1; i<m; i++) 
         {
             if ( a[i][0] == 0 && a[i-1][0] == 0 ) c[i][0] = c[i-1][0] + 1;
             else c[i][0] = MAXX;
         }         
//                print();  
         for (int j=1; j<n; j++)
         {
             if ( a[0][j] == 0 && a[0][j-1] == 0 ) c[0][j] = c[0][j-1] + 1;
             else c[0][j] = MAXX;
         }   
//                print();  
                
         for (int i=1; i<m; i++)
             for (int j=1; j<n; j++)    
          {   
                 if( a[i][j] == 0 ) c[i][j] = min3(i,j) + 1;
                 else c[i][j] = MAXX;
//                 print();
          }      
 //        print();
         if ( c[m-1][n-1] > m + n ) cout << 0 << endl;    
         else cout << c[m-1][n-1]*1000 << endl;
    }
}

void generate()
{
    cout << "1" << endl;
    m = 500; n = 400;
    srand(22);
     cout << m << " " << n << endl;
     for (int i=0; i < m; i++)
     {
      for (int j=0; j < n; j++) 
          if (i==0 && j==0) cout << "0 ";
          else if (i == m - 1 && j == n - 1) cout << "0";
          else
          {
              int k = rand()%3;
              cout << ((k > 0) ? 0 : 1) << " ";
          }
      cout << endl;
     }     
}

int main()
{
//   generate();
 solver();
    return 0;
}

