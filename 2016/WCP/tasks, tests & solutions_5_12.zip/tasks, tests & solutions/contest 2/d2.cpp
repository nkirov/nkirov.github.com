#include <iostream>
#include <cmath>
using namespace std;
 
typedef long long ll;
 
inline ll f(ll n) { return n*(n+1)/2; }
 
int main() 
{
    ll S;
    while (cin >> S) 
	{
        if (S == 0) break;
        ll l = 1, r = 1000000000;
        while (r-l > 1)
		{
            ll m = (l+r)/2;
            if (f(m) < S) 
                l = m+1;
            else 
                r = m;
        }
         
        if (f(l) < S) 
			l++;
        if (f(l) == S) 
            cout << "OK" << endl;
        else 
            cout << f(l)-S << endl;
    }

    return 0;
}