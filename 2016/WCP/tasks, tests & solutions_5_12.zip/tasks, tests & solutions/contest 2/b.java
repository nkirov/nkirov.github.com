import java.util.*;

public class Solution {
    public static void main(String[] args) {
	Scanner in = new Scanner(System.in);
	while (in.hasNextInt()) {
	    int N = in.nextInt();
	    if (!(N>0 && N < 10000))
		throw new IllegalArgumentException();

	    int[] houses = new int[N];
	    for (int i = 0; i < N; ++i) {
		houses[i] = in.nextInt();
		if (!(houses[i] > 0 && houses[i] < 100000))
		    throw new IllegalArgumentException();
	    }

	    int start = in.nextInt();
	    if (!(start > 0 && start < 100000))
		throw new IllegalArgumentException();

	    int mostLeft = start, mostRight = start;
	    
	    // The optimal solution is to go to one side, double back
	    // and then go to the other side. Of course, we double back
	    // on the shorter of the two sides.
	    for (int i = 0; i < N; ++i) {
		mostLeft = Math.min(mostLeft, houses[i]);
		mostRight = Math.max(mostRight, houses[i]);
	    }
	    
	    int ans = mostRight - mostLeft;
	    if (mostRight != start && mostLeft != start) {
		// we do need to double back
		ans += Math.min(mostRight - start, start-mostLeft);
	    }
	    ans += N; // for time to deliver the paper

	    System.out.println(ans);
	}
    }
}