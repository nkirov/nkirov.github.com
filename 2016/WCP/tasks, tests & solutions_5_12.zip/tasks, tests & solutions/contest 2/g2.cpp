#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstring>
#include <memory.h>
using namespace std;

const int MAXN = 21;

int n, m;
bool used[MAXN];
vector <int> E[MAXN];

int calc (int x) 
{
	if (x == n) 
		return 1;

	int ret = calc(x+1);

	bool ok = 1;
	for (auto v: E[x])
		if (used[v]) 
			ok = 0;

	if (ok)
	{
		used[x] = 1;
		ret += calc(x+1);
		used[x] = 0;
	}
	
	return ret;
}

int main (void)
{
	while(scanf("%d%d", &n, &m) && n > -1)
	{
		memset(used, 0, sizeof(used));
		for(int i = 0;i < MAXN;i++)
			E[i].clear();

		for (int i = 0; i < m; ++i) 
		{
			int x, y; 
			scanf("%d%d", &x, &y);
			--x; --y; 
			E[x].push_back(y);
			E[y].push_back(x);
		}

		printf("%d\n", calc(0));
	}
  
	return 0;
}
