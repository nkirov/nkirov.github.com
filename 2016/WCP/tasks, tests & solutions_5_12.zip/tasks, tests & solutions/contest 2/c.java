import java.util.*;

public class Solution {
    public static boolean checkInput(int N, String[] winner, String[] loser) {
	// check that every name is no longer than length 10
	for (int i = 0; i < winner.length; ++i) {
	    if (winner[i].length() > 10 || loser[i].length() > 10) {
		return false;
	    }
	}

	// check that there are 2^N unique names
	Set<String> names = new HashSet<String>();
	for (int i = 0; i < winner.length; ++i) {
	    names.add(winner[i]);
	    names.add(loser[i]);
	}
	if (names.size() != (1<<N)) 
	    return false;

	// check that input describes a perfect single elimination round

	// numMatchWon[i] = # of contestant that has won at least i matches	
	int[] numMatchWon = new int[N+1];
	for (int i = 0; i < (1<<N)-1; ++i) {
	    int matchesWon = 0;
	    for (int j = i; j < (1<<N)-1; ++j) {
		if (winner[i].equals(winner[j])) {
		    ++matchesWon;
		}
	    }
	    ++numMatchWon[matchesWon];
	}

	for (int i = 1; i <= N; ++i) {
	    // there should be exactly (1 << (N-i)) people who've won
	    // at least i matches
	    if (numMatchWon[i] != (1 << (N-i)))
		return false;
	}

	// input is ok!!
	return true;
    }

    public static void main(String[] args) {
	Scanner in = new Scanner(System.in);

	while (in.hasNextInt()) {
	    int N = in.nextInt();
	    if (N == 0)
		break;
	    if (!(N >= 2 && N <= 6))
		throw new IllegalArgumentException("Illegal N");
	
	    int m = (1 << N) - 1; // # of matches
	    String[] winner = new String[m];
	    String[] loser = new String[m];
	    for (int i = 0; i < m; ++i) {
		winner[i] = in.next();
		loser[i] = in.next();
	    }
	    boolean validInput = checkInput(N, winner, loser);
	    if (!validInput) {
		System.out.println("N = " + N + " m = " + m);
		for (int i = 0; i < m; ++i)
		    System.out.println(winner[i] + " " + loser[i]);
		throw new IllegalArgumentException();
	    }

	    // determine number of matches won by each contestant
	    // gold winner should win exactly N matches, silver N-1 matches
	    String gold = "", silver = "";
	    Set<String> seen = new HashSet<String>();
	    for (int i = 0; i < m; ++i) {
		if (!seen.contains(winner[i])) {
		    int numWon = 0;
		    for (int j = i; j < m; ++j) {
			if (winner[i].equals(winner[j])) {
			    ++numWon;
			}
		    }

		    if (numWon == N)
			gold = winner[i];
		    else if (numWon == N-1)
			silver = winner[i];
		    seen.add(winner[i]);
		}
	    }
	    
	    System.out.println("Gold: " + gold);
	    System.out.println("Silver: " + silver);

	    // find the repechage candidates
	    List<String> repechage = new ArrayList<String>();
	    for (int i = 0; i < m; ++i) {
		if (winner[i].equals(gold) || 
		    winner[i].equals(silver))
		    if (!loser[i].equals(silver))
			repechage.add(loser[i]);
	    }
	    Collections.sort(repechage);

	    System.out.print("Repechage: ");
	    for (int i = 0; i < repechage.size(); ++i) {
		if (i > 0) System.out.print(" ");
		System.out.print(repechage.get(i));
	    }
	    System.out.println();
	}
    }
}