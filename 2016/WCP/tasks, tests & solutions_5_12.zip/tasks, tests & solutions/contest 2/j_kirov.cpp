#include <iostream>
using namespace std;

typedef unsigned long long ull;

int sumbits(ull k)
{
    int sum = 0;
    while (k > 0)
    {
        sum += k%2;
        k /= 2;
    }
    return sum;
}

int sumbits1(ull k)
{
    int sum = 0;
    ull one = 1;
    int num = sizeof(ull)*8;
    for (int i = 0; i < num; i++)
        sum += static_cast<int>((((one << i) & k) > 0));
    return sum;
}

int main()
{
    ull k = 0, l;
//    cout << ~k << " " << sizeof(ull) << endl;
    while (cin >> k >> l)
    {
        int sumi = 0;
        for (ull i = k; i <= l; ++i)
            sumi += sumbits(i);
        cout << "  " << sumi << endl;
    }
    return  0;
}
