﻿#include <iostream>
#include <algorithm>
using namespace std;

int n;
int A[10000];

int main () 
{
	cin.sync_with_stdio(0);
	cin.tie(0);

    while(true) 
	{
        int x;
        cin >> n;
        if (cin.eof()) break;
    
        for (int i = 0; i < n; i++) 
            cin >> A[i];
    
        cin >> x;
        sort(A, A + n);

        cout << n + A[n-1] - A[0] + min(abs(x - A[0]), abs(x - A[n-1])) << endl;
    }
}

