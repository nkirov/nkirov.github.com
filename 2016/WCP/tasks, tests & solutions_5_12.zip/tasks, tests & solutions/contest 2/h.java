/******************************************************************/
/* ACM ICPC 2015-2016, NEERC                                      */
/* Northern Subregional Contest                                   */
/* St Petersburg, October 24, 2015                                */
/******************************************************************/
/* Problem A. Alex Origami Squares                                */
/*                                                                */
/* Original idea         Georgiy Korneev                          */
/* Problem statement     Georgiy Korneev                          */
/* Test set              Georgiy Korneev                          */
/******************************************************************/
/* Solution                                                       */
/*                                                                */
/* Author                Georgiy Korneev                          */
/******************************************************************/

import java.io.*;
import java.util.*;

public class Solution {
    static Scanner in;
    static PrintWriter out;

    static void run() {
        int h = in.nextInt();
        int w = in.nextInt();
        int min = Math.min(h, w);
        int max = Math.max(h, w);
        out.println(Math.max(min / 2.0, Math.min(min,  max / 3.0)));
    }

    public static void main(String[] args) throws Exception {
        in = new Scanner(System.in);
        out = new PrintWriter(System.out);

        int t = in.nextInt();
        for(int i = 0;i < t;i++)
        	run();

        in.close();
        out.close();
    }
}

