#include <iostream>
#include <bitset>
using namespace std;

typedef unsigned long long ull;

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

    ull a, b;
    while (cin >> a >> b)
    {
        int ans = 0;
        while(a <= b)
		{
			bitset<64> bs(a);
            ans += bs.count();
			a++;
		}

        cout <<ans<< endl;
    }

    return  0;
}
