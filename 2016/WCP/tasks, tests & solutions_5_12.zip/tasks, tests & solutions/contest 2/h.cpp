/******************************************************************/
/* ACM ICPC 2015-2016, NEERC                                      */
/* Northern Subregional Contest                                   */
/* St Petersburg, October 24, 2015                                */
/******************************************************************/
/* Problem A. Alex Origami Squares                                */
/*                                                                */
/* Original idea         Georgiy Korneev                          */
/* Problem statement     Georgiy Korneev                          */
/* Test set              Georgiy Korneev                          */
/******************************************************************/
/* Solution                                                       */
/*                                                                */
/* Author                Pavel Kunyavskiy                         */
/******************************************************************/

#include <cstdio>
#include <algorithm>
using namespace std;

int main() 
{
	int t, h, w;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&h,&w);

		if (h > w) 
			swap(h, w);

		float ans = h/2.0;
		ans = max(ans, min(h*1.0, w/3.0));

		printf("%.10f\n", ans);   
	}
}
