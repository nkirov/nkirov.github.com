/*
 * Adopted from Unique Encryption Keys
 * ACM ICPC - CERC 2011
 *
 * Sample solution: Unique Encryption Keys (unique)
 * Author: Martin Kacer
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class b {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws Exception {
		unique instance = new unique();
		while (instance.run()) {/*repeat*/}
	}
	String nextToken() throws Exception {
		while (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		return st.nextToken();
	}
	int nextInt() throws Exception {
		return Integer.parseInt(nextToken());
	}

	int[] nums = new int[1000000], last = new int[1000000];
	Map<Integer, Integer> previous = new HashMap<Integer, Integer>(2000000);
	
	boolean run() throws Exception {
		int cnt = nextInt(), q = nextInt();
		if (cnt == 0) return false;
		previous.clear();
		int prvlast = -1;
		for (int i = 0; i < cnt; ++i) {
			nums[i] = nextInt();
			Integer n = Integer.valueOf(nums[i]);
			Integer idx = previous.get(n);
			previous.put(n, Integer.valueOf(i));
			if (idx != null) { 
				int ii = idx.intValue();
				if (prvlast == -1 || ii > prvlast) prvlast = ii;
			}
			last[i] = prvlast;
		}
		for (int i = 0; i < q; ++i) {
			int a = nextInt()-1, b = nextInt()-1;
			if (last[b] >= a)
				System.out.println(nums[last[b]]);
			else
				System.out.println("OK");
		}
		System.out.println();
		return true;
	}
}