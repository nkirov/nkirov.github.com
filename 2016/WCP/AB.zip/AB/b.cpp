/*
 * Adopted from Unique Encryption Keys
 * ACM ICPC - CERC 2011
 *
 * Sample solution: unique
 * Author: Jan Katrenic
 */

#include <cstdio>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int n,m;
vector<int> value;

int main()
{
	for(;;) 
	{
		scanf("%d %d\n", &n, &m);
		if (!n) return 0;
		value.resize(n);

		for (int i = 0; i < n; i++) 
			scanf("%d", &value[i]);


		map<int,int> last_occ;
		vector<int> first_match(n);

		for (int i = n-1; i >= 0; i--)
		{
			first_match[i] = n;  
			if (i < n-1) 
				first_match[i] = first_match[i+1];
			
			if (last_occ.count(value[i]))
				first_match[i] = min(first_match[i], last_occ[value[i]]);

			last_occ[value[i]] = i;
		}

		for (int i = 0; i < m; i++) 
		{
			int x, y;
			scanf("%d %d",&x, &y); x--; y--;
			if (first_match[x] <= y) 
				printf("%d\n",value[first_match[x]]);
			else 
				printf("OK\n");
		}

		printf("\n");
	}
}
