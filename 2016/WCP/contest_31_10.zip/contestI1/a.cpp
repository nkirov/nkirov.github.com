// source - http://www.math.bas.bg/infos/files/2015-04-27-D2.pdf
// analysis - http://www.math.bas.bg/infos/files/2015-04-27-sol-D2.pdf

#include<iostream>
#include<algorithm>
using namespace std;

#define M 1001
#define N 1001

int m, n;
int t[M][N];
int d[M][N];

inline int min3(int &a, int &b, int &c)
{
	return min(min(a, b), c);
}

void dp()
{
	int i, j;
	for(i = 0;i < m;i++) 
		d[i][0] = t[i][0];
	
	for(j = 1;j < n;j++)
	{
		// first row
		i = 0;
		d[i][j] = t[i][j] + min(d[i][j-1], d[i+1][j-1]);
		
		for(i = 1;i < m - 1;i++) 
			d[i][j] = t[i][j] + min3(d[i-1][j-1], d[i][j-1], d[i+1][j-1]);
   
		//last row
		i = m - 1;
		d[i][j] = t[i][j] + min(d[i-1][j-1], d[i][j-1]);
	}
}

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while(cin >> m >> n && m)
	{
		for(int i = 0;i < m;i++)
			for(int j = 0;j < n;j++)
				cin >> t[i][j];

		 dp();

		 int ans = d[0][n - 1];
		 for(int i = 1;i < m;i++) 
			 ans = min(ans, d[i][n-1]);

		 cout << ans << endl;
	}

	return 0;
}
