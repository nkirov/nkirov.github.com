// Author: Damian Straszak

#include <iostream>
#include <algorithm>
#include <cmath>
#define ll long long 

using namespace std;

int n;


int main()
{
    ios_base::sync_with_stdio(0);
    int test;
    cin>>test;
    while(test--)
    {
    	cin>>n;
    	int L=n+1,K;
    	int limit=min((int)(2*sqrt(n)),n);
    	for(int l=2;l<=limit;l++)
    	{
    		ll lo=0,hi=n+1,mid;
    		while(hi-lo>1)
    		{
    			mid=(hi+lo)/2;
    			if (l*(2*mid+l-1)>2*n) hi=mid;
    			else lo=mid;
    		}
    		if (lo>0 && l*(2*lo+l-1)==2*n)
    		{
    			L=l;
    			K=lo;
    			break;
    		}
    	}
    	if (L<=n)
    	{
    		cout<<n<<" = ";
    		for(int i=0;i<L-1;i++) cout<<K+i<<" + ";
    		cout<<K+L-1<<"\n";
    	}
    	else cout<<"IMPOSSIBLE\n";
    }
	return 0;
}


