// source - http://www.math.bas.bg/infos/files/2012-05-08-D2.pdf
// analysis - http://www.math.bas.bg/infos/files/2012-05-08-sol-D2.pdf

/**
AUTHOR: Evgenii Vassilev
*/

#include <iostream>
using namespace std;

int main()
{
	unsigned long long a, b, p, q, s, i;
  
	cin.sync_with_stdio(0);
	cin.tie(0);

	while(cin >> a >> b >> p >> q)
	{
		if (p < q) 
		swap(p, q);
	  
		for (i = p; p % q; p += i);

  
		if (i = a % p)
			a += p - i;
  
		b -= b % p;
  
		for (s = 0;a <= b;a += p) 
			s += a;
	
		cout<<s<<endl;
	}

	return 0;
}