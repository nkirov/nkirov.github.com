// Author: Lech Duraj

#include <iostream>
#include <algorithm>

using namespace std;

int row(int x)
{
    if (x==0)
        return 4;
    return (x+2)/3;
}

int column(int x)
{
    if (x==0)
        return 2;
    return (x-1)%3+1;
}

bool good(int x)
{
    if (x==100 || x==200 || x<10)
        return true;
    if (x>100)
        x -= 100;
    int a = x/10;
    int b = x%10;
    return row(a)<=row(b) && column(a)<=column(b);
}

int abs(int x)
{
    return x>0 ? x : -x;
}

int main()
{
    int TT;
    cin >> TT;
    while(TT--)
    {
        int x;
        cin >> x;
        int best = 1;
        for(int i=1; i<=200; i++)
            if (good(i) && abs(i-x)<abs(best-x))
                best = i;
        cout << best << endl;
    }
}
