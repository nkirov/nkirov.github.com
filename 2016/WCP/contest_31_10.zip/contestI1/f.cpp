// Miguel Araujo
#include <cstdio>
#include <vector>
#include <cstring>

#define MAXN 100000

using namespace std;

int n,m;

vector<int> g[MAXN];
int visited[MAXN];
int pairs[MAXN];

// simple Ford-Fulkerson
bool bpm(int v) {
  if (visited[v]) return false;
  visited[v] = true;
  for (size_t i = 0; i<g[v].size(); i++) {
    if (pairs[g[v][i]] == -1 || bpm(pairs[g[v][i]])) {
      pairs[g[v][i]] = v;
      return true;
    }
  }
  return false;
}

int main() {
  scanf("%d %d", &n, &m);
  int a,b;
  for (int i = 0; i<m; i++) {
    scanf("%d %d", &a, &b);
    g[a].push_back(b);
  }
  
  memset(pairs, -1, sizeof(pairs));
  int cnt = 0;
  for (int i = 0; i<n; i++) {
    memset(visited, 0, sizeof(visited));
    if (bpm(i))
      cnt++;
  }
  puts((cnt==n?"YES": "NO"));
  return 0;
}
