import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Queue;
import java.util.LinkedList;

/**
 * @author Margarida Mamede
 */


public class BookClubEK
{

    private int numNodes;

    private Queue<Integer>[] edges; 

    private int[] leftNode; 

    private int[] rightNode; 


    @SuppressWarnings("unchecked")
    public BookClubEK( int numPeople )
    {
        numNodes = numPeople;
        edges = ( Queue<Integer>[] ) new Queue[numNodes];
        leftNode = new int[numNodes];
        rightNode = new int[numNodes];
        for ( int i = 0; i < numNodes; i++ )
        {
            edges[i] = new LinkedList<Integer>();
            leftNode[i] = -1;
        }
    }


    public void addEdge( int head, int tail )
    {
        edges[head].add(tail);
    }
        

    public int maxMatchingSize( )
    {
        int[] via = new int[numNodes]; 
        int matchSize = 0;
        int head, tail, auxTail;

        for ( int i = 0; i < numNodes; i++ ) 
            if ( ( tail = this.findPath(i, via) ) >= 0 )
            {
                matchSize++;
                do
                    {
                        head = via[tail];
                        auxTail = rightNode[head];
                        rightNode[head] = tail;
                        leftNode[tail] = head;
                        tail = auxTail;
                    }
                while ( head != i );
            }
        return matchSize;
    }


    private int findPath( int node, int[] via )
    {
        Queue<Integer> waiting = new LinkedList<Integer>();
        boolean[] found = new boolean[numNodes];
        int head, auxHead;

        waiting.add(node);
        do
            {
                head = waiting.remove();
                for ( int tail : edges[head] )
                    if ( !found[tail] )
                    {
                        found[tail] = true;
                        via[tail] = head;
                        auxHead = leftNode[tail];
                        if ( auxHead < 0 )
                            return tail;
                            
                        waiting.add(auxHead);
                    }
            }
        while ( !waiting.isEmpty() );

        return -1;
    }


    public static void main( String[] args ) throws IOException
    {
        BufferedReader input = 
            new BufferedReader( new InputStreamReader(System.in) );

        StringTokenizer line = new StringTokenizer( input.readLine() );
        int numPeople = Integer.parseInt( line.nextToken() );
        int numPairs = Integer.parseInt( line.nextToken() );
        BookClubEK graph = new BookClubEK(numPeople);
            
        for ( int i = 0; i < numPairs; i++ )
        {
            line = new StringTokenizer( input.readLine() );
            int member1 = Integer.parseInt( line.nextToken() );
            int member2 = Integer.parseInt( line.nextToken() );
            graph.addEdge(member1, member2);
        }
        input.close();

        if ( graph.maxMatchingSize() == numPeople )
            System.out.println("YES");
        else
            System.out.println("NO");
    }


}
