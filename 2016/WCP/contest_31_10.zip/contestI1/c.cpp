/* Adopted from Vigen�re Cipher Encryption
 * CTU Open Contest 2011
 *
 * Sample solution: vigenere
 * Author: Jan Stoklasa
*/
#include <iostream>
#include <string>
 
using namespace std;
 
const int ALPHA = 'Z' - 'A' + 1;
int main(void)
{
	string key, plaintext;
	while( cin >> key && key != "0" && cin >> plaintext )
	{
		int M = key.length();
		int N = plaintext.length();
		for (int i = 0; i < N; i++)
		{
			cout << static_cast<char>('A' + (key[i % M] - 'A' + 1 + plaintext[i] - 'A') % ALPHA);
		}
	}
	return 0;
}
