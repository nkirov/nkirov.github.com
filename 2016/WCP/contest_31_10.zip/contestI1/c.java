/* Adopted from Vigen�re Cipher Encryption
 * ACM ICPC - CERC 2011
 *
 * Sample solution: Vigenere Cipher Encryption (vigenere)
 * Author: Martin Kacer
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class c {
	StringTokenizer st = new StringTokenizer("");
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	public static void main(String[] args) throws Exception {
		vigenere instance = new vigenere();
		while (instance.run()) {/*repeat*/}
	}
	String nextToken() throws Exception {
		while (!st.hasMoreTokens()) st = new StringTokenizer(input.readLine());
		return st.nextToken();
	}
	
	String sumString(String key, String txt) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < txt.length(); ++i) {
			char c = (char)(txt.charAt(i) + 1 + key.charAt(i % key.length()) - 'A');
			sb.append((c > 'Z') ? (char)(c-26) : c);
		}
		return sb.toString();
	}
	
	boolean run() throws Exception {
		String s = nextToken();
		if ("0".equals(s)) return false;
		System.out.println(sumString(s, nextToken()));
		return true;
	}
}