// SWERC 2014, Problem The Big Painting
// Approach: Aho-Corasick to check where the pattern lines appear on the text lines.
// Then use KMP algorithm to find if the pattern sequence was matched in any of the text columns.
// Author: Miguel Oliveira
#include <stdio.h>
#include <string.h>
#include <queue>
#include <iostream>
#include <string>
using namespace std;
const int ALPHABET_SIZE = 2;
const int MAX = 2002;

struct Node {
  Node* next[ALPHABET_SIZE];
  Node* fall_ptr;
  int pattern_id;
  Node() {
    fall_ptr = NULL;
    pattern_id = -1;
    memset(next, 0, sizeof next);
  }
} root;

char text[MAX+5][MAX+5], pattern[MAX+5][MAX+5];
int PL, PC, L, C, char_index[256];
int pattern_lines_ids[MAX+5], pattern_id = 0, match[MAX+5][MAX+5], found[MAX+5][MAX+5];

int TrieInsert(Node* node, char* s) {
  for (; *s; s++) {
    int ind = char_index[(int)*s];
    if (!node->next[ind])
      node->next[ind] = new Node();
    node = node->next[ind];
  }
  if (node->pattern_id == -1)
    node->pattern_id = ++pattern_id;
  return node->pattern_id;
}
void BuildTrie() {
  int i;
  // Insert pattern lines in the trie.
  for (i = 0; i < PL; i++)
    pattern_lines_ids[i] = TrieInsert(&root, pattern[i]);

  // Build fall function.
  queue<Node*> q;
  for (i = 0; i < ALPHABET_SIZE; i++)
    if (root.next[i] == NULL)
      root.next[i] = &root;  // Complete the next function for the root.
    else {
      q.push(root.next[i]);
      root.next[i]->fall_ptr = &root;
    }
  while (!q.empty()) {
    Node* cur = q.front();  q.pop();
    for (i = 0; i < ALPHABET_SIZE; i++)
      if (cur->next[i]) {
        q.push(cur->next[i]);
        Node* v = cur->fall_ptr;
        while (v->next[i] == NULL)
          v = v->fall_ptr;
        cur->next[i]->fall_ptr = v->next[i];
      }
  }
}
void AhoCorasickSearch() {
  int i, j, ind;
  for (i = 0; i < L; i++) {
    Node* cur = &root;
    for (j = 0; j < C; j++) {
      ind = char_index[(int)text[i][j]];
      while (cur->next[ind] == NULL)
        cur = cur->fall_ptr;
      cur = cur->next[ind];
      // If the pattern lengths are the same, there is only one possible match here.
      if (cur->pattern_id != -1) {
        match[j][i] = cur->pattern_id;  // Note: indexed by column to simplify the 2d search step.
        //printf("Found pattern %d at %d, %d\n", cur->pattern_id, i, j);
      }
    }
  }
}
void Search2d() {
  int next[MAX + 5], i, j;
  // KMP pre-processing which we will use for each text column.
  next[0] = -1;
  for (i = 0, j = -1; i < PL; i++, j++, next[i] = (pattern_lines_ids[i] == pattern_lines_ids[j]) ? next[j] : j)
    while ((j >= 0) && (pattern_lines_ids[i] != pattern_lines_ids[j])) 
      j = next[j];

  // Check if the sequence of pattern lines was matched in any text column.
  for (int col = 0; col < C; col++) {
    for (i=0, j=0; i < L; ) {
      while((j >= 0) && (match[col][i] != pattern_lines_ids[j])) 
        j = next[j];
      ++i;
      if (++j == PL) {
        found[i-PL][col-PC+1] = 1;
      }
    }
  }
}
int main() {
  int i, j;
  char_index[(int)'x'] = 1;
  scanf("%d %d %d %d", &PL, &PC, &L, &C);
  for (i = 0; i < PL; i++)
    scanf("%s", pattern[i]);
  for (i = 0; i < L; i++)
    scanf("%s", text[i]);

  BuildTrie();
  AhoCorasickSearch();
  Search2d();
  int cnt = 0;
  for (i = 0; i < L; i++)
    for (j = 0; j < C; j++)
      if (found[i][j])
	cnt++;
  //printf("%d %d\n", i+1, j+1);
  printf("%d\n", cnt);
  return 0;
}
