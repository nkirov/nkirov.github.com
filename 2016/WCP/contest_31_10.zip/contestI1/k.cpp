#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    for (int k = 0; k < n; k++)
    {
        int a[4];
        for (int i = 0; i < 4; i++)
            cin >> a[i];
        int amin = a[0], imin = 0;
        for (int i = 1; i < 4; i++)
            if (a[i] < amin)
            {
                amin = a[i];
                imin = i;
            }
        int sum = 0;
        for (int i = 0; i < 4; i++) sum += a[i];
        cout << sum - a[imin] + 1 << endl;
    }
    return 0;
}
