// SWERC 2014, Problem Book Club
// Approach: Bipartite maximum matching using fold fulkerson algorithm.
// Author: Miguel Oliveira
import java.io.*;
import java.util.Arrays;
import java.util.StringTokenizer;

public class BookClubMaxFlow {
  public static void main(String[] args) throws IOException {
    BookClubMaxFlow solver = new BookClubMaxFlow();
    solver.solve();
  }

  boolean[] visited;
  int[] to;
  int[] cap;
  int[] head;
  int[] next;
  int ne;

  public void addEdge(int a, int b) {
    to[ne] = b; cap[ne] = 1; next[ne] = head[a]; head[a] = ne++;
    to[ne] = a; cap[ne] = 0; next[ne] = head[b]; head[b] = ne++;
  }
  public void solve() throws IOException {
    int m, i, a, b, source, sink, n;
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    StringTokenizer line = new StringTokenizer(input.readLine());
    n = Integer.parseInt(line.nextToken());
    m = Integer.parseInt(line.nextToken());
    visited = new boolean[2 * n + 2];
    head = new int[2 * n + 2];
    to = new int[2 * m + 4 * n + 20];
    cap = new int[2 * m + 4 * n + 20];
    next = new int[2 * m + 4 * n + 20];
    source = n+n;
    sink = n+n+1;
    ne = 2;
    for (i = 0; i < m; i++) {
      line = new StringTokenizer(input.readLine());
      a = Integer.parseInt(line.nextToken());
      b = Integer.parseInt(line.nextToken());
      addEdge(a, b+n);
    }
    for (i = 0; i < n; i++) {
      addEdge(source, i);
      addEdge(i+n, sink);
    }
    if (maxFlow(source, sink) == n)   System.out.println("YES");
    else                              System.out.println("NO");
  }

  public int dfs(int cur, int sink) {
    visited[cur] = true;
    if (cur == sink)
      return 1;
    for (int e = head[cur]; e > 0; e = next[e]) {
      if (!visited[to[e]]) {
        int x = cap[e];
        if (x > 0 && dfs(to[e], sink) == 1) {
          --cap[e];
          ++cap[e^1];
          return 1;
        }
      }
    }
    return 0;
  }
  public int maxFlow(int source, int sink) {
    int flow = 0, inc;
    do {
      Arrays.fill(visited, false);
      inc = dfs(source, sink);
      flow += inc;
    } while (inc > 0);
    return flow;
  }
}
