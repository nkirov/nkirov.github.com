#include<iostream>
#include<string>
using namespace std;

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	int t;
	cin>>t;
	cin.get();

	while(t--)
	{
		int c = 1, m = 0;
		char b =' ', s =' ';
		
		string str;
		getline(cin, str);

		for(int i = 0;i < str.size();i++)
		{
			if(str[i] != b)
			{
				if(c > m)
				{
					m = c; 
					s = b;
				}

			    if(c == m)
				{
					if(b > s) 
						s = b;
				}
				
				c = 1;
				b = str[i];
			}
			else c++;
		}

		if(c > m)
		{
			m = c; 
			s = b;
		}

		if(c == m)
		{
			if(b > s) 
				s = b;
		}

		cout << m << " " << s << endl;
	}
}
