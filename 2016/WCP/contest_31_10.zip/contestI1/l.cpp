#include <iostream>
#include <cmath>
using namespace std;

bool isprime(unsigned k)
{
    for (int i = 2; i < sqrt(k*1.0) + 1; i++)
        if (k%i == 0) return false;
    return true;
}

int main()
{
    unsigned k = 0;
//    cout << ~k << ((~k > 1000000000) ? " yes" : " no") << endl;
    while (cin >> k)
    {
        int i = k;
        while (!isprime(i)) i++;
        int j = k;
        while (!isprime(j)) j--;
        cout <<  i - j + 1 << " ";
    }
    return 0;
}