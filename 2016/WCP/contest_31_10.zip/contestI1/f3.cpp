// SWERC 2014, Problem Book Club
// Approach: Bipartite maximum matching using fold fulkerson algorithm.
// Author: Miguel Oliveira
#include <stdio.h>
#include <string.h>
#include <map>
#include <vector>
using namespace std;

const int MAX = 2*10000 + 20;
char visited[MAX];
map<int, int> cap[MAX];
vector<int> adj[MAX];

inline void AddEdge(int a, int b) {
  cap[a][b] = 1;
  adj[a].push_back(b);
  adj[b].push_back(a);
}
int Dfs(int cur, int sink, int flow) {
  visited[cur] = 1;
  if (cur == sink)
    return flow;
  for (vector<int>::iterator it = adj[cur].begin(); it != adj[cur].end(); it++) {
    if (!visited[*it]) {
      int x = cap[cur][*it];
      if (x > 0 && (x = Dfs(*it, sink, min(flow, x))) > 0) {
        cap[cur][*it] -= x;
        cap[*it][cur] += x;
        return x;
      }
    }
  }
  return 0;
}
int MaxFlow(int source, int sink) {
  int flow = 0, inc;
  do {
    memset(visited, 0, sizeof visited);
    inc = Dfs(source, sink, 1 << 30);
    flow += inc;
  } while (inc);
  //printf("%d\n", flow);
  return flow;
}
int main() {
  int m, i, a, b, source, sink, n;
  scanf("%d %d", &n, &m);
  source = n+n, sink = n+n+1;
  for (i = 0; i < m; i++) {
    scanf("%d %d", &a, &b);
    AddEdge(a, b+n);
  }
  for (i = 0; i < n; i++) {
    AddEdge(source, i);
    AddEdge(i+n, sink);
  }
  if (MaxFlow(source, sink) == n)   puts("YES");
  else                              puts("NO");
  return 0;
}
