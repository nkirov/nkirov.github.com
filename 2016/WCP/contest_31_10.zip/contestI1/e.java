// Author: Damian Straszak

import java.io.*;
import java.util.*;

public class e
{
	BufferedReader br;
	PrintWriter out;
	StringTokenizer st;
	boolean eof;
	
	int row(int x)
	{
		if (x==0) return 4;
		return (x+2)/3;
	}

	int col(int x)
	{
		if (x==0) return 2;
		return (x+2)%3+1;
	}

	boolean valid(int s)
	{
		if (s==100 || s==200 || s<10) return true;
		if (s>100) s-=100;
		int a=s/10;
		int b=s%10;
		return (row(a)<=row(b) && col(a)<=col(b));
	}
	

	void solve() throws IOException 
	{
		int test=nextInt();
		while(test-->0)
		{
			int s=nextInt();
			int res=1;
			for(int i=1;i<=200;i++)
			{
				if (valid(i) && Math.abs(i-s)<Math.abs(res-s)) res=i;
			}
			out.println(res);
		}
		
	}

	H() throws IOException 
	{
		br=new BufferedReader(new InputStreamReader(System.in));
		out=new PrintWriter(System.out);
		solve();
		out.close();
	}

	public static void main(String[] args) throws IOException 
	{
		new H();
	}

	String nextToken() 
	{
		while (st==null || !st.hasMoreTokens()) 
		{
			try 
			{
				st=new StringTokenizer(br.readLine());
			} 
			catch (Exception e) 
			{
				eof=true;
				return null;
			}
		}
		return st.nextToken();
	}

	String nextString() 
	{
		try 
		{
			return br.readLine();
		} 
		catch (IOException e) 
		{
			eof=true;
			return null;
		}
	}

	int nextInt() throws IOException 
	{
		return Integer.parseInt(nextToken());
	}

	long nextLong() throws IOException 
	{
		return Long.parseLong(nextToken());
	}

	double nextDouble() throws IOException 
	{
		return Double.parseDouble(nextToken());
	}
	
}
