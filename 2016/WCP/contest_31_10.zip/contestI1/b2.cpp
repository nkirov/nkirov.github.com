// source - http://www.math.bas.bg/infos/files/2012-05-08-D2.pdf
// analysis - http://www.math.bas.bg/infos/files/2012-05-08-sol-D2.pdf

/**
AUTHOR: Rusko Shikov
*/

#include <iostream>
using namespace std;

unsigned long long p, q, a, b, lcm, ans, lo, hi;

int main()
{
	cin.sync_with_stdio(0);
	cin.tie(0);

	while(cin >> a >> b >> p >> q)
	{
		if (p < q) 
			swap(p, q);

		lcm = p;
		while ((lcm % q) > 0)
			lcm += p;

		if ((a % lcm)==0)
			lo = a;
		else
			lo = a + (lcm - (a % lcm));
		
		hi = b - (b % lcm);

		ans = 0;
		for (int i = lo;i <= hi;i +=lcm)
			ans += i;

		cout << ans << endl;
	}
	
	return 0;         
}
