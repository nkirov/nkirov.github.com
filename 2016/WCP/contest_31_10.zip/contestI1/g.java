// SWERC 2014, Problem The Big Painting
// Approach: Aho-Corasick to check where the pattern lines appear on the text lines.
// Then use KMP algorithm to find if the pattern sequence was matched in any of the text columns.
// Author: Miguel Oliveira
import java.io.*;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class PaintingBase { 
  public static final int ALPHABET_SIZE = 2;
  public static final int MAX_LINES = 2000 + 5;

  static class Node {
    Node[] next;
    Node fall_node;
    int pattern_id;
    public Node() {
      next = new Node[ALPHABET_SIZE];
      fall_node = null;
      pattern_id = -1;
    }
  }
  static BufferedReader input = new BufferedReader( new InputStreamReader(System.in) );
  public static void main(String[] args) throws IOException {
    PaintingBase p = new PaintingBase();
    p.solve();
  }
  
  String[] text = new String[MAX_LINES];
  String[] pattern = new String[MAX_LINES];
  int[] pattern_lines_ids = new int[MAX_LINES];
  int[][] match = new int[MAX_LINES][MAX_LINES];
  boolean[][] found = new boolean[MAX_LINES][MAX_LINES];
  int cur_pattern_id = 0;
  Node trie_root = new Node();

  public void solve() throws IOException {
    StringTokenizer line = new StringTokenizer(input.readLine());
    int PL = Integer.parseInt(line.nextToken());
    int PC = Integer.parseInt(line.nextToken());
    int L = Integer.parseInt(line.nextToken());
    int C = Integer.parseInt(line.nextToken());
    int i, j;
    for (i = 0; i < PL; i++)
      pattern[i] = input.readLine();
    for (i = 0; i < L; i++)
      text[i] = input.readLine();

    BuildTrie(PL);
    AhoCorasickSearch(L, C);
    Search2d(PL, PC, L, C);
	int cnt = 0;
    for (i = 0; i < L; i++)
      for (j = 0; j < C; j++)
        if (found[i][j])
			cnt = cnt + 1;
			//outputBuilder.append((i+1) + " " + (j+1) + "\n");
    System.out.println(cnt);
  }
  public int TrieInsert(Node node, String s) {
    for (char c : s.toCharArray()) {
      int ind = c == 'x' ? 1 : 0;
      if (node.next[ind] == null)
        node.next[ind] = new Node();
      node = node.next[ind];
    }
    if (node.pattern_id == -1)
      node.pattern_id = ++cur_pattern_id;
    return node.pattern_id;
  }
  void BuildTrie(int PL) {
    int i;
    // Insert pattern lines in the trie.
    for (i = 0; i < PL; i++)
      pattern_lines_ids[i] = TrieInsert(trie_root, pattern[i]);

    // Build fall function.
    LinkedList<Node> q = new LinkedList<Node>();
    for (i = 0; i < ALPHABET_SIZE; i++)
      if (trie_root.next[i] == null)
        trie_root.next[i] = trie_root;  // Complete the next function for the root.
      else {
        q.add(trie_root.next[i]);
        trie_root.next[i].fall_node = trie_root;
      }
    while (!q.isEmpty()) {
      Node cur = q.poll();
      for (i = 0; i < ALPHABET_SIZE; i++)
        if (cur.next[i] != null) {
          q.add(cur.next[i]);
          Node v = cur.fall_node;
          while (v.next[i] == null) {
            v = v.fall_node;
          }
          cur.next[i].fall_node = v.next[i];
        }
    }
  }
  void AhoCorasickSearch(int L, int C) {
    int i, j, ind;
    for (i = 0; i < L; i++) {
      Node cur = trie_root;
      for (j = 0; j < C; j++) {
        char c = text[i].charAt(j);
        ind = c == 'x' ? 1 : 0;
        while (cur.next[ind] == null)
          cur = cur.fall_node;
        cur = cur.next[ind];
        // If the pattern lengths are the same, there is only one possible match here.
        if (cur.pattern_id != -1) {
          match[j][i] = cur.pattern_id;  // Note: indexed by column to simplify the 2d search step.
          //printf("Found pattern %d at %d, %d\n", cur->pattern_id, i, j);
        }
      }
    }
  }
  void Search2d(int PL, int PC, int L, int C) {
    int i, j;
    int[] next = new int[MAX_LINES];
    // KMP pre-processing which we will use for each text column.
    next[0] = -1;
    for (i = 0, j = -1; i < PL; i++, j++, next[i] = (pattern_lines_ids[i] == pattern_lines_ids[j]) ? next[j] : j)
      while ((j >= 0) && (pattern_lines_ids[i] != pattern_lines_ids[j])) 
        j = next[j];

    // Check if the sequence of pattern lines was matched in any text column.
    for (int col = 0; col < C; col++) {
      for (i=0, j=0; i < L; ) {
        while((j >= 0) && (match[col][i] != pattern_lines_ids[j])) 
          j = next[j];
        ++i;
        if (++j == PL) {
          // found at position i-M
          found[i-PL][col-PC+1] = true;
        }
      }
    }
  }
}
