// Author: Adam Polak
#include <cassert>
#include <iostream>
using namespace std;

int GetRow(int x) {
  if (x > 0)
    return (x - 1) / 3;
  else
    return 3;
}

int GetCol(int x) {
  if (x > 0)
    return (x - 1) % 3;
  else
    return 1;
}

bool LessEq(int x, int y) {
  return GetRow(x) <= GetRow(y) && GetCol(x) <= GetCol(y);
}

bool IsOk(int sec) {
  assert(0 < sec && sec <= 200);
  if (sec < 10)
    return true;
  else
    return LessEq((sec / 10) % 10, sec % 10);
}

int main() {
  int Z;
  cin >> Z;
  while (Z--) {
    int sec;
    cin >> sec;
    int delta = 0;
    while (true) {
      if (IsOk(sec + delta)) {
        cout << sec + delta << endl;
        break;
      }
      if (IsOk(sec - delta)) {
        cout << sec - delta << endl;
        break;
      }
      ++delta;
    }
  }
}
