// Author: Adam Polak
#include <cstdlib>
#include <fstream>
#include <iostream>
using namespace std;

int GetRow(int x) {
  if (x > 0)
    return (x - 1) / 3;
  else
    return 3;
}

int GetCol(int x) {
  if (x > 0)
    return (x - 1) % 3;
  else
    return 1;
}

bool LessEq(int x, int y) {
  return GetRow(x) <= GetRow(y) && GetCol(x) <= GetCol(y);
}

bool IsOk(int sec) {
  if (sec < 10)
    return true;
  else
    return LessEq((sec / 10) % 10, sec % 10);
}

int main(int argc, char **argv) {
  ifstream in(argv[1]);
  ifstream hint(argv[2]);
  ifstream out(argv[3]);
  int Z;
  in >> Z;
  while (Z--) {
    int n_in, n_hint, n_out;
    in >> n_in;
    hint >> n_hint;
    out >> n_out;
    if (abs(n_hint - n_in) != abs(n_out - n_in)) {
      cerr << n_out << " is not optimal for " << n_in << ", " << n_hint << " is optimal" << endl;
      exit(1);
    }
    if (!IsOk(n_out)) {
      cerr << n_out << " is not valid choice" << endl;
      exit(1);
    }
  }
  cout << "OK" << endl;
  exit(0);
}
