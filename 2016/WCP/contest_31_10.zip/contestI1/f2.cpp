// SWERC 2014, Problem Book Club
// Approach: Bipartite maximum matching using fold fulkerson algorithm.
// Author: Miguel Oliveira
#include <stdio.h>
#include <string.h>
const int MAXV = 2 * 10000 + 10;
const int MAXE = 4 * 20000 + 20;

// Using an edge list representation of the graph because a matrix NxN is too large.
int to[MAXE], cap[MAXE], next[MAXE], head[MAXV], ne = 2;
char visited[MAXV];

inline void AddEdge(int a, int b) {
  to[ne] = b; cap[ne] = 1; next[ne] = head[a]; head[a] = ne++;
  to[ne] = a; cap[ne] = 0; next[ne] = head[b]; head[b] = ne++;
}
int Dfs(int cur, int sink) {
  visited[cur] = 1;
  if (cur == sink)
    return 1;
  for (int e = head[cur]; e > 0; e = next[e]) {
    if (!visited[to[e]]) {
      int x = cap[e];
      if (x > 0 && Dfs(to[e], sink)) {
        --cap[e];
        ++cap[e^1];
        return 1;
      }
    }
  }
  return 0;
}
int MaxFlow(int source, int sink) {
  int flow = 0, inc;
  do {
    memset(visited, 0, sizeof visited);
    inc = Dfs(source, sink);
    flow += inc;
  } while (inc);
  return flow;
}
int main() {
  int m, i, a, b, source, sink, n;
  scanf("%d %d", &n, &m);
  for (i = 0; i < m; i++) {
    scanf("%d %d", &a, &b);
    AddEdge(a, b+n);
  }
  source = n+n, sink = n+n+1;
  for (i = 0; i < n; i++) {
    AddEdge(source, i);
    AddEdge(i+n, sink);
  }
  if (MaxFlow(source, sink) == n)   puts("YES");
  else                              puts("NO");
  return 0;
}
