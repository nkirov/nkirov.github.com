#include <bits/stdc++.h>

using namespace std;

struct point{int x, v;};
point Arr[200020];

bool cmp(const point &a, const point &b)
{
    if(a.x < b.x) return true;
    if(a.x > b.x) return false;
    if(a.v < b.v) return true;
    return false;
}

int main()
{
    cin.sync_with_stdio(0);
    cin.tie(0);
    
    int T; cin >> T;
    
    while(T--) {
        int N; cin >> N;
        N=N*2;
        
        for(int i=0;i<N;i+=2) {
            cin >> Arr[i].x; Arr[i].v=1;
            cin >> Arr[i+1].x; Arr[i+1].v=-1;
        }
        
        sort(Arr,Arr+N,cmp);
        
        int Max=0;
        int Cur=0;
        
        for(int i=0;i<N;i++) {
            Cur+=Arr[i].v;
            Max=max(Max,Cur);
        }
        
        cout << Max << " ";
        
        Cur=0;
        int Ans=0;
        int last = Arr[0].x-1;
        
        for(int i=0;i<N;i++) {
            Cur+=Arr[i].v;
            
            if(Cur==Max) {
                Ans += Arr[i+1].x - Arr[i].x + 1;
                if(Arr[i].x == last) Ans--;
                
                last = Arr[i+1].x;
            }
        }
        
        cout << Ans << endl;
    }
    
    return 0;
}
