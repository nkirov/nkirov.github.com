//USACO 2016 US Open Contest, Gold, Problem 3. 248 - http://www.usaco.org/index.php?page=viewproblem2&cpid=647
//Analysis - http://www.usaco.org/current/data/sol_248_gold_open16.html

//USACO 2016 US Open Contest, Platinum, Problem 1. 262144 - http://www.usaco.org/index.php?page=viewproblem2&cpid=648
//Analysis - http://www.usaco.org/current/data/sol_262144_platinum_open16.html

#include <iostream>
using namespace std;

int n, tc;

#define MAX 250

int list[MAX];
int dp[MAX][MAX];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin>>tc;
    while(tc--)
    {
        cin>>n;
        for(int i = 0;i < n;i++)
            cin>>list[i];
        
        int ans=-312311232;
        
        for(int len=1;len<=n;len++) {
            for(int i=0;i<=n-len;i++) {
                int j = i+len-1;
                
                dp[i][j]=-1;
                if(len==1)
                    dp[i][j] = list[i];
                
                for(int k=i;k<j;k++) {
                    if(dp[i][k]==dp[k+1][j] && dp[i][k]>0)
                        dp[i][j] = max(dp[i][j],dp[i][k]+1);
                }
                
                ans = max(ans,dp[i][j]);
            }
        }
        
        cout << ans << endl;
    
/*
         int ret = 0;
         for(int len = 1; len <= n; len++)
         {
         for(int i = 0; i + len <= n; i++)
         {
         int j = i + len - 1;
         dp[i][j] = -1;
         if(len == 1)
         dp[i][j] = list[i];
         
         for(int k = i; k < j; k++)
         if(dp[i][k] == dp[k+1][j] && dp[i][k] > 0)
         dp[i][j] = max(dp[i][j], dp[i][k] + 1);
         
         ret = max(ret, dp[i][j]);
         }
         }
         
         cout<<ret<<endl;
*/
    }
    
    return 0;
}
