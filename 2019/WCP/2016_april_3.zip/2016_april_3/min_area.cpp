#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

typedef pair<int,int> pii;

int main() {
    cin.sync_with_stdio(0); cin.tie(0);
    
    int T;
    cin >> T;
    
    while(T--) {
        int N; cin >> N;
        vector<pii> Vec(N), VecRev(N);
        for(int i=0;i<N;i++) {
            int x, y;
            cin >> x >> y;
            
            Vec[i].first=VecRev[i].second=x;
            Vec[i].second=VecRev[i].first=y;
        }
        
        sort(Vec.begin(),Vec.end());
        sort(VecRev.begin(),VecRev.end());
        
        int ans = (Vec[N-1].first-Vec[0].first) * (VecRev[N-1].first-VecRev[0].first);
        
        // remove point with minX
        ans = min(ans,
                  (Vec[N-1].first - Vec[1].first) *
                  (
                   (Vec[0].second==VecRev[N-1].first ? VecRev[N-2].first : VecRev[N-1].first) -
                   (Vec[0].second==VecRev[0].first ? VecRev[1].first : VecRev[0].first))
                  );
        // remove point with maxX
        ans = min(ans,
                  (Vec[N-2].first - Vec[0].first) *
                  (
                   (Vec[N-1].second==VecRev[N-1].first ? VecRev[N-2].first : VecRev[N-1].first) -
                   (Vec[N-1].second==VecRev[0].first ? VecRev[1].first : VecRev[0].first))
                  );
        // remove point with minY
        ans = min(ans,
                  (VecRev[N-1].first - VecRev[1].first) *
                  (
                   (VecRev[0].second==Vec[N-1].first ? Vec[N-2].first : Vec[N-1].first) -
                   (VecRev[0].second==Vec[0].first ? Vec[1].first : Vec[0].first))
                  );
        // remove point with maxY
        ans = min(ans,
                  (VecRev[N-2].first - VecRev[0].first) *
                  (
                   (VecRev[0].second==Vec[N-1].first ? Vec[N-2].first : Vec[N-1].first) -
                   (VecRev[0].second==Vec[0].first ? Vec[1].first : Vec[0].first))
                  );
        
        
        cout << ans << endl;
    }
    
    return 0;
}

