#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int T; cin >> T;
    
    while(T--) {
        vector<int> Vec(10);
        vector<int> Ans(5);
        int sum=0;
        
        for(int i=0;i<10;i++) {
            cin >> Vec[i];
            sum+=Vec[i];
        }
        sort(Vec.begin(),Vec.end());
        
        if(sum%4!=0) { cout << "IMPOSSIBLE" << endl; continue;}
        sum/=4;
        
        Ans[2]=sum-Vec[0]-Vec[9];
        if(Ans[2]==0) { cout << "IMPOSSIBLE" << endl; continue;}
        Ans[0]=Vec[1]-Ans[2];
        if(Ans[0]==0) { cout << "IMPOSSIBLE" << endl; continue;}
        Ans[1]=Vec[0]-Ans[0];
        if(Ans[1]==0) { cout << "IMPOSSIBLE" << endl; continue;}
        Ans[4]=Vec[8]-Ans[2];
        if(Ans[4]==0) { cout << "IMPOSSIBLE" << endl; continue;}
        Ans[3]=Vec[9]-Ans[4];
        if(Ans[3]==0) { cout << "IMPOSSIBLE" << endl; continue;}
        
        for(int i=4;i>=0;i--) {
            if(i<4) cout << " ";
            cout << Ans[i];
        }
        cout << endl;
    }
    
    return 0;
}
