//RSOP 2013
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <set>
using namespace std;
int T, N, M, L, K;

struct Rational {
    int a, b;
    Rational(int _a, int _b) {
        a = _a;
        b = _b;
        int gcd = __gcd(_a, _b);
        a /= gcd;
        b /= gcd;
    }
    
    
    friend Rational operator+ (Rational l, Rational r);
    friend Rational operator- (Rational l, Rational r);
    friend Rational operator* (Rational l, Rational r);
    friend Rational operator/ (Rational l, Rational r);
};

Rational operator+ (Rational l, Rational r) {
    return Rational(l.a * r.b + l.b * r.a, l.b * r.b);
}

Rational operator- (Rational l, Rational r) {
    return Rational(l.a * r.b - l.b * r.a, l.b * r.b);
}

Rational operator* (Rational l, Rational r) {
    return Rational(l.a * r.a, l.b * r.b);
}

Rational operator/ (Rational l, Rational r) {
    return Rational(l.a * r.b, l.b * r.a);
}

int main() {
    //    freopen("RPG.in", "rt", stdin);
    //    freopen("RPG.out", "wt", stdout);
    
    scanf("%d", &T);
    for(int i = 0; i < T; i++) {
        scanf("%d %d %d %d", &N, &L, &M, &K);
        
        set <int> s1, s2;
        for (int j = 0, t; j < L; j++)
            scanf("%d", &t), s1.insert(t);
        for (int j = 0, t; j < K; j++)
            scanf("%d", &t), s2.insert(t);
        L = (int)s1.size(), K = (int)s2.size();
        
        /*if(L == 0 && K == 0) {
         printf("NO SOLUTION\n");
         continue;
         }*/
        
        if(L == 0) {
            printf("0/1\n");
            continue;
        }
        
        if(K == 0) {
            printf("1/1\n");
            continue;
        }
        
        Rational answer = Rational(L, N) * Rational(M * N, (M * N) - ((M - K) * (N - L)));
        printf("%d/%d\n", answer.a, answer.b);
    }
    return 0;
}
