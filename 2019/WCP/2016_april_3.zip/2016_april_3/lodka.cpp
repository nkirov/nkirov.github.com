// https://www.hackerrank.com/contests/april-2016-nbu-contest-3/challenges/challenge-422

#include <iostream>
#include <vector>

using namespace std;

int N,K;
vector<int> Mesta;

bool can(int minDist)
{
    int patetaCnt=1;
    int currentIndex=0;
    
    for(;patetaCnt<K;patetaCnt++)
    {
        int nextPlaceIdx=currentIndex+1;
        while(nextPlaceIdx<Mesta.size())
        {
            if(Mesta[nextPlaceIdx] - Mesta[currentIndex] >= minDist)
            {
                break;
            }
            nextPlaceIdx++;
        }
        
        if(nextPlaceIdx>=Mesta.size())
        {
            break;
        }
        
        currentIndex = nextPlaceIdx;
    }
    
    return patetaCnt==K;
}

int solve()
{
    int lo=Mesta[0];
    int hi=Mesta[N-1];
    int mid=(lo+hi)/2;
    
    while(lo<hi)
    {
        if(can(mid)) {
            lo = mid;
        } else {
            hi = mid-1;
        }
        
        mid=(lo+hi)/2 + 1;
    }
    
    return lo;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    
    int T;
    cin >> T;
    
    while(T--)
    {
        cin >> N >> K;
        Mesta.resize(N);
        
        for(int i=0;i<N;i++)
        {
            cin >> Mesta[i];
        }
        
        cout << solve() << endl;
    }
    
    
    return 0;
}

