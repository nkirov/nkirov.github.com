#include <iostream>
using namespace std;

int main()
{  int pennies = 1;
   int nickels = 12;
   int dimes = 4;
   int quarters = 120;
   
   cout <<  pennies << " "
        <<  pennies * 0.01 << "\n";
   cout <<  nickles << " "
        <<  nickles * 0.05<< "\n";
   cout <<  dimes << " "
        <<  dimes * 0.1 << "\n";
   cout <<  quarters << " "
        <<  quarters * 0.25 << "\n"; 
   return 0;
}