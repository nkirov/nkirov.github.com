/*
 March 2020
 toto.cpp
 
 TOTO-2
 В играта Тото-2 се избират 6 числа от 49.
 Нека $a_1< a_2 < a_3 < a_4 < a_5 < a_6$ и $b_1< b_2 < b_3 < b_4 < b_5 < b_6$ са две комбинации, които означаваме с A и B, съответно.
 Казваме, че A < B, когато $a_j = b_j$, при $j<i$ и $a_i < b_i$, за някоя стойност на $i$ от 1 до 6.
 Да се напише програма, която по дадени две комбинации А и В, намира броя на комбинациите X, за които А < X < B.
 Вход
 За всеки тестов пример от първия ред на стандартния вход се въвеждат числата от комбинация А, а от втория ред – числата от комбинация B, като А < B. Числата във всяка комбинация са различни и са подредени по големина.
 Изход
 На стандартния изход за всеки тестов пример на отделен ред да се изведе търсения брой.
 
 ПРИМЕР
 Вход
 2 9 17 28 34 46
 2 9 17 30 32 45
 Изход
 328
*/
#include <iostream>
#include <algorithm>
using namespace std;

int comb(int n, int k)
{ if(k<0 || k>n) return 0;
    if(k > n-k) k = n-k;
    if(k==0) return 1;
    long c=n;
    for(int i=2; i<=k; i++)
        c = c * (n-i+1)/i;
    return c;
}

int num(int a[])
{ int r = 0;
    for(int i=1; i<=6; i++)
        for(int k=a[i-1]+1; k<a[i]; k++)
            r = r + comb(49-k,6-i);
    return r;
}

int a[7],b[7];

int main()
{
    while(cin >> a[1])
    {
    for(int i=2; i<=6; i++) cin >> a[i];
    for(int i=1; i<=6; i++) cin >> b[i];
    
    int numa = num(a);
    int numb = num(b);
    
    int ans=0;
    if(numa<numb) ans = numb-numa-1;
    
    cout << ans << endl;
    }
    return 0;
}

