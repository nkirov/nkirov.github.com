/*
  March 2020
 sea.cpp

Море
 В света има 46 страни (включително Боливия и Монголия, например), които са без излаз на море, т.е. нито една част от територията им не граничи с вода. Ако един монголец иска да стигне до вода, може да премине през Русия или Китай. Има страни, на които всички съседи са без излаз на море и за да се отиде на море оттам, трябва да се премине през няколко различни държави.
 
 Вашата задача е, по дадена карта (мрежа от квадратни клетки) да определите отдалечеността на всяка страна от водата, т.е. минималният брой страни, през които трябва да се премине, за да се отиде от тази страна до море. Движението от клетка в клетка е хоризонтално, вертикално или диагонално. Ако една държава се състои от „анклави“ (несвързани едно с друго парчета), тогава отдалечеността ѝ е равна на отдалечеността на най-близкия до вода анклав. Клетките представляващи море са запълнени с буквата 'W', а клетките, представящи държави – с някоя друга буква.
 
 Input Format
 Първият ред на стандартния вход ще съдържа броя на тестовите примери. Всеки от тях започва с размерите N и M на картата, 1 ≤ N, M ≤ 1000. Следват N реда с по M главни латински букви на всеки. Различните букви означават различни държави, а единствено буквата 'W' обозначава вода.
 
 Output Format
 За всеки тест програмата трябва да изведе на отделен ред на стандартния изход за всяка участваща държава идентифициращата я буква и отдалечеността ѝ. Държавите трябва да са подредени в лексикографски ред на означаващите ги букви. Извеждайте по един празен ред между всеки два последователни теста.
 
 Sample Input
 1
 7 10
 WWWWWCCDEW
 WWWWCCEEEW
 WTWWWCCCCW
 WWFFFFFFWW
 WWFAAAAFWW
 WWFABCAFFW
 WWFAAAAFWW
 
 Sample Output
 A 1
 B 2
 C 0
 D 1
 E 0
 F 0
 T 0
*/

#include <bits/stdc++.h>
using namespace std;

int main()
{
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    
    int t, n, m;
    cin >> t;
    while(t--)
    {
        cin >> n >> m;
        vector<string> M(n);
        for (int i = 0; i < n; ++i)
            cin >> M[i];
        
        vector<vector<bool> > visited(n, vector<bool>(m, false));
        vector<vector<int> > dist(n, vector<int>(m, 10000));
        deque<pair<int, int> > Q;
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < m; ++j)
            {
                if (M[i][j] == 'W')
                {
                    Q.push_back(make_pair(i, j));
                    dist[i][j] = -1;
                }
            }
        }
        
        while (Q.size() > 0)
        {
            int i, j;
            tie(i, j) = Q.front();
            Q.pop_front();
            if (visited[i][j])
                continue;
            visited[i][j] = true;
            
            char from = M[i][j];
            
            for (int di = -1; di <= 1; ++di)
                for (int dj = -1; dj <= 1; ++dj)
                    if (i+di >= 0 && i+di < n && j+dj >= 0 && j+dj < m)
                    {
                        char to = M[i+di][j+dj];
                        if (from == to)
                        {
                            dist[i+di][j+dj] = min(dist[i+di][j+dj], dist[i][j]);
                            Q.push_front(make_pair(i+di, j+dj));
                        }
                        else
                        {
                            dist[i+di][j+dj] = min(dist[i+di][j+dj], dist[i][j]+1);
                            Q.push_back(make_pair(i+di, j+dj));
                        }
                    }
        }
        
        int val[26];
        memset(val, 10000, sizeof val);
        
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < m; ++j)
                val[M[i][j]-'A'] = min(val[M[i][j]-'A'], dist[i][j]);
        
        for (int c = 0; c < 26; ++c)
            if (val[c] >= 0 && val[c] < 10000)
                cout << char('A' + c) << " " << val[c] << endl;
        
        if(t)
            cout<<endl;
    }
}
