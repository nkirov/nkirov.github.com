/*
March 2020
 tri.cpp
 
 Брой триъгълници
 Дадени са координатите  на  точки в двумерна декартова координатна система. Напишете програма, която намира броя на възможните триъгълници (с положителни лица), които могат да се образуват с дадените точки.
 
 Input Format
 За всеки тестов пример на първия ред от стандартния вход се въвежда стойност за . След това  реда съдържат координати на точки в двумерна декартова координатна система. Всяка точка е на отделен ред и координатите са разделени с интервал.
 
 Constraints
 Координатите на всички точки са цели числа и са по-малки или равни на 100.
 
 Output Format
 За всеки тестов пример на отделен ред на стандартния изход се извежда броя на възможните триъгълници с дадените точки.
 
 Sample Input 0
 4
 0 0
 1 1
 2 0
 2 2
 
 Sample Output 0
 3
*/

#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


struct Point
{
    int x, y;
};

bool determinantValue(int x1, int y1, int x2, int y2, int x3, int y3)
{
    if((x1*(y2 - y3) - y1*(x2 - x3) + 1*(x2*y3 - y2*x3)) != 0)
        return true;
    else
        return false;
}

int countPoints(Point arr[], int n)
{
    int result = 0;
    
    for (int i=0; i<n; i++)
    {
        for (int j=i+1; j<n; j++)
        {
            for (int k=j+1; k<n; k++)
            {
                if (determinantValue(arr[i].x, arr[i].y, arr[j].x, arr[j].y, arr[k].x, arr[k].y))
                    result++;
            }
        }
    }
    return result;
}

int main()
{
    int n;
    while(cin>>n){
        Point arr[n];
        for(int i = 0; i < n; i++)
        {
            cin>>arr[i].x>>arr[i].y;
        }
        cout << countPoints(arr, n)<<endl;
    }
    return 0;
}

