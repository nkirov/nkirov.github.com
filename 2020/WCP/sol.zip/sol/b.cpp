/*
 cont_1
 b.cpp
 26 октомври 2019
*/
#include <iostream>
#include <vector>
using namespace std;

#define ll long long

int res = 0;
void f(vector<int> &v, vector<int> &used, int curr_ind)
{
    if(curr_ind < v.size())
    {
        used[curr_ind] = 1;

        f(v,used, curr_ind + 1);
        used[curr_ind] = 0;
        f(v, used, curr_ind+1);
    }
    else
    {
        int sum = 0;
        for(int i = 0; i<used.size(); ++i)
        {
            if(used[i])
            {
                sum += v[i];
            }
        }
        if (sum == 0)
        {
            res++;
        }
    }
}

int main()
{
    int t;
    cin >> t;
    for (int k = 0; k < t; ++k)
    {
        res = 0;
        int n;
        cin >> n;
        vector<int> v;
        vector<int> used (n ,0);
        
        for (int i =0; i<n; i++)
        {
            int x;
            cin >> x;
            v.push_back(x);
        }
        f(v, used, 0 );
        cout << res -1 << endl;
    }
    return 0;
}
