/*
 cont_1
 d.cpp (2.cpp)
 26 октомври 2019
 
*/
#include <iostream>
#include <string>
using namespace std;

int main()
{
    int alpha[30];
    string s;
    while(cin >> s)
    {
        for(int j = 0; j < 30; j++) alpha[j] = 0;
        for(int i = 0; i < s.length(); i++)
        {
            int si = s[i] - 'a';
            alpha[si]++;
        }
        int i = s.length() - 1;
        do
        {
            if(alpha[s[i] - 'a'] > 1)
            {
                alpha[s[i] - 'a']--;
                s.erase(i,1);
            }
            i--;
//            cout << i << ' ' << s << endl;
        }
        while (i > 0);
        cout << s << endl;
    }
    return 0;
}
