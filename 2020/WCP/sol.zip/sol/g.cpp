/*
cont_1
g.cpp
26 октомври 2019
 
*/
 #include <cstdio>
 #include <cmath>
 #include <vector>
 #include <queue>
 #include <memory.h>
 
 #define MAXN 100005
 #define MAXP 18
 using namespace std;

 vector< vector<int> > tree;
 bool visited[MAXN];
 int parents[MAXN][MAXP];
 int level[MAXN];
 int lg;
 
 void bfs(int start)
 {
 queue<int> q;
 q.push(start);
 visited[start] = true;
 for(int i = 0; i <= lg; i++)
 parents[start][i] = -1;
 
 int current, child;
 while(!q.empty())
 {
 current = q.front(); q.pop();
 for(int i = 0; i < tree[current].size(); ++i)
 {
 child = tree[current][i];
 
 if(visited[child])
 continue;
 
 level[child] = 1 + level[current];
 
 for(int i = 0; i <= lg; i++)
 {
 if(level[current] % ( 1 << i ) == 0)
 parents[child][i] = current;
 else
 parents[child][i] = parents[current][i];
 }
 q.push(child);

 visited[child] = true;
 }
 }
 }

 int lift(int u, int v)
 {
 int ancestor, candidate;
 for(int i = lg; i >= 0; i--)
 {
 candidate = parents[u][i];
 if(level[candidate] == level[v])
 {
 ancestor = candidate;
 break;
 }
 else if(level[candidate] > level[v])
 {
 u = candidate;
 }
 }
 return ancestor;
 }
 
 int lca(int u, int v)
 {

 if(level[u] > level[v])
 u = lift(u, v);
 else if(level[v] > level[u])
 v = lift(v, u);
 
 if(u == v)
 return u;
 
 for(int i = lg; i >= 0; i--)
 {
 if(parents[u][i] != parents[v][i])
 {
 u = parents[u][i];
 v = parents[v][i];
 }
 }
 return parents[u][0];
 }
 
 int main()
 {
 int N, M;
 while(scanf("%d", &N) == 1 && N != -1)
 {
 scanf("%d", &M);
 
 memset(visited, 0, sizeof(visited));
 tree = vector< vector< int > >(N + 1);
 
 int v;
 for(int u = 1; u <= N; u++)
 {
 scanf("%d", &v);
 tree[u].push_back(v);
 tree[v].push_back(u);
 }
 
 lg = 0;
 int p2 = 1;
 while(p2 * 2 < N) { lg++; p2 *= 2; }
 bfs(0);
 
 int x, y;
 for(int q = 0; q < M; q++)
 {
 scanf("%d%d", &x, &y);
 printf("%d\n", lca(x, y));
 }
 }
 }

