/*
 cont_1
 c.cpp (1.cpp)
 26 октомври 2019
*/
#include <iostream>
#include <string>
#define MAX 1000
using namespace std;

int main()
{
    int n;
    while(cin >> n)
    {
        int i1, i2, i3;
        cin >> i1 >> i2 >> i3;
        int sum = i1 + i2 + i3;
        for(int i = 3; i < n; i++)
        {
            i1 = i2;
            i2 = i3;
            cin >> i3;
            if (sum < i1 + i2 + i3) sum = i1 + i2 + i3;
        }
        cout << sum << endl;
    }
    return 0;
}
