/*
 a.cpp
 26 октомври 2019
*/
#include <iostream>
#include <string>
#define MAX 1000
using namespace std;

string div2(string a)
{
    string res;
    int pre = 0;
    int i = 0, del = 0;
    if (a[0] - '0' == 1) { pre = 1; i++; }
    while ( i < a.length())
    {
        if (pre == 1) { del = 10; }
        else del = 0;
        del += a[i] - '0';
  //      cout << "del = " << del << "  ";
        if (del%2) pre = 1;
        else pre = 0;
        res += char('0' + del/2); i++;
    }
    return res;
}

int main()
{
    string s;
    while(cin >> s)
    {
        int ones = 0;
        while (s.length() > 0)
        {
            if ((s[s.length() - 1] - '0')%2) ones++;
            s = div2(s);
        }
        cout << ones << endl;
    }
    return 0;
}
