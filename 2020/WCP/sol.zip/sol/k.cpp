/*
 cont_1
 k.cpp
 26 октомври 2019

 */
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#define ll long long
#define MAXN 100002

using namespace std;
int primes[MAXN];
vector<ll> primeNums;
void generatePrimes(){
    memset(primes, 0 , sizeof(primes));
    for(int i = 2; i < MAXN; i++) {
        if(primes[i] == 0){
            primeNums.push_back(i);
            for(ll j = 1ll*i*i; j < MAXN; j+=i){
                primes[j] = 1;
            }
        }
    }
}
void solve(ll n){
    ll f;
    ll s;
    for(int i = 0; i < primeNums.size(); i++){
        if(n%primeNums[i] == 0){
            f = primeNums[i];
            s = n/primeNums[i];
            break;
        }
    }
    cout << f << " " << s << endl;
}

int main()
{
    //freopen("a.txt", "r", stdin);
    ios_base::sync_with_stdio(false);
    generatePrimes();
    ll n;
    while(cin>>n){
        solve(n);
    }
    return 0;
}
