/*
 cont_1
 f.cpp
 26 октомври 2019
 
*/
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

int main() {
    cin.sync_with_stdio(false);
    cin.tie(0);
    int n,m;
    while(cin >> n >> m) {
        char c;
        int ANS=1000000;
        
        for(int i=0;i<n;i++) {
            for(int j=0;j<m;j++) {
                cin >> c;
                if(c=='*') {
                    ANS=min(ANS,min(i,j)+1);
                    ANS=min(ANS,min(n-i,m-j));
                }
            }
        }
        if(ANS==1000000) printf("-1\n");
        else printf("%d\n",ANS);
    }
    return 0;
}
