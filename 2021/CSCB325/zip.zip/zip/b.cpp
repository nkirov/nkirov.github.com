
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

long long a[30];

string s;
long long n;

void Solve() {
    memset(a, 0, sizeof(a));
    for(int i = 0; i < s.size(); i++) a[s[i] - 'a']++;
    sort(a, a + 26);
    long long cnt = 0;
    for(int i = 25; i > 0; i--) {
        if(cnt < n) a[i - 1] += a[i], a[i] = 0, cnt++;
    }
    long long ans = 0;
    for(int i = 0; i < 26; i++) ans += a[i] * a[i];
    cout << ans << endl;
}

int main() {
    while(cin >> s >> n) Solve();
}
