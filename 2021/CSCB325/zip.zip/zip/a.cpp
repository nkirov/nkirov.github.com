
#include <iostream>
#define MAXH 100
#define MAXX 100
using namespace std;

int it[MAXX][2*MAXX][MAXH];

int xm, ym, h;

void print()
{
    for (int z = 0; z <= h+1; z++)
    {
        for (int y = 0; y < 2*MAXX; y++)
        {
            for(int x = 0; x <= xm; x++) cout << it[x][y][z] << " ";
            cout << endl;
        }
        cout << "--" << endl;
    }
}

int main()
{
    while(cin >> xm >> ym >> h)
    {
        for(int x = 0; x <= xm + 1; x++)
            for (int y = 0; y < 2*MAXX; y++)
                for (int z = 0; z <= h + 1; z++) it[x][y][z] = 0;
        it[1][MAXX][1] = 1;
        for(int x = 2; x < xm; x++)
            for (int y = -MAXX; y < MAXX; y++)
                for (int z = 1; z <= h; z++)
        {
            int y0 = y + MAXX;
            it[x][y0][z] = it[x-1][y0][z] + it[x-1][y0-1][z] + it[x-1][y0+1][z]
                + it[x-1][y0][z-1] + it[x-1][y0-1][z-1] + it[x-1][y0+1][z-1]
                + it[x-1][y0][z+1] + it[x-1][y0-1][z+1] + it[x-1][y0+1][z+1];
        }
   //     print();
        cout << it[xm - 1][ym + MAXX][1] << endl;
    }
  return 0;   
}
