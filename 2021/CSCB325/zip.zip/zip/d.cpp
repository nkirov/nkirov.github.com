
// Златко Донев
#include <bits/stdc++.h>

using namespace std;

int arr[110][110];
int dp[110][110];

int main()
{
    int T;
    cin >> T;
    while(T--) {
        int n;
        cin >> n;
        for(int i=1;i<=n;i++) {
            for(int j=1;j<=n;j++) {
                cin >> arr[i][j];
                
                dp[i][j] = max(dp[i-1][j], dp[i][j-1]) + arr[i][j];
            }
        }
        
        cout << dp[n][n] << endl;
    }
    return 0;
}
