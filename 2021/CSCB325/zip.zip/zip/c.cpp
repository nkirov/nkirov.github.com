
#include <iostream>
#include <queue>
#define MAXX 1000000
using namespace std;

int m, n, k, maxx, sum;
queue<int> q;

void solve()
{
    while (cin >> m >> n)
    {
        sum = 0;
        while(!q.empty()) q.pop();
        for(int i = 0; i < m; i++)
        {
            cin >> k; q.push(k); sum += k;
        }
        maxx = sum;
        for(int i = m; i < n; i++)
        {
            cin >> k; q.push(k); sum += k;
            sum -= q.front(); q.pop();
            if (sum > maxx) maxx = sum;
         //   cout << "sum=" << sum << endl;
        }
        cout << maxx << endl;
    }
}

void slow()
{
    int a[MAXX];
    while (cin >> m >> n)
    {
        for(int i = 0; i < n; i++) cin >> a[i];
        for(int i = 0; i < n - m + 1; i++)
        {
            sum = 0;
            for(int j = i; j < i + m; j++) sum += a[j];
     //       cout << "sum=" << sum << endl;
            if (i == 0) maxx = sum;
            else if (sum > maxx) maxx = sum;
        }
        cout << maxx << endl;
                
    }
}

int main(void)
{
  solve();
 //   slow();
    return 0;
}
