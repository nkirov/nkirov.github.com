// Fig. 9.10: cylindr2.h
// Definition of class Cylinder
#ifndef CYLINDR2_H
#define CYLINDR2_H

#include "circle2.h"

class Cylinder : public Circle {
   friend ostream &operator<<( ostream &, const Cylinder & );

public:
   // default constructor
   Cylinder( double h = 0.0, double r = 0.0,
             int x = 0, int y = 0 );

   void setHeight( double );   // set height
   double getHeight() const;   // return height
   double area() const;        // calculate and return area
   double volume() const;      // calculate and return volume

protected:
   double height;              // height of the Cylinder
};

#endif

