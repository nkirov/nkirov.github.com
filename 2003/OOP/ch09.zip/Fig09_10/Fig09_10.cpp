// Fig. 9.10: fig09_10.cpp
// Driver for class Cylinder
#include <iostream.h>
#include <iomanip.h>
#include "point2.h"
#include "circle2.h"
#include "cylindr2.h"

int main()
{
   // create Cylinder object
   Cylinder cyl( 5.7, 2.5, 12, 23 );

   // use get functions to display the Cylinder
   cout << "X coordinate is " << cyl.getX()
        << "\nY coordinate is " << cyl.getY()
        << "\nRadius is " << cyl.getRadius()
        << "\nHeight is " << cyl.getHeight() << "\n\n";

   // use set functions to change the Cylinder's attributes
   cyl.setHeight( 10 );
   cyl.setRadius( 4.25 );
   cyl.setPoint( 2, 2 );
   cout << "The new location, radius, and height of cyl are:\n"
        << cyl << '\n';

   // display the Cylinder as a Point
   Point &pRef = cyl;   // pRef "thinks" it is a Point
   cout << "\nCylinder printed as a Point is: " 
        << pRef << "\n\n";
   
   // display the Cylinder as a Circle
   Circle &circleRef = cyl;  // circleRef thinks it is a Circle
   cout << "Cylinder printed as a Circle is:\n" << circleRef
        << "\nArea: " << circleRef.area() << endl;

   return 0;
}


