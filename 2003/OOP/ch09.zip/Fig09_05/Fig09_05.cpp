// Fig. 9.5: fig.09_05.cpp
// Overriding a base-class member function in a 
// derived class.
#include <iostream.h>
#include "hourly.h"

int main()
{
   HourlyWorker h( "Bob", "Smith", 40.0, 10.00 );
   h.print();
   return 0;
}

