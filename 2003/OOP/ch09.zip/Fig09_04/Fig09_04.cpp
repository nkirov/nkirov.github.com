// Fig. 9.4: fig09_04.cpp
// Casting base-class pointers to derived-class pointers
#include <iostream.h>
#include <iomanip.h>
#include "point.h"
#include "circle.h"

int main()
{
   Point *pointPtr = 0, p( 30, 50 );
   Circle *circlePtr = 0, c( 2.7, 120, 89 );

   cout << "Point p: " << p << "\nCircle c: " << c << '\n';

   // Treat a Circle as a Point (see only the base class part)
   pointPtr = &c;   // assign address of Circle to pointPtr
   cout << "\nCircle c (via *pointPtr): " 
        << *pointPtr << '\n';

   // Treat a Circle as a Circle (with some casting)
   pointPtr = &c;   // assign address of Circle to pointPtr

   // cast base-class pointer to derived-class pointer
   circlePtr = static_cast< Circle * >( pointPtr );  
   cout << "\nCircle c (via *circlePtr):\n" << *circlePtr 
        << "\nArea of c (via circlePtr): "
        << circlePtr->area() << '\n';

   // DANGEROUS: Treat a Point as a Circle
   pointPtr = &p;   // assign address of Point to pointPtr
   
   // cast base-class pointer to derived-class pointer
   circlePtr = static_cast< Circle * >( pointPtr );
   cout << "\nPoint p (via *circlePtr):\n" << *circlePtr
        << "\nArea of object circlePtr points to: "
        << circlePtr->area() << endl;
   return 0;
}

