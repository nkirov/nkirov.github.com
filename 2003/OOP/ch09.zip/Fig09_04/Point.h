// Fig. 9.4: point.h
// Definition of class Point
#ifndef POINT_H
#define POINT_H

class Point {
   friend ostream &operator<<( ostream &, const Point & );
public:
   Point( int = 0, int = 0 );      // default constructor
   void setPoint( int, int );      // set coordinates
   int getX() const { return x; }  // get x coordinate
   int getY() const { return y; }  // get y coordinate
protected:         // accessible by derived classes
   int x, y;       // x and y coordinates of the Point
};

#endif

