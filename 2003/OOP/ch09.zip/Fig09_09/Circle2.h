// Fig. 9.9: circle2.h
// Definition of class Circle
#ifndef CIRCLE2_H
#define CIRCLE2_H

#include "point2.h"

class Circle : public Point {
   friend ostream &operator<<( ostream &, const Circle & );
public:
   // default constructor
   Circle( double r = 0.0, int x = 0, int y = 0 );
   void setRadius( double );    // set radius
   double getRadius() const;    // return radius
   double area() const;         // calculate area
protected:          // accessible to derived classes
   double radius;   // radius of the Circle
};

#endif

