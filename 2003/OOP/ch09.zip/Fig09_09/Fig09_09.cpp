// Fig. 9.9: fig09_09.cpp
// Driver for class Circle
#include <iostream.h>
#include "point2.h"
#include "circle2.h"

int main()
{
   Circle c( 2.5, 37, 43 );

   cout << "X coordinate is " << c.getX()
        << "\nY coordinate is " << c.getY()
        << "\nRadius is " << c.getRadius();

   c.setRadius( 4.25 );
   c.setPoint( 2, 2 );
   cout << "\n\nThe new location and radius of c are\n"
        << c << "\nArea " << c.area() << '\n';

   Point &pRef = c;
   cout << "\nCircle printed as a Point is: " << pRef << endl;

   return 0;
}

