// Fig. 9.7: point2.h
// Definition of class Point
#ifndef POINT2_H
#define POINT2_H

class Point {
public:
   Point( int = 0, int = 0 );  // default constructor
   ~Point();    // destructor
protected:      // accessible by derived classes
   int x, y;    // x and y coordinates of Point
};

#endif

