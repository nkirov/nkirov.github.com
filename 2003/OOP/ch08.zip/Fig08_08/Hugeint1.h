// Fig. 8.8: hugeint1.h 
// Definition of the HugeInt class
#ifndef HUGEINT1_H
#define HUGEINT1_H

#include <iostream.h>

class HugeInt {
   friend ostream &operator<<( ostream &, HugeInt & );
public:
   HugeInt( long = 0 );       // conversion/default constructor
   HugeInt( const char * );           // conversion constructor
   HugeInt operator+( HugeInt & );    // add another HugeInt
   HugeInt operator+( int );          // add an int
   HugeInt operator+( const char * ); // add an int in a char *
private:
   short integer[30];
};

#endif

