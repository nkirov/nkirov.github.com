// Fig. 7.10: interface.cpp
// Definition of class Interface
#include "interface.h"
#include "implementation.h"

Interface::Interface( int v ) 
   : ptr ( new Implementation( v ) ) { }

// call Implementation's setValue function
void Interface::setValue( int v ) { ptr->setValue( v ); }

// call Implementation's getValue function
int Interface::getValue() const { return ptr->getValue(); }
