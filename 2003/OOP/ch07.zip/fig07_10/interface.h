// Fig. 7.10: interface.h
// Header file for interface.cpp
class Implementation;   // forward class declaration

class Interface {
   public:
      Interface( int );
      void setValue( int );  // same public interface as
      int getValue() const;  // class Implementation
   private:
      Implementation *ptr;   // requires previous 
                             // forward declaration
};
