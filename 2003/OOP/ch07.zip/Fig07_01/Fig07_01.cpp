// Fig. 7.1: fig07_01.cpp
// Attempting to access a const object with
// non-const member functions.
#include <iostream.h>
#include "time5.h"

int main()
{
   Time wakeUp( 6, 45, 0 );       // non-constant object
   const Time noon( 12, 0, 0 );   // constant object

                          // MEMBER FUNCTION   OBJECT
   wakeUp.setHour( 18 );  // non-const         non-const

   noon.setHour( 12 );    // non-const         const

   wakeUp.getHour();      // const             non-const

   noon.getMinute();      // const             const
   noon.printMilitary();  // const             const
   noon.printStandard();  // non-const         const
   return 0;
}


