// Fig. 7.7: fig07_07.cpp  
// Using the this pointer to refer to object members.
#include <iostream.h>

class Test {
public:
   Test( int = 0 );             // default constructor
   void print() const;
private:
   int x;
};

Test::Test( int a ) { x = a; }  // constructor

void Test::print() const   // ( ) around *this required
{
   cout << "        x = " << x
        << "\n  this->x = " << this->x
        << "\n(*this).x = " << ( *this ).x << endl;
}

int main()
{
   Test testObject( 12 );

   testObject.print();

   return 0;
}


