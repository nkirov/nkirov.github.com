// Fig. 13.5: fig13_05.cpp
// Demonstrating new throwing bad_alloc 
// when memory is not allocated
#include <iostream>
#include <new>

int main()
{
   double *ptr[ 10 ];
   
   try {   
      for ( int i = 0; i < 10; i++ ) {
         ptr[ i ] = new double[ 5000000 ];
         cout << "Allocated 5000000 doubles in ptr[ " 
              << i << " ]\n";
      }
   }
   catch ( bad_alloc exception ) {
      cout << "Exception occurred: " 
           << exception.what() << endl;
   }
   
   return 0;
}