// Fig. 13.2: fig13_02.cpp
// Demonstration of rethrowing an exception.
#include <iostream>
#include <exception>

using namespace std;

void throwException() throw ( exception )
{
   // Throw an exception and immediately catch it.
   try {
      cout << "Function throwException\n";
      throw exception();  // generate exception
   }
   catch( exception e )
   {
      cout << "Exception handled in function throwException\n";
      throw;  // rethrow exception for further processing
   }

   cout << "This also should not print\n";
}   

int main()
{
   try {
      throwException();
      cout << "This should not print\n";
   }
   catch ( exception e )
   {
      cout << "Exception handled in main\n";
   }

   cout << "Program control continues after catch in main" 
        << endl;
   return 0;
}

