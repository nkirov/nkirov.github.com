// Fig. 13.4: fig13_04.cpp
// Demonstrating new returning 0 
// when memory is not allocated
#include <iostream.h>

int main()
{
   double *ptr[ 10 ];

   for ( int i = 0; i < 10; i++ ) {
      ptr[ i ] = new double[ 5000000 ];

      if ( ptr[ i ] == 0 ) { // new failed to allocate memory
         cout << "Memory allocation failed for ptr[ " 
              << i << " ]\n";
         break;
      }
      else
         cout << "Allocated 5000000 doubles in ptr[ " 
              << i << " ]\n";    
   }

   return 0;
}