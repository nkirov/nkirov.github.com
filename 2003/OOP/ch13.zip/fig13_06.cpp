// Fig. 13.6: fig13_06.cpp
// Demonstrating set_new_handler
#include <iostream.h>
#include <new.h>
#include <stdlib.h>

void customNewHandler()
{ 
   cerr << "customNewHandler was called"; 
   abort();
}
   
int main()
{
   double *ptr[ 10 ];
   set_new_handler( customNewHandler );
   
   for ( int i = 0; i < 10; i++ ) {
      ptr[ i ] = new double[ 5000000 ];
      
      cout << "Allocated 5000000 doubles in ptr[ " 
           << i << " ]\n";
   }
   
   return 0;
}